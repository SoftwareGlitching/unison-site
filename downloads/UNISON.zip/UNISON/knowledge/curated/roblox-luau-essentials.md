# Roblox Luau essentials

## Where scripts live and where they run
- `ServerScriptService`: server `Script`s. Never replicated to clients, so secrets and game rules belong here.
- `ServerStorage`: server-only assets (maps, tools, NPC templates) cloned in by server code.
- `ReplicatedStorage`: shared `ModuleScript`s, `RemoteEvent`s/`RemoteFunction`s, assets both sides need.
- `StarterPlayer.StarterPlayerScripts`: `LocalScript`s that run once per player when they join.
- `StarterPlayer.StarterCharacterScripts`: scripts copied into each new character (re-run on respawn).
- `StarterGui`: `ScreenGui`s copied into `PlayerGui`; LocalScripts inside them run on the client.
- `Workspace`: the 3D world. `ReplicatedFirst`: loading screens (runs before anything else replicates).
- A `Script` with `RunContext = Client` can run on the client from anywhere; by default use the folders above.

## Client/server model
- The server is the authority. Anything a client changes locally (parts, values, GUI) does NOT replicate
  to the server, except physics of parts the client has network ownership of (its own character).
- Clients talk to the server only through remotes:
  - `RemoteEvent:FireServer(...)` → `RemoteEvent.OnServerEvent:Connect(function(player, ...) end)`
    (the server always receives the sending `player` first; the client cannot fake it).
  - `RemoteEvent:FireClient(player, ...)` / `:FireAllClients(...)` → `OnClientEvent` on the client.
  - `RemoteFunction:InvokeServer(...)` returns a value from `OnServerInvoke`. Avoid `InvokeClient`:
    a client can hang or error it forever.
  - `UnreliableRemoteEvent` for frequent cosmetic data (positions, effects) where losing a packet is fine.

## Remote security checklist (never trust the client)
1. Check argument types: `if typeof(itemId) ~= "string" then return end` (`typeof` also knows Roblox types
   like `"Vector3"`, `"Instance"`). Reject NaN numbers: `if n ~= n then return end`.
2. Look up everything on the server: prices, damage, cooldowns, ownership. Don't accept them as arguments.
3. Check distance/state: is the player alive, near the shop, owning the tool, past the cooldown?
4. Rate-limit per player (store `os.clock()` of the last accepted call in a table keyed by `player`).
5. Clean per-player tables on `Players.PlayerRemoving`.

```lua
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local BuyItem = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("BuyItem")
local PRICES = { Sword = 50, Shield = 75 }
local lastBuy: { [Player]: number } = {}

BuyItem.OnServerEvent:Connect(function(player: Player, itemId: unknown)
	if typeof(itemId) ~= "string" then return end
	local price = PRICES[itemId]
	if not price then return end
	local now = os.clock()
	if lastBuy[player] and now - lastBuy[player] < 0.5 then return end
	lastBuy[player] = now
	local coins = player:FindFirstChild("leaderstats") and player.leaderstats:FindFirstChild("Coins")
	if not coins or coins.Value < price then return end
	coins.Value -= price
	-- give the item here (clone from ServerStorage into player.Backpack)
end)

Players.PlayerRemoving:Connect(function(player) lastBuy[player] = nil end)
```

## ModuleScript pattern
```lua
-- ReplicatedStorage/Shared/Inventory.lua (ModuleScript)
local Inventory = {}
Inventory.__index = Inventory

function Inventory.new(capacity: number)
	return setmetatable({ items = {}, capacity = capacity }, Inventory)
end

function Inventory:Add(itemId: string, amount: number): boolean
	local count = 0
	for _ in pairs(self.items) do count += 1 end
	if not self.items[itemId] and count >= self.capacity then return false end
	self.items[itemId] = (self.items[itemId] or 0) + amount
	return true
end

return Inventory
```
- `require()` runs a module once per environment (once on the server, once per client) and caches the result.
- Avoid circular requires; pass dependencies in or split shared code into a third module.

## Modern APIs to prefer
- `task.wait(s)`, `task.spawn(fn)`, `task.delay(s, fn)`, `task.defer(fn)` instead of `wait`, `spawn`, `delay`.
- `Instance:GetAttribute/SetAttribute` for simple per-instance data; `CollectionService` tags
  (`CollectionService:GetTagged("Lava")`, `GetInstanceAddedSignal`) to give behaviour to many parts.
- `workspace:Raycast(origin, direction, params)` with `RaycastParams` (FilterDescendantsInstances, FilterType).
- `Players.PlayerAdded` plus a loop over `Players:GetPlayers()` so players who joined before the script ran are handled.
- `player.CharacterAdded:Connect(...)` and check `player.Character` for an existing character.
- `:WaitForChild(name, timeout)` on the client for anything that replicates in; on the server objects you
  created are already there.
- Compound operators (`+=`, `-=`), string interpolation `` `Hello {name}` ``, `continue` in loops,
  type annotations (`local n: number = 0`, `function f(x: string): boolean`), `--!strict` at the top.

## Common bugs
- `attempt to index nil with 'X'`: something wasn't loaded yet (use `WaitForChild`) or a lookup failed.
- Infinite yield warnings: `WaitForChild` on a name that never appears (typo, or object lives on the server only).
- Connections leaking: store `local conn = signal:Connect(...)` and `conn:Disconnect()` when done, or use `:Once`.
- `while true do` without `task.wait()` freezes the game.
- Changing things from a LocalScript and expecting other players to see it: must go through the server.
- Touched events fire many times per contact: add a debounce table keyed by the character/player.
