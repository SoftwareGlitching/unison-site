"""UNISON learns from 👍/👎 right away (no GPU training), stays within a GPU-safe context, and finds real Python."""
import os
import sys
import tempfile
import unittest
from pathlib import Path

from tests.helpers import IsolatedSettings  # noqa: I001
from backend.database.db import Database
from backend.training import lessons


class LessonTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self.tmp.name) / "t.db")
        lessons.reset_cache()

    def tearDown(self):
        lessons.reset_cache()
        self.tmp.cleanup()

    def chat(self, user, reply):
        cid = self.db.create_conversation("t")["id"]
        self.db.add_message(cid, "user", user)
        return self.db.add_message(cid, "assistant", reply, "m")["id"]

    def test_no_ratings_no_section(self):
        self.assertEqual(lessons.build(self.db), "")

    def test_thumbs_down_note_and_correction_become_lessons(self):
        mid = self.chat("your gay as fucc", "Ouch, that's pretty harsh. I try to be respectful...")
        self.db.set_feedback(mid, -1, correction="Rude. Accurate? Debatable. What do you need?", note="don't lecture me")
        text = lessons.build(self.db)
        self.assertIn("Lessons from the user's ratings", text)
        self.assertIn("don't lecture me", text)
        self.assertIn("Rude. Accurate? Debatable.", text)
        self.assertIn("your gay as fucc", text)

    def test_thumbs_up_becomes_style_example(self):
        mid = self.chat("hey", "Not much - living rent-free in your PC 😎")
        self.db.set_feedback(mid, 1)
        self.assertIn("rent-free", lessons.build(self.db))

    def test_bare_thumbs_down_is_ignored(self):
        mid = self.chat("x", "y")
        self.db.set_feedback(mid, -1)
        self.assertEqual(lessons.build(self.db), "")

    def test_lessons_reach_the_system_prompt(self):
        from backend.agents import prompts
        mid = self.chat("hi", "hello")
        self.db.set_feedback(mid, -1, note="be funnier")
        orig = lessons.section
        lessons.section = lambda db=None: lessons.build(self.db)
        try:
            with IsolatedSettings():
                self.assertIn("be funnier", prompts.base_prompt("m"))
                self.assertIn("be funnier", prompts.agent_prompt("m"))
        finally:
            lessons.section = orig


class GpuSafetyTests(unittest.TestCase):
    def test_context_is_capped(self):
        from backend.core.config import settings
        from backend.inference.manager import ModelManager
        with IsolatedSettings():
            settings.set("inference", "num_ctx", 16384)   # what crashed a 12 GB card
            m = ModelManager.__new__(ModelManager)
            self.assertEqual(m.default_options().num_ctx, 8192)
            self.assertEqual(m.default_options(num_ctx=32768).num_ctx, 8192)
            settings.set("inference", "max_ctx", 16384)
            self.assertEqual(m.default_options().num_ctx, 16384)


class RealPythonTests(unittest.TestCase):
    def test_real_python_goes_first_on_windows(self):
        from backend.tools import terminal
        orig = sys.platform
        try:
            terminal.sys.platform = "win32"
            env = terminal._command_env()
        finally:
            terminal.sys.platform = orig
        base = os.path.dirname(getattr(sys, "_base_executable", "") or sys.executable)
        self.assertTrue(env["PATH"].startswith(base))
        self.assertEqual(env["PYTHONUTF8"], "1")


if __name__ == "__main__":
    unittest.main()
