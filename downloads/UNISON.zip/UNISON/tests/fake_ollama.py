"""
Test double for the Ollama HTTP API, used ONLY by the automated tests so the backend's
streaming, persistence and error handling can be checked without a GPU or a real model.
The real application never uses this file.
"""
from __future__ import annotations

import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


def fake_embedding(text: str, dim: int = 1024) -> list[float]:
    """Deterministic bag-of-words vector so texts sharing words are similar."""
    import hashlib
    import re
    v = [0.0] * dim
    for w in re.findall(r"[a-z0-9]+", text.lower()):
        if w in ("search_query", "search_document", "file", "section"):
            continue
        v[int(hashlib.md5(w.encode()).hexdigest(), 16) % dim] += 1.0
    return v


class FakeOllama:
    def __init__(self, models=("test-model:1b", "nomic-embed-text:latest"), token_delay=0.0, responder=None,
                 no_tool_models=()):
        self.models = list(models)
        self.token_delay = token_delay
        self.responder = responder          # fn(request_body) -> {"content": str} | {"tool_calls": [...]}
        self.no_tool_models = set(no_tool_models)
        self.requests: list[dict] = []
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), self._handler())
        self.url = f"http://127.0.0.1:{self.server.server_address[1]}"
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)

    def __enter__(self):
        self.thread.start()
        return self

    def __exit__(self, *exc):
        self.server.shutdown()
        self.server.server_close()

    def _handler(self):
        fake = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _json(self, code, obj):
                body = json.dumps(obj).encode()
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_GET(self):
                if self.path == "/api/version":
                    return self._json(200, {"version": "0.0.0-test"})
                if self.path == "/api/tags":
                    return self._json(200, {"models": [
                        {"name": m, "size": 1_000_000, "modified_at": "2026-01-01",
                         "details": {"family": "test", "parameter_size": "1B", "quantization_level": "Q4_K_M"}}
                        for m in fake.models]})
                if self.path == "/api/ps":
                    return self._json(200, {"models": [{"name": fake.models[0], "size": 100, "size_vram": 75}]})
                self._json(404, {"error": "not found"})

            def do_POST(self):
                length = int(self.headers.get("Content-Length", 0))
                body = json.loads(self.rfile.read(length) or b"{}")
                fake.requests.append({"path": self.path, "body": body})
                if self.path == "/api/embed":
                    vecs = [fake_embedding(t) for t in body.get("input", [])]
                    return self._json(200, {"model": body.get("model"), "embeddings": vecs})
                if self.path == "/api/chat":
                    if body.get("model") not in fake.models:
                        return self._json(404, {"error": f"model '{body.get('model')}' not found"})
                    if body.get("tools") and body.get("model") in fake.no_tool_models:
                        return self._json(400, {"error": f"registry.ollama.ai/library/{body['model']} does not support tools"})
                    reply = fake.responder(body) if fake.responder else None
                    if reply and reply.get("tool_calls"):
                        self.send_response(200)
                        self.end_headers()
                        chunk = {"model": body["model"], "done": False,
                                 "message": {"role": "assistant", "content": reply.get("content", ""),
                                             "tool_calls": reply["tool_calls"]}}
                        final = {"model": body["model"], "done": True, "done_reason": "stop", "eval_count": 5,
                                 "eval_duration": 100_000_000, "message": {"role": "assistant", "content": ""}}
                        self.wfile.write((json.dumps(chunk) + "\n" + json.dumps(final) + "\n").encode())
                        return
                    last = next((m["content"] for m in reversed(body["messages"]) if m["role"] == "user"), "")
                    words = (reply["content"] if reply else "Echo: " + last).split(" ")
                    self.send_response(200)
                    self.send_header("Content-Type", "application/x-ndjson")
                    self.end_headers()
                    try:
                        for i, w in enumerate(words):
                            piece = w if i == 0 else " " + w
                            line = {"model": body["model"], "message": {"role": "assistant", "content": piece},
                                    "done": False}
                            self.wfile.write((json.dumps(line) + "\n").encode())
                            self.wfile.flush()
                            if fake.token_delay:
                                time.sleep(fake.token_delay)
                        final = {"model": body["model"], "message": {"role": "assistant", "content": ""},
                                 "done": True, "done_reason": "stop", "total_duration": 2_000_000_000,
                                 "load_duration": 100_000_000, "prompt_eval_count": 20,
                                 "prompt_eval_duration": 100_000_000, "eval_count": len(words),
                                 "eval_duration": 500_000_000}
                        self.wfile.write((json.dumps(final) + "\n").encode())
                    except (BrokenPipeError, ConnectionResetError):
                        pass
                    return
                if self.path == "/api/pull":
                    self.send_response(200)
                    self.end_headers()
                    for s in ({"status": "pulling manifest"}, {"status": "downloading", "total": 10, "completed": 10},
                              {"status": "success"}):
                        self.wfile.write((json.dumps(s) + "\n").encode())
                    fake.models.append(body["model"])
                    return
                self._json(404, {"error": "not found"})

        return H
