"""Set or reset the UNISON sign-in password from the PC.

  password.bat set        prompts for a new password (hidden)
  password.bat clear      removes the password (back to no sign-in; do this only on a trusted PC)
"""
from __future__ import annotations

import getpass
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from backend.security import sessions  # noqa: E402


def main(argv: list[str]) -> int:
    cmd = argv[0] if argv else "set"
    if cmd == "clear":
        sessions.clear_password()
        print("Password removed. UNISON no longer asks to sign in. Turn remote access off if you don't want it open.")
        return 0
    if cmd != "set":
        print(__doc__)
        return 1
    pw = getpass.getpass("New UNISON password: ")
    again = getpass.getpass("Repeat it: ")
    if pw != again:
        print("They didn't match. Nothing changed.")
        return 1
    try:
        sessions.set_password(pw)
    except ValueError as e:
        print(e)
        return 1
    print("Password set. Everyone is signed out; sign in again on each device.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
