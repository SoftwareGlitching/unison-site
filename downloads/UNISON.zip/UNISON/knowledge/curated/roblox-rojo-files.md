# Writing Roblox games as files (Rojo workflow)

UNISON cannot click around inside Roblox Studio, but it can write Luau files. Rojo syncs a folder of files
into Studio, so file-based projects let UNISON build real game code.

## Project layout
```
my-game/
  default.project.json
  src/
    server/            -> ServerScriptService
      main.server.lua  -> Script
    client/            -> StarterPlayer.StarterPlayerScripts
      main.client.lua  -> LocalScript
    shared/            -> ReplicatedStorage.Shared
      Config.lua       -> ModuleScript
```
File naming decides the instance type:
- `name.server.lua` / `.server.luau` → `Script`
- `name.client.lua` / `.client.luau` → `LocalScript`
- `name.lua` / `.luau` → `ModuleScript`
- A folder containing `init.lua` becomes a ModuleScript whose children are the other files
  (`init.server.lua` → Script, `init.client.lua` → LocalScript).
- `name.model.json` / `.rbxm` files describe or contain other instances (RemoteEvents, models).

## default.project.json
```json
{
  "name": "my-game",
  "tree": {
    "$className": "DataModel",
    "ReplicatedStorage": {
      "Shared": { "$path": "src/shared" },
      "Remotes": {
        "$className": "Folder",
        "BuyItem": { "$className": "RemoteEvent" }
      }
    },
    "ServerScriptService": { "Server": { "$path": "src/server" } },
    "StarterPlayer": {
      "StarterPlayerScripts": { "Client": { "$path": "src/client" } }
    }
  }
}
```

## Commands (run in the project folder)
- `rojo init my-game` creates a starter project.
- `rojo serve` starts syncing; in Studio, open the Rojo plugin and click Connect. (This never exits on its
  own, so the user should run it themselves, not an agent with a timeout.)
- `rojo build -o game.rbxl` builds a place file you can open in Studio.
- Toolchain managers: Aftman/Rokit (`aftman.toml` / `rokit.toml`) pin versions of rojo, selene, stylua, wally.
- `selene src` lints Luau (needs `selene.toml` with `std = "roblox"`); `stylua src` formats.
- Wally (`wally.toml`, `wally install`) installs community packages into `Packages/`.

## Tips for an agent
- Create the folder structure first, then the project file, then modules before the scripts that require them.
- Put RemoteEvents in the project file (as above) so both sides can `WaitForChild` them.
- After writing files, run `selene src` if selene is installed to catch errors; otherwise re-read the files.
