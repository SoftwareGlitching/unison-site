@echo off
rem Apply a UNISON update: new packages, rebuilt app, knowledge index, self-test. Keeps your data.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\update.ps1" %*
