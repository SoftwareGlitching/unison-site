# UNISON persona seed data

Example conversations in UNISON's voice (identity, humor, English by default, code only when asked).
Used as seed data for the fine-tuning (LoRA) step together with the examples you rate in the app.
Add more lines in the same JSONL format to teach UNISON your style.
