import { useState } from "react";
import { api } from "../lib/api";

export interface ToolItem {
  kind: "tool";
  key: string;
  callId: string;
  name: string;
  args: Record<string, unknown>;
  decision?: string;
  reason?: string;
  status: "waiting" | "approval" | "running" | "done" | "failed" | "denied";
  approval?: { actionId: string; preview: any };
  output?: string;
  diff?: string | null;
}

const LABELS: Record<string, string> = {
  list_dir: "List folder",
  read_file: "Read file",
  find_files: "Find files",
  search_text: "Search code",
  write_file: "Write file",
  edit_file: "Edit file",
  delete_path: "Delete",
  make_dir: "Create folder",
  copy_path: "Copy",
  run_command: "Run command",
  open_path: "Open",
  search_knowledge: "Search knowledge",
  screen: "Screen action",
};

function summary(name: string, args: Record<string, unknown>): string {
  const a = args as Record<string, any>;
  if (name === "run_command") return String(a.command ?? "");
  if (a.path) return String(a.path);
  if (a.pattern) return String(a.pattern);
  if (a.query) return `"${a.query}"`;
  if (a.source) return `${a.source} → ${a.destination}`;
  const s = JSON.stringify(args);
  return s.length > 120 ? s.slice(0, 120) + "…" : s;
}

function Diff({ text }: { text: string }) {
  return (
    <pre className="diff">
      {text.split("\n").map((l, i) => (
        <div
          key={i}
          className={
            l.startsWith("+++") || l.startsWith("---")
              ? "d-file"
              : l.startsWith("+")
                ? "d-add"
                : l.startsWith("-")
                  ? "d-del"
                  : l.startsWith("@@")
                    ? "d-hunk"
                    : ""
          }
        >
          {l || " "}
        </div>
      ))}
    </pre>
  );
}

function Preview({ p }: { p: any }) {
  if (!p) return null;
  if (p.kind === "diff")
    return (
      <>
        <div className="pv-line">
          {p.new_file ? "Create" : "Change"} <code>{p.path}</code>{" "}
          <span className="d-add-t">+{p.added}</span> <span className="d-del-t">-{p.removed}</span>
        </div>
        <Diff text={p.diff || "(no changes)"} />
      </>
    );
  if (p.kind === "command")
    return (
      <>
        <pre className="cmd">
          <span className="prompt">{p.shell === "powershell" ? "PS>" : ">"}</span> {p.command}
        </pre>
        <div className="pv-line dim">in {p.cwd}</div>
      </>
    );
  if (p.kind === "delete")
    return (
      <div className="pv-line">
        Delete <code>{p.path}</code> {p.is_dir ? "(empty folder)" : "(a backup is kept)"}
      </div>
    );
  if (p.kind === "error") return <div className="pv-line bad-t">{p.summary}</div>;
  return <div className="pv-line">{p.summary}</div>;
}

export function ToolCard({ item }: { item: ToolItem }) {
  const [open, setOpen] = useState(false);
  const [note, setNote] = useState("");
  const [sending, setSending] = useState(false);

  const answer = async (ok: boolean) => {
    if (!item.approval) return;
    setSending(true);
    try {
      await api.approve(item.approval.actionId, ok, note);
    } catch {
      /* the stream reports what happened */
    } finally {
      setSending(false);
    }
  };

  const icon =
    item.status === "done" ? "✓" : item.status === "failed" ? "✕" : item.status === "denied" ? "⊘" : item.status === "approval" ? "?" : "…";

  return (
    <div className={`tool-card st-${item.status}`}>
      <button className="tool-head" onClick={() => setOpen(!open)}>
        <span className="tool-icon">{icon}</span>
        <span className="tool-name">{LABELS[item.name] ?? item.name}</span>
        <span className="tool-sum">{summary(item.name, item.args)}</span>
        {item.status === "running" && <span className="pulse" />}
        {(item.output || item.diff) && <span className="caret">{open ? "▴" : "▾"}</span>}
      </button>

      {item.status === "approval" && item.approval && (
        <div className="approval">
          <div className="approval-title">UNISON wants to do this on your PC:</div>
          <Preview p={item.approval.preview} />
          <input
            className="approval-note"
            placeholder="Optional note to UNISON (e.g. 'use the src folder instead')"
            value={note}
            onChange={(e) => setNote(e.target.value)}
          />
          <div className="approval-actions">
            <button className="approve" disabled={sending} onClick={() => answer(true)}>
              Approve
            </button>
            <button className="deny" disabled={sending} onClick={() => answer(false)}>
              Deny
            </button>
          </div>
        </div>
      )}
      {item.status === "denied" && <div className="tool-note">{item.reason || "Not allowed"}</div>}
      {open && item.diff && <Diff text={item.diff} />}
      {open && item.output && <pre className="tool-output">{item.output}</pre>}
    </div>
  );
}
