# C# / .NET projects and Lua (LOVE2D, plain Lua)

## .NET from the command line
- New projects: `dotnet new console -o TodoApp`, `dotnet new winforms -o MyTool`, `dotnet new wpf -o MyApp`,
  `dotnet new classlib -o Core`, `dotnet new xunit -o Tests`; solution: `dotnet new sln` + `dotnet sln add **/*.csproj`.
- Build/run/test: `dotnet build`, `dotnet run --project TodoApp`, `dotnet test`.
- Packages: `dotnet add package Newtonsoft.Json` (or use built-in `System.Text.Json`).
- Publish a single exe: `dotnet publish -c Release -r win-x64 --self-contained -p:PublishSingleFile=true`.

## Modern C# style (C# 12, .NET 8)
```csharp
using System.Text.Json;

record TodoItem(int Id, string Title, bool Done = false);

class TodoStore(string path)
{
    readonly JsonSerializerOptions _json = new() { WriteIndented = true };
    public List<TodoItem> Load() =>
        File.Exists(path) ? JsonSerializer.Deserialize<List<TodoItem>>(File.ReadAllText(path)) ?? [] : [];
    public void Save(List<TodoItem> items) => File.WriteAllText(path, JsonSerializer.Serialize(items, _json));
}
```
- Top-level statements in Program.cs; `<Nullable>enable</Nullable>`; `string?` for maybe-null.
- LINQ: `items.Where(i => !i.Done).OrderBy(i => i.Title).Select(i => i.Title).ToList()`.
- Async I/O: `await File.ReadAllTextAsync(path)`, `await httpClient.GetStringAsync(url)` (reuse one HttpClient).
- Pattern matching: `switch` expressions `var label = score switch { >= 90 => "A", >= 80 => "B", _ => "C" };`.
- Input parsing: `int.TryParse(Console.ReadLine(), out var n)`.
- WinForms: designer-free code is fine - create controls in the Form constructor, `button.Click += (_, _) => ...`.
- Unity: `public class PlayerController : MonoBehaviour { [SerializeField] float speed = 5f; void Update() { var input = new Vector2(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical")); transform.Translate(input * speed * Time.deltaTime); } }`.
  Physics in FixedUpdate with Rigidbody; cache GetComponent in Awake; ScriptableObjects for data.

## Common C# bugs
- `NullReferenceException`: check what's null, enable nullable warnings, use `?.` and `??`.
- Modifying a collection inside foreach: iterate a copy (`.ToList()`) or use a for loop backwards.
- Forgetting `await` (warning CS4014) or `.Result` deadlocks in UI apps - async all the way.

## Lua essentials
- `local` everywhere (globals are slow and leak). Tables are arrays (1-based) and maps: `local t = {1, 2, x = 3}`; `#t` is the array length.
- Iterate: `for i, v in ipairs(list) do end`, `for k, v in pairs(map) do end`.
- Modules: `local M = {} function M.add(a, b) return a + b end return M` then `local util = require("util")`.
- Classes with metatables:
```lua
local Enemy = {}
Enemy.__index = Enemy
function Enemy.new(x, y) return setmetatable({x = x, y = y, hp = 3}, Enemy) end
function Enemy:hit(n) self.hp = self.hp - n; return self.hp <= 0 end
return Enemy
```
- String ops: `string.format("%s: %d", name, n)`, `s:sub(1, 3)`, `s:gmatch("%w+")`, `table.concat(list, ", ")`.
- Errors: `local ok, err = pcall(fn, arg)`.

## LOVE2D games (love2d.org)
```lua
function love.load()
  love.graphics.setDefaultFilter("nearest", "nearest")   -- crisp pixel art
  player = { x = 400, y = 300, speed = 220, img = love.graphics.newImage("assets/player.png") }
end
function love.update(dt)
  if love.keyboard.isDown("a") then player.x = player.x - player.speed * dt end
  if love.keyboard.isDown("d") then player.x = player.x + player.speed * dt end
end
function love.draw()
  love.graphics.draw(player.img, player.x, player.y, 0, 4, 4)
  love.graphics.print("Score: " .. score, 10, 10)
end
function love.keypressed(key) if key == "escape" then love.event.quit() end end
```
- Run: `love .` in the game folder (install from love2d.org; check with `where love`).
- conf.lua: `function love.conf(t) t.window.title = "Game"; t.window.width = 960; t.window.height = 540 end`.
- Collisions: AABB check `a.x < b.x + b.w and b.x < a.x + a.w and a.y < b.y + b.h and b.y < a.y + a.h`.
