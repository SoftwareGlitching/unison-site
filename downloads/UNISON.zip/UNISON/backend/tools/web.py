"""
Web research: search the internet and read pages, so UNISON can look things up when you ask
("search for...", "what's the latest...", "research...").

- web_search: DuckDuckGo's plain-HTML results page (no account or API key), with Wikipedia as a backup.
- fetch_url: downloads a page and returns its readable text (scripts, menus and styling removed).
Only the search words and the pages you look at go out to the internet; your chats and files stay on the PC.
Turn it off in Settings (tools.web_search = false).
"""
from __future__ import annotations

import html
import re
from typing import Optional
from urllib.parse import parse_qs, quote, unquote, urlparse

import httpx

from ..core.config import settings
from .base import Tool, ToolError, ToolResult

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/131.0 Safari/537.36 UNISON/1.0")
TIMEOUT = 15.0
MAX_PAGE_CHARS = 12000


def enabled() -> bool:
    return bool(settings.get("tools", "web_search", True))


def _client() -> httpx.Client:
    return httpx.Client(timeout=TIMEOUT, follow_redirects=True, headers={"User-Agent": UA, "Accept-Language": "en-US,en;q=0.8"})


def _strip(markup: str) -> str:
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", markup or ""))).strip()


def _ddg_link(href: str) -> str:
    if href.startswith("//"):
        href = "https:" + href
    q = parse_qs(urlparse(href).query)
    if "uddg" in q:
        return unquote(q["uddg"][0])
    return href


def parse_ddg(page: str, limit: int) -> list[dict]:
    out = []
    for m in re.finditer(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>(.*?)(?=<a[^>]+class="result__a"|$)', page, re.S):
        url = _ddg_link(html.unescape(m.group(1)))
        if "duckduckgo.com/y.js" in url or not url.startswith("http"):
            continue   # ads
        snip = re.search(r'class="result__snippet"[^>]*>(.*?)</a>', m.group(3), re.S)
        out.append({"title": _strip(m.group(2)), "url": url, "snippet": _strip(snip.group(1)) if snip else ""})
        if len(out) >= limit:
            break
    return out


def _wikipedia(query: str, limit: int) -> list[dict]:
    with _client() as c:
        r = c.get("https://en.wikipedia.org/w/api.php", params={
            "action": "query", "list": "search", "srsearch": query, "format": "json", "srlimit": limit})
        r.raise_for_status()
        hits = r.json().get("query", {}).get("search", [])
    return [{"title": h["title"], "url": "https://en.wikipedia.org/wiki/" + quote(h["title"].replace(" ", "_")),
             "snippet": _strip(h.get("snippet", ""))} for h in hits]


def search(query: str, limit: int = 6) -> list[dict]:
    """Search results as [{title, url, snippet}]. Raises ToolError if nothing could be reached."""
    query = (query or "").strip()
    if not query:
        raise ToolError("query is required")
    limit = max(1, min(int(limit or 6), 10))
    errors = []
    try:
        with _client() as c:
            r = c.post("https://html.duckduckgo.com/html/", data={"q": query, "kl": "us-en"})
            r.raise_for_status()
            results = parse_ddg(r.text, limit)
        if results:
            return results
    except httpx.HTTPError as e:
        errors.append(f"DuckDuckGo: {e}")
    try:
        results = _wikipedia(query, limit)
        if results:
            return results
    except httpx.HTTPError as e:
        errors.append(f"Wikipedia: {e}")
    if errors:
        raise ToolError("Couldn't reach the internet (" + "; ".join(errors) + "). Is this PC online?")
    return []


def page_text(markup: str) -> tuple[str, str]:
    """(title, readable text) of an HTML page."""
    title = _strip((re.search(r"<title[^>]*>(.*?)</title>", markup, re.S | re.I) or [None, ""])[1])
    body = re.sub(r"(?is)<(script|style|noscript|svg|nav|footer|header|form|aside|iframe)\b.*?</\1>", " ", markup)
    body = re.sub(r"(?i)<br\s*/?>|</(p|div|h[1-6]|li|tr|section|article|pre)>", "\n", body)
    body = re.sub(r"(?i)<h([1-6])[^>]*>", lambda m: "\n" + "#" * int(m.group(1)) + " ", body)
    text = html.unescape(re.sub(r"<[^>]+>", " ", body))
    text = re.sub(r"[ \t ]+", " ", text)
    lines = [ln.strip() for ln in text.splitlines()]
    text = "\n".join(ln for ln in lines if len(ln) > 1)
    return title, re.sub(r"\n{3,}", "\n\n", text).strip()


def fetch(url: str, max_chars: int = MAX_PAGE_CHARS) -> dict:
    url = (url or "").strip()
    if not re.match(r"^https?://", url, re.I):
        raise ToolError("Give a full web address starting with http:// or https://")
    host = (urlparse(url).hostname or "").lower()
    if host in ("localhost", "127.0.0.1", "0.0.0.0", "::1") or host.endswith(".local") or re.match(r"^(10|192\.168|172\.(1[6-9]|2\d|3[01]))\.", host):
        raise ToolError("fetch_url reads public web pages only, not addresses on this PC or network.")
    try:
        with _client() as c:
            r = c.get(url)
            r.raise_for_status()
    except httpx.HTTPError as e:
        raise ToolError(f"Couldn't open {url}: {e}") from e
    ctype = r.headers.get("content-type", "")
    if "html" in ctype or r.text.lstrip()[:15].lower().startswith(("<!doctype", "<html")):
        title, text = page_text(r.text)
    elif ctype.startswith("text/") or "json" in ctype or "xml" in ctype:
        title, text = url, r.text
    else:
        raise ToolError(f"That address is a {ctype or 'binary'} file, not a web page.")
    return {"url": str(r.url), "title": title or url, "text": text[:max_chars], "truncated": len(text) > max_chars}


# --------------------------------------------------------------------------- research for chat mode
_RESEARCH = re.compile(
    r"\b(search|look (it |this |that |them )?up|google|bing|research|browse|on the (web|internet)|online|"
    r"find (me )?(info|information|out|articles|sources)|latest|newest|news|current(ly)?|right now|today|"
    r"this (week|month|year)|recent(ly)?|release date|price of|how much (is|does|are)|who (won|is the)|"
    r"20(2[5-9]|3\d))\b", re.I)


def wants_research(text: Optional[str]) -> bool:
    t = (text or "").strip()
    return bool(t) and len(t) < 2000 and bool(_RESEARCH.search(t))


def research(query: str, pages: int = 3) -> tuple[str, list[dict]]:
    """Search, read the top pages, and return (context for the brain, sources for the user)."""
    q = re.sub(r"^(please |pls |can you |could you )?(search|google|look up|research)( the (web|internet))?( for)?\s*", "", query.strip(), flags=re.I)
    results = search(q[:300] or query[:300], 6)
    sources, parts = [], []
    for n, r in enumerate(results, 1):
        entry = {"n": n, "title": r["title"], "url": r["url"], "snippet": r["snippet"]}
        text = ""
        if n <= pages:
            try:
                text = fetch(r["url"], 2500)["text"]
            except ToolError:
                text = ""
        parts.append(f"[{n}] {r['title']} - {r['url']}\n{text or r['snippet']}")
        sources.append(entry)
    return "\n\n".join(parts), sources


RESEARCH_HEADER = """Fresh web results for the user's question (searched just now). Answer from these, cite the sources you used like [1] or [2], say plainly if they don't answer the question, and don't make up facts that aren't here:
{context}"""


# --------------------------------------------------------------------------- tools
def web_search(a: dict) -> ToolResult:
    if not enabled():
        raise ToolError("Web search is turned off in Settings.")
    results = search(a.get("query", ""), a.get("max_results") or 6)
    if not results:
        return ToolResult(True, f"No results for '{a.get('query')}'.")
    body = "\n\n".join(f"[{n}] {r['title']}\n{r['url']}\n{r['snippet']}" for n, r in enumerate(results, 1))
    return ToolResult(True, f"Web results for '{a.get('query')}':\n\n{body}\n\nUse fetch_url to read a page.",
                      {"results": results})


def fetch_url(a: dict) -> ToolResult:
    if not enabled():
        raise ToolError("Web access is turned off in Settings.")
    page = fetch(a.get("url", ""))
    more = "\n\n(Page shortened.)" if page["truncated"] else ""
    return ToolResult(True, f"{page['title']}\n{page['url']}\n\n{page['text']}{more}", {"url": page["url"]})


def _obj(props: dict, required: list[str]) -> dict:
    return {"type": "object", "properties": props, "required": required}


TOOLS = [
    Tool("web_search",
         "Search the internet (DuckDuckGo). Use it when the user asks you to search/look something up/research, "
         "or for anything recent (news, prices, new versions, docs for a library you don't know well). Returns "
         "titles, links and snippets; then read the best pages with fetch_url and cite them.",
         _obj({"query": {"type": "string", "description": "What to search for"},
               "max_results": {"type": "integer", "description": "1-10 (default 6)"}}, ["query"]),
         "external", web_search, default_mode="auto"),
    Tool("fetch_url",
         "Read a public web page (documentation, article, GitHub README...) and get its text.",
         _obj({"url": {"type": "string", "description": "Full https:// address"}}, ["url"]),
         "external", fetch_url, default_mode="auto"),
]
