# Builds UNISON.exe (the Windows app) with the C# compiler that comes with Windows. Safe to run any time.
#   -IfNeeded   skip the build when UNISON.exe is already up to date with desktop\UnisonApp.cs
#   -Quiet      only print problems
# Exit code 0 = UNISON.exe is ready. Anything else = use the .bat files (they still work without the app).
param([switch]$IfNeeded, [switch]$Quiet)
$ErrorActionPreference = "Continue"
$here = $PSScriptRoot
$root = Split-Path -Parent $here
$src = Join-Path $here "UnisonApp.cs"
$ico = Join-Path $here "unison.ico"
$out = Join-Path $root "UNISON.exe"
$bin = Join-Path $here "bin"
$logDir = Join-Path $root "logs"
$log = Join-Path $logDir "desktop-build.log"
New-Item -ItemType Directory -Force -Path $bin, $logDir | Out-Null

function Say([string]$t, [string]$color = "Gray", [switch]$Always) {
    if ($Always -or -not $Quiet) { Write-Host $t -ForegroundColor $color }
}

if (-not (Test-Path $src)) { Say "   XX  desktop\UnisonApp.cs is missing." Red -Always; exit 1 }
$hash = (Get-FileHash -Path $src -Algorithm SHA256).Hash
$stamp = Join-Path $bin "built.hash"
if ($IfNeeded -and (Test-Path $out) -and (Test-Path $stamp) -and ((Get-Content $stamp -Raw).Trim() -eq $hash)) { exit 0 }

# The compiler ships with .NET Framework 4.x, which is part of Windows 10 and 11.
$fw = Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319"
$platform = "x64"
if (-not (Test-Path (Join-Path $fw "csc.exe"))) {
    $fw = Join-Path $env:WINDIR "Microsoft.NET\Framework\v4.0.30319"
    $platform = "anycpu"
}
$csc = Join-Path $fw "csc.exe"
if (-not (Test-Path $csc)) {
    Say "   !!  Windows' C# compiler (.NET Framework 4) wasn't found, so the UNISON app can't be built. The .bat files still work." Yellow -Always
    exit 1
}

# WebView2 = the Edge engine Windows uses for app windows. Microsoft's small SDK lets UNISON open in its own
# window; without it UNISON opens in an Edge app window instead (works the same, just a different frame).
$wvFiles = @("Microsoft.Web.WebView2.Core.dll", "Microsoft.Web.WebView2.WinForms.dll", "WebView2Loader.dll")
function Test-WebView2 { return -not ($wvFiles | Where-Object { -not (Test-Path (Join-Path $bin $_)) }) }
if (-not (Test-WebView2) -and $platform -eq "x64") {
    Say "   Getting the WebView2 component from Microsoft (one time, a few MB)..."
    $tmp = Join-Path $env:TEMP ("unison-webview2-" + [guid]::NewGuid().ToString("N") + ".zip")
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        $ProgressPreference = "SilentlyContinue"
        Invoke-WebRequest -Uri "https://www.nuget.org/api/v2/package/Microsoft.Web.WebView2" -OutFile $tmp -UseBasicParsing -TimeoutSec 180
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $zip = [IO.Compression.ZipFile]::OpenRead($tmp)
        try {
            foreach ($name in @("Microsoft.Web.WebView2.Core.dll", "Microsoft.Web.WebView2.WinForms.dll")) {
                $pattern = "^lib/net4[0-9]*/" + [regex]::Escape($name) + "$"
                $entry = $zip.Entries | Where-Object { $_.FullName -match $pattern } | Sort-Object FullName -Descending | Select-Object -First 1
                if ($entry) { [IO.Compression.ZipFileExtensions]::ExtractToFile($entry, (Join-Path $bin $name), $true) }
            }
            $entry = $zip.Entries | Where-Object { $_.FullName -eq "runtimes/win-x64/native/WebView2Loader.dll" } | Select-Object -First 1
            if ($entry) { [IO.Compression.ZipFileExtensions]::ExtractToFile($entry, (Join-Path $bin "WebView2Loader.dll"), $true) }
        } finally { $zip.Dispose() }
    } catch {
        Say ("   !!  Couldn't get WebView2 (" + $_.Exception.Message + "). UNISON will open in an Edge app window instead.") Yellow
    } finally {
        Remove-Item $tmp -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-Build([bool]$withWebView) {
    $tmpOut = Join-Path $bin "UNISON.new.exe"
    Remove-Item $tmpOut -Force -ErrorAction SilentlyContinue
    $a = @("/nologo", "/target:winexe", "/platform:$platform", "/optimize+", "/codepage:65001", "/warn:1",
           "/out:$tmpOut", "/r:System.dll", "/r:System.Drawing.dll", "/r:System.Windows.Forms.dll")
    if (Test-Path $ico) { $a += "/win32icon:$ico" }
    if ($withWebView) {
        $a += "/define:WEBVIEW2"
        $a += ("/r:" + (Join-Path $bin "Microsoft.Web.WebView2.Core.dll"))
        $a += ("/r:" + (Join-Path $bin "Microsoft.Web.WebView2.WinForms.dll"))
    }
    $a += $src
    $text = (& $csc @a 2>&1 | Out-String)
    $ok = ($LASTEXITCODE -eq 0) -and (Test-Path $tmpOut)
    Add-Content -Path $log -Value ("==== " + (Get-Date -Format s) + "  webview2=" + $withWebView + "  ok=" + $ok + "`r`n" + $text)
    if ($ok) { return $tmpOut }
    return $null
}

Say "   Building UNISON.exe..."
$built = $null
$embedded = $false
if (Test-WebView2) {
    $built = Invoke-Build $true
    if ($built) { $embedded = $true }
    else { Say "   !!  The WebView2 build failed (details in logs\desktop-build.log). Building the Edge-window version." Yellow }
}
if (-not $built) { $built = Invoke-Build $false }
if (-not $built) {
    Say "   XX  Couldn't build UNISON.exe. Details are in logs\desktop-build.log. The .bat files still work." Red -Always
    exit 1
}
try {
    Move-Item -Force -Path $built -Destination $out -ErrorAction Stop
} catch {
    Remove-Item $built -Force -ErrorAction SilentlyContinue
    if (Test-Path $out) {
        Say "   !!  UNISON is open, so UNISON.exe wasn't replaced. Quit it from the tray icon (by the clock) and run this again." Yellow -Always
        exit 0   # the old app still works
    }
    Say ("   XX  Couldn't save UNISON.exe: " + $_.Exception.Message) Red -Always
    exit 1
}
Set-Content -Path $stamp -Value $hash
if ($embedded) { Say "   ok  Built UNISON.exe (opens in its own window)" Green }
else { Say "   ok  Built UNISON.exe (opens in an Edge app window)" Green }
exit 0
