"""
In-app license-key generator for owner / dev licenses - on the PC that holds the signing key.

Keys must be signed with the owner's private key, which only exists on the owner's PC: either Key Studio's
vault (%USERPROFILE%\\UNISON-owner\\signing-key.vault - AES-256-GCM, key derived from this PC's Windows
MachineGuid + the vault password, so it can't be opened anywhere else) or a plain license-private.pem.
On any other PC this feature simply reports "no signing key here".

Same key format and the same issued_keys.csv log as Key Studio, so both tools share one history.
"""
from __future__ import annotations

import base64
import csv
import json
import os
import re
import time
from pathlib import Path
from typing import Optional

from . import authority
from . import license as lic

OWNER_DIR = Path(os.environ.get("UNISON_OWNER_DIR") or (Path.home() / "UNISON-owner"))
LOG_FIELDS = ["issued", "id", "to", "email", "plan", "expires", "machine", "notes", "key"]
MID_RE = re.compile(r"^[0-9A-F]{4}(-[0-9A-F]{4}){3}$")
PLANS = ("personal", "pro", "lifetime", "trial", "tester", "dev")
MAX_PER_BATCH = 200


class IssuerError(Exception):
    pass


def _paths() -> tuple[Path, Path, Path]:
    return OWNER_DIR / "signing-key.vault", OWNER_DIR / "license-private.pem", OWNER_DIR / "issued_keys.csv"


def _unb64(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def _vault() -> Optional[dict]:
    try:
        return json.loads(_paths()[0].read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def status(plan: Optional[str]) -> dict:
    v, pem, log = _paths()
    vault = _vault()
    wired_here = bool(vault) and vault.get("owner_mid") == lic.machine_id()
    pub = (vault or {}).get("pub")
    return {
        "allowed": plan in ("owner", "dev"),
        "available": wired_here or pem.exists(),
        "vault": bool(vault), "wired_here": wired_here, "plain_key": pem.exists(),
        "needs_password": bool(wired_here and vault.get("has_password")),
        "matches_unison": (pub == authority.PUBLIC_KEY) if pub else None,
        "issued": _count(log),
        "plans": list(PLANS),
    }


def _count(log: Path) -> int:
    try:
        with open(log, newline="", encoding="utf-8") as f:
            return max(0, sum(1 for _ in f) - 1)
    except OSError:
        return 0


def _private_key(password: str):
    from cryptography.hazmat.primitives import serialization
    vault = _vault()
    _, pem_path, _ = _paths()
    if vault and vault.get("owner_mid") == lic.machine_id():
        from cryptography.exceptions import InvalidTag
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
        secret = ("unison-keystudio:" + lic._raw_machine_id() + "\x00" + (password or "")).encode("utf-8")
        k = Scrypt(salt=_unb64(vault["salt"]), length=32, n=2 ** 15, r=8, p=1).derive(secret)
        try:
            pem = AESGCM(k).decrypt(_unb64(vault["nonce"]), _unb64(vault["ct"]), vault["owner_mid"].encode())
        except InvalidTag:
            raise IssuerError("Wrong Key Studio password.") from None
    elif pem_path.exists():
        pem = pem_path.read_bytes()
    else:
        raise IssuerError("This PC doesn't hold the UNISON signing key, so it can't make keys that work. "
                          "Keys can only be made on the owner's PC.")
    return serialization.load_pem_private_key(pem, password=None), pem


def mint(password: str, to: str, plan: str = "personal", days: Optional[int] = None, mid: str = "",
         count: int = 1, email: str = "", notes: str = "") -> list[dict]:
    to = (to or "").strip()
    if not to or len(to) > 80:
        raise IssuerError("Enter who the key is for (up to 80 characters).")
    plan = (plan or "personal").strip().lower()
    if plan not in PLANS:
        raise IssuerError(f"Plan must be one of: {', '.join(PLANS)}.")
    if days is not None and not 1 <= int(days) <= 36500:
        raise IssuerError("Days must be between 1 and 36500.")
    mid = (mid or "").strip().upper()
    if mid and not MID_RE.match(mid):
        raise IssuerError("Machine ID should look like ABCD-1234-EF56-7890.")
    if not 1 <= int(count) <= MAX_PER_BATCH:
        raise IssuerError(f"Make between 1 and {MAX_PER_BATCH} keys at a time.")
    priv, pem = _private_key(password)
    from cryptography.hazmat.primitives import serialization
    pub = lic._b64(priv.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw))
    if authority.PUBLIC_KEY and pub != authority.PUBLIC_KEY:
        raise IssuerError("This signing key doesn't match the one built into UNISON - its keys wouldn't work.")
    out = []
    _, _, log = _paths()
    for i in range(int(count)):
        label = to if int(count) == 1 else f"{to} #{i + 1}"
        key = lic.mint(pem, to=label, plan=plan, days=int(days) if days else None, mid=mid or None)
        data = lic.parse(key, pub_b64=pub, any_pc=True)            # self-check before handing it out
        row = {"issued": time.strftime("%Y-%m-%d %H:%M", time.localtime(data["iat"])), "id": data["id"],
               "to": label, "email": (email or "").strip(), "plan": plan,
               "expires": time.strftime("%Y-%m-%d", time.localtime(data["exp"])) if data.get("exp") else "never",
               "machine": mid or "any PC", "notes": (notes or "").strip(), "key": key}
        _log(log, row)
        out.append(row)
    return out


def _log(log: Path, row: dict) -> None:
    new = not log.exists()
    log.parent.mkdir(parents=True, exist_ok=True)
    with open(log, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=LOG_FIELDS)
        if new:
            w.writeheader()
        w.writerow({k: row.get(k, "") for k in LOG_FIELDS})


def recent(limit: int = 50) -> list[dict]:
    _, _, log = _paths()
    try:
        with open(log, newline="", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
    except OSError:
        return []
    return list(reversed(rows))[:limit]
