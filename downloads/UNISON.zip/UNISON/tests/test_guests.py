"""Website guests: a license key buys a chat-only token that never works as the owner's session."""
import asyncio
import time
import unittest
from unittest import mock

from tests.helpers import IsolatedSettings
from tests.test_auth import Req, tunnel

from backend.licensing import authority, license as lic
from backend.security import sessions


def at(path, token=None):
    r = tunnel(token=token)
    r.url = type("U", (), {"path": path})()
    return r


class GuestTests(unittest.TestCase):
    def setUp(self):
        self.pem, self.pub = lic.new_keypair()
        self.p = mock.patch.object(authority, "PUBLIC_KEY", self.pub)
        self.p.start()
        from backend.api import routes_auth as ra
        ra.failed = ra.FailedLogins()
        self.ra = ra

    def tearDown(self):
        self.p.stop()

    def login(self, key, req=None):
        return asyncio.run(self.ra.key_login(self.ra.KeyBody(key=key), req or tunnel()))

    def test_key_login_gives_chat_only_token(self):
        from backend.security.auth import guest_of, request_authorized
        with IsolatedSettings():
            sessions.set_password("owner-password-123")
            out = self.login(lic.mint(self.pem, to="Buyer", plan="pro", days=30))
            tok = out["token"]
            self.assertEqual(out["to"], "Buyer")
            self.assertLessEqual(out["expires"], time.time() + 12 * 3600 + 5)
            self.assertTrue(guest_of(at("/v1/chat/completions", tok)))           # may chat
            for path in ("/v1/chat", "/v1/settings/inference", "/v1/tools/execute", "/v1/jobs", "/v1/models/active"):
                self.assertIsNone(guest_of(at(path, tok)), path)                  # nothing else
            self.assertFalse(sessions.verify_token(tok))                         # never an owner session
            self.assertFalse(request_authorized(Req(token=tok)))
            owner = sessions.issue_token()
            self.assertIsNone(sessions.verify_guest_token(owner))                # and vice versa

    def test_pc_locked_keys_work_for_the_website(self):
        with IsolatedSettings():
            sessions.set_password("owner-password-123")
            self.assertTrue(self.login(lic.mint(self.pem, to="X", mid="ABCD-1234-EF56-7890"))["ok"])

    def test_bad_expired_and_revoked_keys_are_refused(self):
        with IsolatedSettings():
            sessions.set_password("owner-password-123")
            fake_pem, _ = lic.new_keypair()
            with mock.patch("time.time", return_value=time.time() - 5 * 86400):
                old = lic.mint(self.pem, to="Old", days=1)
            good = lic.mint(self.pem, to="Refund")
            for key in (lic.mint(fake_pem, to="Pirate"), old, "UNISON-garbage.garbage"):
                with self.assertRaises(Exception) as ctx:
                    self.login(key)
                self.assertEqual(ctx.exception.status_code, 401)
            tok = self.login(good)["token"]
            from backend.security.auth import guest_of
            kid = lic.parse(good)["id"]
            sessions.settings.set("remote", "revoked_keys", [kid])
            self.assertIsNone(guest_of(at("/v1/chat/completions", tok)))         # existing token dies too
            with self.assertRaises(Exception) as ctx:
                self.login(good, Req(host_header="x.ts.net", headers={"x-forwarded-for": "198.51.100.1"}))
            self.assertEqual(ctx.exception.status_code, 401)

    def test_guest_token_expires_with_a_short_key(self):
        with IsolatedSettings():
            sessions.set_password("owner-password-123")
            out = self.login(lic.mint(self.pem, to="Trial", days=1))
            self.assertLessEqual(out["expires"], time.time() + 86400 + 5)

    def test_needs_password_and_can_be_switched_off(self):
        from backend.security.auth import guest_of
        with IsolatedSettings():
            key = lic.mint(self.pem, to="A")
            with self.assertRaises(Exception) as ctx:
                self.login(key)                                                  # no owner password yet
            self.assertEqual(ctx.exception.status_code, 403)
            sessions.set_password("owner-password-123")
            tok = self.login(key)["token"]
            sessions.settings.set("remote", "web_guests", False)
            self.assertIsNone(guest_of(at("/v1/chat/completions", tok)))
            with self.assertRaises(Exception) as ctx:
                self.login(key)
            self.assertEqual(ctx.exception.status_code, 403)

    def test_too_many_bad_keys_locks_out(self):
        with IsolatedSettings():
            sessions.set_password("owner-password-123")
            for _ in range(self.ra.MAX_FAILS_PER_IP):
                with self.assertRaises(Exception):
                    self.login("UNISON-nope.nope")
            with self.assertRaises(Exception) as ctx:
                self.login(lic.mint(self.pem, to="Real"))
            self.assertEqual(ctx.exception.status_code, 429)

    def test_cors_allows_the_public_site_only(self):
        from backend import main
        with IsolatedSettings():
            sessions.settings.set("site", "url", "https://softwareglitching.github.io/unison-site/")
            o = main.cors_origins()
            self.assertIn("https://softwareglitching.github.io", o)
            self.assertNotIn("*", o)


if __name__ == "__main__":
    unittest.main()
