@echo off
cd /d "%~dp0.."
".venv\Scripts\python.exe" scripts\eval.py %*
if errorlevel 1 pause
