# Python games with pygame (complete, runnable structure)

## Setup and checks
- Install: `python -m pip install pygame` (pygame-ce also works: `pip install pygame-ce`, same `import pygame`).
- Syntax check: `python -m py_compile main.py`.
- Run check without a window: run_command `python main.py` with `smoke_test_seconds=6` (sets SDL_VIDEODRIVER=dummy).
- Keep a `requirements.txt` with `pygame>=2.5`.

## Skeleton (one file, grows into modules)
```python
import math, random, sys
from pathlib import Path
import pygame

W, H, FPS = 960, 540, 60
ASSETS = Path(__file__).parent / "assets"

def load_image(name, scale=1):
    path = ASSETS / name
    if path.exists():
        img = pygame.image.load(path).convert_alpha()
        return pygame.transform.scale_by(img, scale) if scale != 1 else img
    surf = pygame.Surface((32, 32), pygame.SRCALPHA)       # fallback so the game still runs
    pygame.draw.rect(surf, (155, 135, 255), surf.get_rect(), border_radius=6)
    return surf

class Player(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        self.image = load_image("player.png")
        self.rect = self.image.get_rect(center=pos)
        self.pos = pygame.Vector2(pos)
        self.speed = 280
        self.hp = 5

    def update(self, dt):
        keys = pygame.key.get_pressed()
        d = pygame.Vector2(keys[pygame.K_d] - keys[pygame.K_a], keys[pygame.K_s] - keys[pygame.K_w])
        if d.length_squared():
            d = d.normalize()
        self.pos += d * self.speed * dt
        self.pos.x = max(16, min(W - 16, self.pos.x)); self.pos.y = max(16, min(H - 16, self.pos.y))
        self.rect.center = self.pos

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((W, H))
        pygame.display.set_caption("My Game")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 32)
        self.state = "title"          # title | playing | over
        self.reset()

    def reset(self):
        self.player = Player((W / 2, H / 2))
        self.enemies = pygame.sprite.Group()
        self.bullets = pygame.sprite.Group()
        self.all = pygame.sprite.Group(self.player)
        self.score, self.wave, self.spawn_timer = 0, 1, 0.0

    def handle_events(self):
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if e.type == pygame.KEYDOWN and e.key == pygame.K_RETURN and self.state != "playing":
                self.reset(); self.state = "playing"

    def update(self, dt):
        if self.state != "playing":
            return
        self.all.update(dt)
        # collisions: pygame.sprite.groupcollide(self.bullets, self.enemies, True, True)
        # pygame.sprite.spritecollide(self.player, self.enemies, True)

    def draw(self):
        self.screen.fill((14, 12, 34))
        self.all.draw(self.screen)
        text = {"title": "Press Enter to start", "over": f"Game over - score {self.score} - Enter to retry"}.get(self.state)
        if text:
            img = self.font.render(text, True, (238, 236, 255))
            self.screen.blit(img, img.get_rect(center=(W / 2, H / 2)))
        else:
            self.screen.blit(self.font.render(f"Score {self.score}  Wave {self.wave}", True, (238, 236, 255)), (16, 12))
        pygame.display.flip()

    def run(self):
        while True:
            dt = min(self.clock.tick(FPS) / 1000, 0.05)    # seconds; capped so a hiccup doesn't teleport things
            self.handle_events()
            self.update(dt)
            self.draw()

if __name__ == "__main__":
    Game().run()
```

## Techniques
- Movement uses `dt` (seconds) so speed is the same at any frame rate. Use `pygame.Vector2`.
- Shooting toward the mouse: `direction = (pygame.Vector2(pygame.mouse.get_pos()) - self.pos).normalize()`.
- Remove off-screen bullets: `if not screen_rect.colliderect(self.rect): self.kill()`.
- Spawning: a timer `self.spawn_timer -= dt`; when <= 0, spawn and reset (shorter each wave).
- Animation: list of frames, `self.frame = (self.frame + dt * 10) % len(frames)`, `image = frames[int(self.frame)]`.
  Make frames with make_sprite (a sprite sheet) and slice with `sheet.subsurface((i * w, 0, w, h))`.
- Sound: `pygame.mixer.Sound("assets/shoot.wav")`; wrap in try/except so missing audio devices don't crash.
- High score: `json` file next to the game (`Path(__file__).with_name("save.json")`).
- Screen shake: offset the draw position by a random vector that decays each frame.
- Pixel-art scaling: draw to a small Surface then `pygame.transform.scale(small, (W, H))`.

## Common bugs
- Forgetting `convert_alpha()` (slow) or calling it before `display.set_mode` (error).
- Moving with integers on `rect` (jittery): keep a float `pos`, copy it to `rect.center`.
- Not calling `pygame.event.get()` every frame: the window freezes ("Not responding").
- Loading images inside `update()` every frame: load once.
