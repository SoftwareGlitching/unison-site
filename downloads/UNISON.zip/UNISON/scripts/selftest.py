"""
UNISON end-to-end self-test. Runs against the REAL server and the REAL local model.

  .venv\\Scripts\\python scripts\\selftest.py [--url http://127.0.0.1:8770]

Checks: health, model installed, OpenAI-compatible chat (non-streaming + streaming), native chat with
conversation memory across turns, stats from the engine. Writes docs/SELFTEST.md with the actual replies.
Uses only the Python standard library.
"""
from __future__ import annotations

import argparse
import json
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _auth_header() -> dict:
    """If a sign-in password is set, mint a session token with this PC's own server secret."""
    try:
        import sys as _sys
        _sys.path.insert(0, str(ROOT))
        from backend.security import sessions
        if sessions.password_set():
            return {"Authorization": f"Bearer {sessions.issue_token(days=1)}"}
    except Exception:  # noqa: BLE001
        pass
    return {}


AUTH = None


def req(url, method="GET", body=None, timeout=600):
    global AUTH
    if AUTH is None:
        AUTH = _auth_header()
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(url, data=data, method=method, headers={"Content-Type": "application/json", **AUTH})
    return urllib.request.urlopen(r, timeout=timeout)


def get_json(url):
    with req(url) as r:
        return json.loads(r.read())


def post_json(url, body):
    with req(url, "POST", body) as r:
        return json.loads(r.read())


def sse_events(url, body):
    with req(url, "POST", body) as r:
        for raw in r:
            line = raw.decode("utf-8").strip()
            if line.startswith("data: "):
                yield line[6:]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://127.0.0.1:8770")
    base = ap.parse_args().url.rstrip("/")
    results, transcript = [], []

    def check(name, fn):
        t = time.time()
        try:
            detail = fn()
            results.append((name, True, detail, time.time() - t))
            print(f"  PASS  {name}  ({time.time() - t:.1f}s) {detail or ''}")
            return True
        except Exception as e:  # noqa: BLE001
            body = ""
            if isinstance(e, urllib.error.HTTPError):
                try:
                    body = " - " + e.read().decode("utf-8", "replace")[:500]
                except Exception:  # noqa: BLE001
                    pass
            results.append((name, False, f"{type(e).__name__}: {e}{body}", time.time() - t))
            print(f"  FAIL  {name}: {type(e).__name__}: {e}{body}")
            return False

    print(f"UNISON self-test against {base}\n")

    def t_license():
        st = get_json(f"{base}/v1/license/status")
        assert st["activated"], ("not activated: " + (st.get("problem") or "paste a license key in the app")
                                 + f" (Machine ID {st.get('machine_id')})")
        return f"licensed to {st.get('to')} ({st.get('plan')})"
    if not check("license activated", t_license):
        return finish(results, transcript)

    def t_health():
        h = get_json(f"{base}/v1/health")
        assert h["engine"]["ok"], f"Ollama not reachable: {h['engine'].get('error')}"
        assert h["active_model"], "no active model configured"
        assert h["active_model_installed"], f"model {h['active_model']} is not installed in Ollama"
        return f"model={h['active_model']} ollama={h['engine'].get('version')}"
    if not check("health: engine up, model installed", t_health):
        return finish(results, transcript)

    def t_models():
        m = get_json(f"{base}/v1/models")
        assert m["data"], "no models listed"
        return f"{len(m['data'])} model(s) installed"
    check("GET /v1/models", t_models)

    def t_oa():
        r = post_json(f"{base}/v1/chat/completions", {
            "messages": [{"role": "user", "content": "What is 17 * 23? Reply with only the number."}],
            "temperature": 0, "max_tokens": 20})
        text = r["choices"][0]["message"]["content"].strip()
        transcript.append(("17 * 23 (non-streaming, OpenAI format)", text))
        assert text, "empty reply"
        tps = (r.get("unison", {}).get("stats") or {}).get("tokens_per_second")
        verdict = "correct" if "391" in text else "model answered differently"
        return f"reply={text[:40]!r} ({verdict}), {tps} tok/s"
    check("POST /v1/chat/completions (non-streaming)", t_oa)

    def t_oa_stream():
        chunks, text = 0, []
        for data in sse_events(f"{base}/v1/chat/completions", {
                "stream": True, "temperature": 0.2, "max_tokens": 200,
                "messages": [{"role": "user", "content": "Write a Roblox Luau function that returns the sum of a table of numbers. Code only."}]}):
            if data == "[DONE]":
                break
            obj = json.loads(data)
            assert "error" not in obj, obj
            delta = obj["choices"][0]["delta"].get("content") if obj.get("choices") else None
            if delta:
                chunks += 1
                text.append(delta)
        full = "".join(text)
        transcript.append(("Luau sum function (streaming, OpenAI format)", full))
        assert chunks > 3, f"only {chunks} streamed chunks"
        return f"{chunks} streamed chunks, {'contains' if 'function' in full else 'missing'} 'function'"
    check("POST /v1/chat/completions (streaming)", t_oa_stream)

    def t_native():
        name = "Ada"
        first = post_json(f"{base}/v1/chat", {"stream": False, "tools": False, "options": {"temperature": 0},
                                              "message": f"My name is {name}. Just say hello to me."})
        cid = first["conversation_id"]
        second = post_json(f"{base}/v1/chat", {"stream": False, "tools": False, "conversation_id": cid, "options": {"temperature": 0},
                                               "message": "What is my name? Answer with just the name."})
        transcript.append(("Conversation turn 1", first["content"]))
        transcript.append(("Conversation turn 2 (should recall the name)", second["content"]))
        conv = get_json(f"{base}/v1/conversations/{cid}")
        assert len(conv["messages"]) == 4, f"expected 4 stored messages, found {len(conv['messages'])}"
        remembered = name.lower() in second["content"].lower()
        return f"stored 4 messages; name recalled: {'yes' if remembered else 'NO'}"
    check("POST /v1/chat (conversation history)", t_native)

    def t_native_stream():
        types = set()
        for data in sse_events(f"{base}/v1/chat", {"message": "Say OK.", "stream": True, "tools": False, "options": {"max_tokens": 10}}):
            obj = json.loads(data)
            assert obj["type"] != "error", obj
            types.add(obj["type"])
        assert {"start", "token", "done"} <= types, types
        return "start/token/done events received"
    check("POST /v1/chat (streaming events)", t_native_stream)

    def t_knowledge():
        k = get_json(f"{base}/v1/knowledge")
        assert k["embedding_ready"], k.get("problem")
        assert k["chunks"] > 0, "knowledge base is empty (run scripts\\index_knowledge.bat)"
        hits = post_json(f"{base}/v1/knowledge/search", {"query": "how to save player data with DataStores", "k": 3})["data"]
        assert hits, "no search results"
        return f"{k['chunks']} chunks; top hit for a DataStore question: {hits[0]['title']} ({hits[0]['score']})"
    check("knowledge base (local embeddings + search)", t_knowledge)

    def t_agent():
        """The real model uses tools: write a file (auto-approved by this test), read it back, then clean up."""
        target = "unison-selftest/hello.txt"
        events, approvals = [], 0
        req_body = {"stream": True, "tools": True, "options": {"temperature": 0},
                    "message": f"Use your tools: create the file {target} containing exactly the text "
                               "UNISON-OK, then read the file back and tell me what it contains."}
        for data in sse_events(f"{base}/v1/chat", req_body):
            ev = json.loads(data)
            events.append(ev)
            if ev["type"] == "approval_required":
                approvals += 1
                ok = ev["name"] in ("write_file", "make_dir") and "unison-selftest" in json.dumps(ev["args"])
                post_json(f"{base}/v1/approvals/{ev['action_id']}", {"approve": ok, "note": "" if ok else "self-test only allows its own file"})
            if ev["type"] == "error":
                raise AssertionError(ev.get("message"))
        calls = [e["name"] for e in events if e["type"] == "tool_call"]
        transcript.append(("Agent tool use", "tools called: " + ", ".join(calls) + "\n\n" +
                           next((e["content"] for e in reversed(events) if e["type"] == "assistant_saved"), "")))
        read = post_json(f"{base}/v1/tools/execute", {"name": "read_file", "arguments": {"path": target}})
        post_json(f"{base}/v1/tools/execute", {"name": "delete_path", "arguments": {"path": target}, "approved": True})
        post_json(f"{base}/v1/tools/execute", {"name": "delete_path", "arguments": {"path": "unison-selftest"}, "approved": True})
        assert "write_file" in calls, f"model never called write_file (called: {calls or 'nothing'})"
        assert read.get("ok") and "UNISON-OK" in read.get("output", ""), "file wasn't written correctly"
        return f"tools used: {', '.join(calls)}; {approvals} approval(s); file verified and removed"
    check("agent: model uses tools to write and read a file", t_agent)

    def t_screen():
        st = get_json(f"{base}/v1/computer")
        if not st["supported"]:
            return f"skipped: {st['problem']}"
        shot = get_json(f"{base}/v1/computer/screenshot")
        assert shot["width"] > 0 and shot["image"], "empty screenshot"
        vm = "ready" if st["vision_model_installed"] else "NOT downloaded (screen mode needs it)"
        return f"screen {shot['width']}x{shot['height']} captured; vision model {st['vision_model']} {vm}"
    check("screen capture (no mouse/keyboard used)", t_screen)

    def t_metrics():
        m = get_json(f"{base}/v1/system/metrics")
        last = m["inference"]["last"] or {}
        assert last.get("tokens_per_second"), "no generation stats recorded"
        loaded = m["loaded_models"]
        gpu = f"{loaded[0]['gpu_percent']}% on GPU" if loaded else "not loaded"
        return f"{last['tokens_per_second']} tok/s last reply, model {gpu}, RAM {m['system']['ram_percent']}%"
    check("GET /v1/system/metrics (real numbers)", t_metrics)

    return finish(results, transcript)


def finish(results, transcript) -> int:
    passed = sum(1 for r in results if r[1])
    lines = ["# UNISON self-test", "", f"Run: {time.strftime('%Y-%m-%d %H:%M')}", "",
             f"**{passed}/{len(results)} checks passed**", "", "| Check | Result | Detail |", "|---|---|---|"]
    for name, ok, detail, _ in results:
        lines.append(f"| {name} | {'PASS' if ok else 'FAIL'} | {str(detail or '').replace('|', '/')} |")
    if transcript:
        lines += ["", "## Actual model replies", ""]
        for q, a in transcript:
            lines += [f"### {q}", "", "```", a.strip(), "```", ""]
    out = ROOT / "docs" / "SELFTEST.md"
    out.write_text("\n".join(lines), encoding="utf-8")
    print(f"\n{passed}/{len(results)} checks passed. Details: {out}")
    return 0 if passed == len(results) and results else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except urllib.error.URLError as e:
        print(f"Could not reach UNISON: {e}")
        raise SystemExit(1)
