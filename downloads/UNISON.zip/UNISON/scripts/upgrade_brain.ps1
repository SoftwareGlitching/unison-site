# Upgrade UNISON's brain: a strong general model (Qwen3) packaged as UNISON's own model "unison",
# with UNISON's personality built in, then made the active model. Your chats and settings are kept.
param([string]$Base = "", [switch]$Yes)

. (Join-Path $PSScriptRoot "common.ps1")
Set-Location $Root
try { Start-Transcript -Path (Join-Path $Root "logs\upgrade-brain.log") -Append | Out-Null } catch { }

Write-Host ""
Write-Host "  U N I S O N   brain upgrade" -ForegroundColor Cyan
if (-not (Test-Path $VenvPy)) { Write-Bad "UNISON isn't set up yet. Run Setup.bat first."; Read-Host "Press Enter to close"; exit 1 }

# ------------------------------------------------------------------ 1. pick the base model for this GPU
$vram = & $VenvPy -c "import json; d=json.load(open('config/hardware.json', encoding='utf-8-sig')); print(max([g.get('vram_gb') or 0 for g in d.get('gpus', []) if g.get('vendor') in ('nvidia','amd')] or [0]))" 2>$null
$vram = [double]($vram | Select-Object -First 1)
$size = 10
if (-not $Base) {
    if ($vram -ge 11) { $Base = "qwen3:14b"; $size = 9.3 }
    elseif ($vram -ge 6) { $Base = "qwen3:8b"; $size = 5.2 }
    else { $Base = "qwen3:4b"; $size = 2.6 }
}
Write-Step "1/5" "Brain for your GPU ($vram GB): $Base (~$size GB download, one time)"

$ollama = Find-OllamaExe
if (-not $ollama -or -not (Start-OllamaIfNeeded)) { Write-Bad "Ollama isn't running. Open Ollama from the Start menu and try again."; Read-Host "Press Enter to close"; exit 1 }

# ------------------------------------------------------------------ 2. make room
Write-Step "2/5" "Disk space"
$modelDir = [Environment]::GetEnvironmentVariable("OLLAMA_MODELS", "User")
if (-not $modelDir) { $modelDir = Join-Path $env:USERPROFILE ".ollama\models" }
$drive = (Split-Path -Qualifier $modelDir).TrimEnd(":")
$free = [math]::Round((Get-PSDrive $drive).Free / 1GB, 1)
$haveBase = (& $ollama list 2>$null | Out-String) -match [regex]::Escape($Base)
$need = $size + 3
Write-Host "   Models live on ${drive}: ($free GB free)."
if (-not $haveBase -and $free -lt $need) {
    $best = Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Name -ne $drive -and $_.Free -gt ($need + 5) * 1GB } |
            Sort-Object Free -Descending | Select-Object -First 1
    if (-not $best) { Write-Bad "Not enough space: free at least $need GB on ${drive}: and run this again."; Read-Host "Press Enter to close"; exit 1 }
    $target = "$($best.Name):\Ollama\models"
    Write-Warn2 "${drive}: is too full for $Base. Your $($best.Name): drive has $([math]::Round($best.Free / 1GB)) GB free."
    if (-not ($Yes -or (Ask-YesNo "Move Ollama's models to $target first? (nothing is downloaded again)" $true))) { exit 1 }
    & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot "move_models.ps1") -Target $target
    $env:OLLAMA_MODELS = [Environment]::GetEnvironmentVariable("OLLAMA_MODELS", "User")
    if (-not (Start-OllamaIfNeeded)) { Write-Bad "Ollama didn't come back after the move. Open it from the Start menu and run this again."; Read-Host "Press Enter to close"; exit 1 }
    Write-Ok "Models now on $target"
} else { Write-Ok "Enough space." }

# ------------------------------------------------------------------ 3. download
Write-Step "3/5" "Downloading $Base"
if ($haveBase) { Write-Ok "Already downloaded." }
else {
    & $ollama pull $Base
    if ($LASTEXITCODE -ne 0) { Write-Bad "Download failed (see above). Check your internet and run Upgrade-Brain.bat again."; Read-Host "Press Enter to close"; exit 1 }
    Write-Ok "Downloaded"
}

# ------------------------------------------------------------------ 4. build UNISON's own model
Write-Step "4/5" "Building UNISON's own model: unison"
$persona = (Get-Content (Join-Path $PSScriptRoot "brain\persona.txt") -Raw -Encoding UTF8).Trim()
$mf = @"
FROM $Base
PARAMETER temperature 0.7
PARAMETER top_p 0.9
PARAMETER top_k 40
PARAMETER repeat_penalty 1.05
PARAMETER num_ctx 8192
SYSTEM """$persona"""
LICENSE """UNISON model by PerkyPop. Built on the open-weight $Base model, licensed Apache-2.0 (https://www.apache.org/licenses/LICENSE-2.0)."""
"@
$mfPath = Join-Path $Root "config\unison.Modelfile"
[IO.File]::WriteAllText($mfPath, $mf, (New-Object Text.UTF8Encoding $false))
& $ollama create unison -f $mfPath
if ($LASTEXITCODE -ne 0) { Write-Bad "Couldn't build the unison model (see above)."; Read-Host "Press Enter to close"; exit 1 }
& $VenvPy -c @"
from backend.core.config import settings
settings.set('inference', 'active_model', 'unison')
for k, v in {'temperature': 0.7, 'top_p': 0.9, 'top_k': 40, 'repeat_penalty': 1.05, 'num_ctx': 8192, 'think': False}.items():
    settings.set('inference', k, v)
settings.set('assistant', 'system_prompt', open('scripts/brain/persona.txt', encoding='utf-8').read().strip())
print('   active model: unison')
"@
Write-Ok "UNISON now runs on its own model 'unison' (built on $Base)."

# ------------------------------------------------------------------ 5. quick test
Write-Step "5/5" "Talking to the new brain"
& $VenvPy (Join-Path $PSScriptRoot "brain_check.py") unison
try { Stop-Transcript | Out-Null } catch { }
Write-Host ""
Write-Host "  Done. Restart UNISON (close its window, then Start-UNISON.bat) to use the new brain." -ForegroundColor Green
if (-not $Yes) { Read-Host "Press Enter to close" }
