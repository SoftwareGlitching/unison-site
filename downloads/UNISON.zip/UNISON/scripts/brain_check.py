"""Quick check of a model through Ollama: a few chat replies, speed, and how much of it is on the GPU."""
import json
import sys
import time
import urllib.request

OLLAMA = "http://127.0.0.1:11434"
MODEL = sys.argv[1] if len(sys.argv) > 1 else "unison"
PROMPTS = ["hey whats up", "who made you?", "tell me a short joke about programmers"]


def post(path, body, timeout=600):
    req = urllib.request.Request(OLLAMA + path, data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read())


def main() -> int:
    ok = True
    for p in PROMPTS:
        body = {"model": MODEL, "messages": [{"role": "user", "content": p}], "stream": False, "think": False}
        t = time.time()
        try:
            out = post("/api/chat", body)
        except Exception as e:  # noqa: BLE001
            if "think" in str(e).lower():
                body.pop("think")
                out = post("/api/chat", body)
            else:
                print(f"   XX  {p!r}: {e}")
                ok = False
                continue
        reply = (out.get("message") or {}).get("content", "").strip()
        n, ns = out.get("eval_count") or 0, out.get("eval_duration") or 0
        tps = f"{n / (ns / 1e9):.0f} tok/s" if ns else f"{time.time() - t:.1f}s"
        print(f"\n   you:    {p}\n   unison: {reply[:400]}\n           ({tps})")
    try:
        with urllib.request.urlopen(OLLAMA + "/api/ps", timeout=10) as r:
            for m in json.loads(r.read()).get("models", []):
                if m.get("name", "").startswith(MODEL):
                    size, vram = m.get("size") or 1, m.get("size_vram") or 0
                    pct = round(100 * vram / size)
                    print(f"\n   {pct}% of the model is on the GPU" + ("" if pct >= 95 else
                          "  <- under 100%: lower num_ctx or pick a smaller base (Upgrade-Brain.bat -Base qwen3:8b)"))
    except Exception:  # noqa: BLE001
        pass
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
