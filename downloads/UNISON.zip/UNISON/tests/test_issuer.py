"""In-app key generator: opens Key Studio's vault (same format), only on the PC it's wired to."""
import importlib.util
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from backend.licensing import authority, issuer, license as lic

KS = Path(__file__).resolve().parents[1] / "owner-tools" / "keystudio" / "key_studio.py"


def load_key_studio(owner_dir: str, guid: str):
    os.environ["UNISON_OWNER_DIR"], os.environ["UNISON_FAKE_MACHINE"] = owner_dir, guid
    spec = importlib.util.spec_from_file_location("key_studio_under_test", KS)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


@unittest.skipUnless(KS.exists(), "owner tools not present (downloads don't include them)")
class IssuerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.ks = load_key_studio(self.tmp.name, "GUID-OWNER-PC")
        self.priv = self.ks.Ed25519PrivateKey.generate()
        self.ks.vault_create(self.priv, "vault-pass")
        self.pub = self.ks.pub_of(self.priv)
        self.patches = [mock.patch.object(issuer, "OWNER_DIR", Path(self.tmp.name)),
                        mock.patch.object(authority, "PUBLIC_KEY", self.pub)]
        for p in self.patches:
            p.start()
        lic.machine_id.cache_clear()

    def tearDown(self):
        for p in self.patches:
            p.stop()
        lic.machine_id.cache_clear()
        os.environ.pop("UNISON_OWNER_DIR", None)
        os.environ.pop("UNISON_FAKE_MACHINE", None)
        self.tmp.cleanup()

    def on_pc(self, guid):
        lic.machine_id.cache_clear()
        return mock.patch.object(lic, "_raw_machine_id", return_value=guid)

    def test_dev_makes_working_keys_on_the_owner_pc(self):
        with self.on_pc("GUID-OWNER-PC"):
            st = issuer.status("dev")
            self.assertTrue(st["allowed"] and st["available"] and st["needs_password"] and st["matches_unison"])
            keys = issuer.mint("vault-pass", "Buyer", plan="pro", days=30, count=3, email="b@x.com")
            self.assertEqual(len(keys), 3)
            for k in keys:
                d = lic.parse(k["key"], any_pc=True)
                self.assertEqual(d["plan"], "pro")
            self.assertEqual(issuer.status("dev")["issued"], 3)
            self.assertEqual(issuer.recent(1)[0]["to"], "Buyer #3")
            # shares Key Studio's log format
            self.assertEqual(self.ks.log_read()[0]["email"], "b@x.com")
            with self.assertRaises(issuer.IssuerError):
                issuer.mint("wrong", "X")
            self.assertFalse(issuer.status("personal")["allowed"])

    def test_vault_copied_to_another_pc_is_useless(self):
        with self.on_pc("GUID-SOMEONE-ELSE"):
            st = issuer.status("dev")
            self.assertFalse(st["available"])
            with self.assertRaises(issuer.IssuerError) as ctx:
                issuer.mint("vault-pass", "Pirate")
            self.assertIn("owner's PC", str(ctx.exception))

    def test_refuses_a_signing_key_unison_wouldnt_accept(self):
        with self.on_pc("GUID-OWNER-PC"), mock.patch.object(authority, "PUBLIC_KEY", "x" * 43):
            with self.assertRaises(issuer.IssuerError):
                issuer.mint("vault-pass", "Buyer")


if __name__ == "__main__":
    unittest.main()
