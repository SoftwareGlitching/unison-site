# Upgrade UNISON's brain: a strong open-weight model (Google's Gemma 4 by default) packaged as UNISON's own model
# "unison", with UNISON's personality built in, then made the active model. Your chats and settings are kept.
# Also makes Ollama gentler on the GPU (flash attention, compact memory, one model at a time) and makes sure
# screen control has a model that can see.
#   -Base <tag>   use a different base model, e.g. -Base qwen3:14b
#   -Yes          accept every default
param([string]$Base = "", [switch]$Yes)

. (Join-Path $PSScriptRoot "common.ps1")
Set-Location $Root
try { Start-Transcript -Path (Join-Path $Root "logs\upgrade-brain.log") -Append | Out-Null } catch { }

function Stop-Upgrade([string]$msg) {
    Write-Bad $msg
    try { Stop-Transcript | Out-Null } catch { }
    if (-not $Yes) { Read-Host "Press Enter to close" }
    exit 1
}

Write-Host ""
Write-Host "  U N I S O N   brain upgrade" -ForegroundColor Cyan
if (-not (Test-Path $VenvPy)) { Stop-Upgrade "UNISON isn't set up yet. Run Setup.bat first." }

# ------------------------------------------------------------------ 1. pick the base model for this GPU
$vram = & $VenvPy -c "import json; d=json.load(open('config/hardware.json', encoding='utf-8-sig')); print(max([g.get('vram_gb') or 0 for g in d.get('gpus', []) if g.get('vendor') in ('nvidia','amd')] or [0]))" 2>$null
$vram = [double]($vram | Select-Object -First 1)
# Best first; if one won't download or run, the next is tried. Sizes are the download in GB.
if ($Base) { $candidates = @(@{ tag = $Base; size = 10 }) }
elseif ($vram -ge 11) { $candidates = @(@{ tag = "gemma4:12b"; size = 7.7 }, @{ tag = "qwen3:14b"; size = 9.3 }, @{ tag = "qwen3:8b"; size = 5.2 }) }
elseif ($vram -ge 7) { $candidates = @(@{ tag = "gemma4:e4b"; size = 6.6 }, @{ tag = "qwen3:8b"; size = 5.2 }) }
elseif ($vram -ge 5) { $candidates = @(@{ tag = "gemma4:e2b"; size = 4.6 }, @{ tag = "qwen3:4b"; size = 2.6 }) }
else { $candidates = @(@{ tag = "qwen3:4b"; size = 2.6 }, @{ tag = "gemma4:e2b"; size = 4.6 }) }
Write-Step "1/7" ("Brain for your GPU ($vram GB): " + $candidates[0].tag + " (~" + $candidates[0].size + " GB, one time)")

$ollama = Find-OllamaExe
if (-not $ollama) { Stop-Upgrade "Ollama isn't installed. Run Setup.bat first." }

# ------------------------------------------------------------------ 0. close UNISON and rebuild the app
Write-Step "0/7" "Closing UNISON and rebuilding the app with the latest fixes"
Get-Process -Name "UNISON" -ErrorAction SilentlyContinue | ForEach-Object { & taskkill /PID $_.Id /T /F 2>$null | Out-Null }
if (Test-Http "$UnisonUrl/v1/health") {
    Write-Warn2 "UNISON is still running in a console window. Close that window, then press Enter."
    if (-not $Yes) { Read-Host "   " }
}
Push-Location (Join-Path $Root "frontend")
& npm.cmd install --no-fund --no-audit --loglevel=error
& npm.cmd run build
$webOk = ($LASTEXITCODE -eq 0)
Pop-Location
if ($webOk) { Write-Ok "App rebuilt" } else { Write-Warn2 "The app rebuild failed (see above); the brain upgrade continues anyway." }
& (Join-Path $Root "desktop\build.ps1") -IfNeeded -Quiet

# ------------------------------------------------------------------ 2. gentler on the GPU
Write-Step "2/7" "Making Ollama gentler on your graphics card"
# flash attention + 8-bit memory (KV cache) roughly halve the memory a conversation needs; one model at a time
# stops two models fighting over VRAM (the cause of slow replies and 'CUDA error' crashes on 12 GB cards).
$gentle = [ordered]@{ OLLAMA_FLASH_ATTENTION = "1"; OLLAMA_KV_CACHE_TYPE = "q8_0"; OLLAMA_MAX_LOADED_MODELS = "1";
                     OLLAMA_NUM_PARALLEL = "1"; OLLAMA_KEEP_ALIVE = "10m" }
$changed = $false
foreach ($k in $gentle.Keys) {
    if ([Environment]::GetEnvironmentVariable($k, "User") -ne $gentle[$k]) {
        [Environment]::SetEnvironmentVariable($k, $gentle[$k], "User")
        $changed = $true
    }
    Set-Item -Path "Env:$k" -Value $gentle[$k]
}
if ($changed) {
    Write-Host "   Restarting Ollama so the new settings apply..."
    Get-Process -Name "ollama app", "ollama" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
}
if (-not (Start-OllamaIfNeeded)) { Stop-Upgrade "Ollama isn't running. Open Ollama from the Start menu and try again." }
Write-Ok "Flash attention on, compact 8-bit memory, one model loaded at a time, unloads after 10 idle minutes"

# ------------------------------------------------------------------ 3. room on disk
Write-Step "3/7" "Disk space"
$modelDir = [Environment]::GetEnvironmentVariable("OLLAMA_MODELS", "User")
if (-not $modelDir) { $modelDir = Join-Path $env:USERPROFILE ".ollama\models" }
$drive = (Split-Path -Qualifier $modelDir).TrimEnd(":")
$free = [math]::Round((Get-PSDrive $drive).Free / 1GB, 1)
$need = $candidates[0].size + 3
Write-Host "   Models live on ${drive}: ($free GB free)."
$haveFirst = (& $ollama list 2>$null | Out-String) -match [regex]::Escape($candidates[0].tag)
if (-not $haveFirst -and $free -lt $need) {
    $best = Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Name -ne $drive -and $_.Free -gt ($need + 5) * 1GB } |
            Sort-Object Free -Descending | Select-Object -First 1
    if (-not $best) { Stop-Upgrade "Not enough space: free at least $need GB on ${drive}: and run this again." }
    $target = "$($best.Name):\Ollama\models"
    Write-Warn2 "${drive}: is too full. Your $($best.Name): drive has $([math]::Round($best.Free / 1GB)) GB free."
    if (-not ($Yes -or (Ask-YesNo "Move Ollama's models to $target first? (nothing is downloaded again)" $true))) { exit 1 }
    & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot "move_models.ps1") -Target $target
    $env:OLLAMA_MODELS = [Environment]::GetEnvironmentVariable("OLLAMA_MODELS", "User")
    if (-not (Start-OllamaIfNeeded)) { Stop-Upgrade "Ollama didn't come back after the move. Open it from the Start menu and run this again." }
    Write-Ok "Models now on $target"
} else { Write-Ok "Enough space." }

# ------------------------------------------------------------------ 4+5. download and build UNISON's own model
$persona = (Get-Content (Join-Path $PSScriptRoot "brain\persona.txt") -Raw -Encoding UTF8).Trim()
$mfPath = Join-Path $Root "config\unison.Modelfile"
$built = $null
foreach ($c in $candidates) {
    $tag = $c.tag
    Write-Step "4/7" "Downloading $tag"
    if ((& $ollama list 2>$null | Out-String) -match [regex]::Escape($tag)) { Write-Ok "Already downloaded." }
    else {
        & $ollama pull $tag
        if ($LASTEXITCODE -ne 0) { Write-Warn2 "Couldn't download $tag (Ollama may need updating). Trying the next option."; continue }
        Write-Ok "Downloaded"
    }
    Write-Step "5/7" "Building UNISON's own model 'unison' on $tag"
    $mf = @"
FROM $tag
PARAMETER temperature 0.7
PARAMETER top_p 0.9
PARAMETER top_k 40
PARAMETER repeat_penalty 1.05
PARAMETER num_ctx 8192
SYSTEM """$persona"""
LICENSE """UNISON model by PerkyPop. Built on the open-weight $tag model; its own license applies (see https://ollama.com/library)."""
"@
    [IO.File]::WriteAllText($mfPath, $mf, (New-Object Text.UTF8Encoding $false))
    & $ollama create unison -f $mfPath
    if ($LASTEXITCODE -ne 0) { Write-Warn2 "Couldn't build on $tag. Trying the next option."; continue }
    & $VenvPy (Join-Path $PSScriptRoot "brain_check.py") unison
    if ($LASTEXITCODE -ne 0) { Write-Warn2 "$tag didn't answer properly on this PC. Trying the next option."; continue }
    $built = $tag
    break
}
if (-not $built) { Stop-Upgrade "None of the brains worked. Update Ollama (ollama.com/download) and run this again." }

& $VenvPy -c @"
from backend.core.config import settings
settings.set('inference', 'active_model', 'unison')
for k, v in {'temperature': 0.7, 'top_p': 0.9, 'top_k': 40, 'repeat_penalty': 1.05, 'num_ctx': 8192,
             'max_ctx': 8192, 'keep_alive': '10m', 'think': False}.items():
    settings.set('inference', k, v)
settings.set('assistant', 'system_prompt', open('scripts/brain/persona.txt', encoding='utf-8').read().strip())
"@
Write-Ok "UNISON now runs on its own model 'unison' (built on $built), with an 8K-token memory that fits on the GPU."

# ------------------------------------------------------------------ 6. screen control needs a model that can see
Write-Step "6/7" "Screen control (a model that can see your screen)"
if ($vram -ge 7) { $vm = "qwen3-vl:8b" } elseif ($vram -ge 4) { $vm = "qwen3-vl:4b" } else { $vm = "qwen3-vl:2b" }
if ((& $ollama list 2>$null | Out-String) -match [regex]::Escape($vm)) {
    Write-Ok "$vm is ready"
} elseif ($Yes -or (Ask-YesNo "Download $vm for screen control? (about 6 GB)" $true)) {
    & $ollama pull $vm
    if ($LASTEXITCODE -eq 0) { Write-Ok "Downloaded $vm" } else { Write-Warn2 "Download failed; screen control won't work until $vm is downloaded." }
}
& $VenvPy -c "import sys; from backend.core.config import settings; settings.set('computer', 'vision_model', sys.argv[1])" $vm
Write-Ok "Screen control uses $vm. The chat brain is unloaded while it works, so they never fight over VRAM."

# ------------------------------------------------------------------ 7. tidy up
Write-Step "7/7" "Old brains"
$old = @("qwen3:14b", "qwen3:8b", "qwen2.5-coder:14b") | Where-Object { $_ -ne $built -and ((& $ollama list 2>$null | Out-String) -match [regex]::Escape($_)) }
foreach ($o in $old) {
    if ($Yes -or (Ask-YesNo "Delete the old model $o to free disk space? (UNISON doesn't use it anymore)" $true)) {
        & $ollama rm $o | Out-Null
        Write-Ok "Deleted $o"
    }
}

try { Stop-Transcript | Out-Null } catch { }
Write-Host ""
Write-Host "  Done. UNISON now runs on $built." -ForegroundColor Green
$app = Join-Path $Root "UNISON.exe"
$launcher = if (Test-Path $app) { $app } else { Join-Path $Root "Start-UNISON.bat" }
if ($Yes -or (Ask-YesNo "Open UNISON now?" $true)) { Start-Process -FilePath $launcher -WorkingDirectory $Root }
