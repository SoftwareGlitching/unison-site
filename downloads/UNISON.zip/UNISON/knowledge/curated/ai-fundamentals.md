# AI fundamentals: how UNISON works

## Transformers in one page
- Text is split into tokens (sub-word pieces, ~3–4 characters of English each). Each token id maps to an
  embedding vector.
- A transformer layer = self-attention + a feed-forward network, each wrapped with residual connections and
  normalisation. Models stack dozens of layers.
- Self-attention: every token makes a query Q, key K and value V (linear projections). Scores =
  softmax(Q·Kᵀ / √d) say how much each token looks at each earlier token (causal mask); the output is the
  score-weighted sum of V. Multiple heads attend to different relationships in parallel.
- Generation is autoregressive: predict a probability for every next token, sample one (temperature,
  top-p, top-k control randomness), append it, repeat. The KV cache stores past keys/values so each new
  token is cheap; its size grows with the context length, which is why long contexts use more VRAM.
- Quantisation (e.g. Q4_K_M) stores weights in ~4–5 bits instead of 16, shrinking memory ~3–4x with a
  small quality loss. That's how 7B–30B models fit on consumer GPUs.

## Embeddings and RAG
- An embedding model maps text to a vector; similar meaning → nearby vectors (cosine similarity).
- Retrieval-augmented generation: split documents into chunks, embed them once, and at question time
  embed the question, find the nearest chunks, and paste them into the prompt.
- RAG adds knowledge at answer time and is easy to update. It does NOT change what the model is able to
  do in general; fine-tuning changes the weights.

## Fine-tuning
- Supervised fine-tuning (SFT): train on (prompt → ideal reply) examples.
- LoRA: freeze the base model and train small low-rank matrices added to some layers (a few MB to a few
  hundred MB). QLoRA does this on a 4-bit quantised base so 7B–8B models can be tuned on ~8–12 GB VRAM.
- Preference training (DPO): train on (prompt, chosen, rejected) pairs to prefer better answers.
- Quality of data matters more than quantity, but small datasets (< a few hundred examples) rarely move a
  model much. Always measure on a held-out benchmark before and after; watch for regressions elsewhere.
- Adapters can be loaded on top of the same base model in Ollama with an `ADAPTER` line in a Modelfile,
  keeping the original model untouched.

## Agents and tool calling
- The model is given tool definitions (name, description, JSON-schema parameters). Instead of answering,
  it can emit a structured call; the runtime executes it and returns the result as a `tool` message;
  the model continues until it can answer.
- Good agent loops: look before acting, small verifiable steps, run tests after changes, stop when done,
  cap the number of steps, and require human approval for risky actions.

## MCP (Model Context Protocol)
- An open protocol for connecting AI apps to tools and data. A client (UNISON) starts or connects to MCP
  servers; servers expose tools (`tools/list`, `tools/call`), resources and prompts over JSON-RPC 2.0,
  commonly via stdio (one JSON message per line) or HTTP.
- Session: client sends `initialize` (protocol version, capabilities) → server replies → client sends
  `notifications/initialized` → then lists and calls tools. Clients can expose "roots" (allowed folders).
