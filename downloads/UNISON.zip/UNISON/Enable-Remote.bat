@echo off
rem Private remote access to UNISON from your phone (Tailscale). Use "Enable-Remote.bat -Off" to turn it off.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\remote.ps1" %*
