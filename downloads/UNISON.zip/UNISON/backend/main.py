"""UNISON application: API under /v1, interactive docs at /docs, web app at /."""
from __future__ import annotations

import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from . import __version__
from .api.routes import router
from .api.routes_agent import router as agent_router
from .api.routes_auth import router as auth_router
from .api.routes_jobs import router as jobs_router
from .api.routes_license import router as license_router
from .core.config import FRONTEND_DIST
from .inference.base import InferenceError
from .knowledge.tool import TOOL as KNOWLEDGE_TOOL
from .mcp.client import mcp_manager
from .security import sessions
from .security.auth import PUBLIC_PATHS, guest_of, is_remote, log_request, request_authorized
from .tools.registry import registry


@asynccontextmanager
async def lifespan(_app: FastAPI):
    from .agents.approvals import broker
    from .agents.jobs import JobRunner, set_runner
    from .database.db import get_db
    from .inference.manager import manager
    registry.register(KNOWLEDGE_TOOL)
    await mcp_manager.start_enabled()
    runner = JobRunner(get_db(), manager, broker)
    set_runner(runner)
    runner.start()
    yield
    await runner.shutdown()
    set_runner(None)
    await mcp_manager.stop_all()


app = FastAPI(
    lifespan=lifespan,
    title="UNISON API",
    version=__version__,
    description="Private, self-hosted AI. Every request is served by a model running on this computer. "
                "OpenAI-compatible endpoint: POST /v1/chat/completions.",
    docs_url="/docs",
    redoc_url="/redoc",
)

@app.middleware("http")
async def remote_owner_check(request: Request, call_next):
    """Requests through Tailscale (remote access) carry the signed-in Tailscale user; only the owner may in."""
    login = request.headers.get("tailscale-user-login")
    if login and not remote_allowed(login):
        return JSONResponse(status_code=403, content={"error": {"code": "not_owner",
                            "message": f"{login} is not allowed to use this UNISON"}})
    return await call_next(request)


LICENSE_FREE_PATHS = {"/v1/health", "/v1/license/status", "/v1/license/activate", "/v1/license/deactivate",
                      "/v1/auth/status", "/v1/auth/login", "/v1/auth/setup", "/v1/auth/change", "/v1/auth/logout_all"}


@app.middleware("http")
async def require_license(request: Request, call_next):
    """Without an activated license key, only sign-in and activation work."""
    path = request.url.path
    if path.startswith("/v1") and path not in LICENSE_FREE_PATHS:
        from .licensing.license import is_activated
        if not is_activated():
            return JSONResponse(status_code=402, content={"error": {"code": "license_required",
                                "message": "Activate UNISON with a license key."}})
    return await call_next(request)


@app.middleware("http")
async def require_signin(request: Request, call_next):
    """Once a password is set, every /v1 call (except health and the sign-in endpoints) needs a session
    token or an API key — local or remote. This is the real lock for remote access."""
    path = request.url.path
    remote = is_remote(request)
    if remote and path in ("/docs", "/redoc", "/openapi.json", "/docs/oauth2-redirect"):
        return JSONResponse(status_code=404, content={"error": {"code": "not_found", "message": "Not found"}})
    request.state.guest = None
    if path.startswith("/v1") and path not in PUBLIC_PATHS:
        if sessions.password_set():
            kid = guest_of(request)            # website visitor with a license key: chat only
            if kid:
                request.state.guest = kid
                return await call_next(request)
            if not request_authorized(request):
                return JSONResponse(status_code=401, content={"error": {"code": "auth_required",
                                    "message": "Please sign in."}})
        elif remote:
            # Never serve another device without a password — that would hand your PC to anyone with the link.
            return JSONResponse(status_code=403, content={"error": {"code": "password_required",
                                "message": "Set a sign-in password on the PC before using UNISON from other devices."}})
    return await call_next(request)


def remote_allowed(login: str) -> bool:
    from .core.config import settings
    allowed = [a.lower() for a in (settings.get("remote", "allowed_logins") or [])]
    return not allowed or login.lower() in allowed


APP_CSP = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; "
           "font-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; "
           "frame-ancestors 'none'")


@app.middleware("http")
async def security_headers(request: Request, call_next):
    """Browser hardening for everything UNISON serves - matters most for the public link."""
    response = await call_next(request)
    h = response.headers
    h.setdefault("X-Content-Type-Options", "nosniff")
    h.setdefault("X-Frame-Options", "DENY")
    h.setdefault("Referrer-Policy", "no-referrer")
    h.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=(), usb=()")
    h.setdefault("Cross-Origin-Opener-Policy", "same-origin")
    if (h.get("content-type") or "").startswith("text/html") and request.url.path != "/docs" \
            and not request.url.path.startswith("/redoc"):
        h.setdefault("Content-Security-Policy", APP_CSP)
    if is_remote(request):
        h.setdefault("Strict-Transport-Security", "max-age=31536000")
        if request.url.path.startswith("/v1"):
            h.setdefault("Cache-Control", "no-store")
    return response


@app.middleware("http")
async def access_log(request: Request, call_next):
    start = time.perf_counter()
    status = 500
    try:
        response = await call_next(request)
        status = response.status_code
        return response
    finally:
        if request.url.path.startswith("/v1"):
            log_request(request, status, (time.perf_counter() - start) * 1000)


@app.exception_handler(InferenceError)
async def inference_error(_: Request, exc: InferenceError):
    from .core.chat_service import log_error
    log_error("", exc)
    return JSONResponse(status_code=exc.status, content={"error": {"code": exc.code, "message": str(exc)}})


@app.exception_handler(HTTPException)
async def http_error(_: Request, exc: HTTPException):
    detail = exc.detail if isinstance(exc.detail, dict) else {"code": "error", "message": str(exc.detail)}
    return JSONResponse(status_code=exc.status_code, content={"error": detail}, headers=exc.headers)


def cors_origins() -> list[str]:
    """The Vite dev server, plus the public website (so its browser chat can talk to this PC through the
    public link). Only the origin is allowed - the site itself never gets owner access: owner calls still
    need the password session, and guests may only chat."""
    from urllib.parse import urlsplit
    from .core.config import settings
    origins = ["http://127.0.0.1:5173", "http://localhost:5173"]
    for u in [settings.get("site", "url") or ""] + list(settings.get("remote", "allowed_origins") or []):
        parts = urlsplit(u.strip())
        if parts.scheme == "https" and parts.netloc:
            origins.append(f"https://{parts.netloc.lower()}")
    return sorted(set(origins))


# Added last = outermost, so preflight (OPTIONS) requests are answered before the sign-in/license checks
# and error responses still carry the CORS headers the browser needs to read them.
app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins(),
    allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "X-API-Key"],
    max_age=600,
)

app.include_router(auth_router)
app.include_router(license_router)
app.include_router(router)
app.include_router(agent_router)
app.include_router(jobs_router)

if (FRONTEND_DIST / "index.html").exists():
    app.mount("/", StaticFiles(directory=FRONTEND_DIST, html=True), name="web")
else:
    @app.get("/", include_in_schema=False)
    async def no_frontend():
        return HTMLResponse(
            "<body style='font-family:system-ui;background:#0b0d10;color:#ddd;padding:40px'>"
            "<h2>UNISON API is running</h2><p>The web app has not been built yet. Run <b>Setup.bat</b> "
            "(or <code>cd frontend &amp;&amp; npm install &amp;&amp; npm run build</code>).</p>"
            "<p>API docs: <a style='color:#7cc4ff' href='/docs'>/docs</a></p></body>")
