"""One screen-control run at a time, shared by the API."""
from __future__ import annotations

import sys
from typing import Optional

from ..core.config import settings
from .agent import ScreenAgent

DEFAULT_VISION_MODEL = "qwen3-vl:8b"
VISION_MODELS = ["qwen3-vl:2b", "qwen3-vl:4b", "qwen3-vl:8b", "qwen3-vl:30b", "qwen2.5vl:7b"]

_current: Optional[ScreenAgent] = None


# Families that can read images, for when Ollama can't tell us (older versions, offline checks).
_VISION_HINTS = ("-vl", "vl:", "vision", "llava", "minicpm-v", "gemma3:", "gemma4", "moondream", "bonsai-2",
                 "mistral-small3", "granite3.2-vision", "llama4", "mimo-v")


def vision_model() -> str:
    return settings.get("computer", "vision_model") or DEFAULT_VISION_MODEL


def looks_like_vision(name: str) -> bool:
    n = (name or "").lower()
    return any(h in n for h in _VISION_HINTS) and not n.startswith("gemma3:1b")


def _installed(name: str, installed: set) -> bool:
    return name in installed or f"{name}:latest" in installed


async def pick_vision_model(backend, requested: Optional[str] = None) -> tuple[Optional[str], str]:
    """The model screen control should use: one that can SEE screenshots. A text-only chat model (like a
    'unison' brain built on a text model) can't, and would just fail to give actions. Returns
    (model, "") or (None, reason)."""
    installed = {m.name for m in await backend.list_models()}

    async def can_see(name: str) -> bool:
        if not name or not _installed(name, installed):
            return False
        caps = []
        if hasattr(backend, "capabilities"):
            try:
                caps = await backend.capabilities(name)
            except Exception:  # noqa: BLE001
                caps = []
        if caps:
            return "vision" in caps            # Ollama knows: trust it
        return name == requested or name == vision_model() or looks_like_vision(name)

    for name in (requested, vision_model(), *VISION_MODELS):
        if name and await can_see(name):
            return name, ""
    want = vision_model()
    return None, (f"Screen control needs a vision model (one that can see screenshots), and none is downloaded. "
                  f"Open Settings -> Screen to download {want}, or run: ollama pull {want}")


async def free_vram_for(backend, model: str) -> None:
    """Unload every other model so the vision model gets the whole GPU (two models rarely fit in 12 GB)."""
    if not hasattr(backend, "loaded_models") or not hasattr(backend, "unload"):
        return
    try:
        for m in await backend.loaded_models():
            name = m.get("name") or ""
            if name and name not in (model, f"{model}:latest") and f"{name}:latest" != model:
                await backend.unload(name)
    except Exception:  # noqa: BLE001
        pass


def supported() -> tuple[bool, str]:
    if sys.platform != "win32":
        return False, "Screen control is only available on Windows."
    return True, ""


def current() -> Optional[ScreenAgent]:
    return _current


def set_current(agent: Optional[ScreenAgent]) -> None:
    global _current
    _current = agent


def stop_current(reason: str = "Stopped from the app") -> bool:
    if _current is None:
        return False
    _current.stop(reason)
    return True
