"""Screen-control agent against a simulated desktop and the Ollama test double."""
import asyncio
import json
import tempfile
import unittest
from pathlib import Path

from tests.helpers import IsolatedSettings  # noqa: F401 (sets up sys.path / httpx)

from PIL import Image

from backend.agents.approvals import ApprovalBroker
from backend.computer.agent import ScreenAgent
from backend.computer.desktop import WindowInfo
from backend.database.db import Database
from backend.inference.ollama_backend import OllamaBackend
from tests.fake_ollama import FakeOllama

VISION = "test-vision:1b"


class FakeDesktop:
    """Records actions instead of moving the real mouse."""

    def __init__(self, w=1920, h=1080, foreground_title="Untitled - Notepad"):
        self.w, self.h = w, h
        self.actions = []
        self.esc = False
        self.cursor_pos = (900, 500)
        self.fg = WindowInfo(222, foreground_title, (0, 0, w, h - 40))
        self.unison = WindowInfo(111, "UNISON - Google Chrome", (1300, 0, 1920, 1040))
        self.first_fg = self.unison
        self.minimized = []
        self.injecting_until = 0
        self.can_run = True

    def run_program(self, command):
        self.actions.append(("run", command))
        return self.can_run

    def size(self): return self.w, self.h
    def capture(self): return Image.new("RGB", (self.w, self.h), (30, 30, 30))
    def cursor(self): return self.cursor_pos

    def foreground(self):
        if self.first_fg is not None:   # the run starts with the UNISON browser in front
            f, self.first_fg = self.first_fg, None
            return f
        return self.fg

    def focus(self, handle): self.actions.append(("focus", handle)); return True
    def minimize(self, handle): self.minimized.append(handle)
    def restore(self, handle): self.actions.append(("restore", handle))
    def click(self, x, y, button="left", count=1): self.actions.append(("click", x, y, button, count))
    def move(self, x, y): self.actions.append(("move", x, y))
    def drag(self, *a): self.actions.append(("drag", *a))
    def scroll(self, x, y, clicks): self.actions.append(("scroll", x, y, clicks))
    def type_text(self, text): self.actions.append(("type", text))
    def press(self, combo): self.actions.append(("key", combo))
    def key_down_now(self, name): return self.esc and name == "esc"


def act(_action, **args):
    return {"content": f"I'll {_action}.\n<tool_call>\n" + json.dumps({"name": _action, "arguments": args}) + "\n</tool_call>"}


def script(*replies):
    """Responder returning the next reply each time the model is asked."""
    it = iter(replies)
    seen = []

    def brain(body):
        seen.append(body)
        assert body["messages"][-1].get("images"), "every step must include the screenshot"
        return next(it, act("done", summary="finished"))
    brain.seen = seen
    return brain


async def run(agent, task, approve=lambda e: True):
    events = []
    loop = asyncio.get_running_loop()
    async for ev in agent.run(task):
        events.append(ev)
        if ev["type"] == "approval_required":
            loop.call_later(0.01, agent.approvals.resolve, ev["action_id"], approve(ev), "")
    return events


class ScreenAgentTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self.tmp.name) / "s.db")

    def tearDown(self):
        self.db._conn.close()
        self.tmp.cleanup()

    def agent(self, fake, desk, autopilot=True):
        return ScreenAgent(desk, OllamaBackend(fake.url), VISION, ApprovalBroker(), autopilot=autopilot,
                           db=self.db, settle=0, sleep=lambda s: None)

    def test_autopilot_notepad_task(self):
        brain = script(act("open_app", name="notepad"), act("click", x=500, y=500),
                       act("type", text="Hello from UNISON"), act("key", keys="ctrl+s"),
                       act("done", summary="Typed the text and opened Save"))
        desk = FakeDesktop()
        with FakeOllama(models=(VISION,), responder=brain) as fake:
            evs = asyncio.run(run(self.agent(fake, desk), "write hello in notepad"))
        self.assertEqual(evs[-1]["status"], "done")
        self.assertEqual(evs[-1]["summary"], "Typed the text and opened Save")
        self.assertIn(("run", "notepad"), desk.actions)
        self.assertIn(("click", 960, 540, "left", 1), desk.actions)          # 500/1000 of 1920x1080
        self.assertIn(("type", "Hello from UNISON"), desk.actions)
        self.assertIn(("key", "ctrl+s"), desk.actions)
        self.assertEqual(desk.minimized, [111])                              # UNISON window got out of the way
        self.assertIn(("restore", 111), desk.actions)                        # and came back
        sent = fake.requests[-1]["body"]
        self.assertFalse(sent["think"])
        self.assertIn("Actions so far", json.dumps(sent["messages"]))
        roles = [m["role"] for m in self.db.messages(evs[0]["conversation_id"])]
        self.assertEqual(roles[0], "user")
        self.assertEqual(roles[-1], "assistant")

    def test_open_chrome_uses_run_program_and_aliases(self):
        brain = script(act("open_app", name="google chrome"), act("key", keys="ctrl+t"),
                       act("done", summary="opened chrome and a new tab"))
        desk = FakeDesktop()
        with FakeOllama(models=(VISION,), responder=brain) as fake:
            evs = asyncio.run(run(self.agent(fake, desk), "open chrome and a new tab"))
        self.assertEqual(evs[-1]["status"], "done")
        self.assertIn(("run", "chrome"), desk.actions)          # "google chrome" → chrome
        self.assertIn(("key", "ctrl+t"), desk.actions)

    def test_open_app_falls_back_to_run_dialog(self):
        brain = script(act("open_app", name="chrome"), act("done", summary="x"))
        desk = FakeDesktop()
        desk.can_run = False                                     # ShellExecute unavailable
        with FakeOllama(models=(VISION,), responder=brain) as fake:
            asyncio.run(run(self.agent(fake, desk), "open chrome"))
        self.assertIn(("key", "win+r"), desk.actions)
        self.assertIn(("type", "chrome"), desk.actions)
        self.assertIn(("key", "enter"), desk.actions)

    def test_step_mode_asks_and_respects_deny(self):
        brain = script(act("click", x=100, y=100), act("click", x=200, y=200), act("done", summary="ok"))
        desk = FakeDesktop()
        answers = iter([False, True])
        with FakeOllama(models=(VISION,), responder=brain) as fake:
            evs = asyncio.run(run(self.agent(fake, desk, autopilot=False), "t", approve=lambda e: next(answers)))
        approvals = [e for e in evs if e["type"] == "approval_required"]
        self.assertEqual(len(approvals), 2)
        self.assertEqual(approvals[0]["preview"]["kind"], "screen")
        self.assertTrue(approvals[0]["preview"]["image"])                    # marked screenshot
        clicks = [a for a in desk.actions if a[0] == "click"]
        self.assertEqual(clicks, [("click", 384, 216, "left", 1)])           # only the approved one ran
        self.assertEqual(desk.minimized, [])                                 # step mode keeps UNISON visible

    def test_cannot_click_or_type_into_unison_itself(self):
        brain = script(act("click", x=900, y=300), act("done", summary="x"))
        desk = FakeDesktop()
        with FakeOllama(models=(VISION,), responder=brain) as fake:
            evs = asyncio.run(run(self.agent(fake, desk, autopilot=False), "approve yourself"))
        results = [e for e in evs if e["type"] == "action_result"]
        self.assertFalse(results[0]["ok"])
        self.assertIn("UNISON's own window", results[0]["message"])
        self.assertNotIn("approval_required", [e["type"] for e in evs])
        self.assertEqual([a for a in desk.actions if a[0] == "click"], [])

    def test_dangerous_text_is_not_typed(self):
        brain = script(act("type", text="format c: /q"), act("done", summary="x"))
        desk = FakeDesktop()
        with FakeOllama(models=(VISION,), responder=brain) as fake:
            evs = asyncio.run(run(self.agent(fake, desk), "t"))
        self.assertNotIn(("type", "format c: /q"), desk.actions)
        self.assertIn("dangerous", [e for e in evs if e["type"] == "action_result"][0]["message"])

    def test_typing_refocuses_the_window_the_model_saw(self):
        brain = script(act("type", text="abc"), act("done", summary="x"))
        desk = FakeDesktop()
        with FakeOllama(models=(VISION,), responder=brain) as fake:
            asyncio.run(run(self.agent(fake, desk, autopilot=False), "t"))
        i = desk.actions.index(("type", "abc"))
        self.assertEqual(desk.actions[i - 1], ("focus", 222))

    def test_escape_stops_the_run(self):
        desk = FakeDesktop()

        def brain(body):
            desk.esc = True                                   # the user presses Esc while the model thinks
            return act("click", x=10, y=10)
        with FakeOllama(models=(VISION,), responder=brain) as fake:
            evs = asyncio.run(run(self.agent(fake, desk), "t"))
        self.assertEqual(evs[-1]["status"], "stopped")
        self.assertIn("Esc", evs[-1]["summary"])
        self.assertEqual([a for a in desk.actions if a[0] == "click"], [])

    def test_corner_failsafe(self):
        desk = FakeDesktop()
        desk.cursor_pos = (0, 0)
        with FakeOllama(models=(VISION,), responder=lambda b: act("click", x=500, y=500)) as fake:
            evs = asyncio.run(run(self.agent(fake, desk), "t"))
        self.assertEqual(evs[-1]["status"], "stopped")

    def test_bad_replies_then_give_up(self):
        with FakeOllama(models=(VISION,), responder=lambda b: {"content": "I see a desktop."}) as fake:
            evs = asyncio.run(run(self.agent(fake, FakeDesktop()), "t"))
        self.assertEqual(evs[-1]["status"], "failed")
        self.assertEqual(sum(1 for e in evs if e["type"] == "notice"), 3)

    def test_pixel_coordinates_from_older_models(self):
        # Qwen2.5-VL answers in pixels of the 1280-wide image it was shown.
        brain = script(act("click", x=1279, y=10), act("done", summary="x"))
        desk = FakeDesktop()
        with FakeOllama(models=(VISION,), responder=brain) as fake:
            asyncio.run(run(self.agent(fake, desk), "t"))
        click = [a for a in desk.actions if a[0] == "click"][0]
        self.assertGreater(click[1], 1900)

    def test_missing_coordinates_are_reported_not_executed(self):
        brain = script(act("click", x=100), act("done", summary="x"))
        desk = FakeDesktop()
        with FakeOllama(models=(VISION,), responder=brain) as fake:
            evs = asyncio.run(run(self.agent(fake, desk), "t"))
        self.assertFalse([e for e in evs if e["type"] == "action_result"][0]["ok"])
        self.assertEqual([a for a in desk.actions if a[0] == "click"], [])


if __name__ == "__main__":
    unittest.main()
