# Steps shared by Setup.bat and Update.bat after the app is built:
# embedding model, knowledge index, workspace choice, tests and the real-model self-test.
param([switch]$Yes)

. (Join-Path $PSScriptRoot "common.ps1")
Set-Location $Root

# ------------------------------------------------------------------------------------------
Write-Step "A" "Embedding model for the knowledge base (nomic-embed-text, ~0.3 GB)"
$ollama = Find-OllamaExe
if (-not (Start-OllamaIfNeeded)) { Write-Bad "Ollama isn't running; skipping."; return }
$have = & $ollama list 2>$null | Out-String
if ($have -match "nomic-embed-text") { Write-Ok "Already downloaded." }
else {
    & $ollama pull nomic-embed-text
    if ($LASTEXITCODE -eq 0) { Write-Ok "Downloaded" } else { Write-Warn2 "Download failed; the knowledge base stays off until it succeeds (run Update.bat again)." }
}

# ------------------------------------------------------------------------------------------
Write-Step "B" "Indexing UNISON's programming notes"
& $VenvPy (Join-Path $Root "scripts\index_knowledge.py")

# ------------------------------------------------------------------------------------------
Write-Step "C" "Where may UNISON create and edit files?"
$current = & $VenvPy -c "from backend.tools.sandbox import workspaces; print(workspaces.default)" 2>$null
Write-Host "   Current default workspace: $current"
$desktop = & $VenvPy -c "from backend.tools.sandbox import desktop_path; print(desktop_path() or '')" 2>$null
if (-not $Yes -and $desktop) {
    Write-Host "   1) A new folder on your Desktop: $desktop\UNISON Projects   <- recommended"
    Write-Host "   2) Your whole Desktop folder"
    Write-Host "   3) Keep the current setting"
    $ans = Read-Host "   Choose [1-3, Enter = 3]"
    $target = $null
    if ($ans -eq "1") {
        $target = Join-Path $desktop "UNISON Projects"
        New-Item -ItemType Directory -Force -Path $target | Out-Null
    } elseif ($ans -eq "2") { $target = $desktop }
    if ($target) {
        & $VenvPy -c "import sys; from backend.tools.sandbox import workspaces; workspaces.add(sys.argv[1]); workspaces.make_default(sys.argv[1]); print('   default workspace:', workspaces.default)" "$target"
    }
}
Write-Host "   You can add more folders any time in the app: Settings -> PC access." -ForegroundColor DarkGray

# ------------------------------------------------------------------------------------------
Write-Step "D" "Vision model for screen control (optional)"
$modelDir = [Environment]::GetEnvironmentVariable("OLLAMA_MODELS", "User")
if (-not $modelDir) { $modelDir = Join-Path $env:USERPROFILE ".ollama\models" }
$mdrive = (Split-Path -Qualifier $modelDir).TrimEnd(":")
$free = [math]::Round((Get-PSDrive $mdrive).Free / 1GB, 1)
$vram = & $VenvPy -c "import json; d=json.load(open('config/hardware.json', encoding='utf-8-sig')); print(max([g.get('vram_gb') or 0 for g in d.get('gpus', []) if g.get('vendor') in ('nvidia','amd')] or [0]))" 2>$null
$vram = [double]($vram | Select-Object -First 1)
if ($vram -ge 7) { $vm = "qwen3-vl:8b"; $vsize = 6.2 } elseif ($vram -ge 4) { $vm = "qwen3-vl:4b"; $vsize = 3.3 } else { $vm = "qwen3-vl:2b"; $vsize = 1.9 }
Write-Host "   Models are stored on ${mdrive}: ($free GB free). Suggested for your GPU: $vm ($vsize GB)."
$haveVm = (& $ollama list 2>$null | Out-String) -match [regex]::Escape($vm)
if ($haveVm) {
    Write-Ok "$vm already downloaded"
} elseif ($free -lt ($vsize + 3)) {
    Write-Warn2 "Not enough space on ${mdrive}: for $vm. Run Move-Models.bat to move Ollama's models to another drive, then Update.bat again."
} elseif ($Yes -or (Ask-YesNo "Download $vm now?" $true)) {
    & $ollama pull $vm
    if ($LASTEXITCODE -eq 0) {
        & $VenvPy -c "import sys; from backend.core.config import settings; settings.set('computer', 'vision_model', sys.argv[1])" $vm
        Write-Ok "Screen control will use $vm"
    } else { Write-Warn2 "Download failed; try again later with Update.bat." }
}

# ------------------------------------------------------------------------------------------
Write-Step "L" "License"
$lic = (& $VenvPy -c "from backend.licensing import license as l; s=l.status(force=True); print('yes' if s['activated'] else 'no')" 2>$null | Select-Object -Last 1)
if ($lic -eq "yes") {
    Write-Ok "UNISON is activated."
} elseif (Test-Path (Join-Path $Root "scripts\license_admin.py")) {
    Write-Host "   You have the owner tools. Set up your license signing key and unlock this PC?"
    if ($Yes -or (Ask-YesNo "Run owner license setup now?" $true)) {
        & $VenvPy (Join-Path $Root "scripts\license_admin.py") setup
    }
} else {
    Write-Warn2 "Not activated yet. Start UNISON and paste your license key on the activation screen."
}

# ------------------------------------------------------------------------------------------
Write-Step "E" "Automated tests"
& $VenvPy -m unittest discover -s tests -t . 2>&1 | Select-Object -Last 4 | ForEach-Object { Write-Host "   $_" }

# ------------------------------------------------------------------------------------------
Write-Step "F" "End-to-end self-test with the real model (chat, knowledge, agent)"
$server = $null
if (-not (Test-Http "$UnisonUrl/v1/health")) {
    $server = Start-Process -FilePath $VenvPy -ArgumentList "-m", "backend.run" -WorkingDirectory $Root -PassThru `
        -WindowStyle Hidden -RedirectStandardOutput (Join-Path $Root "logs\selftest-server.log") `
        -RedirectStandardError (Join-Path $Root "logs\selftest-server.err.log")
    $up = $false
    for ($k = 0; $k -lt 60; $k++) { Start-Sleep -Milliseconds 500; if (Test-Http "$UnisonUrl/v1/health") { $up = $true; break } }
    if (-not $up) {
        if ($server -and -not $server.HasExited) { Stop-Process -Id $server.Id -Force }
        Write-Bad "The UNISON server did not start. See logs\selftest-server.err.log."
        return
    }
}
Write-Host "   The first reply loads the model; agent steps can take a few minutes on slower PCs." -ForegroundColor DarkGray
& $VenvPy (Join-Path $Root "scripts\selftest.py")
$script:SelfTestOk = ($LASTEXITCODE -eq 0)
if ($server -and -not $server.HasExited) { Stop-Process -Id $server.Id -Force }
