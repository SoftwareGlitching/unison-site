"""
API keys, authentication, rate limiting and request logging.

- Keys look like `unison-<random>`; only a SHA-256 hash is stored, the key itself is shown once.
- While UNISON listens on localhost only, the bundled web app needs no key (nothing else can reach it).
- If you expose UNISON to your network, run.py refuses to start unless keys are required and TLS is set.
"""
from __future__ import annotations

import hashlib
import json
import logging
import secrets
import threading
import time
from logging.handlers import RotatingFileHandler
from typing import Optional

from fastapi import HTTPException, Request

from ..core.config import LOG_DIR, settings
from ..database.db import get_db
from . import sessions

LOOPBACK = {"127.0.0.1", "::1", "localhost"}

# Paths reachable without a session, even once a password is set.
PUBLIC_PATHS = {"/v1/health", "/v1/auth/status", "/v1/auth/login", "/v1/auth/setup", "/v1/license/status",
                "/v1/auth/key-login"}
# The only thing a website guest (signed in with a license key) may do: chat with the active model.
GUEST_PATHS = {"/v1/chat/completions"}
# License plans with extra privileges (higher website limits, the in-app key generator on the owner's PC).
PRIVILEGED_PLANS = {"owner", "dev"}

# ---------------- keys ----------------

def hash_key(key: str) -> str:
    return hashlib.sha256(key.encode("utf-8")).hexdigest()


def create_api_key(name: str) -> tuple[str, dict]:
    key = "unison-" + secrets.token_urlsafe(32)
    record = get_db().add_api_key(name, key[:14], hash_key(key))
    return key, record


def _extract_key(request: Request) -> Optional[str]:
    auth = request.headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        return auth[7:].strip()
    return request.headers.get("x-api-key")


def is_loopback(request: Request) -> bool:
    """True when the TCP connection comes from this PC. NOTE: Tailscale serve/funnel and other tunnels also
    connect from 127.0.0.1, so use is_truly_local() to know whether a *person at this PC* sent it."""
    return bool(request.client) and request.client.host in LOOPBACK


PROXY_HEADERS = ("x-forwarded-for", "forwarded", "x-forwarded-host", "x-real-ip", "cf-connecting-ip",
                 "tailscale-user-login", "tailscale-funnel-request", "tailscale-headers-info")
LOCAL_HOSTS = {"127.0.0.1", "localhost", "::1", "[::1]"}


def _host_name(request: Request) -> str:
    host = (request.headers.get("host") or "").strip().lower()
    if host.startswith("["):
        return host.split("]")[0] + "]"
    return host.rsplit(":", 1)[0] if host.count(":") == 1 else host


def is_truly_local(request: Request) -> bool:
    """A browser or script on this PC talking to 127.0.0.1/localhost directly — not through a tunnel/proxy."""
    if not is_loopback(request):
        return False
    if any(request.headers.get(h) for h in PROXY_HEADERS):
        return False
    return _host_name(request) in LOCAL_HOSTS


def client_ip(request: Request) -> str:
    """The real visitor address (first X-Forwarded-For hop for proxied requests)."""
    if not is_truly_local(request):
        xff = request.headers.get("x-forwarded-for") or request.headers.get("cf-connecting-ip") or ""
        if xff:
            return xff.split(",")[0].strip()
    return request.client.host if request.client else "?"


# ---------------- rate limiting ----------------

class TokenBucket:
    def __init__(self) -> None:
        self._buckets: dict[str, tuple[float, float]] = {}
        self._lock = threading.Lock()

    def allow(self, ident: str, per_minute: int) -> tuple[bool, float]:
        if per_minute <= 0:
            return True, 0.0
        now = time.monotonic()
        rate = per_minute / 60.0
        with self._lock:
            tokens, last = self._buckets.get(ident, (float(per_minute), now))
            tokens = min(float(per_minute), tokens + (now - last) * rate)
            if tokens >= 1:
                self._buckets[ident] = (tokens - 1, now)
                return True, 0.0
            self._buckets[ident] = (tokens, now)
            return False, (1 - tokens) / rate


limiter = TokenBucket()


# ---------------- FastAPI dependencies ----------------

async def authenticate(request: Request) -> dict:
    required = bool(settings.get("auth", "require_api_key"))
    exempt = bool(settings.get("auth", "exempt_loopback", True)) and is_truly_local(request)
    ident: dict = {"id": "local", "name": "local", "prefix": None}
    key = _extract_key(request)
    if key:
        rec = get_db().find_api_key(hash_key(key))
        if rec:
            ident = {"id": rec["id"], "name": rec["name"], "prefix": rec["prefix"]}
        elif required and not exempt:
            raise HTTPException(401, {"code": "invalid_api_key", "message": "Invalid or revoked API key"})
    elif required and not exempt:
        raise HTTPException(401, {"code": "missing_api_key",
                                  "message": "Send 'Authorization: Bearer unison-...' (create a key with scripts\\apikey.bat)"})
    request.state.identity = ident
    return ident


async def rate_limited(request: Request) -> dict:
    guest = getattr(request.state, "guest", None)
    if guest:
        ident = {"id": f"guest:{guest}", "name": "website guest", "prefix": None}
        request.state.identity = ident
        dev = getattr(request.state, "guest_plan", "") in PRIVILEGED_PLANS
        who, per_min = ident["id"], int(settings.get("remote", "dev_requests_per_minute" if dev else
                                                     "guest_requests_per_minute", 60 if dev else 12))
    else:
        ident = await authenticate(request)
        # Remote requests all arrive from 127.0.0.1 through the tunnel: limit by the real visitor address.
        who = ident["id"] if ident["id"] != "local" else f"ip:{client_ip(request)}"
        per_min = int(settings.get("rate_limit", "requests_per_minute", 120))
    ok, retry = limiter.allow(who, per_min)
    if not ok:
        raise HTTPException(429, {"code": "rate_limited", "message": f"Too many requests. Retry in {retry:.1f}s"},
                            headers={"Retry-After": str(int(retry) + 1)})
    return ident


async def pc_only(request: Request) -> None:
    """The riskiest settings (MCP servers = running programs, workspace folders, tool permissions, autopilot,
    API keys, license): only from a browser on the PC itself - never through remote access, even signed in.
    A leaked password then still can't widen what UNISON is allowed to do."""
    if is_truly_local(request):
        return
    raise HTTPException(403, {"code": "pc_only",
                              "message": "For safety this can only be changed on the PC itself, not over remote access."})


async def local_only(request: Request) -> None:
    """Owner-only endpoints: allowed from this PC, or from another device only when a sign-in password is set
    (the middleware has then already checked the session token)."""
    if is_truly_local(request):
        return
    if is_loopback(request) and sessions.password_set():
        return
    raise HTTPException(403, {"code": "local_only",
                              "message": "Set a sign-in password on the PC first; then you can do this from other devices."})


def is_remote(request: Request) -> bool:
    """True when the request came from another device (through Tailscale or another tunnel)."""
    return not is_truly_local(request)


def guests_enabled() -> bool:
    return bool(settings.get("remote", "web_guests", True))


def revoked_keys() -> set[str]:
    return {str(x) for x in (settings.get("remote", "revoked_keys") or [])}


def guest_of(request: Request) -> Optional[str]:
    """License key ID of a website guest's token (only for GUEST_PATHS, only when guests are on)."""
    if request.url.path not in GUEST_PATHS or not guests_enabled():
        return None
    claims = sessions.guest_claims(_extract_key(request))
    if not claims or claims["g"] in revoked_keys():
        return None
    try:
        request.state.guest_plan = claims.get("p") or ""
    except AttributeError:
        pass
    return claims["g"]


def request_authorized(request: Request) -> bool:
    """Gate used by the middleware once a password is set: a valid session token or API key is required."""
    token = _extract_key(request)
    if not token:
        return False
    if sessions.verify_token(token):
        return True
    return bool(get_db().find_api_key(hash_key(token)))


# ---------------- request logging (no bodies, no secrets) ----------------

def request_logger() -> logging.Logger:
    log = logging.getLogger("unison.requests")
    if not log.handlers:
        h = RotatingFileHandler(LOG_DIR / "requests.log", maxBytes=5_000_000, backupCount=3, encoding="utf-8")
        h.setFormatter(logging.Formatter("%(message)s"))
        log.addHandler(h)
        log.setLevel(logging.INFO)
        log.propagate = False
    return log


def log_request(request: Request, status: int, ms: float) -> None:
    ident = getattr(request.state, "identity", None) or {}
    request_logger().info(json.dumps({
        "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "method": request.method,
        "path": request.url.path,
        "status": status,
        "ms": round(ms, 1),
        "client": request.client.host if request.client else None,
        "key": ident.get("prefix"),
    }))
