import { useCallback, useEffect, useRef, useState, type KeyboardEvent } from "react";
import { api, streamSSE, type Conversation, type Health, type Stats, type StoredMessage, type Feedback } from "./lib/api";
import { Markdown } from "./chat/Markdown";
import { ToolCard, type ToolItem } from "./chat/ToolCard";
import { FeedbackBar } from "./chat/FeedbackBar";
import { ScreenStep, type ScreenItem } from "./chat/ScreenStep";
import { Telemetry } from "./components/Telemetry";
import { ModelMenu } from "./components/ModelMenu";
import { SettingsDrawer } from "./components/SettingsDrawer";
import { JobsDrawer } from "./components/JobsDrawer";
import { SignIn } from "./components/SignIn";
import { Activate } from "./components/Activate";
import { auth, license, setAuthLostHandler, setLicenseLostHandler } from "./lib/api";

interface UserItem {
  kind: "user";
  key: string;
  content: string;
}
interface AssistantItem {
  kind: "assistant";
  key: string;
  id?: string;
  content: string;
  thinking?: string;
  stats?: Stats | null;
  model?: string | null;
  status: "streaming" | "stopped" | "error" | "done";
  error?: string;
  rating?: number | null;
}
interface NoticeItem {
  kind: "notice";
  key: string;
  text: string;
}
interface SourcesItem {
  kind: "sources";
  key: string;
  items: { title: string; score: number; kind: string }[];
}
type Item = UserItem | AssistantItem | ToolItem | NoticeItem | SourcesItem | ScreenItem;
type Mode = "chat" | "agent" | "screen";

interface Attachment {
  name: string;
  text: string;
}

const MAX_ATTACH_BYTES = 200_000;
const STARTERS = [
  "Make a small Python number-guessing game in a new folder, then run it once to check it works.",
  "Look at the files in my workspace and tell me what this project does.",
  "Create a Rojo project for a Roblox obby with a checkpoint system and a leaderboard.",
  "Write a Blender Python script that makes a low-poly wooden crate and exports it as FBX.",
];
const TOOL_BLOCK = /<tool_call>[\s\S]*?(<\/tool_call>|$)/g;

let counter = 0;
const k = () => `k${Date.now()}_${counter++}`;

function fence(name: string) {
  const ext = name.split(".").pop()?.toLowerCase() ?? "";
  const map: Record<string, string> = { py: "python", ts: "typescript", tsx: "tsx", js: "javascript", lua: "lua",
    luau: "lua", cs: "csharp", cpp: "cpp", h: "cpp", md: "markdown", json: "json", sql: "sql", html: "html", css: "css" };
  return map[ext] ?? ext;
}

/** Rebuild the on-screen items from stored messages (assistant text + tool cards). */
function itemsFromStored(msgs: StoredMessage[], feedback: Record<string, Feedback>): Item[] {
  const out: Item[] = [];
  const toolByCall = new Map<string, ToolItem>();
  for (const m of msgs) {
    if (m.role === "user") out.push({ kind: "user", key: m.id, content: m.content });
    else if (m.role === "assistant") {
      if (m.content || !m.tool_calls?.length) {
        out.push({
          kind: "assistant", key: m.id, id: m.id, content: m.content, stats: m.stats, model: m.model,
          status: m.stats?.done_reason === "stopped" ? "stopped" : "done", rating: feedback[m.id]?.rating ?? null,
        });
      }
      for (const c of m.tool_calls ?? []) {
        const t: ToolItem = { kind: "tool", key: `${m.id}_${c.id}`, callId: c.id, name: c.name, args: c.arguments, status: "waiting" };
        toolByCall.set(c.id, t);
        out.push(t);
      }
    } else if (m.role === "tool") {
      const t = (m.meta?.call_id && toolByCall.get(m.meta.call_id)) || undefined;
      if (t) {
        t.output = m.content;
        t.diff = m.meta?.diff ?? null;
        t.status = m.meta?.ok ? "done" : /declined|Not allowed/.test(m.content) ? "denied" : "failed";
        if (t.status === "denied") t.reason = m.content;
      }
    }
  }
  return out;
}

export default function App() {
  const [convs, setConvs] = useState<Conversation[]>([]);
  const [search, setSearch] = useState("");
  const [currentId, setCurrentId] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [items, setItems] = useState<Item[]>([]);
  const [input, setInput] = useState("");
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [busy, setBusy] = useState(false);
  const [health, setHealth] = useState<Health | null>(null);
  const [drawer, setDrawer] = useState<null | "pc" | "sampling" | "share">(null);
  const [renaming, setRenaming] = useState<string | null>(null);
  const [notice, setNotice] = useState("");
  const [refreshKey, setRefreshKey] = useState(0);
  const [mode, setMode] = useState<Mode>("agent");
  const agent = mode === "agent";
  const [autopilot, setAutopilot] = useState(false);
  const [workspace, setWorkspace] = useState("");
  const [screenReady, setScreenReady] = useState<null | { ok: boolean; msg: string }>(null);
  const [needSignIn, setNeedSignIn] = useState<boolean | null>(null);
  const [needLicense, setNeedLicense] = useState<boolean | null>(null);
  const [hasPassword, setHasPassword] = useState(false);
  const [jobsOpen, setJobsOpen] = useState(false);
  const [navOpen, setNavOpen] = useState(false);
  const [jobAlert, setJobAlert] = useState(0);

  const abortRef = useRef<AbortController | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const stickRef = useRef(true);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const bufRef = useRef("");
  const rafRef = useRef<number | null>(null);

  // ---------------- data loading ----------------
  const loadConvs = useCallback(async (q = search) => {
    try {
      setConvs(await api.conversations(q));
    } catch {
      /* telemetry shows server state */
    }
  }, [search]);

  const checkHealth = useCallback(async () => {
    try {
      setHealth(await api.health());
    } catch {
      setHealth(null);
    }
  }, []);

  const loadAgent = useCallback(async () => {
    try {
      const [a, w] = await Promise.all([api.agentSettings(), api.workspaces()]);
      setMode((m) => (m === "screen" ? m : a.agent_default ? "agent" : "chat"));
      setWorkspace(w.default);
    } catch {
      /* older server */
    }
  }, []);

  useEffect(() => {
    checkHealth();
    loadAgent();
    const id = setInterval(checkHealth, 10000);
    return () => clearInterval(id);
  }, [checkHealth, loadAgent]);

  // sign-in gate: a 401 anywhere flips to the sign-in screen; on load, require it if a password is set
  // but no token is stored on this device.
  useEffect(() => {
    setLicenseLostHandler(() => setNeedLicense(true));
    license.status().then((s) => setNeedLicense(!s.activated)).catch(() => setNeedLicense(false));
  }, []);

  useEffect(() => {
    setAuthLostHandler(() => setNeedSignIn(true));
    auth
      .status()
      .then((s) => {
        let hasToken = false;
        try {
          hasToken = !!localStorage.getItem("unison_token");
        } catch {
          hasToken = false;
        }
        setHasPassword(s.password_set);
        setNeedSignIn(s.password_set && !hasToken);
      })
      .catch(() => setNeedSignIn(false));
  }, []);

  // badge: jobs waiting for approval
  useEffect(() => {
    if (needSignIn !== false || needLicense !== false) return;
    const tick = () => api.jobs().then((js) => setJobAlert(js.filter((j) => j.status === "waiting_approval").length)).catch(() => undefined);
    tick();
    const t = setInterval(tick, 5000);
    return () => clearInterval(t);
  }, [needSignIn, needLicense]);

  useEffect(() => {
    const t = setTimeout(() => loadConvs(search), 200);
    return () => clearTimeout(t);
  }, [search, loadConvs]);

  // When the user picks screen mode, check the vision model is ready and warn clearly if not.
  useEffect(() => {
    if (mode !== "screen") return setScreenReady(null);
    api
      .computer()
      .then((c) =>
        setScreenReady(
          !c.supported
            ? { ok: false, msg: c.problem ?? "Screen control isn't available on this system." }
            : !c.vision_model_installed
              ? { ok: false, msg: `The vision model ${c.vision_model} isn't downloaded yet. Open settings to download it.` }
              : { ok: true, msg: "" },
        ),
      )
      .catch(() => setScreenReady(null));
  }, [mode, refreshKey]);

  const openConversation = async (id: string) => {
    if (busy) return;
    try {
      const c = await api.conversation(id);
      setCurrentId(id);
      setTitle(c.title);
      setItems(itemsFromStored(c.messages, c.feedback ?? {}));
      stickRef.current = true;
    } catch (e: any) {
      setNotice(e.message);
    }
  };

  const newConversation = () => {
    if (busy) return;
    setCurrentId(null);
    setTitle("");
    setItems([]);
    setTimeout(() => inputRef.current?.focus(), 0);
  };

  // ---------------- scrolling ----------------
  useEffect(() => {
    const el = scrollRef.current;
    if (el && stickRef.current) el.scrollTop = el.scrollHeight;
  }, [items]);

  const onScroll = () => {
    const el = scrollRef.current;
    if (el) stickRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
  };

  // ---------------- streaming helpers ----------------
  const updateTool = (callId: string, fn: (t: ToolItem) => ToolItem) =>
    setItems((xs) => xs.map((x) => (x.kind === "tool" && x.callId === callId ? fn(x) : x)));

  /** Apply fn to the streaming assistant item, creating one if the last item isn't one. */
  const withStreaming = (fn: (a: AssistantItem) => AssistantItem) =>
    setItems((xs) => {
      const last = xs[xs.length - 1];
      if (last && last.kind === "assistant" && last.status === "streaming") return [...xs.slice(0, -1), fn(last)];
      return [...xs, fn({ kind: "assistant", key: k(), content: "", status: "streaming" })];
    });

  const flushTokens = () => {
    rafRef.current = null;
    const chunk = bufRef.current;
    bufRef.current = "";
    if (chunk) withStreaming((a) => ({ ...a, content: a.content + chunk }));
  };

  const handleEvent = (ev: any) => {
    switch (ev.type) {
      case "start":
        setCurrentId(ev.conversation_id);
        setTitle(ev.title);
        withStreaming((a) => ({ ...a, model: ev.model }));
        loadConvs();
        break;
      case "sources":
        setItems((xs) => {
          const last = xs[xs.length - 1];
          const src: SourcesItem = { kind: "sources", key: k(), items: ev.items };
          // keep the streaming placeholder last
          if (last && last.kind === "assistant" && last.status === "streaming" && !last.content)
            return [...xs.slice(0, -1), src, last];
          return [...xs, src];
        });
        break;
      case "token":
        bufRef.current += ev.content;
        if (rafRef.current == null) rafRef.current = requestAnimationFrame(flushTokens);
        break;
      case "thinking":
        withStreaming((a) => ({ ...a, thinking: (a.thinking ?? "") + ev.content }));
        break;
      case "assistant_saved":
        flushTokens();
        setItems((xs) => {
          const last = xs[xs.length - 1];
          if (!last || last.kind !== "assistant" || last.status !== "streaming") {
            return ev.content ? [...xs, { kind: "assistant", key: k(), id: ev.message_id, content: ev.content, stats: ev.stats, status: "done" }] : xs;
          }
          if (!ev.content && ev.has_tool_calls) return xs.slice(0, -1); // pure tool-call step: no text bubble
          return [...xs.slice(0, -1), { ...last, id: ev.message_id, content: ev.content, stats: ev.stats, status: "done" }];
        });
        break;
      case "tool_call":
        setItems((xs) => [
          ...xs,
          {
            kind: "tool", key: k(), callId: ev.call_id, name: ev.name, args: ev.args, decision: ev.decision,
            reason: ev.reason, status: ev.decision === "deny" ? "denied" : "waiting",
          },
        ]);
        break;
      case "approval_required":
        updateTool(ev.call_id, (t) => ({ ...t, status: "approval", approval: { actionId: ev.action_id, preview: ev.preview } }));
        break;
      case "approval_resolved":
        updateTool(ev.call_id, (t) => ({ ...t, status: ev.approved ? "running" : "denied", reason: ev.approved ? t.reason : `You declined${ev.note ? `: ${ev.note}` : ""}` }));
        break;
      case "tool_running":
        updateTool(ev.call_id, (t) => ({ ...t, status: "running" }));
        break;
      case "tool_result":
        updateTool(ev.call_id, (t) => ({
          ...t, status: t.status === "denied" ? "denied" : ev.ok ? "done" : "failed", output: ev.output, diff: ev.diff,
        }));
        break;
      case "notice":
        setItems((xs) => [...xs, { kind: "notice", key: k(), text: ev.message }]);
        break;
      case "done":
        flushTokens();
        setItems((xs) => {
          // attach totals to the final reply
          for (let i = xs.length - 1; i >= 0; i--) {
            const x = xs[i];
            if (x.kind === "assistant") {
              const copy = [...xs];
              copy[i] = { ...x, id: x.id ?? ev.message_id, status: x.status === "streaming" ? "done" : x.status,
                stats: { ...(x.stats ?? {}), ...ev.stats } };
              return copy;
            }
          }
          return xs;
        });
        break;
      case "error":
        flushTokens();
        withStreaming((a) => ({ ...a, status: "error", error: ev.message }));
        break;
    }
  };

  const updateScreen = (step: number, fn: (x: ScreenItem) => ScreenItem) =>
    setItems((xs) => xs.map((x) => (x.kind === "screen" && x.step === step ? fn(x) : x)));

  const handleScreenEvent = (ev: any) => {
    switch (ev.type) {
      case "start":
        if (ev.conversation_id) setCurrentId(ev.conversation_id);
        setTitle("Screen task");
        setItems((xs) => xs.filter((x) => !(x.kind === "assistant" && x.status === "streaming" && !x.content)));
        loadConvs();
        break;
      case "screen":
        setItems((xs) => [...xs, { kind: "screen", key: k(), step: ev.step, image: ev.image, window: ev.window, thought: "", status: "thinking" }]);
        break;
      case "token":
        updateScreen(ev.step, (x) => ({ ...x, thought: x.thought + ev.content }));
        break;
      case "action":
        updateScreen(ev.step, (x) => ({ ...x, action: { name: ev.name, description: ev.description, decision: ev.decision }, status: "running" }));
        break;
      case "approval_required":
        updateScreen(ev.step, (x) => ({ ...x, status: "approval", approval: { actionId: ev.action_id, image: ev.preview.image, summary: ev.preview.summary } }));
        break;
      case "approval_resolved":
        updateScreen(ev.step, (x) => ({ ...x, status: ev.approved ? "running" : "denied", result: ev.approved ? x.result : "You declined" }));
        break;
      case "action_result":
        updateScreen(ev.step, (x) => ({ ...x, status: ev.ok ? "done" : x.status === "denied" ? "denied" : "failed", result: ev.message }));
        break;
      case "notice":
        setItems((xs) => [...xs, { kind: "notice", key: k(), text: ev.message }]);
        break;
      case "done":
        setItems((xs) => [...xs, { kind: "assistant", key: k(), content: `**${ev.status === "done" ? "Done" : ev.status === "failed" ? "Couldn't finish" : "Stopped"}** after ${ev.steps} action(s). ${ev.summary}`, status: "done" }]);
        break;
      case "error":
        setItems((xs) => [...xs, { kind: "assistant", key: k(), content: "", status: "error", error: ev.message }]);
        break;
    }
  };

  const runScreen = async (task: string) => {
    const ctl = new AbortController();
    abortRef.current = ctl;
    setBusy(true);
    stickRef.current = true;
    try {
      await streamSSE("/v1/computer/run", { task, autopilot }, handleScreenEvent, ctl.signal);
    } catch (e: any) {
      if (e.name !== "AbortError") setItems((xs) => [...xs, { kind: "assistant", key: k(), content: "", status: "error", error: e.message }]);
    } finally {
      setItems((xs) =>
        xs.filter((x) => !(x.kind === "assistant" && x.status === "streaming" && !x.content))
          .map((x) => (x.kind === "screen" && (x.status === "thinking" || x.status === "approval" || x.status === "running") ? { ...x, status: "denied" as const, result: "Stopped" } : x)));
      setBusy(false);
      abortRef.current = null;
      loadConvs();
      setRefreshKey((n) => n + 1);
    }
  };

  const run = async (body: Record<string, unknown>) => {
    const ctl = new AbortController();
    abortRef.current = ctl;
    setBusy(true);
    stickRef.current = true;
    try {
      await streamSSE("/v1/chat", { ...body, stream: true, tools: agent }, handleEvent, ctl.signal);
    } catch (e: any) {
      flushTokens();
      if (e.name === "AbortError") withStreaming((a) => ({ ...a, status: "stopped" }));
      else withStreaming((a) => ({ ...a, status: "error", error: e.message }));
    } finally {
      if (rafRef.current != null) cancelAnimationFrame(rafRef.current);
      flushTokens();
      setItems((xs) =>
        xs
          .filter((x) => !(x.kind === "assistant" && x.status === "streaming" && !x.content))
          .map((x) =>
            x.kind === "assistant" && x.status === "streaming" ? { ...x, status: "done" as const }
            : x.kind === "tool" && (x.status === "approval" || x.status === "running" || x.status === "waiting")
              ? { ...x, status: "denied" as const, reason: "Stopped" } : x),
      );
      setBusy(false);
      abortRef.current = null;
      loadConvs();
      setRefreshKey((n) => n + 1);
    }
  };

  const send = async (text?: string) => {
    let content = (text ?? input).trim();
    if ((!content && attachments.length === 0) || busy) return;
    for (const a of attachments) {
      content += `\n\n**Attached file: ${a.name}**\n\`\`\`${fence(a.name)}\n${a.text}\n\`\`\``;
    }
    setInput("");
    setAttachments([]);
    setItems((xs) => [
      ...xs,
      { kind: "user", key: k(), content: content.trim() },
      { kind: "assistant", key: k(), content: "", status: "streaming" },
    ]);
    if (mode === "screen") {
      await runScreen(content.trim());
      return;
    }
    await run({ conversation_id: currentId, message: content.trim() });
  };

  const regenerate = async () => {
    if (busy || !currentId) return;
    setItems((xs) => {
      let i = xs.length;
      while (i > 0 && xs[i - 1].kind !== "user") i--;
      return [...xs.slice(0, i), { kind: "assistant", key: k(), content: "", status: "streaming" }];
    });
    await run({ conversation_id: currentId, regenerate: true });
  };

  const stop = () => {
    if (mode === "screen") api.stopScreen().catch(() => undefined);
    abortRef.current?.abort();
  };

  // ---------------- attachments ----------------
  const onFiles = async (files: FileList | null) => {
    if (!files) return;
    const next: Attachment[] = [];
    for (const f of Array.from(files)) {
      if (f.size > MAX_ATTACH_BYTES) {
        setNotice(`${f.name} is larger than 200 KB; attach a smaller file or put it in a workspace folder.`);
        continue;
      }
      const t = await f.text();
      if (t.includes("\u0000")) {
        setNotice(`${f.name} looks like a binary file. Only text and code files can be attached.`);
        continue;
      }
      next.push({ name: f.name, text: t });
    }
    setAttachments((a) => [...a, ...next]);
    if (fileRef.current) fileRef.current.value = "";
  };

  // ---------------- conversation actions ----------------
  const remove = async (id: string) => {
    if (!confirm("Delete this conversation? This cannot be undone.")) return;
    await api.remove(id);
    if (id === currentId) newConversation();
    loadConvs();
  };

  const commitRename = async (id: string, value: string) => {
    setRenaming(null);
    const v = value.trim();
    if (!v) return;
    await api.rename(id, v);
    if (id === currentId) setTitle(v);
    loadConvs();
  };

  const onKey = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault();
      send();
    }
  };

  useEffect(() => {
    const el = inputRef.current;
    if (el) {
      el.style.height = "auto";
      el.style.height = Math.min(el.scrollHeight, 260) + "px";
    }
  }, [input]);

  const lastAssistantKey = [...items].reverse().find((x) => x.kind === "assistant")?.key;
  const engineDown = health && !health.engine.ok;
  const modelMissing = health && health.engine.ok && health.active_model_installed === false;
  const wsName = workspace ? workspace.split(/[\\/]/).pop() : "";

  if (needSignIn === null || needLicense === null) return <div className="signin"><div className="dim">loading…</div></div>;
  if (needSignIn) return <SignIn onDone={() => setNeedSignIn(false)} />;
  if (needLicense) return <Activate onDone={() => { setNeedLicense(false); setRefreshKey((n) => n + 1); }} />;

  return (
    <div className={`app ${navOpen ? "nav-open" : ""}`} onClick={(e) => navOpen && !(e.target as HTMLElement).closest(".sidebar, .menu-btn") && setNavOpen(false)}>
      <aside className="sidebar">
        <div className="brand">
          <svg viewBox="0 0 32 32" className="brand-mark" aria-hidden>
            <circle cx="12" cy="16" r="7" />
            <circle cx="20" cy="16" r="7" className="second" />
          </svg>
          <div>
            <div className="brand-name">UNISON</div>
            <div className="brand-sub">local intelligence</div>
          </div>
        </div>
        <button className="new-btn" onClick={newConversation} disabled={busy}>
          <span>＋</span> New conversation
        </button>
        <input className="search" placeholder="Search conversations" value={search} onChange={(e) => setSearch(e.target.value)} />
        <nav className="conv-list">
          {convs.length === 0 && <div className="conv-empty">{search ? "No matches" : "No conversations yet"}</div>}
          {convs.map((c) => (
            <div
              key={c.id}
              className={`conv ${c.id === currentId ? "on" : ""}`}
              onClick={() => { openConversation(c.id); setNavOpen(false); }}
              onDoubleClick={() => setRenaming(c.id)}
              title="Double-click to rename"
            >
              {renaming === c.id ? (
                <input
                  autoFocus
                  defaultValue={c.title}
                  className="rename"
                  onClick={(e) => e.stopPropagation()}
                  onBlur={(e) => commitRename(c.id, e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") commitRename(c.id, (e.target as HTMLInputElement).value);
                    if (e.key === "Escape") setRenaming(null);
                  }}
                />
              ) : (
                <span className="conv-title">{c.title}</span>
              )}
              <button
                className="conv-del"
                onClick={(e) => {
                  e.stopPropagation();
                  remove(c.id);
                }}
                aria-label="Delete conversation"
              >
                ×
              </button>
            </div>
          ))}
        </nav>
        <div className="sidebar-foot">
          <button className="link-btn" onClick={() => setDrawer("pc")}>settings</button>
          <span className="sep">·</span>
          <button className="link-btn" onClick={() => setDrawer("share")} title="Download link to share, and updates">share</button>
          {hasPassword && (
            <>
              <span className="sep">·</span>
              <button
                className="link-btn"
                onClick={() => {
                  auth.logout();
                  setNeedSignIn(true);
                }}
                title="Sign out of this device"
              >
                lock
              </button>
            </>
          )}
          <span className="sep">·</span>
          <span className="local-badge">● local</span>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <button className="icon-btn menu-btn" onClick={() => setNavOpen(!navOpen)} aria-label="Conversations">☰</button>
          <div className="title">{title || "New conversation"}</div>
          <div className="topbar-right">
            <button className={`icon-btn jobs-btn ${jobAlert ? "on" : ""}`} onClick={() => setJobsOpen(true)} title="Background jobs">
              jobs{jobAlert ? ` (${jobAlert} waiting)` : ""}
            </button>
            <ModelMenu onChanged={() => { checkHealth(); setRefreshKey((n) => n + 1); }} />
            <button className="icon-btn" onClick={() => setDrawer("pc")} title="Settings: PC access, knowledge, training, MCP">⚙</button>
          </div>
        </header>
        <Telemetry refreshKey={refreshKey} />

        {mode === "screen" && screenReady && !screenReady.ok && (
          <div className="banner warn" onClick={() => setDrawer("pc")}>
            {screenReady.msg} <span className="dim">(click to open settings)</span>
          </div>
        )}
        {engineDown && (
          <div className="banner bad">
            The Ollama engine isn't running, so UNISON can't think right now. Start the Ollama app (or close and reopen
            Start-UNISON.bat). <span className="dim">{health?.engine.error}</span>
          </div>
        )}
        {modelMissing && (
          <div className="banner warn">
            The active model <code>{health?.active_model}</code> isn't downloaded. Open the model menu above and download it.
          </div>
        )}
        {notice && (
          <div className="banner warn" onClick={() => setNotice("")}>
            {notice} <span className="dim">(click to dismiss)</span>
          </div>
        )}

        <div className="scroll" ref={scrollRef} onScroll={onScroll}>
          {items.length === 0 ? (
            <div className="empty">
              <svg viewBox="0 0 32 32" className="empty-mark" aria-hidden>
                <circle cx="12" cy="16" r="7" />
                <circle cx="20" cy="16" r="7" className="second" />
              </svg>
              <h1>What are we building?</h1>
              <p>
                Replies come from <code>{health?.active_model ?? "your local model"}</code> on this computer.
                {agent ? <> In agent mode UNISON can work in <code>{workspace || "your workspace"}</code> — it asks before changing files or running commands.</> : null}
              </p>
              <div className="starters">
                {STARTERS.map((s) => (
                  <button key={s} onClick={() => send(s)} disabled={busy || !!engineDown || !!modelMissing}>
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="thread">
              {items.map((x) => {
                if (x.kind === "user")
                  return (
                    <article key={x.key} className="msg user">
                      <div className="msg-head"><span className="who">you</span></div>
                      <div className="user-text"><Markdown text={x.content} /></div>
                    </article>
                  );
                if (x.kind === "tool") return <ToolCard key={x.key} item={x} />;
                if (x.kind === "screen") return <ScreenStep key={x.key} item={x} />;
                if (x.kind === "notice") return <div key={x.key} className="notice">{x.text}</div>;
                if (x.kind === "sources")
                  return (
                    <div key={x.key} className="sources">
                      <span className="dim">looked up:</span>
                      {x.items.map((s, i) => (
                        <span key={i} className="chip" title={`similarity ${s.score}`}>{s.title}</span>
                      ))}
                    </div>
                  );
                const text = x.content.replace(TOOL_BLOCK, "").trim();
                return (
                  <article key={x.key} className="msg assistant">
                    <div className="msg-head">
                      <span className="who">unison</span>
                      {x.model && <span className="msg-model">{x.model}</span>}
                      {x.status === "streaming" && <span className="pulse" />}
                    </div>
                    {x.thinking && (
                      <details className="thinking">
                        <summary>reasoning</summary>
                        <pre>{x.thinking}</pre>
                      </details>
                    )}
                    {text ? <Markdown text={text} /> : x.status === "streaming" ? <div className="waiting">thinking…</div> : null}
                    {x.status === "error" && <div className="msg-error">⚠ {x.error}</div>}
                    {x.status !== "streaming" && (
                      <div className="msg-foot">
                        {x.status === "stopped" && <span className="stopped">stopped</span>}
                        {x.stats?.tokens_per_second ? (
                          <span>
                            {x.stats.tokens_per_second.toFixed(1)} tok/s
                            {(x.stats as any).tool_calls ? ` · ${(x.stats as any).tool_calls} tool step(s)` : ""}
                          </span>
                        ) : null}
                        {x.id && !x.id.startsWith("k") && !busy && (
                          <FeedbackBar
                            messageId={x.id}
                            rating={x.rating ?? null}
                            onChange={(r) => setItems((xs) => xs.map((y) => (y.key === x.key ? { ...y, rating: r } as AssistantItem : y)))}
                          />
                        )}
                        {x.key === lastAssistantKey && !busy && currentId && (
                          <button className="link-btn" onClick={regenerate}>↻ regenerate</button>
                        )}
                      </div>
                    )}
                  </article>
                );
              })}
            </div>
          )}
        </div>

        <div className="composer-wrap">
          {attachments.length > 0 && (
            <div className="attachments">
              {attachments.map((a, i) => (
                <span key={i} className="chip on">
                  {a.name}
                  <button onClick={() => setAttachments((x) => x.filter((_, j) => j !== i))}>×</button>
                </span>
              ))}
            </div>
          )}
          <div className="composer">
            <button className="icon-btn" title="Attach text or code files" onClick={() => fileRef.current?.click()}>⎘</button>
            <input ref={fileRef} type="file" multiple hidden onChange={(e) => onFiles(e.target.files)} />
            <textarea
              ref={inputRef}
              rows={1}
              value={input}
              placeholder={
                mode === "screen" ? "Tell UNISON what to do on your screen, e.g. 'open Notepad and write a shopping list'"
                : agent ? "Ask UNISON to build, fix or explain something…" : "Message UNISON…  (Enter to send)"}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={onKey}
            />
            {busy ? (
              <button className="send stop" onClick={stop} title="Stop">■ stop</button>
            ) : (
              <button className="send" onClick={() => send()} disabled={!input.trim() && attachments.length === 0}>send ↵</button>
            )}
          </div>
          <div className="composer-opts">
            <div className="mode-switch" role="tablist">
              <button className={mode === "chat" ? "on" : ""} disabled={busy} onClick={() => setMode("chat")} title="Just talk">chat</button>
              <button className={mode === "agent" ? "on" : ""} disabled={busy} onClick={() => setMode("agent")}
                title="Files, terminal and MCP tools in your workspaces">agent</button>
              <button className={mode === "screen" ? "on" : ""} disabled={busy} onClick={() => setMode("screen")}
                title="A vision model sees your screen and uses the mouse and keyboard">screen</button>
            </div>
            {agent && wsName && (
              <button className="chip" onClick={() => setDrawer("pc")} title={workspace}>
                workspace: {wsName}
              </button>
            )}
            {mode === "screen" && (
              <>
                <button className={`chip ${autopilot ? "on" : ""}`} disabled={busy} onClick={() => setAutopilot(!autopilot)}
                  title="Autopilot runs every action without asking and minimises this window while it works">
                  {autopilot ? "◉ autopilot" : "○ ask before each action"}
                </button>
                <span className="esc-hint">Esc or mouse to top-left corner = stop</span>
              </>
            )}
          </div>
        </div>
      </main>
      {jobsOpen && <JobsDrawer onClose={() => setJobsOpen(false)} />}
      {drawer && (
        <SettingsDrawer
          initial={drawer}
          onClose={() => {
            setDrawer(null);
            loadAgent();
            checkHealth();
          }}
        />
      )}
    </div>
  );
}
