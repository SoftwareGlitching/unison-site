"""Agent loop, approvals, text-protocol fallback, knowledge retrieval and MCP — against test doubles."""
import asyncio
import json
import sys
import tempfile
import unittest
from pathlib import Path

from tests.helpers import IsolatedSettings, ROOT

from backend.agents.approvals import ApprovalBroker
from backend.core.chat_service import ChatService, parse_text_tool_calls
from backend.database.db import Database
from backend.inference.manager import ModelManager
from backend.inference.ollama_backend import OllamaBackend
from backend.knowledge.store import KnowledgeStore
from backend.tools.registry import ToolRegistry
from tests.fake_ollama import FakeOllama

MODEL = "test-model:1b"


class EmptyKnowledge:
    def counts(self):
        return {"sources": 0, "chunks": 0}


def tool_results(body):
    return [m for m in body["messages"] if m["role"] == "tool" or m["content"].startswith("[Result of")]


def call(name, **args):
    return {"tool_calls": [{"function": {"name": name, "arguments": args}}]}


async def drive(agen, approve=None):
    """Consume events; answer approval requests with approve(event) -> bool."""
    events = []
    loop = asyncio.get_running_loop()
    broker = drive.broker
    async for ev in agen:
        events.append(ev)
        if ev["type"] == "approval_required":
            ok = approve(ev) if approve else True
            loop.call_later(0.01, broker.resolve, ev["action_id"], ok, "" if ok else "not now")
    return events


class AgentTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self.tmp.name) / "t.db")
        self.broker = ApprovalBroker()
        drive.broker = self.broker

    def tearDown(self):
        self.db._conn.close()
        self.tmp.cleanup()

    def svc(self, fake, knowledge=None):
        return ChatService(self.db, ModelManager(OllamaBackend(fake.url)), tools=ToolRegistry(),
                           approvals=self.broker, knowledge=knowledge or EmptyKnowledge())

    def test_agent_writes_runs_and_summarises(self):
        def brain(body):
            n = len(tool_results(body))
            assert body.get("tools"), "tools should be offered in agent mode"
            if n == 0:
                return call("write_file", path="hello.py", content="print('hi from agent')\n")
            if n == 1:
                return call("run_command", command=f'"{sys.executable}" hello.py')
            return {"content": "Done: created hello.py and ran it."}

        with IsolatedSettings() as env, FakeOllama(responder=brain) as fake:
            evs = asyncio.run(drive(self.svc(fake).run(conversation_id=None, content="make hello.py and run it",
                                                       model=MODEL, tools=True)))
            types = [e["type"] for e in evs]
            self.assertEqual(types.count("approval_required"), 2)
            approvals = [e for e in evs if e["type"] == "approval_required"]
            self.assertEqual(approvals[0]["preview"]["kind"], "diff")
            self.assertIn("+print('hi from agent')", approvals[0]["preview"]["diff"])
            self.assertEqual(approvals[1]["preview"]["kind"], "command")
            results = [e for e in evs if e["type"] == "tool_result"]
            self.assertTrue(all(r["ok"] for r in results), results)
            self.assertIn("hi from agent", results[1]["output"])
            self.assertEqual((env.workspace / "hello.py").read_text(), "print('hi from agent')\n")
            self.assertEqual(types[-1], "done")
            self.assertEqual(evs[-1]["stats"]["tool_calls"], 2)
            roles = [m["role"] for m in self.db.messages(evs[1]["conversation_id"])]
            self.assertEqual(roles, ["user", "assistant", "tool", "assistant", "tool", "assistant"])
            last_body = fake.requests[-1]["body"]
            self.assertEqual(last_body["messages"][-1]["role"], "tool")
            self.assertEqual(last_body["messages"][-1]["tool_name"], "run_command")

    def test_declined_action_is_not_performed(self):
        def brain(body):
            res = tool_results(body)
            if not res:
                return call("write_file", path="nope.txt", content="x")
            return {"content": "OK, I won't create it."}

        with IsolatedSettings() as env, FakeOllama(responder=brain) as fake:
            evs = asyncio.run(drive(self.svc(fake).run(conversation_id=None, content="make nope.txt", model=MODEL,
                                                       tools=True), approve=lambda e: False))
            self.assertFalse((env.workspace / "nope.txt").exists())
            res = [e for e in evs if e["type"] == "tool_result"][0]
            self.assertFalse(res["ok"])
            self.assertIn("declined", res["output"])
            self.assertIn("not now", res["output"])

    def test_read_tools_need_no_approval(self):
        def brain(body):
            return call("list_dir", path=".") if not tool_results(body) else {"content": "There is one file."}

        with IsolatedSettings() as env, FakeOllama(responder=brain) as fake:
            (env.workspace / "a.lua").write_text("print(1)")
            evs = asyncio.run(drive(self.svc(fake).run(conversation_id=None, content="what's here?", model=MODEL,
                                                       tools=True), approve=lambda e: self.fail("asked")))
            self.assertNotIn("approval_required", [e["type"] for e in evs])
            self.assertIn("a.lua", [e for e in evs if e["type"] == "tool_result"][0]["output"])

    def test_text_protocol_fallback(self):
        def brain(body):
            assert not body.get("tools")
            if not tool_results(body):
                return {"content": 'Let me look. <tool_call>{"name": "list_dir", "arguments": {"path": "."}}</tool_call>'}
            return {"content": "Found it."}

        from backend.core import chat_service
        self.addCleanup(chat_service._text_protocol_models.discard, MODEL)   # don't leak into other tests
        with IsolatedSettings() as env, FakeOllama(responder=brain, no_tool_models=[MODEL]) as fake:
            (env.workspace / "z.py").write_text("x=1")
            evs = asyncio.run(drive(self.svc(fake).run(conversation_id=None, content="list", model=MODEL, tools=True)))
            types = [e["type"] for e in evs]
            self.assertIn("notice", types)
            self.assertIn("z.py", [e for e in evs if e["type"] == "tool_result"][0]["output"])
            saved = [e for e in evs if e["type"] == "assistant_saved"][0]
            self.assertEqual(saved["content"], "Let me look.")   # tool block stripped from what the user sees
            sys_prompt = fake.requests[-1]["body"]["messages"][0]["content"]
            self.assertIn("<tool_call>", sys_prompt)

    def test_json_code_block_calls_with_native_tools_offered(self):
        """qwen2.5-coder:7b's real behaviour: tools offered natively, but it writes ```json calls and invents results."""
        from tests.test_toolparse import REAL_SELFTEST_OUTPUT

        def brain(body):
            if not tool_results(body):
                return {"content": REAL_SELFTEST_OUTPUT}
            return {"content": "The file contains UNISON-OK."}

        with IsolatedSettings() as env, FakeOllama(responder=brain) as fake:
            evs = asyncio.run(drive(self.svc(fake).run(conversation_id=None, content="write and read", model=MODEL,
                                                       tools=True)))
            calls = [e["name"] for e in evs if e["type"] == "tool_call"]
            self.assertEqual(calls, ["write_file", "read_file"])
            self.assertEqual((env.workspace / "unison-selftest" / "hello.txt").read_text(), "UNISON-OK")
            results = [e for e in evs if e["type"] == "tool_result"]
            self.assertIn("UNISON-OK", results[1]["output"])
            first_saved = [e for e in evs if e["type"] == "assistant_saved"][0]
            self.assertNotIn("After creating the file", first_saved["content"])

    def test_repeating_model_is_stopped(self):
        with IsolatedSettings(), FakeOllama(responder=lambda b: call("list_dir", path=".")) as fake:
            evs = asyncio.run(drive(self.svc(fake).run(conversation_id=None, content="loop", model=MODEL, tools=True)))
            outputs = [e["output"] for e in evs if e["type"] == "tool_result"]
            self.assertIn("already made this exact call", outputs[2])
            self.assertEqual(evs[-2]["type"], "notice")
            self.assertIn("Stopped after", evs[-2]["message"])

    def test_plain_chat_offers_no_tools(self):
        with IsolatedSettings(), FakeOllama() as fake:
            asyncio.run(drive(self.svc(fake).run(conversation_id=None, content="hi", model=MODEL, tools=False)))
            self.assertNotIn("tools", fake.requests[-1]["body"])

    def test_regenerate_removes_tool_steps(self):
        def brain(body):
            return call("list_dir", path=".") if not tool_results(body) else {"content": "done"}

        with IsolatedSettings(), FakeOllama(responder=brain) as fake:
            svc = self.svc(fake)
            evs = asyncio.run(drive(svc.run(conversation_id=None, content="x", model=MODEL, tools=True)))
            cid = evs[1]["conversation_id"]
            asyncio.run(drive(svc.run(conversation_id=cid, content=None, regenerate=True, model=MODEL, tools=True)))
            roles = [m["role"] for m in self.db.messages(cid)]
            self.assertEqual(roles, ["user", "assistant", "tool", "assistant"])

    def test_text_tool_call_parser(self):
        text, calls = parse_text_tool_calls('Sure.\n<tool_call>\n{"name": "read_file", "arguments": {"path": "a.py"}}\n</tool_call>')
        self.assertEqual(text, "Sure.")
        self.assertEqual(calls[0].name, "read_file")
        self.assertEqual(calls[0].arguments, {"path": "a.py"})
        _, calls = parse_text_tool_calls('<tool_call>{"name": "list_dir", "arguments": "{\\"path\\": \\".\\"}"}')
        self.assertEqual(calls[0].arguments, {"path": "."})
        self.assertEqual(parse_text_tool_calls("no tools here")[1], [])


class KnowledgeTests(unittest.TestCase):
    def test_ingest_search_and_injection(self):
        with tempfile.TemporaryDirectory() as d, IsolatedSettings(), FakeOllama() as fake:
            d = Path(d)
            docs = d / "docs"
            docs.mkdir()
            (docs / "remotes.md").write_text("# RemoteEvents\n\nNever trust the client. Validate every RemoteEvent "
                                             "argument on the server before changing player data.\n")
            (docs / "uv.md").write_text("# Blender UV unwrapping\n\nUse Smart UV Project for hard surface props "
                                        "and mark seams for organic meshes.\n")
            (docs / ".env").write_text("SECRET=1")
            store = KnowledgeStore(d / "k.db", backend=OllamaBackend(fake.url))
            stats = asyncio.run(store.ingest_folder(docs, "knowledge", "curated"))
            self.assertEqual(stats["files"], 2)          # .env is never indexed
            again = asyncio.run(store.ingest_folder(docs, "knowledge", "curated"))
            self.assertEqual(again["indexed"], 0)        # unchanged files are skipped
            hits = asyncio.run(store.search("validate RemoteEvent arguments on the server", k=1))
            self.assertEqual(hits[0]["title"], "remotes.md")

            (docs / "uv.md").unlink()
            removed = asyncio.run(store.ingest_folder(docs, "knowledge", "curated"))
            self.assertEqual(removed["removed"], 1)

            db = Database(d / "c.db")
            svc = ChatService(db, ModelManager(OllamaBackend(fake.url)), tools=ToolRegistry(),
                              approvals=ApprovalBroker(), knowledge=store)
            drive.broker = ApprovalBroker()
            from backend.core.config import settings
            settings.data.setdefault("knowledge", {})["min_score"] = 0.1
            evs = asyncio.run(drive(svc.run(conversation_id=None, content="how do I validate a RemoteEvent?",
                                            model="test-model:1b")))
            src = [e for e in evs if e["type"] == "sources"]
            self.assertTrue(src and src[0]["items"][0]["title"] == "remotes.md")
            sys_prompt = fake.requests[-1]["body"]["messages"][0]["content"]
            self.assertIn("Never trust the client", sys_prompt)
            db._conn.close()
            store.conn.close()


class MCPTests(unittest.TestCase):
    def test_stdio_server_tools_are_registered_and_callable(self):
        from backend.mcp import client as mcp
        from backend.tools.registry import registry

        async def go():
            srv = mcp.MCPServer("fake", sys.executable, [str(ROOT / "tests" / "fake_mcp_server.py")])
            await srv.start(timeout=20)
            mgr = mcp.MCPManager()
            mgr.servers["fake"] = srv
            mgr._register(srv)
            tool = registry.get("fake__shout")
            self.assertIsNotNone(tool)
            self.assertEqual(tool.risk, "external")
            self.assertEqual(registry.decide(tool, {})[0], "ask")
            res = await registry.execute("fake__shout", {"text": "hello"})
            await asyncio.sleep(0)
            srv.stop()
            registry.unregister_source("mcp:fake")
            return res

        with IsolatedSettings():
            res = asyncio.run(go())
        self.assertTrue(res.ok, res.output)
        self.assertEqual(res.output, "HELLO (roots=1)")

    def test_bad_command_reports_failure(self):
        from backend.mcp import client as mcp

        async def go():
            srv = mcp.MCPServer("nope", "definitely-not-a-real-program-xyz")
            with self.assertRaises(mcp.MCPError):
                await srv.start(timeout=5)
            return srv.status

        self.assertEqual(asyncio.run(go()), "failed")


if __name__ == "__main__":
    unittest.main()
