"""
Terminal tool: runs a command inside a workspace folder.

Every command is classified:
  blocked  - never runs (disk formatting, registry edits, disabling security, piping downloads into a shell...)
  safe     - read-only commands with no shell operators (git status, dir, python --version...) run without asking
  ask      - everything else waits for the user to approve it in the app
"""
from __future__ import annotations

from typing import Optional

import os
import re
import signal
import subprocess
import sys
import time

from .base import Tool, ToolError, ToolResult, i, obj, s
from .sandbox import workspaces

MAX_OUTPUT = 16_000
DEFAULT_TIMEOUT = 120
MAX_TIMEOUT = 900

BLOCKED = [
    (r"\bformat(\.com)?\s+[a-z]:", "formats a drive"),
    (r"\bdiskpart\b", "partitions disks"),
    (r"\bbcdedit\b", "changes boot settings"),
    (r"\b(shutdown|restart-computer|stop-computer)\b", "shuts down the computer"),
    (r"\breg(\.exe)?\s+(add|delete|import|load|restore)\b", "edits the registry"),
    (r"\b(set|new|remove)-itemproperty\b.*\bhk(lm|cu|cr|u)\b", "edits the registry"),
    (r"\bset-executionpolicy\b", "changes PowerShell security policy"),
    (r"\b(cipher\s+/w|vssadmin|wbadmin)\b", "destroys backups or wipes free space"),
    (r"\bwmic\s+shadowcopy\b", "deletes shadow copies"),
    (r"\bnetsh\s+(advfirewall|firewall)\b", "changes the firewall"),
    (r"\bset-mppreference\b|\badd-mppreference\b", "changes Windows Defender"),
    (r"\bnet\s+(user|localgroup)\b", "changes user accounts"),
    (r"\b(takeown|icacls)\b", "changes file ownership/permissions"),
    (r"\bschtasks\s+/create\b|\bregister-scheduledtask\b", "creates scheduled tasks"),
    (r"\bsc(\.exe)?\s+(create|delete|config)\b|\bnew-service\b", "changes Windows services"),
    (r"\b(cmdkey|get-credential|mimikatz)\b", "accesses stored credentials"),
    (r"(iwr|irm|invoke-webrequest|invoke-restmethod|curl|wget)\b[^|]*\|\s*(iex|invoke-expression|sh|bash|cmd|powershell)\b",
     "runs code downloaded from the internet"),
    (r"\b(iex|invoke-expression)\b", "evaluates dynamic code"),
    (r"-(e|enc|encodedcommand)\s+[a-z0-9+/=]{20,}", "runs an encoded PowerShell command"),
    (r"\brm\s+(-[a-z]*r[a-z]*f|-[a-z]*f[a-z]*r)\s+(/|~|[a-z]:[\\/]?)(\s|$)", "deletes a whole drive or home folder"),
    (r"\b(rd|rmdir)\s+/s\b.*\s[a-z]:\\?\s*$", "deletes a whole drive"),
    (r"\b(rd|rmdir)\s+/s\s+/q\s+[a-z]:\\?(\s|\)|$)", "deletes a whole drive"),
    (r"\bdel\s+.*\s[a-z]:\\\*", "deletes a whole drive"),
    (r"\bremove-item\b.*\s[a-z]:\\\*?\s*(-|$)", "deletes a whole drive"),
    (r"\bclear-disk\b|\binitialize-disk\b|\bformat-volume\b", "erases a disk"),
]

SAFE_PREFIXES = [
    "git status", "git diff", "git log", "git show", "git branch", "git remote -v", "git rev-parse",
    "dir", "ls", "tree", "where ", "which ", "pwd", "cd",
    "python --version", "python -v", "py --version", "py -0", "node --version", "node -v", "npm --version",
    "npm -v", "npm ls", "pip list", "pip show", "pip --version", "dotnet --version", "dotnet --info",
    "rojo --version", "selene --version", "stylua --version", "cargo --version", "rustc --version",
    "go version", "java -version", "gcc --version", "cmake --version", "blender --version",
]
SHELL_OPERATORS = re.compile(r"[&|;<>`]|\$\(|\r|\n")


def classify(command: str) -> tuple[str, str]:
    c = " ".join(command.strip().split()).lower()
    if not c:
        return "blocked", "empty command"
    for pattern, why in BLOCKED:
        if re.search(pattern, c):
            return "blocked", f"blocked because it {why}"
    if not SHELL_OPERATORS.search(c):
        for p in SAFE_PREFIXES:
            if c == p.strip() or c.startswith(p if p.endswith(" ") else p + " ") or c == p:
                return "safe", "read-only command"
    return "ask", "needs your approval"


def _truncate(text: str) -> str:
    if len(text) <= MAX_OUTPUT:
        return text
    half = MAX_OUTPUT // 2
    return text[:half] + f"\n\n... ({len(text) - MAX_OUTPUT:,} characters omitted) ...\n\n" + text[-half:]


def _kill_tree(proc: subprocess.Popen) -> None:
    try:
        if sys.platform == "win32":
            subprocess.run(["taskkill", "/T", "/F", "/PID", str(proc.pid)], capture_output=True, timeout=15,
                           creationflags=0x08000000)
        else:
            os.killpg(proc.pid, signal.SIGKILL)
    except Exception:  # noqa: BLE001
        proc.kill()


def _shell_args(command: str, shell: str):
    if sys.platform == "win32":
        if shell == "powershell":
            return ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", command], False
        return command, True   # cmd.exe /c via COMSPEC
    return command, True


def _real_python_dirs() -> list[str]:
    """Folders of a real Python install. On Windows, a bare `python` often hits the Microsoft Store alias
    ("Python was not found; run without arguments to install from the Microsoft Store") even when Python is
    installed - so put the real one first on PATH for commands UNISON runs."""
    base = getattr(sys, "_base_executable", "") or sys.executable
    if not base or "WindowsApps" in base:
        return []
    d = os.path.dirname(base)
    return [d, os.path.join(d, "Scripts")]


def _command_env() -> dict:
    env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1", NO_COLOR="1", FORCE_COLOR="0")
    if sys.platform == "win32":
        extra = [p for p in _real_python_dirs() if os.path.isdir(p)]
        if extra:
            env["PATH"] = os.pathsep.join(extra + [env.get("PATH", "")])
    return env


# Models often type Linux commands, but run_command uses cmd.exe on Windows, where `ls`, `cat`, `rm -rf`...
# don't exist ("'ls' is not recognized"). Common ones are translated; the result says what really ran.
UNIX_ONLY = {"ls", "cat", "pwd", "touch", "rm", "cp", "mv", "which", "head", "tail", "grep", "clear", "ll"}


def _winpath(arg: str) -> str:
    if arg.startswith("-") or arg.startswith("/") and len(arg) <= 3:
        return arg
    a = arg.replace("/", "\\")
    return f'"{a}"' if " " in a and not a.startswith('"') else a


def _translate_one(cmd: str) -> Optional[str]:
    import shlex
    try:
        parts = shlex.split(cmd, posix=True)
    except ValueError:
        return None
    if not parts or parts[0].lower() not in UNIX_ONLY:
        return None
    name, args = parts[0].lower(), parts[1:]
    flags = "".join(x.lstrip("-") for x in args if x.startswith("-") and len(x) > 1)
    paths = [_winpath(x) for x in args if not x.startswith("-")]
    target = " ".join(paths)
    if name in ("ls", "ll"):
        return ("dir /s /b " + target if "R" in flags else "dir " + target).strip()
    if name == "cat" and paths:
        return "type " + target
    if name == "pwd":
        return "cd"
    if name == "which" and paths:
        return "where " + target
    if name == "clear":
        return "cls"
    if name == "touch" and paths:
        return " & ".join(f"type nul >> {p}" for p in paths)
    if name == "rm" and paths:
        if "r" in flags.lower():
            return " & ".join(f"(if exist {p}\\* (rmdir /s /q {p}) else (del /q {p}))" for p in paths)
        return "del /q " + target
    if name == "cp" and len(paths) == 2:
        return (f"xcopy /e /i /y {paths[0]} {paths[1]}" if "r" in flags.lower() else f"copy /y {paths[0]} {paths[1]}")
    if name == "mv" and len(paths) == 2:
        return f"move /y {paths[0]} {paths[1]}"
    return None


def windows_command(command: str) -> tuple[str, str]:
    """Return (command to run in cmd.exe, note). Translates Linux-style commands (and 'mkdir -p')."""
    segments = re.split(r"(\s*&&\s*)", command)
    changed, out = False, []
    for seg in segments:
        if re.fullmatch(r"\s*&&\s*", seg):
            out.append(" && ")
            continue
        m = re.match(r"\s*mkdir\s+-p\s+(.+)$", seg)
        if m:
            out.append("mkdir " + " ".join(_winpath(x) for x in m.group(1).split()))
            changed = True
            continue
        t = _translate_one(seg.strip())
        if t is not None:
            out.append(t)
            changed = True
        else:
            out.append(seg.strip())
    if not changed:
        return command, ""
    new = "".join(out)
    return new, f"(Windows has no Linux commands like ls/cat/rm - ran as: {new}. Tip: use list_dir and read_file to look at files.)"


def run_command(a: dict) -> ToolResult:
    command = (a.get("command") or "").strip()
    verdict, why = classify(command)
    if verdict == "blocked":
        raise ToolError(f"Command {why}. UNISON never runs this kind of command.")
    cwd = workspaces.resolve(a.get("cwd"))
    if not cwd.is_dir():
        raise ToolError(f"Working folder not found: {cwd}")
    smoke = int(a.get("smoke_test_seconds") or 0)
    timeout = max(5, min(int(a.get("timeout_seconds") or DEFAULT_TIMEOUT), MAX_TIMEOUT))
    if smoke:
        timeout = max(2, min(smoke, 60))
    shell = (a.get("shell") or "cmd").lower()
    note = ""
    if sys.platform == "win32" and shell != "powershell":
        command, note = windows_command(command)
        if note and classify(command)[0] == "blocked":
            raise ToolError(f"Command {classify(command)[1]}. UNISON never runs this kind of command.")
    args, use_shell = _shell_args(command, shell)
    env = _command_env()
    if smoke:
        # games open no window and play no sound during the check
        env.update(SDL_VIDEODRIVER="dummy", SDL_AUDIODRIVER="dummy", PYGAME_HIDE_SUPPORT_PROMPT="1")
    kwargs = {}
    if sys.platform == "win32":
        kwargs["creationflags"] = 0x08000000 | 0x00000200  # CREATE_NO_WINDOW | CREATE_NEW_PROCESS_GROUP
    else:
        kwargs["start_new_session"] = True
    started = time.time()
    proc = subprocess.Popen(args, shell=use_shell, cwd=str(cwd), env=env, stdin=subprocess.DEVNULL,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, **kwargs)
    timed_out = False
    try:
        out, _ = proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        _kill_tree(proc)
        out, _ = proc.communicate()
    text = out.decode("utf-8", errors="replace") if isinstance(out, bytes) else (out or "")
    if sys.platform == "win32" and "�" in text:
        try:
            text = out.decode("mbcs", errors="replace")   # legacy console code page
        except LookupError:
            pass
    secs = round(time.time() - started, 1)
    status = f"TIMED OUT after {timeout}s (process stopped)" if timed_out else f"exit code {proc.returncode}"
    body = _truncate(text.strip()) or "(no output)"
    if smoke:
        crashed = (not timed_out and proc.returncode != 0) or "Traceback (most recent call last)" in text
        verdict = ("SMOKE TEST FAILED - it crashed; fix the error below." if crashed else
                   f"SMOKE TEST PASSED - it ran {secs}s without crashing" + (" (then exited normally)." if not timed_out else " and was stopped."))
        return ToolResult(not crashed, f"$ {command}\n(cwd: {cwd}, {status}, {secs}s)\n{verdict}\n{(note + chr(10)) if note else ''}{body}",
                          {"exit_code": proc.returncode, "timed_out": timed_out, "seconds": secs, "cwd": str(cwd), "smoke": True})
    if note:
        body = note + "\n" + body
    return ToolResult(not timed_out and proc.returncode == 0,
                      f"$ {command}\n(cwd: {cwd}, {status}, {secs}s)\n{body}",
                      {"exit_code": proc.returncode, "timed_out": timed_out, "seconds": secs, "cwd": str(cwd)})


def preview_command(a: dict) -> dict:
    command = (a.get("command") or "").strip()
    verdict, why = classify(command)
    try:
        cwd = str(workspaces.resolve(a.get("cwd")))
    except ToolError as e:
        cwd = f"(invalid: {e})"
    return {"kind": "command", "command": command, "cwd": cwd, "shell": a.get("shell") or "cmd",
            "classification": verdict, "reason": why}


def open_path(a: dict) -> ToolResult:
    p = workspaces.resolve(a.get("path"))
    if not p.exists():
        raise ToolError(f"Not found: {p}")
    if p.suffix.lower() in (".exe", ".bat", ".cmd", ".ps1", ".vbs", ".js", ".msi", ".scr", ".com", ".lnk"):
        raise ToolError("open_path doesn't launch programs or scripts; use run_command so you can review it.")
    if sys.platform == "win32":
        os.startfile(str(p))  # type: ignore[attr-defined]
    else:
        subprocess.Popen(["xdg-open", str(p)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return ToolResult(True, f"Opened {p} with its default app")


def preview_open(a: dict) -> dict:
    return {"kind": "action", "summary": f"Open {a.get('path')} with its default app"}


TOOLS = [
    Tool("run_command",
         "Run a terminal command in a workspace folder on the user's Windows PC (cmd.exe by default, or "
         "shell='powershell'). Use it to run programs, tests, builds, git, pip/npm. Non-interactive: the command "
         "gets no keyboard input. Long-running servers will be stopped at the timeout. To check a game "
         "(pygame, tkinter...) or server runs without crashing, pass smoke_test_seconds.",
         obj({"command": s("The command line to run"),
              "cwd": s("Working folder (default: the default workspace)"),
              "shell": {"type": "string", "enum": ["cmd", "powershell"], "description": "Which shell (default cmd)"},
              "timeout_seconds": i("Stop after this many seconds (default 120, max 900)"),
              "smoke_test_seconds": i("For games/GUIs/servers that never exit: run this many seconds (e.g. 6) with "
                                      "no window or sound, then stop it. Passes if it didn't crash.")}, ["command"]),
         "exec", run_command, preview_command, default_mode="classify"),
    Tool("open_path", "Open a file or folder on the user's screen with its default app (e.g. a folder in "
                      "Explorer, an image, an .rbxl place in Roblox Studio, a .blend file in Blender).",
         obj({"path": s("File or folder to open")}, ["path"]),
         "launch", open_path, preview_open),
]
