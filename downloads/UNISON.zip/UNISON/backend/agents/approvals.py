"""Approval broker: an agent step that needs permission waits here until the user answers in the app."""
from __future__ import annotations

import asyncio
import time
import uuid
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Pending:
    id: str
    info: dict
    future: asyncio.Future
    created: float = field(default_factory=time.time)


class ApprovalBroker:
    def __init__(self) -> None:
        self.pending: dict[str, Pending] = {}

    def create(self, info: dict) -> Pending:
        p = Pending("act_" + uuid.uuid4().hex[:16], info, asyncio.get_running_loop().create_future())
        self.pending[p.id] = p
        return p

    def resolve(self, action_id: str, approved: bool, note: str = "") -> bool:
        p = self.pending.get(action_id)
        if not p or p.future.done():
            return False
        p.future.set_result({"approved": bool(approved), "note": note or ""})
        return True

    async def wait(self, p: Pending, timeout: float) -> dict:
        try:
            return await asyncio.wait_for(asyncio.shield(p.future), timeout)
        except asyncio.TimeoutError:
            return {"approved": False, "note": "No answer in time", "timeout": True}
        finally:
            self.pending.pop(p.id, None)

    def cancel_for(self, conversation_id: Optional[str]) -> None:
        for p in list(self.pending.values()):
            if p.info.get("conversation_id") == conversation_id and not p.future.done():
                p.future.set_result({"approved": False, "note": "Conversation stopped"})

    def list(self) -> list[dict]:
        return [{"action_id": p.id, **p.info, "waiting_seconds": round(time.time() - p.created)}
                for p in self.pending.values() if not p.future.done()]


broker = ApprovalBroker()
