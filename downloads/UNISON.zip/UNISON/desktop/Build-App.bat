@echo off
rem Rebuilds UNISON.exe (the Windows app). Setup and Start-UNISON.bat do this automatically.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0desktop\build.ps1"
pause
