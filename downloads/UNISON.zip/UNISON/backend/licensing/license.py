"""
UNISON license keys.

A key looks like  UNISON-<payload>.<signature>  (base64url). The payload is JSON:
  {"v": 1, "id": "...", "to": "Buyer name", "plan": "personal", "iat": 1731234567, "exp": 1733826567|null,
   "mid": "ABCD-EF01-2345-6789"|null}
The signature is Ed25519 over the payload bytes, made with the owner's private key. UNISON only holds the
public key (authority.py), so it can check keys offline but can't create them.

- "exp" null = never expires.  "mid" = the Machine ID the key is locked to (null = any PC).
- The activated key is stored in config/unison.json and re-checked on every request (cached briefly), so an
  expired key stops working without a restart.
"""
from __future__ import annotations

import base64
import hashlib
import json
import subprocess
import sys
import time
import uuid
from functools import lru_cache
from typing import Optional

from ..core.config import settings
from . import authority

PREFIX = "UNISON-"


def _b64(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _unb64(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


# ---------------------------------------------------------------- machine id
def _raw_machine_id() -> str:
    if sys.platform == "win32":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography",
                                0, winreg.KEY_READ | getattr(winreg, "KEY_WOW64_64KEY", 0)) as k:
                return str(winreg.QueryValueEx(k, "MachineGuid")[0])
        except OSError:
            pass
    for path in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
        try:
            with open(path, encoding="ascii") as f:
                v = f.read().strip()
                if v:
                    return v
        except OSError:
            continue
    if sys.platform == "darwin":
        try:
            out = subprocess.run(["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"], capture_output=True, text=True,
                                 timeout=5).stdout
            for line in out.splitlines():
                if "IOPlatformUUID" in line:
                    return line.split('"')[-2]
        except Exception:  # noqa: BLE001
            pass
    return str(uuid.getnode())


@lru_cache(maxsize=1)
def machine_id() -> str:
    """A stable, anonymous ID for this PC (a hash — it reveals nothing about the hardware)."""
    h = hashlib.sha256(("unison:" + _raw_machine_id()).encode()).hexdigest().upper()[:16]
    return "-".join(h[i:i + 4] for i in range(0, 16, 4))


# ---------------------------------------------------------------- verification
class LicenseError(Exception):
    pass


def _public_key(pub_b64: Optional[str] = None):
    key = pub_b64 if pub_b64 is not None else authority.PUBLIC_KEY
    if not key:
        raise LicenseError("This copy of UNISON has no license authority configured.")
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    except ImportError as e:   # pragma: no cover - only when requirements weren't installed
        raise LicenseError("A required package is missing (cryptography). Run Update.bat.") from e
    return Ed25519PublicKey.from_public_bytes(_unb64(key))


def parse(key: str, pub_b64: Optional[str] = None, now: Optional[float] = None,
          mid: Optional[str] = None, any_pc: bool = False) -> dict:
    """Check a key. Returns its payload, or raises LicenseError with a human-readable reason."""
    key = "".join((key or "").split())          # tolerate line breaks / spaces from copy-paste
    if not key.startswith(PREFIX) or key.count(".") != 1:
        raise LicenseError("That doesn't look like a UNISON license key.")
    body, sig = key[len(PREFIX):].split(".")
    try:
        payload_bytes, sig_bytes = _unb64(body), _unb64(sig)
    except Exception as e:  # noqa: BLE001
        raise LicenseError("The key is damaged (copy it again).") from e
    from cryptography.exceptions import InvalidSignature
    try:
        _public_key(pub_b64).verify(sig_bytes, payload_bytes)
    except InvalidSignature as e:
        raise LicenseError("This key isn't valid for UNISON.") from e
    except ValueError as e:
        raise LicenseError("The key is damaged (copy it again).") from e
    data = json.loads(payload_bytes)
    t = time.time() if now is None else now
    if data.get("exp") and t > data["exp"]:
        raise LicenseError(f"This key expired on {time.strftime('%Y-%m-%d', time.localtime(data['exp']))}.")
    if data.get("mid") and not any_pc and data["mid"] != (mid or machine_id()):
        raise LicenseError("This key belongs to a different computer.")
    return data


# ---------------------------------------------------------------- activation state
_cache: tuple[float, dict] = (0.0, {})


def status(force: bool = False) -> dict:
    global _cache
    if not force and time.time() - _cache[0] < 30:
        return _cache[1]
    key = settings.get("license", "key") or ""
    info = {"activated": False, "machine_id": machine_id(), "authority": bool(authority.PUBLIC_KEY)}
    if key:
        try:
            data = parse(key)
            info.update(activated=True, to=data.get("to"), plan=data.get("plan"), id=data.get("id"),
                        expires=data.get("exp"), locked_to_this_pc=bool(data.get("mid")))
        except LicenseError as e:
            info["problem"] = str(e)
    elif not authority.PUBLIC_KEY:
        info["problem"] = "This copy of UNISON has no license authority configured."
    _cache = (time.time(), info)
    return info


def activate(key: str) -> dict:
    parse(key)   # raises LicenseError with the reason
    settings.set("license", "key", "".join(key.split()))
    return status(force=True)


def deactivate() -> dict:
    settings.set("license", "key", "")
    return status(force=True)


def is_activated() -> bool:
    return bool(status().get("activated"))


# ---------------------------------------------------------------- minting (owner only: needs the private key)
def mint(private_pem: bytes, to: str, plan: str = "personal", days: Optional[int] = None,
         mid: Optional[str] = None) -> str:
    from cryptography.hazmat.primitives import serialization
    priv = serialization.load_pem_private_key(private_pem, password=None)
    now = int(time.time())
    payload = {"v": 1, "id": uuid.uuid4().hex[:12], "to": to, "plan": plan, "iat": now,
               "exp": now + days * 86400 if days else None, "mid": mid or None}
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return PREFIX + _b64(raw) + "." + _b64(priv.sign(raw))


def new_keypair() -> tuple[bytes, str]:
    """(private key PEM, public key base64url)."""
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    priv = Ed25519PrivateKey.generate()
    pem = priv.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                             serialization.NoEncryption())
    pub = priv.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    return pem, _b64(pub)
