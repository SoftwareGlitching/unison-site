# Developing on Windows: shells, Python, Node, paths

## cmd.exe vs PowerShell
| Task | cmd.exe | PowerShell |
|---|---|---|
| list files | `dir` / `dir /s /b *.py` | `Get-ChildItem` (`ls`, `gci -Recurse -Filter *.py`) |
| show file | `type file.txt` | `Get-Content file.txt` (`cat`) |
| make folder | `mkdir a\b` (creates parents) | `New-Item -ItemType Directory a\b` (`mkdir`) |
| copy / move | `copy`, `xcopy /e /i`, `move` | `Copy-Item -Recurse`, `Move-Item` |
| delete | `del file`, `rmdir /s /q folder` | `Remove-Item -Recurse -Force folder` |
| env var | `%USERPROFILE%`, `set X=1` | `$env:USERPROFILE`, `$env:X = "1"` |
| chain | `a && b` (b only if a succeeds) | `a; b` (PowerShell 7 also has `&&`) |
| find text | `findstr /s /i "needle" *.lua` | `Select-String -Path *.lua -Pattern needle` |
- Paths use backslashes; quote any path with spaces: `"C:\Users\Me\My Game\main.py"`.
- `cd` in cmd doesn't change drive without `/d`: `cd /d D:\projects`.
- The user's Desktop may be redirected into OneDrive (`C:\Users\<name>\OneDrive\Desktop`).
- Line endings: Windows tools usually write CRLF (`\r\n`); git may convert (`core.autocrlf`).

## Python
- The `py` launcher picks versions: `py -3.12 script.py`, `py -0p` lists installed Pythons.
- `python` may be the Microsoft Store stub if Python isn't on PATH (it prints a message and exits 9009).
- Virtual environments: `py -3.12 -m venv .venv`, then run `.venv\Scripts\python -m pip install requests`
  (no need to "activate" when calling the venv's python directly).
- `python -m pip`, `python -m pytest`, `python -m unittest` avoid PATH problems with script launchers.
- UnicodeEncodeError when printing emoji/non-ASCII in old consoles: set `PYTHONUTF8=1` or
  `PYTHONIOENCODING=utf-8`.
- `ModuleNotFoundError`: the package isn't installed in the interpreter you ran, or the working directory
  isn't the project root (run `python -m package.module` from the root).

## Node.js
- `npm init -y`, `npm install <pkg>`, `npm run <script>`, `npx <tool>`; on Windows the executables are
  `npm.cmd`/`npx.cmd` (fine to type `npm` in cmd).
- `node script.js`; ES modules need `"type": "module"` in package.json or the `.mjs` extension.
- PowerShell may block `npm.ps1` with an execution-policy error; use `npm.cmd` or run from cmd.

## .NET / C#
- `dotnet new console -n MyApp`, `dotnet run --project MyApp`, `dotnet build`, `dotnet test`.

## Non-interactive commands (important for agents)
- Commands run without a keyboard: pass `-y`/`--yes` (npm init -y, pip install has no prompt) and avoid
  anything that opens an editor (`git commit` without `-m`) or waits (`pause`, `input()`).
- Don't start long-running servers (`npm run dev`, `rojo serve`, `python -m http.server`) as a one-shot
  command: they never exit. Tell the user how to start them instead.
- Exit code 0 means success. Python tracebacks, `npm ERR!` and `error CS####` lines tell you what failed.
