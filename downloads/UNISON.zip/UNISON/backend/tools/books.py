"""
Reading books and long documents: PDF, EPUB, Word (.docx), text and Markdown.

- read_book: read a page/chapter range, or find the passages about something. Big books are read in parts,
  so the brain never needs the whole book in its memory at once.
- learn_book: save the book's text into UNISON's library (the knowledge base), so it can answer questions
  about it in any later chat.
Only the standard library is needed, except PDFs, which use pypdf (installed by Setup / Fix-UNISON).
"""
from __future__ import annotations

import html
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

from ..core.config import ROOT
from .base import Tool, ToolError, ToolResult
from .sandbox import workspaces

BOOK_TYPES = {".pdf", ".epub", ".docx", ".txt", ".md", ".markdown", ".rst", ".html", ".htm"}
PART_CHARS = 4000          # size of one "part" for formats without pages
READ_LIMIT = 14000         # most characters returned by one read_book call
MAX_BOOK_BYTES = 80 * 1024 * 1024
KNOWLEDGE_DIR = ROOT / "knowledge"   # same folder as backend/knowledge/store.py


def _clean(text: str) -> str:
    text = text.replace("\r", "")
    text = re.sub(r"[ \t ]+", " ", text)
    text = re.sub(r"\n\s*\n\s*\n+", "\n\n", text)
    return text.strip()


def _html_text(markup: str) -> str:
    markup = re.sub(r"(?is)<(script|style|head)\b.*?</\1>", " ", markup)
    markup = re.sub(r"(?i)<br\s*/?>|</(p|div|h[1-6]|li|tr|section)>", "\n", markup)
    return _clean(html.unescape(re.sub(r"<[^>]+>", " ", markup)))


def _split_parts(text: str, label: str = "Part") -> list[tuple[str, str]]:
    text = _clean(text)
    parts, buf = [], ""
    for para in text.split("\n\n"):
        if buf and len(buf) + len(para) > PART_CHARS:
            parts.append(buf)
            buf = ""
        buf += ("\n\n" if buf else "") + para
    if buf:
        parts.append(buf)
    return [(f"{label} {n}", p) for n, p in enumerate(parts, 1)]


def _pdf(path: Path) -> list[tuple[str, str]]:
    try:
        from pypdf import PdfReader
    except ImportError as e:
        raise ToolError("Reading PDFs needs the pypdf package. Run Fix-UNISON.bat (or: .venv\\Scripts\\pip install pypdf).") from e
    try:
        reader = PdfReader(str(path))
        if reader.is_encrypted:
            try:
                reader.decrypt("")
            except Exception:  # noqa: BLE001
                raise ToolError("This PDF is password-protected.")
        out = []
        for n, page in enumerate(reader.pages, 1):
            try:
                out.append((f"Page {n}", _clean(page.extract_text() or "")))
            except Exception:  # noqa: BLE001 - one bad page shouldn't stop the book
                out.append((f"Page {n}", ""))
    except ToolError:
        raise
    except Exception as e:  # noqa: BLE001
        raise ToolError(f"Couldn't read this PDF: {e}") from e
    if out and not any(t for _, t in out):
        raise ToolError("This PDF has no text layer (it's scanned images), so it can't be read as text.")
    return out


def _epub(path: Path) -> list[tuple[str, str]]:
    try:
        z = zipfile.ZipFile(path)
    except zipfile.BadZipFile as e:
        raise ToolError("This EPUB file is damaged.") from e
    with z:
        names = set(z.namelist())
        order: list[str] = []
        try:
            container = ET.fromstring(z.read("META-INF/container.xml"))
            opf_path = next(el.get("full-path") for el in container.iter() if el.tag.endswith("rootfile"))
            opf = ET.fromstring(z.read(opf_path))
            base = opf_path.rsplit("/", 1)[0] + "/" if "/" in opf_path else ""
            manifest = {el.get("id"): el.get("href") for el in opf.iter() if el.tag.endswith("item")}
            for el in opf.iter():
                if el.tag.endswith("itemref") and manifest.get(el.get("idref")):
                    href = base + manifest[el.get("idref")].split("#")[0]
                    if href in names:
                        order.append(href)
        except Exception:  # noqa: BLE001 - fall back to file order
            order = []
        if not order:
            order = sorted(n for n in names if n.lower().endswith((".xhtml", ".html", ".htm")))
        out = []
        for name in order:
            text = _html_text(z.read(name).decode("utf-8", "replace"))
            if len(text) > 40:
                out.append((f"Chapter {len(out) + 1}", text))
    return out


def _docx(path: Path) -> list[tuple[str, str]]:
    try:
        with zipfile.ZipFile(path) as z:
            xml = z.read("word/document.xml")
    except (zipfile.BadZipFile, KeyError) as e:
        raise ToolError("This Word file is damaged or isn't a .docx.") from e
    ns = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    paras = []
    for p in ET.fromstring(xml).iter(ns + "p"):
        paras.append("".join(t.text or "" for t in p.iter(ns + "t")))
    return _split_parts("\n\n".join(paras))


def extract(path: Path) -> list[tuple[str, str]]:
    """The book as (label, text) sections: pages for PDFs, chapters for EPUBs, parts for everything else."""
    suffix = path.suffix.lower()
    if suffix not in BOOK_TYPES:
        raise ToolError(f"Can't read {suffix or 'this'} files as a book. Supported: PDF, EPUB, DOCX, TXT, MD, HTML.")
    if path.stat().st_size > MAX_BOOK_BYTES:
        raise ToolError("That file is over 80 MB.")
    if suffix == ".pdf":
        return _pdf(path)
    if suffix == ".epub":
        return _epub(path)
    if suffix == ".docx":
        return _docx(path)
    raw = path.read_bytes().decode("utf-8", "replace")
    if suffix in (".html", ".htm"):
        raw = _html_text(raw)
    return _split_parts(raw)


def _find(sections: list[tuple[str, str]], query: str, limit: int = 8) -> list[tuple[str, str]]:
    words = [w for w in re.findall(r"\w{3,}", query.lower())]
    if not words:
        return []
    scored = []
    for label, text in sections:
        for para in re.split(r"\n\s*\n", text):
            low = para.lower()
            score = sum(low.count(w) for w in words) + 2 * (query.lower() in low)
            if score:
                scored.append((score, label, para.strip()))
    scored.sort(key=lambda x: -x[0])
    return [(label, para[:1200]) for _, label, para in scored[:limit]]


# --------------------------------------------------------------------------- tools
def read_book(a: dict) -> ToolResult:
    path = workspaces.resolve(a.get("path"))
    if not path.is_file():
        raise ToolError(f"Not found: {path}")
    sections = extract(path)
    total = len(sections)
    unit = sections[0][0].split()[0].lower() + "s" if sections else "parts"
    query = (a.get("query") or "").strip()
    if query:
        hits = _find(sections, query)
        if not hits:
            return ToolResult(True, f"{path.name}: nothing mentions '{query}' ({total} {unit}).")
        body = "\n\n".join(f"[{label}] {para}" for label, para in hits)
        return ToolResult(True, f"{path.name} - passages about '{query}' ({total} {unit} in the book):\n\n{body}")
    start = max(1, int(a.get("start") or 1))
    count = max(1, int(a.get("count") or 0)) if a.get("count") else None
    if start > total:
        raise ToolError(f"{path.name} only has {total} {unit}.")
    out, used, n = [], 0, start
    while n <= total and (count is None or n < start + count):
        label, text = sections[n - 1]
        if out and used + len(text) > READ_LIMIT:
            break
        text = text[:READ_LIMIT - used] if not out else text
        out.append(f"--- {label} ---\n{text}")
        used += len(text)
        n += 1
    more = f"\n\n(Read {unit} {start}-{n - 1} of {total}. Call read_book with start={n} to continue.)" if n <= total \
        else f"\n\n(End of the book: {total} {unit}.)"
    return ToolResult(True, f"{path.name}\n\n" + "\n\n".join(out) + more, {"total": total, "next": n if n <= total else None})


def save_to_library(name: str, sections: list[tuple[str, str]]) -> Path:
    safe = re.sub(r"[^A-Za-z0-9 ._-]", "_", Path(name).stem).strip() or "book"
    dest = KNOWLEDGE_DIR / "user" / "books" / f"{safe}.md"
    dest.parent.mkdir(parents=True, exist_ok=True)
    body = "\n\n".join(f"## {safe} - {label}\n\n{text}" for label, text in sections if text)
    dest.write_text(f"# {safe}\n\n{body}\n", encoding="utf-8")
    return dest


async def learn_book(a: dict) -> ToolResult:
    path = workspaces.resolve(a.get("path"))
    if not path.is_file():
        raise ToolError(f"Not found: {path}")
    sections = extract(path)
    dest = save_to_library(path.name, sections)
    from ..knowledge.store import get_store
    store = get_store()
    ok, why = await store.available()
    if not ok:
        return ToolResult(True, f"Saved {path.name} to the library ({dest.name}) but couldn't index it yet: {why}")
    chunks = await store.ingest_file(dest, "knowledge", "knowledge", title=f"books/{dest.name}")
    return ToolResult(True, f"Added {path.name} to UNISON's library: {len(sections)} sections, {chunks} searchable chunks. "
                            "Its contents now come up automatically when the user asks about it.")


def _obj(props: dict, required: list[str]) -> dict:
    return {"type": "object", "properties": props, "required": required}


TOOLS = [
    Tool("read_book",
         "Read a book or long document (PDF, EPUB, DOCX, TXT, MD, HTML) in the workspace. Reads pages (PDF), "
         "chapters (EPUB) or parts from 'start'; long books come back in pieces - call again with the 'start' it "
         "tells you to keep reading. Give 'query' instead to get just the passages about a topic.",
         _obj({"path": {"type": "string", "description": "The book file"},
               "start": {"type": "integer", "description": "First page/chapter/part to read (default 1)"},
               "count": {"type": "integer", "description": "How many pages/chapters/parts (default: as many as fit)"},
               "query": {"type": "string", "description": "Find passages about this instead of reading in order"}},
              ["path"]),
         "read", read_book, default_mode="auto"),
    Tool("learn_book",
         "Add a book or document to UNISON's permanent library so you can answer questions about it in any future "
         "chat (it's split up and indexed for search).",
         _obj({"path": {"type": "string", "description": "The book file"}}, ["path"]),
         "write", learn_book, default_mode="auto"),
]
