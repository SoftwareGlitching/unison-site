"""Remote lockdown: 2-step sign-in codes, PC-only settings, no autonomous jobs through the tunnel."""
import asyncio
import time
import unittest

from tests.helpers import IsolatedSettings
from tests.test_auth import Req, tunnel

from backend.security import sessions


def run(c):
    return asyncio.run(c)


class TotpTests(unittest.TestCase):
    def test_rfc6238_vector(self):
        # RFC 6238 test secret "12345678901234567890" (base32 below), T=59s -> 94287082 -> last 6 digits
        secret = "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ"
        self.assertEqual(sessions._totp_at(secret, 59 // 30), "287082")

    def test_setup_confirm_and_single_use(self):
        with IsolatedSettings():
            out = sessions.totp_begin()
            secret = out["secret"].replace(" ", "")
            self.assertIn("otpauth://totp/", out["uri"])
            self.assertFalse(sessions.totp_enabled())               # not on until confirmed
            now = time.time()
            code = sessions._totp_at(secret, int(now // 30))
            self.assertTrue(sessions.totp_confirm(code))
            self.assertTrue(sessions.totp_enabled())
            self.assertFalse(sessions.totp_check(code))             # same code can't be replayed
            nxt = sessions._totp_at(secret, int(now // 30) + 1)
            self.assertTrue(sessions.totp_check(nxt))               # next step (clock drift) works once
            self.assertFalse(sessions.totp_check("000000x"))
            sessions.totp_disable()
            self.assertFalse(sessions.totp_enabled())


class RemoteLoginTests(unittest.TestCase):
    def setUp(self):
        from backend.api import routes_auth as ra
        ra.failed = ra.FailedLogins()
        self.ra = ra

    def login(self, req, password, code=None):
        return run(self.ra.login(self.ra.PasswordBody(password=password, code=code), req))

    def test_remote_needs_password_and_code_local_needs_only_password(self):
        with IsolatedSettings():
            sessions.set_password("owner-password-123")
            secret = sessions.totp_begin()["secret"].replace(" ", "")
            step = int(time.time() // 30)
            sessions.totp_confirm(sessions._totp_at(secret, step - 1))
            st = run(self.ra.status(tunnel()))
            self.assertTrue(st["code_required"])
            self.assertFalse(run(self.ra.status(Req()))["code_required"])
            with self.assertRaises(Exception) as ctx:                # leaked password alone: refused
                self.login(tunnel(), "owner-password-123")
            self.assertEqual(ctx.exception.detail["code"], "wrong_password_or_code")
            with self.assertRaises(Exception) as ctx:                # right code, wrong password: same message
                self.login(tunnel(), "nope", sessions._totp_at(secret, step))
            self.assertEqual(ctx.exception.detail["code"], "wrong_password_or_code")
            ok = self.login(tunnel(), "owner-password-123", sessions._totp_at(secret, step))
            self.assertTrue(sessions.verify_token(ok["token"]))
            self.assertTrue(self.login(Req(), "owner-password-123")["ok"])   # at the PC: no code needed

    def test_two_factor_setup_only_at_the_pc(self):
        from backend.security.auth import pc_only
        with IsolatedSettings():
            sessions.set_password("owner-password-123")
            with self.assertRaises(Exception) as ctx:
                run(pc_only(tunnel()))                               # even with a session
            self.assertEqual(ctx.exception.status_code, 403)
            run(pc_only(Req()))


class AutonomousJobTests(unittest.TestCase):
    def test_autonomous_jobs_blocked_through_tunnel(self):
        from backend.api import routes_jobs as rj
        with IsolatedSettings():
            body = rj.JobRequest(kind="agent", task="delete everything", autonomous=True)
            with self.assertRaises(Exception) as ctx:
                run(rj.create_job(body, tunnel()))
            self.assertEqual(ctx.exception.status_code, 403)


if __name__ == "__main__":
    unittest.main()
