# Python essentials for writing solid code

## Idioms
- Iterate directly: `for item in items`, with index `for i, item in enumerate(items)`, pairs `zip(a, b)`.
- Comprehensions: `[x * 2 for x in xs if x > 0]`, `{k: v for k, v in pairs}`, generators `sum(x for x in xs)`.
- `collections`: `Counter` (counting), `defaultdict(list)` (grouping), `deque` (queues, `maxlen`),
  `OrderedDict.move_to_end` (LRU caches).
- `pathlib.Path`: `Path("data") / "file.txt"`, `.read_text(encoding="utf-8")`, `.exists()`, `.glob("*.py")`,
  `.mkdir(parents=True, exist_ok=True)`. Always pass `encoding="utf-8"` when reading/writing text on Windows.
- `with open(...) as f:` closes files even on errors.
- f-strings: `f"{name!r} has {score:.2f} points"`.
- Unpacking: `first, *rest = items`, swapping `a, b = b, a`.
- `sorted(items, key=lambda x: (-x.score, x.name))` sorts by score descending then name.
- `bisect.bisect_left` for binary search on sorted lists; `heapq` for priority queues / top-k.
- `functools.lru_cache` for memoisation; `itertools` (`chain`, `groupby` on sorted data, `product`, `islice`).

## Structure
- `if __name__ == "__main__": main()` so modules can be imported without running.
- `@dataclass` for plain data classes (`field(default_factory=list)` for mutable defaults).
- Type hints: `def load(path: Path) -> dict[str, int]:`; `Optional[X]` / `X | None`.
- Never use mutable default arguments (`def f(items=[])`) — use `None` and create inside.
- Raise specific exceptions (`ValueError`, `FileNotFoundError`) with clear messages; catch only what you can handle.
- `logging` instead of print for programs: `logging.basicConfig(level=logging.INFO)`.

## Testing
```python
# test_mathutils.py
import unittest
from mathutils import clamp

class ClampTests(unittest.TestCase):
    def test_inside(self):
        self.assertEqual(clamp(5, 0, 10), 5)
    def test_low(self):
        self.assertEqual(clamp(-1, 0, 10), 0)

if __name__ == "__main__":
    unittest.main()
```
Run: `python -m unittest` (discovers `test_*.py`) or `python -m pytest -q` (if pytest is installed; plain
`assert` statements, fixtures, `pytest.raises(ValueError)`).

## Async
- `asyncio.run(main())`; `await asyncio.gather(*tasks)` runs coroutines concurrently;
  `asyncio.to_thread(blocking_fn)` for blocking work; never call `time.sleep` inside async code.

## Reading errors
- Read tracebacks bottom-up: the last line is the error type and message; the line above shows where.
- `IndentationError` / `SyntaxError`: look at the line shown AND the one before it (unclosed bracket/quote).
- `TypeError: 'NoneType' object is not subscriptable`: a function returned None (often a missing `return`).
- `KeyError`: use `dict.get(key, default)` when absence is normal.
- `RecursionError`: missing base case, or recursion on huge input — switch to a loop/stack.
