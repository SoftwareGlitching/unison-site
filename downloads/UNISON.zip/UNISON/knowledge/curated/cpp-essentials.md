# Modern C++ (C++17/20) essentials for real projects

## Building on Windows
- MinGW/MSYS2 g++: `g++ -std=c++17 -O2 -Wall -Wextra main.cpp -o app.exe`, then `app.exe`.
- MSVC (Developer Command Prompt / "x64 Native Tools"): `cl /EHsc /std:c++17 /W4 main.cpp`.
- Check what's installed: `where g++`, `where cl`, `where cmake`. If nothing: install MSYS2 (then `pacman -S mingw-w64-ucrt-x86_64-gcc`) or "Visual Studio Build Tools" (Desktop development with C++).
- CMake for multi-file projects:
```cmake
cmake_minimum_required(VERSION 3.20)
project(MyApp LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
add_executable(myapp src/main.cpp src/game.cpp)
target_include_directories(myapp PRIVATE include)
if(MSVC)
  target_compile_options(myapp PRIVATE /W4)
else()
  target_compile_options(myapp PRIVATE -Wall -Wextra)
endif()
```
  Build: `cmake -S . -B build` then `cmake --build build --config Release`.

## Project layout
- `include/game.hpp` (declarations, `#pragma once`), `src/game.cpp` (definitions), `src/main.cpp`.
- One class per header/source pair; keep headers light (forward-declare instead of including when you can).

## Core rules
- RAII: resources are owned by objects whose destructor frees them. Never raw `new`/`delete`:
  `auto p = std::make_unique<Enemy>(...)`, `std::vector<std::unique_ptr<Enemy>>`.
- Prefer values and references: `void update(const Config& cfg)`, return by value (moves are cheap).
- Containers: `std::vector`, `std::string`, `std::unordered_map`, `std::array`, `std::optional`, `std::variant`.
- Loops: `for (const auto& e : enemies)`; algorithms: `std::sort(v.begin(), v.end(), [](auto& a, auto& b){ return a.score > b.score; })`,
  remove-erase: `std::erase_if(v, [](auto& e){ return e.dead; })` (C++20) or `v.erase(std::remove_if(...), v.end())`.
- `const` everything that doesn't change; `constexpr` for compile-time constants; `enum class` over plain enums.
- Errors: exceptions for exceptional failures, `std::optional`/return codes for expected misses.
- Strings and files: `<fstream>` `std::ifstream in(path); std::string line; while (std::getline(in, line)) {...}`;
  `<filesystem>` `std::filesystem::exists(p)`.
- Formatting: `std::format("{} has {} hp", name, hp)` (C++20) or `std::cout << ...`.
- Random: `std::mt19937 rng{std::random_device{}()}; std::uniform_int_distribution<int> d(1, 6); d(rng);`
- Time: `<chrono>` `auto t0 = std::chrono::steady_clock::now();`.
- Threads: `std::jthread`, `std::mutex` + `std::lock_guard`, `std::atomic<int>`.

## Classes
```cpp
#pragma once
#include <string>
class Account {
public:
    explicit Account(std::string owner, double balance = 0.0);
    void deposit(double amount);              // throws std::invalid_argument if amount <= 0
    [[nodiscard]] double balance() const noexcept { return balance_; }
private:
    std::string owner_;
    double balance_;
};
```
- Rule of zero: if members manage themselves (strings, vectors, unique_ptr) don't write copy/move/destructor.
- Virtual base classes need `virtual ~Base() = default;`; mark overrides with `override`.

## Games
- raylib (simplest): `InitWindow(800, 450, "Game"); SetTargetFPS(60); while (!WindowShouldClose()) { float dt = GetFrameTime(); BeginDrawing(); ClearBackground(BLACK); ... EndDrawing(); } CloseWindow();`
- SFML 2.6/3: `sf::RenderWindow`, poll events, `sf::Clock` for dt, `window.draw(sprite)`.
- Console games: clear with `system("cls")` sparingly; better `\x1b[2J\x1b[H` with virtual terminal enabled.

## Common bugs
- Dangling references/iterators after `vector::push_back` (reallocation) - store indices or reserve.
- Integer division (`1/2 == 0`), signed/unsigned comparison warnings, uninitialized variables (always initialize).
- Forgetting `#pragma once` (redefinition errors) or defining functions in headers without `inline`.
- "undefined reference": the .cpp wasn't compiled/linked - add it to the g++ line or CMake target.
