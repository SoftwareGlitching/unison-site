# Roblox DataStores: saving player data safely

## Basics
- `local DataStoreService = game:GetService("DataStoreService")`
- `local store = DataStoreService:GetDataStore("PlayerData_v1")` (version the name so you can migrate).
- Keys: use the numeric `player.UserId` (e.g. `"u_" .. player.UserId`), never the display name.
- Every call can fail (throttling, outages): wrap it in `pcall` and handle the failure.
- Studio needs "Enable Studio Access to API Services" (Game Settings → Security) to use DataStores.
- Values must be JSON-compatible tables, strings, numbers, booleans; no Instances, Vector3s or functions.
  Convert e.g. `Vector3` to `{x, y, z}`. Each value is limited to 4 MB.

## Load with retries
```lua
local function withRetries<T>(attempts: number, fn: () -> T): (boolean, T?)
	for attempt = 1, attempts do
		local ok, result = pcall(fn)
		if ok then return true, result end
		warn(`DataStore attempt {attempt} failed: {result}`)
		task.wait(2 ^ attempt) -- exponential backoff: 2s, 4s, 8s
	end
	return false, nil
end

local DEFAULT = { Coins = 0, Level = 1, Inventory = {} }

local function load(player: Player)
	local ok, data = withRetries(3, function()
		return store:GetAsync("u_" .. player.UserId)
	end)
	if not ok then
		-- Do NOT let them play with default data that would later overwrite their real save.
		player:Kick("Couldn't load your data. Please rejoin.")
		return nil
	end
	data = data or table.clone(DEFAULT)
	for k, v in pairs(DEFAULT) do -- fill in fields added after the player's last save
		if data[k] == nil then data[k] = v end
	end
	return data
end
```

## Save with UpdateAsync
`UpdateAsync` reads the current value and writes yours in one step, so two servers can't silently
overwrite each other the way two `SetAsync` calls can.
```lua
local function save(player: Player, data)
	return withRetries(3, function()
		return store:UpdateAsync("u_" .. player.UserId, function(old)
			-- return nil here to cancel the write (e.g. if old data looks newer than ours)
			return data
		end)
	end)
end
```

## When to save
- `Players.PlayerRemoving` for each leaving player.
- `game:BindToClose(function() ... end)` when the server shuts down: save every player still in the game,
  in parallel with `task.spawn`, and wait for them (BindToClose gives about 30 seconds).
- Autosave every few minutes for long sessions (a loop with `task.wait(120)`), not on every change.
- Keep a `loaded[player] = true` flag and only save players whose data actually loaded.

```lua
game:BindToClose(function()
	local pending = 0
	for _, player in Players:GetPlayers() do
		pending += 1
		task.spawn(function()
			save(player, sessionData[player])
			pending -= 1
		end)
	end
	while pending > 0 do task.wait() end
end)
```

## Limits and design notes
- Requests per minute are budgeted per server (`DataStoreService:GetRequestBudgetForRequestType`).
  Don't save in loops over many keys at once.
- Session locking (preventing two servers from editing the same player's data, e.g. during fast server
  hops) can be built by storing a lock with server id + timestamp inside the saved table, or use a
  community library such as ProfileStore/ProfileService that implements it.
- `OrderedDataStore` stores only integers and is for leaderboards (`GetSortedAsync`).
- `MemoryStoreService` is for fast, temporary cross-server data (matchmaking queues), not saves.
- Keep a schema version number in the saved table and migrate old shapes when loading.
