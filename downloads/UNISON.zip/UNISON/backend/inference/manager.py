"""
Model manager: owns the inference backend, the active model, sampling defaults and live
performance numbers (measured from real generations, never estimated).
"""
from __future__ import annotations

import time
from collections import deque
from typing import AsyncIterator, Optional

from ..core.config import settings
from .base import ChatMessage, GenerationOptions, GenerationStats, InferenceError, StreamEvent
from .ollama_backend import OllamaBackend


class ModelManager:
    def __init__(self, backend=None):
        self.backend = backend or OllamaBackend(
            settings.get("inference", "ollama_url", "http://127.0.0.1:11434"),
            float(settings.get("inference", "request_timeout_seconds", 600)))
        self.active_generations = 0
        self.last_stats: Optional[GenerationStats] = None
        self.history: deque[dict] = deque(maxlen=100)
        self.started_at = time.time()

    # ---------- model selection ----------
    @property
    def active_model(self) -> str:
        m = settings.get("inference", "active_model") or ""
        if not m:
            m = settings.models_config().get("active_model", "")
        return m

    async def set_active_model(self, name: str) -> None:
        installed = {m.name for m in await self.backend.list_models()}
        if name not in installed:
            raise InferenceError(f"Model '{name}' is not installed. Download it first.", 404, "model_not_found")
        settings.set("inference", "active_model", name)

    async def resolve_model(self, requested: Optional[str]) -> str:
        """Pick the model for a request: explicit choice, else the active model, else any installed one."""
        if requested and requested not in ("unison", "default"):
            return requested
        if self.active_model:
            return self.active_model
        models = await self.backend.list_models()
        if not models:
            raise InferenceError("No models are installed. Run Setup.bat or download one from the model menu.",
                                 404, "no_models")
        return models[0].name

    # ---------- generation ----------
    def default_options(self, **overrides) -> GenerationOptions:
        g = settings.data.get("inference", {})
        opts = GenerationOptions(
            temperature=g.get("temperature"), top_p=g.get("top_p"), top_k=g.get("top_k"),
            repeat_penalty=g.get("repeat_penalty"), num_ctx=g.get("num_ctx"))
        for k, v in overrides.items():
            if v is not None and hasattr(opts, k):
                setattr(opts, k, v)
        return opts

    def system_prompt(self, model: str) -> str:
        tpl = settings.get("assistant", "system_prompt", "") or ""
        return tpl.replace("{model}", model)

    async def stream(self, model: str, messages: list[ChatMessage],
                     options: GenerationOptions, tools: Optional[list[dict]] = None) -> AsyncIterator[StreamEvent]:
        self.active_generations += 1
        started = time.time()
        try:
            async for ev in self.backend.chat_stream(model, messages, options,
                                                     settings.get("inference", "keep_alive"), tools=tools):
                if ev.type == "done" and ev.stats:
                    self.last_stats = ev.stats
                    self.history.append({"at": time.time(), "wall_ms": round((time.time() - started) * 1000),
                                         **ev.stats.to_dict()})
                yield ev
        finally:
            self.active_generations -= 1

    def status(self) -> dict:
        tps = [h["tokens_per_second"] for h in self.history if h.get("tokens_per_second")]
        return {
            "active_model": self.active_model,
            "engine": getattr(self.backend, "name", "unknown"),
            "state": "generating" if self.active_generations else "idle",
            "active_generations": self.active_generations,
            "last": self.last_stats.to_dict() if self.last_stats else None,
            "avg_tokens_per_second": round(sum(tps) / len(tps), 2) if tps else None,
            "generations_since_start": len(self.history),
        }


manager = ModelManager()
