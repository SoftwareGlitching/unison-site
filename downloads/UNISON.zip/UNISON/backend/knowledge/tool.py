"""Lets the agent look things up in the local knowledge base (curated docs + indexed projects)."""
from __future__ import annotations

from ..tools.base import Tool, ToolResult, i, obj, s
from .store import format_context, get_store


async def search_knowledge(a: dict) -> ToolResult:
    query = (a.get("query") or "").strip()
    if not query:
        return ToolResult(False, "query is required")
    store = get_store()
    ok, why = await store.available()
    if not ok:
        return ToolResult(False, why)
    hits = await store.search(query, k=max(1, min(int(a.get("limit") or 5), 10)), min_score=0.3)
    if not hits:
        return ToolResult(True, "No matching notes in the knowledge base.")
    return ToolResult(True, format_context(hits), {"sources": [h["path"] for h in hits]})


TOOL = Tool(
    "search_knowledge",
    "Search UNISON's local knowledge base: curated programming notes (Python, JS/TS, C#, Luau/Roblox, Blender "
    "bpy, Git, debugging) and any indexed project code. Use it to find how something is done in the user's "
    "projects or to check an API you're unsure about.",
    obj({"query": s("What to look for, in plain words"), "limit": i("Max results (default 5)")}, ["query"]),
    "read", search_knowledge, default_mode="auto")
