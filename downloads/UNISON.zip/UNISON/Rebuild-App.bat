@echo off
rem Rebuilds UNISON after an update (about 30 seconds) and reopens it.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\rebuild_app.ps1"
