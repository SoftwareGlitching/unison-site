"""The public half of the UNISON license-signing key (Ed25519, base64url).

Only the owner's private key (kept OFF this computer's UNISON folder and out of GitHub) can create keys
that verify against it. Set by `License-Admin.bat setup` on the owner's PC.
An empty value means no license authority is configured: UNISON stays locked.
"""
PUBLIC_KEY = "ca0QGySY2IMmhMXY5_egV-vasWuIHsWEFK5mLQwfHkA"
