"""A tiny MCP stdio server used only by the tests. Offers one tool, `shout`, and asks the client for roots."""
import json
import sys


def send(obj):
    sys.stdout.write(json.dumps(obj) + "\n")
    sys.stdout.flush()


roots_seen = None
for line in sys.stdin:
    msg = json.loads(line)
    method, mid = msg.get("method"), msg.get("id")
    if method == "initialize":
        send({"jsonrpc": "2.0", "id": mid, "result": {"protocolVersion": msg["params"]["protocolVersion"],
                                                       "capabilities": {"tools": {}},
                                                       "serverInfo": {"name": "fake", "version": "1.0"}}})
    elif method == "notifications/initialized":
        send({"jsonrpc": "2.0", "id": 900, "method": "roots/list"})
    elif mid == 900 and "result" in msg:
        roots_seen = msg["result"]["roots"]
    elif method == "tools/list":
        send({"jsonrpc": "2.0", "id": mid, "result": {"tools": [{
            "name": "shout", "description": "Uppercase some text",
            "inputSchema": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]}}]}})
    elif method == "tools/call":
        args = msg["params"]["arguments"]
        if msg["params"]["name"] == "shout":
            text = args.get("text", "").upper() + f" (roots={len(roots_seen or [])})"
            send({"jsonrpc": "2.0", "id": mid, "result": {"content": [{"type": "text", "text": text}]}})
        else:
            send({"jsonrpc": "2.0", "id": mid, "error": {"code": -32602, "message": "unknown tool"}})
    elif mid is not None:
        send({"jsonrpc": "2.0", "id": mid, "error": {"code": -32601, "message": "not found"}})
