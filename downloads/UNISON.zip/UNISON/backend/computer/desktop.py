"""
Screen capture and mouse/keyboard input on Windows, with no third-party automation libraries:
screenshots via Pillow's ImageGrab, input via the Win32 SendInput API (ctypes).

Coordinates are physical screen pixels of the primary monitor. The process is made DPI-aware so
screenshots and clicks use the same pixels on scaled (125%/150%) displays.
"""
from __future__ import annotations

import base64
import io
import sys
import threading
import time
from dataclasses import dataclass
from typing import Optional, Protocol

from PIL import Image, ImageDraw


@dataclass
class WindowInfo:
    handle: int
    title: str
    rect: tuple[int, int, int, int]   # left, top, right, bottom


class Desktop(Protocol):
    def size(self) -> tuple[int, int]: ...
    def capture(self) -> Image.Image: ...
    def cursor(self) -> tuple[int, int]: ...
    def foreground(self) -> Optional[WindowInfo]: ...
    def focus(self, handle: int) -> bool: ...
    def minimize(self, handle: int) -> None: ...
    def restore(self, handle: int) -> None: ...
    def click(self, x: int, y: int, button: str = "left", count: int = 1) -> None: ...
    def move(self, x: int, y: int) -> None: ...
    def drag(self, x1: int, y1: int, x2: int, y2: int) -> None: ...
    def scroll(self, x: int, y: int, clicks: int) -> None: ...
    def type_text(self, text: str) -> None: ...
    def press(self, combo: str) -> None: ...
    def key_down_now(self, name: str) -> bool: ...


# ----------------------------------------------------------------------------- image helpers
def scaled(img: Image.Image, max_width: int) -> Image.Image:
    if img.width <= max_width:
        return img
    h = round(img.height * max_width / img.width)
    return img.resize((max_width, h), Image.LANCZOS)


def to_b64(img: Image.Image, fmt: str = "JPEG", quality: int = 82) -> str:
    buf = io.BytesIO()
    img.convert("RGB").save(buf, format=fmt, quality=quality)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def mark(img: Image.Image, points: list[tuple[int, int]], max_width: int = 640) -> str:
    """Thumbnail with red targets drawn where an action will happen (for the approval card)."""
    small = scaled(img, max_width).convert("RGB")
    f = small.width / img.width
    d = ImageDraw.Draw(small)
    for x, y in points:
        sx, sy, r = x * f, y * f, 11
        d.ellipse([sx - r, sy - r, sx + r, sy + r], outline=(255, 60, 60), width=3)
        d.line([sx - r - 6, sy, sx + r + 6, sy], fill=(255, 60, 60), width=2)
        d.line([sx, sy - r - 6, sx, sy + r + 6], fill=(255, 60, 60), width=2)
    return to_b64(small, quality=78)


# ----------------------------------------------------------------------------- Windows
if sys.platform == "win32":
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    ULONG_PTR = ctypes.c_size_t

    class MOUSEINPUT(ctypes.Structure):
        _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                    ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

    class KEYBDINPUT(ctypes.Structure):
        _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                    ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

    class HARDWAREINPUT(ctypes.Structure):
        _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD), ("wParamH", wintypes.WORD)]

    class _INPUTUNION(ctypes.Union):
        _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]

    class INPUT(ctypes.Structure):
        _fields_ = [("type", wintypes.DWORD), ("u", _INPUTUNION)]

    INPUT_MOUSE, INPUT_KEYBOARD = 0, 1
    KEYEVENTF_EXTENDEDKEY, KEYEVENTF_KEYUP, KEYEVENTF_UNICODE = 0x0001, 0x0002, 0x0004
    MOUSE_FLAGS = {"left": (0x0002, 0x0004), "right": (0x0008, 0x0010), "middle": (0x0020, 0x0040)}
    MOUSEEVENTF_WHEEL = 0x0800

    user32.SendInput.argtypes = (wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int)
    user32.GetWindowTextW.argtypes = (wintypes.HWND, wintypes.LPWSTR, ctypes.c_int)
    user32.GetForegroundWindow.restype = wintypes.HWND

    VK = {
        "backspace": 0x08, "tab": 0x09, "enter": 0x0D, "return": 0x0D, "shift": 0x10, "ctrl": 0x11, "control": 0x11,
        "alt": 0x12, "pause": 0x13, "capslock": 0x14, "esc": 0x1B, "escape": 0x1B, "space": 0x20,
        "pageup": 0x21, "pagedown": 0x22, "end": 0x23, "home": 0x24, "left": 0x25, "up": 0x26, "right": 0x27,
        "down": 0x28, "printscreen": 0x2C, "insert": 0x2D, "delete": 0x2E, "del": 0x2E, "win": 0x5B,
        "windows": 0x5B, "cmd": 0x5B, "super": 0x5B, "menu": 0x5D, "apps": 0x5D,
        **{f"f{n}": 0x6F + n for n in range(1, 13)},
    }
    EXTENDED = {0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x2D, 0x2E, 0x5B, 0x5D}

    def make_dpi_aware() -> None:
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)   # per-monitor aware
        except Exception:  # noqa: BLE001
            try:
                user32.SetProcessDPIAware()
            except Exception:  # noqa: BLE001
                pass

    def _send(*inputs: INPUT) -> None:
        arr = (INPUT * len(inputs))(*inputs)
        user32.SendInput(len(inputs), arr, ctypes.sizeof(INPUT))

    def _key(vk: int, up: bool) -> INPUT:
        flags = (KEYEVENTF_KEYUP if up else 0) | (KEYEVENTF_EXTENDEDKEY if vk in EXTENDED else 0)
        return INPUT(type=INPUT_KEYBOARD, u=_INPUTUNION(ki=KEYBDINPUT(wVk=vk, wScan=0, dwFlags=flags, time=0, dwExtraInfo=0)))

    def _unicode(code_unit: int, up: bool) -> INPUT:
        flags = KEYEVENTF_UNICODE | (KEYEVENTF_KEYUP if up else 0)
        return INPUT(type=INPUT_KEYBOARD, u=_INPUTUNION(ki=KEYBDINPUT(wVk=0, wScan=code_unit, dwFlags=flags, time=0, dwExtraInfo=0)))

    def _mouse(flags: int, data: int = 0) -> INPUT:
        return INPUT(type=INPUT_MOUSE, u=_INPUTUNION(mi=MOUSEINPUT(dx=0, dy=0, mouseData=data & 0xFFFFFFFF,
                                                                   dwFlags=flags, time=0, dwExtraInfo=0)))

    def vk_for(name: str) -> int:
        n = name.strip().lower()
        if n in VK:
            return VK[n]
        if len(n) == 1:
            if n.isalnum():
                return ord(n.upper())
            res = user32.VkKeyScanW(ctypes.c_wchar(n))
            if res != -1:
                return res & 0xFF
        raise ValueError(f"Unknown key '{name}'")

    class WindowsDesktop:
        def __init__(self) -> None:
            make_dpi_aware()
            self.injecting_until = 0.0
            self._lock = threading.Lock()

        def size(self) -> tuple[int, int]:
            return user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)

        def capture(self) -> Image.Image:
            from PIL import ImageGrab
            w, h = self.size()
            return ImageGrab.grab(bbox=(0, 0, w, h)).convert("RGB")

        def cursor(self) -> tuple[int, int]:
            pt = wintypes.POINT()
            user32.GetCursorPos(ctypes.byref(pt))
            return pt.x, pt.y

        def foreground(self) -> Optional[WindowInfo]:
            h = user32.GetForegroundWindow()
            if not h:
                return None
            buf = ctypes.create_unicode_buffer(512)
            user32.GetWindowTextW(h, buf, 512)
            r = wintypes.RECT()
            user32.GetWindowRect(h, ctypes.byref(r))
            return WindowInfo(int(h), buf.value, (r.left, r.top, r.right, r.bottom))

        def focus(self, handle: int) -> bool:
            if user32.IsIconic(handle):
                user32.ShowWindow(handle, 9)  # SW_RESTORE
            # Windows only lets the foreground thread hand over focus: attach to its input queue first.
            # (The common "tap Alt" trick is avoided because Alt opens menu bars in apps like Notepad.)
            kernel32 = ctypes.windll.kernel32
            fg = user32.GetForegroundWindow()
            fg_thread = user32.GetWindowThreadProcessId(fg, None) if fg else 0
            me = kernel32.GetCurrentThreadId()
            attached = bool(fg_thread and fg_thread != me and user32.AttachThreadInput(me, fg_thread, True))
            try:
                user32.BringWindowToTop(handle)
                user32.SetForegroundWindow(handle)
            finally:
                if attached:
                    user32.AttachThreadInput(me, fg_thread, False)
            time.sleep(0.15)
            if int(user32.GetForegroundWindow() or 0) != int(handle):
                user32.ShowWindow(handle, 6)   # minimise + restore also hands focus over
                user32.ShowWindow(handle, 9)
                time.sleep(0.25)
            return int(user32.GetForegroundWindow() or 0) == int(handle)

        def minimize(self, handle: int) -> None:
            user32.ShowWindow(handle, 6)  # SW_MINIMIZE

        def restore(self, handle: int) -> None:
            user32.ShowWindow(handle, 9)

        def _mark_injecting(self, seconds: float = 0.6) -> None:
            self.injecting_until = time.time() + seconds

        def move(self, x: int, y: int) -> None:
            user32.SetCursorPos(int(x), int(y))

        def click(self, x: int, y: int, button: str = "left", count: int = 1) -> None:
            down, up = MOUSE_FLAGS.get(button, MOUSE_FLAGS["left"])
            self.move(x, y)
            time.sleep(0.05)
            for _ in range(max(1, count)):
                _send(_mouse(down), _mouse(up))
                time.sleep(0.06)

        def drag(self, x1: int, y1: int, x2: int, y2: int) -> None:
            down, up = MOUSE_FLAGS["left"]
            self.move(x1, y1)
            time.sleep(0.05)
            _send(_mouse(down))
            steps = 12
            for i in range(1, steps + 1):
                self.move(x1 + (x2 - x1) * i / steps, y1 + (y2 - y1) * i / steps)
                time.sleep(0.02)
            _send(_mouse(up))

        def scroll(self, x: int, y: int, clicks: int) -> None:
            self.move(x, y)
            _send(_mouse(MOUSEEVENTF_WHEEL, 120 * int(clicks)))  # positive = up

        def type_text(self, text: str) -> None:
            self._mark_injecting(len(text) * 0.02 + 0.5)
            for ch in text:
                if ch == "\n":
                    _send(_key(0x0D, False), _key(0x0D, True))
                elif ch == "\t":
                    _send(_key(0x09, False), _key(0x09, True))
                else:
                    data = ch.encode("utf-16-le")
                    units = [int.from_bytes(data[i:i + 2], "little") for i in range(0, len(data), 2)]
                    _send(*[_unicode(u, False) for u in units], *[_unicode(u, True) for u in units])
                time.sleep(0.008)

        def press(self, combo: str) -> None:
            names = [p for p in combo.replace(" ", "").replace("-", "+").split("+") if p]
            vks = [vk_for(n) for n in names]
            self._mark_injecting()
            _send(*[_key(v, False) for v in vks])
            time.sleep(0.03)
            _send(*[_key(v, True) for v in reversed(vks)])

        def key_down_now(self, name: str) -> bool:
            return bool(user32.GetAsyncKeyState(vk_for(name)) & 0x8000)

        def run_program(self, command: str) -> bool:
            """Launch a program directly (ShellExecute), the way the Run box does. Returns True on success.
            Resolves bare names like 'chrome' or 'notepad' via the App Paths registry."""
            try:
                # ShellExecuteW returns a value > 32 on success.
                rc = ctypes.windll.shell32.ShellExecuteW(None, "open", command, None, None, 1)
                return int(rc) > 32
            except Exception:  # noqa: BLE001
                return False


def make_desktop() -> Desktop:
    if sys.platform != "win32":
        raise RuntimeError("Screen control is only implemented for Windows.")
    return WindowsDesktop()
