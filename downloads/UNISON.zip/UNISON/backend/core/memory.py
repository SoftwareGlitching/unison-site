"""
Long-term memory: what UNISON remembers about you across conversations. Everything stays in data/unison.db.

Three parts:
- Facts: short notes about you ("Nick's GitHub is SoftwareGlitching", "likes pixel-art games"). Saved when you
  say "remember ...", "my name is ...", "call me ...", when the brain adds a hidden [remember: ...] note to a
  reply, or with the `remember` tool in agent mode. You can see, add and delete them in Settings -> Memory.
- Recent chats: the titles of your last few conversations, so the brain knows what you've been working on.
- Recall: when you refer to an earlier chat ("like last time", "the game we made", "remember when..."), the
  most relevant bits of past conversations are looked up and given to the brain.
No extra model calls: it costs no GPU time.
"""
from __future__ import annotations

import re
import time
from typing import Optional

from .config import settings

MAX_FACTS = 300
MAX_FACT_CHARS = 300
SECTION_CHARS = 3000

# A hidden note the brain may add at the end of a reply; removed before it's shown or saved.
NOTE = re.compile(r"\[\s*remember\s*:\s*([^\]\n]{3,300})\]", re.I)

_REMEMBER = re.compile(
    r"(?:^|[.!?]\s+|\b(?:please|pls|plz|also|and|ok(?:ay)?|hey|unison)[, ]+)(?:can you |could you |will you )?"
    r"(?:always )?remember(?: that| this:?)?\s+(?!when\b|what\b|how\b|our\b|the convo|us\b|me\b\s*$|everything)(.{3,240}?)\s*(?:[.!?]|$)",
    re.I)
_NAME = re.compile(r"\bmy name(?:'s| is)\s+(?!not\b|the\b|a\b|an\b|so\b|kinda\b|actually\b)([A-Za-z][\w'-]{1,30})", re.I)
_CALL_ME = re.compile(r"\b(?:call me|i go by)\s+([\w'-]{2,30})", re.I)
_FORGET = re.compile(r"\bforget (?:that |about )?(.{3,120}?)\s*(?:[.!?]|$)", re.I)
_PAST = re.compile(
    r"\b(remember (when|what|how|the|that time|our)|last time|earlier|yesterday|the other day|before|we (talked|made|built|did|discussed|worked)|"
    r"you (said|told|made|built|wrote)|our (last |old |previous )?(chat|convo|conversation|talk)|previous(ly)?|again)\b", re.I)
STOP = set("""the and for you your with that this have from what when where which would could should about there their
they them then than been were will just like make made want need into some more also only over very please thanks okay
yeah does did done dont cant wont its it's i'm im is are was a an of to in on at by it me my we our us be do so or if
not no yes can get got how why who all any one two use used using thing things stuff really still even back again
remember last time earlier before yesterday talked said told""".split())


def enabled() -> bool:
    return bool(settings.get("assistant", "memory", True))


# --------------------------------------------------------------------------- facts
def facts(db) -> list[dict]:
    return [dict(r) for r in db.query("SELECT id, text, source, created_at FROM memories ORDER BY created_at")]


def add(db, text: str, source: Optional[str] = None) -> Optional[dict]:
    text = re.sub(r"\s+", " ", (text or "").strip().strip('"').strip()).rstrip(".")[:MAX_FACT_CHARS]
    if len(text) < 3:
        return None
    low = text.lower()
    for f in facts(db):
        if f["text"].lower() == low or (len(low) > 12 and low in f["text"].lower()):
            return None   # already known
    from ..database.db import new_id
    row = {"id": new_id("mem"), "text": text, "source": source, "created_at": time.time()}
    with db.tx() as c:
        c.execute("INSERT INTO memories(id, text, source, created_at) VALUES(?,?,?,?)",
                  (row["id"], row["text"], row["source"], row["created_at"]))
        # keep the newest MAX_FACTS
        c.execute("DELETE FROM memories WHERE id NOT IN (SELECT id FROM memories ORDER BY created_at DESC LIMIT ?)",
                  (MAX_FACTS,))
    return row


def delete(db, mid: str) -> bool:
    with db.tx() as c:
        return c.execute("DELETE FROM memories WHERE id=?", (mid,)).rowcount > 0


def clear(db) -> int:
    with db.tx() as c:
        return c.execute("DELETE FROM memories").rowcount


def forget_matching(db, words: str) -> list[str]:
    keys = [w for w in re.findall(r"[\w'-]{3,}", words.lower()) if w not in STOP]
    if not keys:
        return []
    gone = []
    for f in facts(db):
        low = f["text"].lower()
        if all(k in low for k in keys):
            delete(db, f["id"])
            gone.append(f["text"])
    return gone


def capture(db, user_text: str, source: Optional[str] = None) -> tuple[list[str], list[str]]:
    """Save what the user explicitly asked to be remembered. Returns (remembered, forgotten)."""
    if not enabled() or not user_text:
        return [], []
    text = user_text.strip()
    saved, gone = [], []
    for m in _FORGET.finditer(text):
        gone += forget_matching(db, m.group(1))
    for m in _REMEMBER.finditer(text):
        what = m.group(1).strip()
        if re.match(r"^(our|my|the)?\s*(convos?|conversations?|chats?)\b", what, re.I):
            continue   # "remember our convos" is a request for this feature, not a fact
        if re.match(r"^(i|i'm|im|i am|my|me)\b", what, re.I):
            what = "The user said: " + re.sub(r"^im\b", "I'm", re.sub(r"^i\b", "I", what))
        if add(db, what, source):
            saved.append(what)
    m = _NAME.search(text)
    if m:
        name = m.group(1)[0].upper() + m.group(1)[1:]
        if add(db, f"The user's name is {name}", source):
            saved.append(f"your name is {name}")
    m = _CALL_ME.search(text)
    if m and add(db, f"The user likes to be called {m.group(1)}", source):
        saved.append(f"call you {m.group(1)}")
    return saved, gone


def take_notes(db, reply: str, source: Optional[str] = None) -> tuple[str, list[str]]:
    """Pull [remember: ...] notes out of a reply. Returns (clean reply, saved notes)."""
    saved = []
    if enabled():
        for m in NOTE.finditer(reply or ""):
            if add(db, m.group(1), source):
                saved.append(m.group(1).strip())
    clean = NOTE.sub("", reply or "").rstrip()
    return clean, saved


# --------------------------------------------------------------------------- past conversations
def recent_chats(db, exclude: Optional[str] = None, n: int = 6) -> list[dict]:
    rows = db.query("SELECT id, title, updated_at FROM conversations WHERE id != ? ORDER BY updated_at DESC LIMIT ?",
                    (exclude or "", n))
    return [dict(r) for r in rows]


def refers_to_past(text: str) -> bool:
    return bool(_PAST.search(text or ""))


def recall(db, query: str, exclude: Optional[str] = None, k: int = 4) -> list[dict]:
    """Best-matching messages from OTHER conversations, by shared keywords (fast, no embeddings)."""
    words = [w for w in re.findall(r"[a-z0-9][\w'-]{2,}", (query or "").lower()) if w not in STOP][:8]
    if not words:
        return []
    like = " OR ".join("lower(m.content) LIKE ?" for _ in words)
    rows = db.query(
        f"SELECT m.content, m.role, m.created_at, c.title, c.id AS cid FROM messages m JOIN conversations c ON c.id = m.conversation_id "
        f"WHERE m.conversation_id != ? AND m.role IN ('user','assistant') AND ({like}) ORDER BY m.created_at DESC LIMIT 400",
        (exclude or "", *[f"%{w}%" for w in words]))
    scored = []
    for r in rows:
        low = r["content"].lower()
        score = sum(1 for w in words if w in low) + (0.5 if r["role"] == "user" else 0)
        scored.append((score, r))
    scored.sort(key=lambda x: (-x[0], -x[1]["created_at"]))
    out, per_conv = [], {}
    for score, r in scored:
        if per_conv.get(r["cid"], 0) >= 2:
            continue
        per_conv[r["cid"]] = per_conv.get(r["cid"], 0) + 1
        out.append({"title": r["title"], "role": r["role"], "when": time.strftime("%b %d", time.localtime(r["created_at"])),
                    "text": _snippet(r["content"], words)})
        if len(out) >= k:
            break
    return out


def _snippet(text: str, words: list[str], width: int = 360) -> str:
    low = text.lower()
    pos = min([low.find(w) for w in words if w in low] or [0])
    start = max(0, pos - width // 3)
    s = re.sub(r"\s+", " ", text[start:start + width]).strip()
    return ("..." if start else "") + s + ("..." if start + width < len(text) else "")


# --------------------------------------------------------------------------- prompt section
NOTE_RULE = ("If the user tells you something worth remembering for future chats (their name, preferences, projects, "
             "goals, people in their life), you may end your reply with a hidden note on its own line: "
             "[remember: short fact in third person]. Only for lasting facts, at most one per reply; never mention the note.")


def section(db, query: str = "", cid: Optional[str] = None, notes: bool = True) -> str:
    if not enabled():
        return ""
    parts = []
    fs = facts(db)
    if fs:
        lines, used = [], 0
        for f in reversed(fs):             # newest first, within a budget
            used += len(f["text"]) + 3
            if used > 1800:
                break
            lines.insert(0, f"- {f['text']}")
        parts.append("What you remember about the user from earlier chats (use it naturally when it helps; don't "
                     "recite it or say 'according to my memory'):\n" + "\n".join(lines))
    chats = recent_chats(db, cid)
    if chats:
        parts.append("Your recent conversations with the user: " + "; ".join(
            f"\"{c['title']}\" ({time.strftime('%b %d', time.localtime(c['updated_at']))})" for c in chats))
    if query and refers_to_past(query):
        hits = recall(db, query, cid)
        if hits:
            parts.append("From earlier conversations that may be what the user means:\n" + "\n".join(
                f"- [{h['when']}, \"{h['title']}\", {'user' if h['role'] == 'user' else 'you'}] {h['text']}" for h in hits))
    if notes:
        parts.append(NOTE_RULE)
    text = "\n\n".join(parts)
    return text[-SECTION_CHARS:] if len(text) > SECTION_CHARS else text
