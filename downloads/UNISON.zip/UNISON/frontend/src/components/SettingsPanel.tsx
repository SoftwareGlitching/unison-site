import { useEffect, useState } from "react";
import { api, type InferenceSettings } from "../lib/api";

const FIELDS: { key: keyof InferenceSettings; label: string; min: number; max: number; step: number; hint: string }[] = [
  { key: "temperature", label: "Temperature", min: 0, max: 1.5, step: 0.05, hint: "Lower = more focused and repeatable" },
  { key: "top_p", label: "Top-p", min: 0.1, max: 1, step: 0.05, hint: "Nucleus sampling cutoff" },
  { key: "top_k", label: "Top-k", min: 1, max: 100, step: 1, hint: "Candidates considered per token" },
  { key: "repeat_penalty", label: "Repeat penalty", min: 1, max: 1.5, step: 0.01, hint: "Discourages loops" },
];


export function SettingsPanel({ onClose, embedded }: { onClose: () => void; embedded?: boolean }) {
  const [s, setS] = useState<InferenceSettings | null>(null);
  const [saved, setSaved] = useState("");
  const [err, setErr] = useState("");

  useEffect(() => {
    api.settings().then(setS).catch((e) => setErr(e.message));
  }, []);

  const save = async (patch: Partial<InferenceSettings>) => {
    if (!s) return;
    setS({ ...s, ...patch });
    try {
      const next = await api.saveSettings(patch);
      setS(next);
      setSaved("saved");
      setTimeout(() => setSaved(""), 1000);
    } catch (e: any) {
      setErr(e.message);
    }
  };

  return (
    <div className={embedded ? "tab-body" : "settings-panel"}>
      <div className="settings-head" style={embedded ? { display: "none" } : undefined}>
        <span>Sampling</span>
        <span className="saved">{saved}</span>
        <button className="icon-btn" onClick={onClose} aria-label="Close">
          ×
        </button>
      </div>
      {!s && !err && <div className="pop-empty">loading…</div>}
      {s &&
        FIELDS.map((f) => (
          <label key={f.key} className="field">
            <div className="field-top">
              <span>{f.label}</span>
              <span className="field-val">{s[f.key]}</span>
            </div>
            <input
              type="range"
              min={f.min}
              max={f.max}
              step={f.step}
              value={s[f.key] as number}
              onChange={(e) => setS({ ...s, [f.key]: Number(e.target.value) })}
              onMouseUp={(e) => save({ [f.key]: Number((e.target as HTMLInputElement).value) })}
              onKeyUp={(e) => save({ [f.key]: Number((e.target as HTMLInputElement).value) })}
            />
            <span className="field-hint">{f.hint}</span>
          </label>
        ))}
      <div className="field">
        <div className="field-top">
          <span>Memory (context length)</span>
        </div>
        <span className="field-hint">
          Set by the effort level in the model menu: Eco 8K, Balanced 16K, Max 24K tokens. Bigger remembers more of the
          chat and the project.
        </span>
      </div>
      {err && <div className="pop-error">{err}</div>}
    </div>
  );
}
