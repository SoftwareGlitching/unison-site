"""One screen-control run at a time, shared by the API."""
from __future__ import annotations

import sys
from typing import Optional

from ..core.config import settings
from .agent import ScreenAgent

DEFAULT_VISION_MODEL = "qwen3-vl:8b"
VISION_MODELS = ["qwen3-vl:2b", "qwen3-vl:4b", "qwen3-vl:8b", "qwen3-vl:30b", "qwen2.5vl:7b"]

_current: Optional[ScreenAgent] = None


def vision_model() -> str:
    return settings.get("computer", "vision_model") or DEFAULT_VISION_MODEL


def supported() -> tuple[bool, str]:
    if sys.platform != "win32":
        return False, "Screen control is only available on Windows."
    return True, ""


def current() -> Optional[ScreenAgent]:
    return _current


def set_current(agent: Optional[ScreenAgent]) -> None:
    global _current
    _current = agent


def stop_current(reason: str = "Stopped from the app") -> bool:
    if _current is None:
        return False
    _current.stop(reason)
    return True
