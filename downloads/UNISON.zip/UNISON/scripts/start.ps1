# Starts UNISON: makes sure Ollama is running, starts the server, opens the browser.
param([switch]$NoBrowser)
. (Join-Path $PSScriptRoot "common.ps1")
Set-Location $Root
$Host.UI.RawUI.WindowTitle = "UNISON server  -  close this window to stop UNISON"

if (-not (Test-Path (Join-Path $Root ".setup-complete")) -or -not (Test-Path $VenvPy)) {
    Write-Host "First run: starting setup..." -ForegroundColor Cyan
    & (Join-Path $PSScriptRoot "setup.ps1")
    exit $LASTEXITCODE
}

if (Test-Http "$UnisonUrl/v1/health") {
    Write-Host "UNISON is already running."
    if (-not $NoBrowser) { Start-Process $UnisonUrl }
    Start-Sleep -Seconds 2
    exit 0
}

Write-Host "Checking the Ollama engine..."
if (-not (Start-OllamaIfNeeded)) {
    Write-Bad "Ollama isn't running and couldn't be started. Open the Ollama app from the Start menu and try again."
    Read-Host "Press Enter to close"
    exit 1
}

Write-Host ""
Write-Host "  U N I S O N" -ForegroundColor Cyan
Write-Host "  Keep this window open while you use UNISON. Close it to stop the server." -ForegroundColor DarkGray
Write-Host ""
if ($NoBrowser) { & $VenvPy -m backend.run } else { & $VenvPy -m backend.run --open }
if ($LASTEXITCODE -ne 0) {
    Write-Bad "UNISON stopped with an error (exit code $LASTEXITCODE). See the messages above."
    Read-Host "Press Enter to close"
}
