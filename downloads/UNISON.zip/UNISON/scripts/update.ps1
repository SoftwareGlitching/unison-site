# UNISON update: install new dependencies, rebuild the app, then run the post-install steps.
# Your chats, settings, models and knowledge base are kept.
param([switch]$Yes)

. (Join-Path $PSScriptRoot "common.ps1")
Set-Location $Root
try { Start-Transcript -Path (Join-Path $Root "logs\update.log") -Append | Out-Null } catch { }

Write-Host ""
Write-Host "  U N I S O N   update" -ForegroundColor Cyan

if (-not (Test-Path $VenvPy)) {
    Write-Warn2 "UNISON isn't set up yet; running full setup instead."
    & (Join-Path $PSScriptRoot "setup.ps1")
    exit $LASTEXITCODE
}
if (Test-Http "$UnisonUrl/v1/health") {
    Write-Warn2 "UNISON is running. Close its server window first, then press Enter."
    Read-Host "   "
}

Write-Step "1/2" "Python packages"
& $VenvPy -m pip install -r (Join-Path $Root "requirements.txt") --disable-pip-version-check -q
if ($LASTEXITCODE -ne 0) { Write-Bad "pip install failed (see above)."; Read-Host "Press Enter to close"; exit 1 }
Write-Ok "Installed"

Write-Step "2/2" "Rebuilding the web app"
Push-Location (Join-Path $Root "frontend")
& npm.cmd install --no-fund --no-audit
& npm.cmd run build
$built = ($LASTEXITCODE -eq 0)
Pop-Location
if (-not $built) { Write-Bad "Web app build failed (see above)."; Read-Host "Press Enter to close"; exit 1 }
Write-Ok "Built"

$script:SelfTestOk = $false
. (Join-Path $PSScriptRoot "post_install.ps1") -Yes:$Yes
try { Stop-Transcript | Out-Null } catch { }

Write-Host ""
if ($script:SelfTestOk) { Write-Host "  Update complete. All self-tests passed." -ForegroundColor Green }
else { Write-Host "  Update complete, but some self-tests failed. Send me docs\SELFTEST.md." -ForegroundColor Yellow }
if (-not $Yes -and (Ask-YesNo "Start UNISON now?" $true)) {
    Start-Process -FilePath (Join-Path $Root "Start-UNISON.bat") -WorkingDirectory $Root
}
