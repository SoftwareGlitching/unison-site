import { useState } from "react";
import { api } from "../lib/api";

/** 👍 / 👎 on a reply. A thumbs-down can carry a correction, which becomes a training example. */
export function FeedbackBar({
  messageId,
  rating,
  onChange,
}: {
  messageId: string;
  rating: number | null;
  onChange: (rating: number | null) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [text, setText] = useState("");
  const [error, setError] = useState("");

  const rate = async (r: 1 | -1) => {
    setError("");
    try {
      if (rating === r) {
        await api.clearFeedback(messageId);
        onChange(null);
        setEditing(false);
        return;
      }
      await api.feedback(messageId, r);
      onChange(r);
      setEditing(r === -1);
    } catch (e: any) {
      setError(e.message);
    }
  };

  const saveCorrection = async () => {
    try {
      await api.feedback(messageId, -1, text.trim());
      setEditing(false);
    } catch (e: any) {
      setError(e.message);
    }
  };

  return (
    <>
      <button className={`fb ${rating === 1 ? "on" : ""}`} title="Good answer (saved as a training example)" onClick={() => rate(1)}>
        👍
      </button>
      <button className={`fb ${rating === -1 ? "on bad" : ""}`} title="Bad answer" onClick={() => rate(-1)}>
        👎
      </button>
      {error && <span className="bad-t">{error}</span>}
      {editing && (
        <div className="correction">
          <textarea
            rows={4}
            placeholder="Optional: what should UNISON have said? This becomes a training example."
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
          <div className="approval-actions">
            <button className="approve" onClick={saveCorrection} disabled={!text.trim()}>
              Save correction
            </button>
            <button className="deny" onClick={() => setEditing(false)}>
              Skip
            </button>
          </div>
        </div>
      )}
    </>
  );
}
