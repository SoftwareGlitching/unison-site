"""Manage UNISON API keys from the command line.

  apikey.bat create "My website"
  apikey.bat list
  apikey.bat revoke key_xxxxxxxx
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from backend.database.db import get_db  # noqa: E402
from backend.security.auth import create_api_key  # noqa: E402


def main(argv: list[str]) -> int:
    if not argv or argv[0] not in ("create", "list", "revoke"):
        print(__doc__)
        return 1
    if argv[0] == "create":
        name = " ".join(argv[1:]) or "default"
        key, rec = create_api_key(name)
        print(f"Created key '{name}' ({rec['id']})\n\n    {key}\n")
        print("Copy it now: UNISON stores only a hash and cannot show it again.")
        print("Use it as:  Authorization: Bearer <key>")
    elif argv[0] == "list":
        for k in get_db().list_api_keys():
            used = time.strftime("%Y-%m-%d %H:%M", time.localtime(k["last_used_at"])) if k["last_used_at"] else "never"
            print(f"{k['id']}  {k['prefix']}...  {k['name']:<24} last used {used}{'  [REVOKED]' if k['revoked'] else ''}")
    else:
        if len(argv) < 2:
            print("Usage: apikey.bat revoke <key_id>")
            return 1
        print("Revoked." if get_db().revoke_api_key(argv[1]) else "No such key.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
