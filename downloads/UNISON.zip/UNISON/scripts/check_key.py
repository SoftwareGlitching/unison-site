"""Setup's license gate: check (and save) a UNISON license key before anything big is downloaded.

  check_key.py --existing      exit 0 if this PC is already activated
  check_key.py UNISON-....     verify the key, save it, exit 0 - or print why not and exit 1
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from backend.licensing import license as lic  # noqa: E402


def main() -> int:
    args = sys.argv[1:]
    if args == ["--existing"]:
        s = lic.status(force=True)
        if s.get("activated"):
            print(f"   ok  Licensed to {s.get('to')} ({s.get('plan')})")
            return 0
        return 1
    try:
        s = lic.activate("".join(args))
    except lic.LicenseError as e:
        print(f"   XX  {e}")
        if "different computer" in str(e):
            print(f"       This PC's Machine ID is {lic.machine_id()} - send it with your purchase to get a key for this PC.")
        return 1
    exp = s.get("expires")
    import time
    print(f"   ok  Licensed to {s.get('to')} ({s.get('plan')}, "
          f"{'expires ' + time.strftime('%Y-%m-%d', time.localtime(exp)) if exp else 'never expires'})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
