# JavaScript in the browser (DOM, events, storage)

## Finding and changing elements
- `document.querySelector(".card")`, `document.querySelectorAll("[data-add]")` (returns a NodeList; use `forEach`).
- Build lists from data with template strings, then one `innerHTML` assignment:
  `grid.innerHTML = items.map(p => cardHTML(p)).join("")`.
- Never put user-typed text into `innerHTML`: use `el.textContent = text`, or escape it:
  `const esc = s => String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));`
- Classes: `el.classList.add/remove/toggle("open")`; data attributes: `el.dataset.id` for `data-id="..."`.

## Events
- Event delegation for lists that re-render (one listener on the parent):
```js
grid.addEventListener("click", e => {
  const btn = e.target.closest("[data-add]");
  if (!btn) return;
  Cart.add(btn.dataset.add);
});
```
- Forms: `form.addEventListener("submit", e => { e.preventDefault(); const data = Object.fromEntries(new FormData(form)); ... })`.
- Validation: `form.checkValidity()` / `input.setCustomValidity("message")` / `form.reportValidity()`.
- Run code after the HTML loads: put scripts at the end of body or use `<script defer>`.
- Search box: debounce input (`clearTimeout(t); t = setTimeout(run, 200)`).

## Storage and state
- `localStorage` stores strings: `localStorage.setItem("cart", JSON.stringify(cart))`,
  `JSON.parse(localStorage.getItem("cart") || "[]")`. Wrap in `try/catch` (private mode can throw).
- Keep one source of truth (an array/object), change it with functions, then call `render()`.
- Sync between tabs: `window.addEventListener("storage", e => { if (e.key === "cart") render(); })`.
- URL parameters for detail pages: `new URLSearchParams(location.search).get("id")` (product.html?id=3).

## Money
- Store prices in cents (integers) to avoid 0.1 + 0.2 bugs; show with
  `new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(cents / 100)`.

## Fetching data
- `const res = await fetch("data/products.json"); if (!res.ok) throw new Error(res.status); const data = await res.json();`
- `fetch` of local files does NOT work when a page is opened as `file://` in most browsers. For a site
  people open by double-clicking, put the data in a JS file (`js/products.js` with `const PRODUCTS = [...]`)
  instead of JSON, or run a local server (`python -m http.server 8000`, then http://localhost:8000).

## Modules
- `<script type="module" src="js/main.js">` lets files `import { Cart } from "./cart.js"` - but modules also
  fail on `file://`. For double-click sites use plain scripts loaded in order (`products.js`, `cart.js`, `app.js`)
  that share globals, or wrap each in an object (`const Cart = { ... }`).

## Animation and feel
- CSS transitions for hover/open states; `element.animate([{transform:"scale(1)"},{transform:"scale(1.2)"},{transform:"scale(1)"}], 300)`
  for a quick "bump" on the cart badge.
- `IntersectionObserver` to fade sections in when they scroll into view.

## Checking your work
- `node --check js/app.js` catches syntax errors (browser globals like `document` are fine for --check).
- Open the page (open_path index.html). Use the browser console (F12) for runtime errors.
- Common bugs: script runs before the element exists (use defer), wrong path case (`Images/` vs `images/`),
  forgetting `JSON.parse`, comparing a string id with a number id (`String(p.id) === id`).
