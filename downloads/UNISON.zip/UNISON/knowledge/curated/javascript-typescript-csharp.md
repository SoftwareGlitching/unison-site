# JavaScript, TypeScript and C# quick reference

## Modern JavaScript
- `const` by default, `let` when reassigning; never `var`.
- Strict equality `===`; `??` (null/undefined default) vs `||` (any falsy); optional chaining `a?.b?.c`.
- Arrays: `map`, `filter`, `reduce`, `find`, `some`, `every`, `flat(Infinity)`, `Array.from({length: n}, (_, i) => i)`.
- Objects: spread `{...a, b: 1}`, `Object.entries(obj)`, destructuring `const {x, y = 0} = point`.
- Async: `async function` + `await`; run in parallel with `await Promise.all([...])`; always handle
  rejections (`try/catch` around await). `fetch` returns a Response: `await (await fetch(url)).json()`.
- Modules: `export function f()`, `import { f } from "./f.js"` (ESM) vs `module.exports`/`require` (CommonJS).
- Classes: `class Enemy { #hp = 100; hit(n) { this.#hp -= n; } }` (`#` = private field).
- Debounce: keep a timer id and `clearTimeout` it before `setTimeout` again.
- Testing: `node --test` (built in), or Vitest/Jest. Node's `assert.deepStrictEqual` compares structures.

## TypeScript
- Annotate boundaries: `function area(r: number): number`, `type Point = { x: number; y: number }`,
  `interface Enemy { id: string; hp: number }`.
- Unions + narrowing: `type Result = { ok: true; value: T } | { ok: false; error: string }`, then `if (r.ok)`.
- Generics: `function first<T>(xs: T[]): T | undefined`.
- `unknown` for untrusted data (narrow it before use); avoid `any`.
- `tsc --noEmit` type-checks; `tsconfig.json` with `"strict": true`.
- React: `useState<T>()`, `useEffect(() => { ...; return cleanup }, [deps])`, keys on list items,
  never mutate state in place (`setItems(items => [...items, x])`).

## C#
- `dotnet new console`, `dotnet run`. Entry point with top-level statements in `Program.cs`.
- Types: `class` (reference), `struct`/`record struct` (value), `record` (immutable data with equality).
- Collections: `List<T>`, `Dictionary<K,V>` (`TryGetValue`), `HashSet<T>`, LINQ (`Where`, `Select`,
  `OrderBy`, `GroupBy`, `ToList()`).
- Nullability: `string?`, `?.`, `??`; enable `<Nullable>enable</Nullable>`.
- Async: `async Task<T>`, `await`; never `.Result` on UI/game threads.
- Properties: `public int Health { get; private set; }`; events: `public event Action<int>? Damaged;`.
- Unity specifics: `MonoBehaviour` with `Awake/Start/Update/FixedUpdate`, `[SerializeField] private float speed;`,
  physics in `FixedUpdate`, cache `GetComponent` results, avoid `Find` in Update.

## C++ (short)
- Prefer RAII and smart pointers (`std::unique_ptr`, `std::make_unique`) over `new`/`delete`.
- `std::vector`, `std::string`, `std::unordered_map`; pass big objects by `const&`.
- Build with CMake: `cmake -S . -B build && cmake --build build --config Release`.
