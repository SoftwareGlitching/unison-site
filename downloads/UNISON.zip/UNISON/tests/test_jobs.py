"""Background jobs: autonomous runs, remote approvals, stopping, persistence, screen jobs."""
import asyncio
import json
import sys
import tempfile
import unittest
from pathlib import Path

from tests.helpers import IsolatedSettings

from backend.agents.approvals import ApprovalBroker
from backend.agents.jobs import JobRunner, JobStore
from backend.core.chat_service import ChatService
from backend.database.db import Database
from backend.inference.manager import ModelManager
from backend.inference.ollama_backend import OllamaBackend
from backend.tools.registry import ToolRegistry
from tests.fake_ollama import FakeOllama

MODEL = "test-model:1b"


def tool_results(body):
    return [m for m in body["messages"] if m["role"] == "tool"]


def writer_brain(body):
    if not tool_results(body):
        return {"tool_calls": [{"function": {"name": "write_file", "arguments": {
            "path": "game/main.py", "content": f'print("built by job")\n'}}}]}
    if len(tool_results(body)) == 1:
        return {"tool_calls": [{"function": {"name": "run_command",
                                             "arguments": {"command": f'"{sys.executable}" game/main.py'}}}]}
    return {"content": "Built game/main.py and ran it."}


class JobTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self.tmp.name) / "j.db")
        self.broker = ApprovalBroker()

    def tearDown(self):
        self.db._conn.close()
        self.tmp.cleanup()

    def runner(self, fake, **kw):
        mgr = ModelManager(OllamaBackend(fake.url))

        def svc(job):
            return ChatService(self.db, mgr, tools=ToolRegistry(), approvals=self.broker, knowledge=_NoKnowledge(),
                               max_steps=20, approval_timeout=30, auto_approve=job["autonomous"])
        return JobRunner(self.db, mgr, self.broker, chat_service_factory=svc, **kw)

    def test_autonomous_job_finishes_without_anyone_there(self):
        with IsolatedSettings() as env, FakeOllama(responder=writer_brain) as fake:
            r = self.runner(fake)
            job = r.submit("agent", "make a game script and run it", autonomous=True, model=MODEL)
            asyncio.run(r.run_one(r.store.get(job["id"])))
            done = r.store.get(job["id"], with_events=True)
            self.assertEqual(done["status"], "done", done)
            self.assertEqual(done["summary"], "Built game/main.py and ran it.")
            self.assertEqual(done["steps"], 2)
            self.assertTrue((env.workspace / "game" / "main.py").exists())
            types = [e["type"] for e in done["events"]]
            self.assertNotIn("approval_required", types)
            self.assertNotIn("token", types)
            self.assertIn("built by job", json.dumps(done["events"]))
            conv = self.db.get_conversation(done["conversation_id"])
            self.assertTrue(conv["title"].startswith("Job: "))

    def test_supervised_job_waits_for_approval_from_another_device(self):
        with IsolatedSettings() as env, FakeOllama(responder=writer_brain) as fake:
            r = self.runner(fake)
            job = r.submit("agent", "make it", autonomous=False, model=MODEL)

            async def go():
                t = asyncio.create_task(r.run_one(r.store.get(job["id"])))
                for _ in range(2):   # the phone polls, sees the pending action, approves it
                    for _ in range(200):
                        await asyncio.sleep(0.02)
                        j = r.store.get(job["id"])
                        if j["status"] == "waiting_approval":
                            break
                    self.assertEqual(j["status"], "waiting_approval")
                    self.assertTrue(self.broker.resolve(j["pending_action"], True))
                await t
            asyncio.run(go())
            self.assertEqual(r.store.get(job["id"])["status"], "done")
            self.assertTrue((env.workspace / "game" / "main.py").exists())

    def test_stop_running_job(self):
        def slow(body):
            return {"tool_calls": [{"function": {"name": "run_command",
                                                 "arguments": {"command": f'"{sys.executable}" -c "import time; time.sleep(20)"',
                                                               "timeout_seconds": 30}}}]}
        with IsolatedSettings(), FakeOllama(responder=slow) as fake:
            r = self.runner(fake)
            job = r.submit("agent", "x", autonomous=False, model=MODEL)

            async def go():
                t = asyncio.create_task(r.run_one(r.store.get(job["id"])))
                for _ in range(200):
                    await asyncio.sleep(0.02)
                    if r.store.get(job["id"])["status"] == "waiting_approval":
                        break
                self.assertTrue(r.stop(job["id"]))
                try:
                    await t
                except asyncio.CancelledError:
                    pass
            asyncio.run(go())
            self.assertEqual(r.store.get(job["id"])["status"], "stopped")

    def test_queue_and_cancel_before_start(self):
        with IsolatedSettings(), FakeOllama() as fake:
            r = self.runner(fake)
            a = r.submit("agent", "first", False, MODEL)
            b = r.submit("agent", "second", False, MODEL)
            self.assertEqual(r.store.next_queued()["id"], a["id"])
            self.assertTrue(r.stop(b["id"]))
            self.assertEqual(r.store.get(b["id"])["status"], "stopped")

    def test_running_jobs_become_interrupted_after_restart(self):
        store = JobStore(self.db)
        j = store.create("agent", "x", False, None)
        store.update(j["id"], status="running")
        JobStore(self.db)   # server restarts
        self.assertEqual(store.get(j["id"])["status"], "interrupted")

    def test_screen_job_uses_autopilot_and_saves_last_screenshot(self):
        from tests.test_screen_agent import FakeDesktop, act, script
        desk = FakeDesktop()
        brain = script(act("click", x=500, y=500), act("done", summary="clicked it"))
        with IsolatedSettings(), FakeOllama(models=("vis:1b",), responder=brain) as fake:
            r = self.runner(fake, desktop_factory=lambda: desk)
            import backend.computer.agent as agent_mod
            orig = agent_mod.SETTLE_SECONDS
            job = r.submit("screen", "click the middle", autonomous=True, model="vis:1b")
            asyncio.run(r.run_one(r.store.get(job["id"])))
            agent_mod.SETTLE_SECONDS = orig
            done = r.store.get(job["id"], with_events=True)
        self.assertEqual(done["status"], "done", done["summary"])
        self.assertEqual(done["summary"], "clicked it")
        self.assertTrue(done["last_image"])
        self.assertIn(("click", 960, 540, "left", 1), desk.actions)
        self.assertNotIn("image", json.dumps([e for e in done["events"] if e["type"] == "screen"]))


class RemoteOwnerTests(unittest.TestCase):
    def test_only_listed_tailscale_logins_allowed(self):
        try:
            from backend.main import remote_allowed
        except ImportError:
            self.skipTest("FastAPI not installed in this environment")
        with IsolatedSettings():
            from backend.core.config import settings
            self.assertTrue(remote_allowed("anyone@example.com"))      # no list yet
            settings.data["remote"] = {"allowed_logins": ["Owner@Example.com"]}
            self.assertTrue(remote_allowed("owner@example.com"))
            self.assertFalse(remote_allowed("stranger@example.com"))


class _NoKnowledge:
    def counts(self):
        return {"sources": 0, "chunks": 0}


if __name__ == "__main__":
    unittest.main()
