"""License activation."""
from __future__ import annotations

import asyncio
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from ..core.config import settings
from ..licensing import issuer
from ..licensing import license as lic
from ..security.auth import pc_only

router = APIRouter(prefix="/v1/license", tags=["license"])


class KeyBody(BaseModel):
    key: str = Field(..., min_length=10, max_length=4000)


@router.get("/status")
async def license_status():
    s = lic.status()
    return {**s, "purchase_url": settings.get("site", "purchase_url") or settings.get("site", "url") or ""}


@router.post("/activate", dependencies=[Depends(pc_only)])
async def activate(body: KeyBody):
    try:
        return lic.activate(body.key)
    except lic.LicenseError as e:
        raise HTTPException(400, {"code": "invalid_license", "message": str(e)})


@router.post("/deactivate", dependencies=[Depends(pc_only)])
async def deactivate():
    return lic.deactivate()


# ---------------- in-app key generator (owner / dev license, on the PC that holds the signing key) ----------------
class IssueBody(BaseModel):
    password: str = Field("", max_length=256, description="Key Studio vault password (empty if it has none)")
    to: str = Field(..., min_length=1, max_length=80)
    email: str = Field("", max_length=200)
    plan: str = Field("personal", max_length=24)
    days: Optional[int] = Field(None, ge=1, le=36500)
    machine: str = Field("", max_length=19)
    count: int = Field(1, ge=1, le=200)
    notes: str = Field("", max_length=300)


def _privileged() -> str:
    s = lic.status(force=True)
    plan = s.get("plan") if s.get("activated") else None
    if plan not in ("owner", "dev"):
        raise HTTPException(403, {"code": "not_dev", "message": "Making keys needs an owner or dev license."})
    return plan


@router.get("/issuer", dependencies=[Depends(pc_only)])
async def issuer_status():
    s = lic.status()
    return issuer.status(s.get("plan") if s.get("activated") else None)


@router.post("/issue", dependencies=[Depends(pc_only)])
async def issue_keys(body: IssueBody):
    _privileged()
    try:
        keys = await asyncio.to_thread(issuer.mint, body.password, body.to, body.plan, body.days, body.machine,
                                       body.count, body.email, body.notes)
    except issuer.IssuerError as e:
        raise HTTPException(400, {"code": "issue_failed", "message": str(e)})
    return {"keys": keys}


@router.get("/issued", dependencies=[Depends(pc_only)])
async def issued_keys(limit: int = 50):
    _privileged()
    return {"data": issuer.recent(max(1, min(limit, 500)))}
