"""Checks UNISON end to end with the real brain on this PC: engine, speed, GPU use, tool calling (agent mode),
reading a real screenshot (screen control), Blender (3D) and sprites. Prints a report; exit code 1 if anything
important failed. Run by Fix-UNISON.bat; its output lands in logs/fix-unison.log."""
from __future__ import annotations

import base64
import io
import json
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

OLLAMA = "http://127.0.0.1:11434"
results: list[tuple[str, bool, str]] = []


def post(path: str, body: dict, timeout: float = 600) -> dict:
    req = urllib.request.Request(OLLAMA + path, data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read().decode("utf-8", "replace").strip()
    lines = [json.loads(x) for x in raw.splitlines() if x.strip()]
    if len(lines) <= 1:
        return lines[0] if lines else {}
    # a streamed answer: join the pieces into one reply
    merged = dict(lines[-1])
    content, calls = "", []
    for x in lines:
        m = x.get("message") or {}
        content += m.get("content") or ""
        calls += m.get("tool_calls") or []
    merged["message"] = {"role": "assistant", "content": content, **({"tool_calls": calls} if calls else {})}
    return merged


def get(path: str, timeout: float = 10) -> dict:
    with urllib.request.urlopen(OLLAMA + path, timeout=timeout) as r:
        return json.loads(r.read())


def check(name: str, important: bool = True):
    def wrap(fn):
        started = time.time()
        try:
            ok, detail = fn()
        except Exception as e:  # noqa: BLE001
            ok, detail = False, f"{type(e).__name__}: {e}"
        results.append((name, ok or not important, detail + f"  ({time.time() - started:.0f}s)"))
        print(f"   {'ok' if ok else ('XX' if important else '!!')}  {name}: {detail}", flush=True)
        return fn
    return wrap


def main() -> int:
    from backend.core.config import settings
    from backend.inference.manager import EFFORTS, effort

    model = settings.get("inference", "active_model") or "unison"
    prof = EFFORTS[effort()]
    opts = {"num_ctx": prof["num_ctx"]}
    if prof["num_gpu"] is not None:
        opts["num_gpu"] = prof["num_gpu"]

    @check("Ollama engine")
    def _():
        return True, "running, version " + get("/api/version").get("version", "?")

    @check("Brain installed and able to see + use tools")
    def _():
        caps = post("/api/show", {"model": model}, 30).get("capabilities") or []
        ok = "vision" in caps and ("tools" in caps or "completion" in caps)
        return ok, f"{model}: {', '.join(caps) or 'unknown'}"

    @check("Loading the brain + speed")
    def _():
        out = post("/api/chat", {"model": model, "stream": False, "think": False, "options": opts, "keep_alive": prof["keep_alive"],
                                 "messages": [{"role": "user", "content": "hey whats up"}]})
        n, ns = out.get("eval_count") or 0, out.get("eval_duration") or 1
        load = (out.get("load_duration") or 0) / 1e9
        reply = (out.get("message") or {}).get("content", "").strip().replace("\n", " ")
        tps = n / (ns / 1e9)
        return bool(reply) and tps > 3, f"{tps:.0f} tokens/s, load {load:.0f}s, effort {effort()} - \"{reply[:80]}\""

    @check("GPU use")
    def _():
        for m in get("/api/ps").get("models", []):
            if (m.get("name") or "").split(":")[0] == model.split(":")[0]:
                size, vram = m.get("size") or 1, m.get("size_vram") or 0
                pct = round(100 * vram / size)
                want = 95 if prof["num_gpu"] is None else 30
                return pct >= want, f"{pct}% of the brain on the graphics card ({vram / 1e9:.1f} GB of VRAM)"
        return False, "the brain isn't loaded"

    @check("Agent mode: calling tools")
    def _():
        tools = [{"type": "function", "function": {"name": "list_dir", "description": "List files in a folder",
                  "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}}}]
        out = post("/api/chat", {"model": model, "stream": False, "think": False, "options": opts, "tools": tools,
                                 "messages": [{"role": "user", "content": "What files are in my project folder? Use your tools."}]})
        msg = out.get("message") or {}
        if msg.get("tool_calls"):
            return True, "native tool call: " + json.dumps(msg["tool_calls"][0].get("function", {}))[:120]
        from backend.core.toolparse import extract_tool_calls
        _, calls = extract_tool_calls(msg.get("content", ""), {"list_dir"})
        return bool(calls), ("text tool call (works via UNISON's text protocol)" if calls else
                             "no tool call: " + msg.get("content", "")[:120])

    @check("Screen control: reading your real screen")
    def _():
        if sys.platform != "win32":
            return False, "Windows only"
        from backend.computer.agent import ACTIONS, SYSTEM
        from backend.computer.desktop import make_desktop, scaled, to_b64
        from backend.core.toolparse import extract_tool_calls
        img = make_desktop().capture()
        actions = "\n".join(f"- {v}" for v in ACTIONS.values())
        msgs = [{"role": "system", "content": SYSTEM.format(actions=actions)},
                {"role": "user", "content": "Task: open the Windows Start menu"},
                {"role": "user", "content": f"Current screen (real size {img.width}x{img.height}). What is the next action?",
                 "images": [to_b64(scaled(img, 1280))]}]
        out = post("/api/chat", {"model": model, "stream": False, "think": False, "messages": msgs,
                                 "options": {**opts, "temperature": 0.1, "num_predict": 300}})
        text = (out.get("message") or {}).get("content", "")
        _, calls = extract_tool_calls(text, ACTIONS.keys())
        if not calls:
            return False, "no valid action: " + text[:160].replace("\n", " ")
        c = calls[0]
        return True, f"answered with {c.name}({json.dumps(c.arguments)[:80]})"

    @check("3D assets: Blender", important=False)
    def _():
        from backend.tools.creative import find_blender
        p = find_blender()
        return bool(p), p or "Blender not found - 3D models need Blender (blender.org)"

    @check("Sprites for games", important=False)
    def _():
        from backend.tools.creative import make_sprite
        from backend.tools.sandbox import workspaces
        target = Path(workspaces.default) / "_unison_selfcheck.png"
        r = make_sprite({"path": str(target), "palette": {"a": "#ff0000"}, "pixels": ["a.", ".a"]})
        try:
            target.unlink()
        except OSError:
            pass
        return r.ok, "sprite PNG written and removed"

    failed = [n for n, ok, _ in results if not ok]
    print("\n   " + ("All checks passed." if not failed else "Failed: " + ", ".join(failed)))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
