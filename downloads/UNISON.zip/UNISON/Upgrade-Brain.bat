@echo off
rem Give UNISON a smarter brain (Gemma 4, sized for your GPU), gentler GPU settings and working screen control.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\upgrade_brain.ps1" %*
