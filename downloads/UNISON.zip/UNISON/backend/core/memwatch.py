"""
RAM watcher: every minute, records how much memory UNISON's server, Ollama (the engine + the loaded brain) and
the app window (WebView2) use, plus the whole PC. Written to logs/memory.log (kept small) and shown at
GET /v1/system/memory, so a leak shows exactly which part is growing.
If UNISON's own server ever grows past SELF_LIMIT_MB it frees what it can (garbage collection).
"""
from __future__ import annotations

import asyncio
import gc
import json
import os
import time
from collections import deque
from typing import Optional

import psutil

from .config import LOG_DIR

INTERVAL = 60
SELF_LIMIT_MB = 1500
LOG_MAX_BYTES = 512 * 1024
samples: deque[dict] = deque(maxlen=180)       # 3 hours of one-minute samples
_task: Optional[asyncio.Task] = None


def _mb(n: int) -> int:
    return round(n / 1048576)


def sample() -> dict:
    me = psutil.Process(os.getpid())
    groups = {"unison_server": 0, "ollama": 0, "app_window": 0}
    for p in psutil.process_iter(["name", "memory_info"]):
        try:
            name = (p.info["name"] or "").lower()
            rss = p.info["memory_info"].rss if p.info["memory_info"] else 0
        except (psutil.Error, AttributeError):
            continue
        if name.startswith("ollama"):
            groups["ollama"] += rss
        elif name.startswith("msedgewebview2") or name == "unison.exe":
            groups["app_window"] += rss
    try:
        groups["unison_server"] = me.memory_info().rss
    except psutil.Error:
        pass
    vm = psutil.virtual_memory()
    return {"at": time.strftime("%Y-%m-%dT%H:%M:%S"), **{k: _mb(v) for k, v in groups.items()},
            "pc_used_mb": _mb(vm.total - vm.available), "pc_total_mb": _mb(vm.total), "pc_percent": vm.percent}


def _write(s: dict) -> None:
    path = LOG_DIR / "memory.log"
    try:
        if path.exists() and path.stat().st_size > LOG_MAX_BYTES:
            lines = path.read_text(encoding="utf-8").splitlines()[-1000:]
            path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(s) + "\n")
    except OSError:
        pass


def growth() -> dict:
    """MB each part grew over the samples we have (positive = growing)."""
    if len(samples) < 2:
        return {}
    a, b = samples[0], samples[-1]
    return {k: b[k] - a[k] for k in ("unison_server", "ollama", "app_window", "pc_used_mb")}


async def _loop() -> None:
    while True:
        try:
            s = await asyncio.to_thread(sample)
            if s["unison_server"] > SELF_LIMIT_MB:
                gc.collect()
                s["note"] = "server over limit - freed memory"
            samples.append(s)
            _write(s)
        except Exception:  # noqa: BLE001 - never let the watcher take the server down
            pass
        await asyncio.sleep(INTERVAL)


def start() -> None:
    global _task
    if _task is None or _task.done():
        _task = asyncio.get_running_loop().create_task(_loop())


async def stop() -> None:
    global _task
    if _task:
        _task.cancel()
        try:
            await _task
        except (asyncio.CancelledError, Exception):  # noqa: BLE001
            pass
        _task = None
