"""Start the UNISON server with the safety checks for network exposure."""
from __future__ import annotations

import ipaddress
import sys
import threading
import time
import webbrowser

import uvicorn

from .core.config import settings


def _is_loopback(host: str) -> bool:
    if host == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def main() -> int:
    if sys.platform == "win32":
        # Screenshots and clicks must use the same physical pixels on scaled (125%/150%) displays.
        from .computer.desktop import make_dpi_aware
        make_dpi_aware()
    host = settings.get("server", "host", "127.0.0.1")
    port = int(settings.get("server", "port", 8770))
    cert = settings.get("server", "ssl_certfile") or None
    key = settings.get("server", "ssl_keyfile") or None

    if not _is_loopback(host):
        problems = []
        if not settings.get("auth", "require_api_key"):
            problems.append("auth.require_api_key must be true")
        if not (cert and key):
            problems.append("server.ssl_certfile and server.ssl_keyfile must be set (HTTPS)")
        if problems:
            print(f"[UNISON] Refusing to listen on {host}: exposing UNISON beyond this computer requires:")
            for p in problems:
                print("   -", p)
            print("   Edit config\\unison.json, or set server.host back to 127.0.0.1.")
            return 2

    scheme = "https" if cert else "http"
    url = f"{scheme}://{'127.0.0.1' if host in ('0.0.0.0', '::') else host}:{port}"
    if "--open" in sys.argv:
        def _open():
            # Wait until the server answers, then open the browser once.
            import ssl
            import urllib.request
            ctx = ssl._create_unverified_context() if cert else None  # local self-signed certs
            for _ in range(120):
                try:
                    urllib.request.urlopen(f"{url}/v1/health", timeout=2, context=ctx)
                    break
                except Exception:  # noqa: BLE001
                    time.sleep(0.5)
            webbrowser.open(url)
        threading.Thread(target=_open, daemon=True).start()

    print(f"[UNISON] Web app:  {url}")
    print(f"[UNISON] API docs: {url}/docs")
    uvicorn.run("backend.main:app", host=host, port=port, ssl_certfile=cert, ssl_keyfile=key,
                log_level="info", access_log=False)
    return 0


if __name__ == "__main__":
    sys.exit(main())
