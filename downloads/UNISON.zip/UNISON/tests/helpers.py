"""Test helpers: isolate settings and data so tests never touch the real config, database or backups."""
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

try:
    import httpx  # noqa: F401
except ImportError:  # the build sandbox ships an httpx-compatible package under another name
    import httpx2
    sys.modules["httpx"] = httpx2

from backend.core.config import settings  # noqa: E402


class IsolatedSettings:
    """Context manager: in-memory settings + a temporary workspace and backup folder."""

    def __init__(self, extra_workspaces: int = 0):
        self.extra = extra_workspaces

    def __enter__(self):
        import copy
        from backend.tools import sandbox
        self._tmp = tempfile.TemporaryDirectory()
        base = Path(self._tmp.name).resolve()
        self.workspace = base / "ws"
        self.workspace.mkdir()
        self.others = []
        for n in range(self.extra):
            d = base / f"ws{n + 2}"
            d.mkdir()
            self.others.append(d)
        self.outside = base / "outside"
        self.outside.mkdir()
        self._orig_data = copy.deepcopy(settings.data)
        self._orig_set = settings.set
        settings.set = lambda section, key, value: settings.data.setdefault(section, {}).__setitem__(key, value)
        settings.data.setdefault("tools", {})["workspaces"] = [str(self.workspace)] + [str(d) for d in self.others]
        settings.data["tools"]["permissions"] = {}
        self._orig_backup = sandbox.BACKUP_DIR
        sandbox.BACKUP_DIR = base / "backups"
        return self

    def __exit__(self, *exc):
        from backend.tools import sandbox
        settings.data = self._orig_data
        settings.set = self._orig_set
        sandbox.BACKUP_DIR = self._orig_backup
        self._tmp.cleanup()
