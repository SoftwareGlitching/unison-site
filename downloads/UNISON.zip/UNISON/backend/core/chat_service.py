"""
Chat service: turns a user message into a reply, optionally as an agent that uses tools.

- Plain chat: one model call, streamed.
- Agent mode: the model may call tools (files, terminal, MCP). Safe tools run straight away; others
  pause the stream with an `approval_required` event until the user approves or declines in the app.
  The loop stops when the model answers without tool calls, after MAX_STEPS, or if it repeats itself.
- Retrieval: relevant chunks from the local knowledge base are added to the system prompt and
  reported to the client as `sources`.

Everything (user messages, assistant messages, tool calls and results) is stored in SQLite.
Framework-independent so it can be reused by the API, scripts and evaluations.
"""
from __future__ import annotations

import asyncio
import json
import re
import time
import uuid
from typing import AsyncIterator, Optional

from ..agents import prompts
from ..agents.approvals import ApprovalBroker, broker as default_broker
from ..database.db import Database
from ..inference.base import ChatMessage, GenerationOptions, InferenceError, ToolCall
from ..inference.manager import ModelManager
from ..tools.base import ToolResult
from ..tools.registry import ToolRegistry, registry as default_registry
from .config import settings
from .toolparse import extract_tool_calls

CHARS_PER_TOKEN = 3.5          # rough average for English + code; used only to trim old turns
REPLY_RESERVE_TOKENS = 1024    # leave room in the context window for the answer
MAX_STEPS = 25
APPROVAL_TIMEOUT = 900
UI_OUTPUT_LIMIT = 6000

TOOL_BLOCK = re.compile(r"<tool_call>\s*(\{.*?\})\s*</tool_call>", re.S)
# Models without native tool support sometimes open the tag and stop generating before closing it.
TOOL_BLOCK_OPEN = re.compile(r"<tool_call>\s*(\{.*\})\s*$", re.S)

# Models remembered to lack native tool calling (switch to the text protocol for them).
_text_protocol_models: set[str] = set()


def log_error(model: str, e: Exception) -> None:
    """Keep engine errors (with Ollama's own message) for diagnosis: logs/errors.log."""
    from .config import LOG_DIR
    with open(LOG_DIR / "errors.log", "a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "model": model,
                            "error": str(e), "code": getattr(e, "code", "")}) + "\n")


def estimate_tokens(text: str) -> int:
    return int(len(text) / CHARS_PER_TOKEN) + 4


def fit_context(system: Optional[ChatMessage], history: list[ChatMessage], num_ctx: int) -> list[ChatMessage]:
    """Keep the system prompt and as many of the most recent messages as fit the context window."""
    budget = max(num_ctx - REPLY_RESERVE_TOKENS, 512)
    if system:
        budget -= estimate_tokens(system.content)
    kept: list[ChatMessage] = []
    for msg in reversed(history):
        cost = estimate_tokens(msg.content) + (estimate_tokens(json.dumps([c.to_dict() for c in msg.tool_calls]))
                                               if msg.tool_calls else 0)
        if kept and cost > budget:
            break
        kept.append(msg)
        budget -= cost
    kept.reverse()
    # Never start with an orphaned tool result.
    while len(kept) > 1 and kept[0].role == "tool":
        kept.pop(0)
    return ([system] if system else []) + kept


def select_hits(hits: list[dict], k: int, max_per_file: int = 2, spread: float = 0.08) -> list[dict]:
    """Keep only hits close to the best one, at most two chunks per file, at most k in total."""
    if not hits:
        return []
    best = hits[0]["score"]
    out, per_file = [], {}
    for h in hits:
        if h["score"] < best - spread:
            break
        if per_file.get(h["path"], 0) >= max_per_file:
            continue
        per_file[h["path"]] = per_file.get(h["path"], 0) + 1
        out.append(h)
        if len(out) >= k:
            break
    return out


def make_title(text: str) -> str:
    line = " ".join(text.strip().split())
    return (line[:57] + "...") if len(line) > 60 else (line or "New conversation")


def parse_text_tool_calls(content: str, known=None) -> tuple[str, list[ToolCall]]:
    """Tool calls written as text (tagged, fenced JSON or bare JSON). See core/toolparse.py."""
    return extract_tool_calls(content, known)


def history_from_db(rows: list[dict]) -> list[ChatMessage]:
    out: list[ChatMessage] = []
    for m in rows:
        if m["role"] == "user":
            out.append(ChatMessage("user", m["content"]))
        elif m["role"] == "assistant":
            calls = [ToolCall(c["name"], c.get("arguments") or {}, c.get("id", "")) for c in (m.get("tool_calls") or [])]
            out.append(ChatMessage("assistant", m["content"], tool_calls=calls or None))
        elif m["role"] == "tool":
            out.append(ChatMessage("tool", m["content"], tool_name=m.get("tool_name")))
    return out


def for_text_protocol(msgs: list[ChatMessage]) -> list[ChatMessage]:
    """Models without a tool template ignore tool roles; present calls and results as plain turns."""
    out = []
    for m in msgs:
        if m.role == "tool":
            out.append(ChatMessage("user", f"[Result of {m.tool_name}]\n{m.content}"))
        elif m.role == "assistant" and m.tool_calls:
            blocks = "\n".join("<tool_call>\n" + json.dumps({"name": c.name, "arguments": c.arguments}) + "\n</tool_call>"
                               for c in m.tool_calls)
            out.append(ChatMessage("assistant", (m.content + "\n" + blocks).strip()))
        else:
            out.append(ChatMessage(m.role, m.content))
    return out


def _short_args(args: dict) -> dict:
    return {k: (v[:400] + f"... ({len(v)} chars)" if isinstance(v, str) and len(v) > 400 else v)
            for k, v in (args or {}).items()}


class ChatService:
    def __init__(self, db: Database, manager: ModelManager, tools: Optional[ToolRegistry] = None,
                 approvals: Optional[ApprovalBroker] = None, knowledge=None, *, max_steps: int = MAX_STEPS,
                 approval_timeout: float = APPROVAL_TIMEOUT, auto_approve: Optional[bool] = None):
        self.max_steps = max_steps
        self.approval_timeout = approval_timeout
        self.auto_approve = auto_approve   # None = follow the "autonomous" setting
        self.db = db
        self.manager = manager
        self.tools = tools or default_registry
        self.approvals = approvals or default_broker
        self.knowledge = knowledge

    async def _retrieve(self, query: str) -> list[dict]:
        if not query or not settings.get("knowledge", "auto_retrieve", True):
            return []
        store = self.knowledge
        if store is None:
            from ..knowledge.store import get_store
            store = get_store()
        try:
            if not store.counts()["chunks"]:
                return []
            k = int(settings.get("knowledge", "top_k", 4))
            hits = await store.search(query[:2000], k=k * 3,
                                      min_score=float(settings.get("knowledge", "min_score", 0.62)))
            return select_hits(hits, k)
        except Exception:  # noqa: BLE001 - retrieval is best-effort; chat must still work
            return []

    async def run(self, *, conversation_id: Optional[str], content: Optional[str], model: Optional[str] = None,
                  regenerate: bool = False, system: Optional[str] = None,
                  options: Optional[GenerationOptions] = None, tools: bool = False) -> AsyncIterator[dict]:
        """Yields events: user_saved, start, sources, token, thinking, assistant_saved, tool_call,
        approval_required, approval_resolved, tool_result, notice, done."""
        model_name = await self.manager.resolve_model(model)
        opts = options or self.manager.default_options()

        conv = self.db.get_conversation(conversation_id) if conversation_id else None
        if conversation_id and not conv:
            raise InferenceError(f"Conversation '{conversation_id}' not found", 404, "conversation_not_found")
        if conv is None:
            if not content:
                raise InferenceError("A message is required to start a conversation", 400, "empty_message")
            conv = self.db.create_conversation(make_title(content), model_name)
        cid = conv["id"]

        if regenerate:
            self.db.delete_last_assistant(cid)
            rows = self.db.messages(cid)
            if not rows:
                raise InferenceError("Nothing to regenerate", 400, "nothing_to_regenerate")
            query = next((m["content"] for m in reversed(rows) if m["role"] == "user"), "")
        else:
            if not content or not content.strip():
                raise InferenceError("Message is empty", 400, "empty_message")
            user_msg = self.db.add_message(cid, "user", content)
            yield {"type": "user_saved", "message_id": user_msg["id"]}
            query = content

        history = history_from_db(self.db.messages(cid))
        yield {"type": "start", "conversation_id": cid, "model": model_name, "agent": tools,
               "title": self.db.get_conversation(cid)["title"]}

        hits = await self._retrieve(query)
        if hits:
            shown: dict[str, dict] = {}
            for h in hits:   # one chip per file
                if h["path"] not in shown:
                    shown[h["path"]] = {"title": h["title"], "path": h["path"], "score": h["score"],
                                        "lines": h["lines"], "kind": h["kind"]}
            yield {"type": "sources", "items": list(shown.values())}
        from ..knowledge.store import format_context

        def system_text(text_protocol: bool) -> str:
            if system is not None:
                base = system
            elif tools:
                base = prompts.agent_prompt(model_name, text_protocol, self.tools.describe_for_prompt())
            else:
                base = prompts.base_prompt(model_name)
            if hits:
                base += "\n\n" + prompts.KNOWLEDGE_HEADER.format(context=format_context(hits))
            return base

        text_protocol = tools and model_name in _text_protocol_models
        seen: dict[str, int] = {}
        last_stats = None
        totals = {"completion_tokens": 0, "prompt_tokens": 0, "steps": 0, "tool_calls": 0}
        started = time.time()
        final_message_id = None

        retries = 0
        for step in range(self.max_steps):
            totals["steps"] = step + 1
            sys_msg = ChatMessage("system", system_text(text_protocol))
            msgs = fit_context(sys_msg, history, opts.num_ctx or 8192)
            if text_protocol:
                msgs = for_text_protocol(msgs)
            schemas = self.tools.schemas() if (tools and not text_protocol) else None

            parts: list[str] = []
            calls: list[ToolCall] = []
            stats = None
            finished = False
            gen = self.manager.stream(model_name, msgs, opts, tools=schemas)
            try:
                async for ev in gen:
                    if ev.type == "token":
                        parts.append(ev.content)
                        yield {"type": "token", "content": ev.content}
                    elif ev.type == "thinking":
                        yield {"type": "thinking", "content": ev.content}
                    elif ev.type == "tool_calls" and ev.tool_calls:
                        calls.extend(ev.tool_calls)
                    elif ev.type == "done":
                        stats = ev.stats.to_dict() if ev.stats else None
                finished = True
            except InferenceError as e:
                if e.code == "engine_error" and not parts and retries < 2:
                    retries += 1
                    log_error(model_name, e)
                    await asyncio.sleep(2 * retries)
                    continue
                if e.code == "tools_unsupported" and not text_protocol and not parts:
                    _text_protocol_models.add(model_name)
                    text_protocol = True
                    yield {"type": "notice", "message": f"{model_name} has no native tool calling; "
                                                        "using UNISON's text tool protocol instead."}
                    continue
                raise
            finally:
                await gen.aclose()
                if not finished:
                    # Stopped by the user mid-reply: keep what was written so far.
                    partial = "".join(parts)
                    if partial:
                        self.db.add_message(cid, "assistant", TOOL_BLOCK.sub("", partial).strip(), model_name,
                                            {"model": model_name, "done_reason": "stopped",
                                             "wall_ms": round((time.time() - started) * 1000)})

            text = "".join(parts)
            if tools and not calls:
                text, calls = parse_text_tool_calls(text, {t.name for t in self.tools.enabled()})
            if not tools:
                calls = []
            for c in calls:
                c.id = c.id or f"call_{uuid.uuid4().hex[:8]}"
            if stats:
                last_stats = stats
                totals["completion_tokens"] += stats.get("completion_tokens", 0)
                totals["prompt_tokens"] += stats.get("prompt_tokens", 0)

            saved = self.db.add_message(
                cid, "assistant", text, model_name, stats,
                tool_calls=[{"id": c.id, "name": c.name, "arguments": c.arguments} for c in calls] or None)
            final_message_id = saved["id"]
            history.append(ChatMessage("assistant", text, tool_calls=calls or None))
            yield {"type": "assistant_saved", "message_id": saved["id"], "has_tool_calls": bool(calls),
                   "content": text, "stats": stats}

            if not calls:
                break

            for call in calls:
                totals["tool_calls"] += 1
                result = None
                async for ev in self._run_tool(cid, call, seen):
                    if ev["type"] == "_result":
                        result = ev["result"]
                        continue
                    yield ev
                assert result is not None
                meta = {"call_id": call.id, "ok": result.ok, "args": _short_args(call.arguments),
                        "data": {k: v for k, v in result.data.items() if k != "diff"},
                        "diff": (result.data.get("diff") or "")[:20000] or None}
                self.db.add_message(cid, "tool", result.output, model_name, tool_name=call.name, meta=meta)
                history.append(ChatMessage("tool", result.output, tool_name=call.name))
                yield {"type": "tool_result", "call_id": call.id, "name": call.name, "ok": result.ok,
                       "output": result.output[:UI_OUTPUT_LIMIT], "data": meta["data"], "diff": meta["diff"]}
        else:
            note = f"Stopped after {self.max_steps} steps to avoid running forever. Say 'continue' to let me keep going."
            saved = self.db.add_message(cid, "assistant", note, model_name, {"done_reason": "max_steps"})
            final_message_id = saved["id"]
            yield {"type": "notice", "message": note}

        summary = dict(last_stats or {})
        summary.update({"total_completion_tokens": totals["completion_tokens"], "steps": totals["steps"],
                        "tool_calls": totals["tool_calls"], "wall_ms": round((time.time() - started) * 1000)})
        yield {"type": "done", "conversation_id": cid, "message_id": final_message_id, "stats": summary}

    async def _run_tool(self, cid: str, call: ToolCall, seen: dict[str, int]) -> AsyncIterator[dict]:
        key = call.name + json.dumps(call.arguments, sort_keys=True)
        seen[key] = seen.get(key, 0) + 1
        tool = self.tools.get(call.name)
        if not tool:
            decision, reason = "deny", "unknown tool"
        else:
            decision, reason = self.tools.decide(tool, call.arguments)
            autonomous = self.auto_approve if self.auto_approve is not None else \
                bool(settings.get("tools", "autonomous", False))
            if decision == "ask" and autonomous:
                decision, reason = "auto", "autonomous mode"
        yield {"type": "tool_call", "call_id": call.id, "name": call.name, "args": _short_args(call.arguments),
               "decision": decision, "reason": reason, "risk": tool.risk if tool else None}

        if seen[key] > 2:
            yield {"type": "_result", "result": ToolResult(
                False, "You already made this exact call twice with the same result. Do something different, "
                       "or explain the problem to the user.")}
            return
        if not tool:
            yield {"type": "_result", "result": ToolResult(
                False, f"Unknown tool '{call.name}'. Available tools: {', '.join(t.name for t in self.tools.enabled())}")}
            return
        if decision == "deny":
            yield {"type": "_result", "result": ToolResult(False, f"Not allowed: {reason}.")}
            return
        if decision == "ask":
            preview = self.tools.preview(tool, call.arguments)
            pending = self.approvals.create({"conversation_id": cid, "call_id": call.id, "name": call.name,
                                             "args": _short_args(call.arguments), "preview": preview})
            yield {"type": "approval_required", "action_id": pending.id, "call_id": call.id, "name": call.name,
                   "args": _short_args(call.arguments), "preview": preview, "reason": reason}
            answer = await self.approvals.wait(pending, self.approval_timeout)
            yield {"type": "approval_resolved", "action_id": pending.id, "call_id": call.id,
                   "approved": answer["approved"], "note": answer.get("note", "")}
            if not answer["approved"]:
                why = " (no answer within 15 minutes)" if answer.get("timeout") else ""
                note = f" The user said: {answer['note']}" if answer.get("note") and not answer.get("timeout") else ""
                yield {"type": "_result", "result": ToolResult(False, f"The user declined this action{why}.{note}")}
                return
        yield {"type": "tool_running", "call_id": call.id}
        yield {"type": "_result", "result": await self.tools.execute(call.name, call.arguments)}
