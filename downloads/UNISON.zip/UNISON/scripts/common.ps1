# Shared helpers for UNISON's Windows scripts. Dot-source this file.
$ErrorActionPreference = "Continue"
$Root = Split-Path -Parent $PSScriptRoot
$Venv = Join-Path $Root ".venv"
$VenvPy = Join-Path $Venv "Scripts\python.exe"
$OllamaUrl = "http://127.0.0.1:11434"
$UnisonUrl = "http://127.0.0.1:8770"

function Write-Step([string]$n, [string]$t) { Write-Host ""; Write-Host "[$n] $t" -ForegroundColor Cyan }
function Write-Ok([string]$t) { Write-Host "   ok  $t" -ForegroundColor Green }
function Write-Warn2([string]$t) { Write-Host "   !!  $t" -ForegroundColor Yellow }
function Write-Bad([string]$t) { Write-Host "   XX  $t" -ForegroundColor Red }

function Update-SessionPath {
    $machine = [Environment]::GetEnvironmentVariable("Path", "Machine")
    $user = [Environment]::GetEnvironmentVariable("Path", "User")
    $env:Path = "$machine;$user"
}

function Ask-YesNo([string]$question, [bool]$default = $true) {
    $hint = if ($default) { "[Y/n]" } else { "[y/N]" }
    $a = Read-Host "   $question $hint"
    if ([string]::IsNullOrWhiteSpace($a)) { return $default }
    return $a.Trim().ToLower().StartsWith("y")
}

function Test-Http([string]$url, [int]$timeoutSec = 3) {
    try {
        $r = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec $timeoutSec
        return ($r.StatusCode -ge 200 -and $r.StatusCode -lt 500)
    } catch { return $false }
}

function Find-OllamaExe {
    $cmd = Get-Command ollama -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($cmd) { return $cmd.Source }
    $p = Join-Path $env:LOCALAPPDATA "Programs\Ollama\ollama.exe"
    if (Test-Path $p) { return $p }
    return $null
}

function Start-OllamaIfNeeded {
    if (Test-Http "$OllamaUrl/api/version") { return $true }
    $exe = Find-OllamaExe
    if (-not $exe) { return $false }
    # Prefer the tray app if installed (it manages the server); otherwise run the server headless.
    $app = Join-Path (Split-Path -Parent $exe) "ollama app.exe"
    if (Test-Path $app) { Start-Process -FilePath $app -WindowStyle Hidden }
    else { Start-Process -FilePath $exe -ArgumentList "serve" -WindowStyle Hidden }
    for ($i = 0; $i -lt 40; $i++) {
        Start-Sleep -Milliseconds 750
        if (Test-Http "$OllamaUrl/api/version") { return $true }
    }
    return $false
}

function Find-Python {
    # Prefer 3.12 (best wheel coverage), then other supported versions.
    $py = Get-Command py -ErrorAction SilentlyContinue
    if ($py) {
        foreach ($v in @("3.12", "3.11", "3.13", "3.14", "3.10")) {
            $exe = & py "-$v" -c "import sys; print(sys.executable)" 2>$null
            if ($LASTEXITCODE -eq 0 -and $exe) { return ($exe | Select-Object -First 1).Trim() }
        }
    }
    foreach ($name in @("python", "python3")) {
        $cmd = Get-Command $name -ErrorAction SilentlyContinue | Where-Object { $_.Source -notlike "*\WindowsApps\*" } | Select-Object -First 1
        if ($cmd) {
            $ver = & $cmd.Source -c "import sys; print('%d.%d' % sys.version_info[:2])" 2>$null
            if ($LASTEXITCODE -eq 0 -and $ver) {
                $v = [version]($ver.Trim())
                if ($v -ge [version]"3.10" -and $v -lt [version]"3.15") { return $cmd.Source }
            }
        }
    }
    return $null
}

function Get-NodeMajor {
    $node = Get-Command node -ErrorAction SilentlyContinue
    if (-not $node) { return 0 }
    $v = & node --version 2>$null
    if ($v -match "v(\d+)") { return [int]$Matches[1] }
    return 0
}

function Install-WithWinget([string]$id, [string]$label, [string]$manualUrl) {
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        Write-Bad "winget is not available, so $label can't be installed automatically."
        Write-Host "       Install it from $manualUrl, then run Setup.bat again."
        return $false
    }
    Write-Host "   Installing $label with winget (this accepts the package's license terms)..."
    & winget install --id $id -e --silent --accept-source-agreements --accept-package-agreements
    Update-SessionPath
    return $true
}
