import { useEffect, useState } from "react";
import { api, type InferenceSettings } from "../lib/api";

const FIELDS: { key: keyof InferenceSettings; label: string; min: number; max: number; step: number; hint: string }[] = [
  { key: "temperature", label: "Temperature", min: 0, max: 1.5, step: 0.05, hint: "Lower = more focused and repeatable" },
  { key: "top_p", label: "Top-p", min: 0.1, max: 1, step: 0.05, hint: "Nucleus sampling cutoff" },
  { key: "top_k", label: "Top-k", min: 1, max: 100, step: 1, hint: "Candidates considered per token" },
  { key: "repeat_penalty", label: "Repeat penalty", min: 1, max: 1.5, step: 0.01, hint: "Discourages loops" },
];

const CTX = [2048, 4096, 8192, 16384, 32768];

export function SettingsPanel({ onClose, embedded }: { onClose: () => void; embedded?: boolean }) {
  const [s, setS] = useState<InferenceSettings | null>(null);
  const [saved, setSaved] = useState("");
  const [err, setErr] = useState("");

  useEffect(() => {
    api.settings().then(setS).catch((e) => setErr(e.message));
  }, []);

  const save = async (patch: Partial<InferenceSettings>) => {
    if (!s) return;
    setS({ ...s, ...patch });
    try {
      const next = await api.saveSettings(patch);
      setS(next);
      setSaved("saved");
      setTimeout(() => setSaved(""), 1000);
    } catch (e: any) {
      setErr(e.message);
    }
  };

  return (
    <div className={embedded ? "tab-body" : "settings-panel"}>
      <div className="settings-head" style={embedded ? { display: "none" } : undefined}>
        <span>Sampling</span>
        <span className="saved">{saved}</span>
        <button className="icon-btn" onClick={onClose} aria-label="Close">
          ×
        </button>
      </div>
      {!s && !err && <div className="pop-empty">loading…</div>}
      {s &&
        FIELDS.map((f) => (
          <label key={f.key} className="field">
            <div className="field-top">
              <span>{f.label}</span>
              <span className="field-val">{s[f.key]}</span>
            </div>
            <input
              type="range"
              min={f.min}
              max={f.max}
              step={f.step}
              value={s[f.key] as number}
              onChange={(e) => setS({ ...s, [f.key]: Number(e.target.value) })}
              onMouseUp={(e) => save({ [f.key]: Number((e.target as HTMLInputElement).value) })}
              onKeyUp={(e) => save({ [f.key]: Number((e.target as HTMLInputElement).value) })}
            />
            <span className="field-hint">{f.hint}</span>
          </label>
        ))}
      {s && (
        <label className="field">
          <div className="field-top">
            <span>Context length</span>
            <span className="field-val">{s.num_ctx.toLocaleString()} tokens</span>
          </div>
          <div className="ctx-row">
            {CTX.map((c) => (
              <button key={c} className={`chip ${s.num_ctx === c ? "on" : ""}`} onClick={() => save({ num_ctx: c })}>
                {c >= 1024 ? `${c / 1024}K` : c}
              </button>
            ))}
          </div>
          <span className="field-hint">Longer context remembers more of the chat but uses more VRAM.</span>
        </label>
      )}
      {err && <div className="pop-error">{err}</div>}
    </div>
  );
}
