"""Thinking is switched off for chat; models that don't support the switch are retried without it once."""
import asyncio
import unittest

from tests.helpers import IsolatedSettings

from backend.inference.base import ChatMessage, GenerationOptions, InferenceError, StreamEvent
from backend.inference.manager import ModelManager


class FakeBackend:
    name = "fake"

    def __init__(self, supports_think):
        self.supports_think, self.calls = supports_think, []

    async def chat_stream(self, model, messages, options, keep_alive=None, tools=None, think=None):
        self.calls.append(think)
        if think is not None and not self.supports_think:
            raise InferenceError("model rejected the think option", 400, "think_unsupported")
        yield StreamEvent("token", "hi")


def run(mgr, model="m"):
    async def go():
        return [e.content async for e in mgr.stream(model, [ChatMessage("user", "x")], GenerationOptions())]
    return asyncio.run(go())


class ThinkTests(unittest.TestCase):
    def test_think_off_for_thinking_models(self):
        with IsolatedSettings():
            b = FakeBackend(True)
            self.assertEqual(run(ModelManager(b)), ["hi"])
            self.assertEqual(b.calls, [False])

    def test_falls_back_and_remembers_for_other_models(self):
        with IsolatedSettings():
            b = FakeBackend(False)
            m = ModelManager(b)
            self.assertEqual(run(m), ["hi"])
            self.assertEqual(run(m), ["hi"])
            self.assertEqual(b.calls, [False, None, None])
            self.assertEqual(m.active_generations, 0)


if __name__ == "__main__":
    unittest.main()
