@echo off
rem Double-click to start UNISON. Runs setup automatically the first time.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\start.ps1" %*
