# Move Ollama's downloaded models (several GB) off the C: drive.
# Sets the OLLAMA_MODELS environment variable for your user account and moves the existing files,
# so nothing has to be downloaded again.
param([string]$Target = "")

. (Join-Path $PSScriptRoot "common.ps1")

Write-Host ""
Write-Host "  Move Ollama models to another drive" -ForegroundColor Cyan
Write-Host ""

$current = [Environment]::GetEnvironmentVariable("OLLAMA_MODELS", "User")
if (-not $current) { $current = Join-Path $env:USERPROFILE ".ollama\models" }
$sizeGb = 0
if (Test-Path $current) {
    $sizeGb = [math]::Round(((Get-ChildItem $current -Recurse -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum) / 1GB, 1)
}
Write-Host "   Models are now in: $current  ($sizeGb GB)"
Write-Host ""
Write-Host "   Drives:"
Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Used -ne $null -and ($_.Free + $_.Used) -gt 0 } | ForEach-Object {
    Write-Host ("     {0}:  {1,7:N1} GB free of {2,7:N1} GB" -f $_.Name, ($_.Free / 1GB), (($_.Free + $_.Used) / 1GB))
}
Write-Host ""

if (-not $Target) {
    $drive = Read-Host "   Move them to which drive letter? [Enter = D]"
    if ([string]::IsNullOrWhiteSpace($drive)) { $drive = "D" }
    $drive = $drive.Trim().TrimEnd(":", "\").ToUpper()
    $Target = "${drive}:\Ollama\models"
}
$targetDrive = (Split-Path -Qualifier $Target).TrimEnd(":")
$psd = Get-PSDrive -Name $targetDrive -ErrorAction SilentlyContinue
if (-not $psd) { Write-Bad "Drive ${targetDrive}: not found."; Read-Host "Press Enter to close"; exit 1 }
if (($psd.Free / 1GB) -lt ($sizeGb + 8)) {
    Write-Warn2 ("Only {0:N1} GB free on {1}: - that leaves little room for new models." -f ($psd.Free / 1GB), $targetDrive)
    if (-not (Ask-YesNo "Continue anyway?" $false)) { exit 1 }
}
if ((Resolve-Path $current -ErrorAction SilentlyContinue).Path -eq $Target) { Write-Ok "Already there."; exit 0 }

Write-Host "   Target: $Target"
if (-not (Ask-YesNo "Stop Ollama, move the models and point Ollama at the new folder?" $true)) { exit 1 }

# 1. stop Ollama (tray app + server) so no file is in use
Get-Process -Name "ollama app", "ollama", "ollama_llama_server" -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 2

# 2. move files (robocopy /MOVE keeps going on errors and can be re-run safely)
New-Item -ItemType Directory -Force -Path $Target | Out-Null
if (Test-Path $current) {
    & robocopy $current $Target /E /MOVE /R:2 /W:2 /NFL /NDL /NP | Out-Null
    if ($LASTEXITCODE -ge 8) {
        Write-Bad "Some files could not be moved (robocopy code $LASTEXITCODE). Nothing was deleted that wasn't copied."
        Write-Host "   Close anything using Ollama and run this again."
        Read-Host "Press Enter to close"
        exit 1
    }
}

# 3. tell Ollama where models live (for this user, permanently) and restart it
[Environment]::SetEnvironmentVariable("OLLAMA_MODELS", $Target, "User")
$env:OLLAMA_MODELS = $Target
Write-Ok "OLLAMA_MODELS = $Target"

if (Start-OllamaIfNeeded) {
    $list = & (Find-OllamaExe) list 2>$null | Out-String
    Write-Host $list
    Write-Ok "Ollama restarted and sees the models in their new place."
} else {
    Write-Warn2 "Ollama didn't restart by itself. Open it from the Start menu (sign out and back in if it still uses C:)."
}
$freeC = [math]::Round((Get-PSDrive C).Free / 1GB, 1)
Write-Host "   C: now has $freeC GB free."
Read-Host "Press Enter to close"
