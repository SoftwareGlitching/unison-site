"""
Ollama inference backend.

Ollama runs the open-weight model locally (llama.cpp under the hood, CUDA/ROCm when available,
CPU otherwise). UNISON talks to it only over localhost; nothing leaves the machine.
"""
from __future__ import annotations

import asyncio
import os
import shutil
import subprocess
import sys
import json
from typing import AsyncIterator, Optional

import httpx

from .base import (ChatMessage, GenerationOptions, GenerationStats, InferenceError, ModelInfo,
                   StreamEvent, ToolCall)


def _ns_to_ms(v) -> float:
    return round((v or 0) / 1e6, 1)


def stats_from_final(model: str, chunk: dict) -> GenerationStats:
    eval_count = chunk.get("eval_count") or 0
    eval_ns = chunk.get("eval_duration") or 0
    p_count = chunk.get("prompt_eval_count") or 0
    p_ns = chunk.get("prompt_eval_duration") or 0
    return GenerationStats(
        model=model,
        prompt_tokens=p_count,
        completion_tokens=eval_count,
        tokens_per_second=round(eval_count / (eval_ns / 1e9), 2) if eval_ns else 0.0,
        prompt_tokens_per_second=round(p_count / (p_ns / 1e9), 2) if p_ns else 0.0,
        load_ms=_ns_to_ms(chunk.get("load_duration")),
        total_ms=_ns_to_ms(chunk.get("total_duration")),
        done_reason=chunk.get("done_reason") or "stop",
    )


def build_ollama_options(o: GenerationOptions) -> dict:
    opts: dict = {}
    for src, dst in (("temperature", "temperature"), ("top_p", "top_p"), ("top_k", "top_k"),
                     ("repeat_penalty", "repeat_penalty"), ("num_ctx", "num_ctx"), ("seed", "seed"),
                     ("max_tokens", "num_predict"), ("stop", "stop"), ("num_gpu", "num_gpu"),
                     ("num_thread", "num_thread")):
        v = getattr(o, src)
        if v is not None:
            opts[dst] = v
    return opts


# Settings that make Ollama gentle and fast on a 12 GB card. Used whenever UNISON starts Ollama itself.
OLLAMA_DEFAULTS = {"OLLAMA_FLASH_ATTENTION": "1", "OLLAMA_KV_CACHE_TYPE": "q8_0",
                   "OLLAMA_MAX_LOADED_MODELS": "2", "OLLAMA_NUM_PARALLEL": "1"}


def ollama_env() -> dict:
    """Environment for starting 'ollama serve': this process's env, plus the user's saved OLLAMA_* settings
    (read from the registry, so it works even if UNISON started before they were set), plus our defaults."""
    env = dict(os.environ)
    if sys.platform == "win32":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as k:
                i = 0
                while True:
                    try:
                        name, value, _ = winreg.EnumValue(k, i)
                    except OSError:
                        break
                    if name.upper().startswith("OLLAMA_") and value:
                        env[name.upper()] = str(value)
                    i += 1
        except OSError:
            pass
    for k, v in OLLAMA_DEFAULTS.items():
        env.setdefault(k, v)
    return env


class OllamaBackend:
    name = "ollama"

    def __init__(self, base_url: str = "http://127.0.0.1:11434", timeout: float = 600.0):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def _client(self, read_timeout: Optional[float] = None) -> httpx.AsyncClient:
        t = httpx.Timeout(connect=5.0, read=read_timeout or self.timeout, write=30.0, pool=5.0)
        # Plain http to this PC needs no certificates. verify=False stops httpx from loading certifi's CA file
        # at all, so a deleted/missing cacert.pem can't take the engine connection down (it did once).
        plain = self.base_url.startswith("http://")
        return httpx.AsyncClient(base_url=self.base_url, timeout=t, verify=not plain, trust_env=not plain)

    def _unreachable(self, exc: Exception) -> InferenceError:
        return InferenceError(
            f"Cannot reach Ollama at {self.base_url}. Is it running? Start the Ollama app or run "
            f"'ollama serve'. ({type(exc).__name__})", 503, "engine_offline")

    async def health(self) -> dict:
        try:
            async with self._client(5.0) as c:
                r = await c.get("/api/version")
                r.raise_for_status()
                return {"ok": True, "engine": "ollama", "version": r.json().get("version"), "url": self.base_url}
        except Exception as exc:  # noqa: BLE001 - report any failure as offline
            return {"ok": False, "engine": "ollama", "error": str(self._unreachable(exc)), "url": self.base_url}

    async def list_models(self) -> list[ModelInfo]:
        try:
            async with self._client(15.0) as c:
                r = await c.get("/api/tags")
                r.raise_for_status()
        except httpx.HTTPError as exc:
            raise self._unreachable(exc) from exc
        out = []
        for m in r.json().get("models", []):
            d = m.get("details") or {}
            out.append(ModelInfo(
                name=m.get("name") or m.get("model", ""),
                size_bytes=m.get("size") or 0,
                family=d.get("family", ""),
                parameter_size=d.get("parameter_size", ""),
                quantization=d.get("quantization_level", ""),
                modified_at=m.get("modified_at", ""),
                details=d,
            ))
        return out

    async def loaded_models(self) -> list[dict]:
        """Models currently in memory, with how much of each sits in VRAM (real numbers from Ollama)."""
        try:
            async with self._client(5.0) as c:
                r = await c.get("/api/ps")
                r.raise_for_status()
        except httpx.HTTPError:
            return []
        out = []
        for m in r.json().get("models", []):
            size = m.get("size") or 0
            vram = m.get("size_vram") or 0
            out.append({
                "name": m.get("name"),
                "size_bytes": size,
                "vram_bytes": vram,
                "gpu_percent": round(100 * vram / size, 1) if size else 0.0,
                "context_length": m.get("context_length"),
                "expires_at": m.get("expires_at"),
            })
        return out

    async def ensure_running(self) -> bool:
        """If Ollama isn't answering (closed, crashed, killed with a console window), start it again - detached,
        so closing any window can't take it down - and wait for it. Windows only; elsewhere just reports."""
        async def up() -> bool:
            try:
                async with self._client(3.0) as c:
                    return (await c.get("/api/version")).status_code == 200
            except httpx.HTTPError:
                return False
        if await up():
            return True
        if sys.platform != "win32" or not self.base_url.startswith(("http://127.0.0.1", "http://localhost")):
            return False
        exe = shutil.which("ollama") or os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Ollama", "ollama.exe")
        if not os.path.exists(exe):
            return False
        # The background engine only ("ollama serve"), never Ollama's desktop app: the app opens a big window,
        # and closing that window quits Ollama - which left UNISON with no engine.
        cmd = [exe, "serve"]
        env = ollama_env()
        detached = 0x00000008 | 0x00000200 | 0x08000000          # DETACHED | NEW_GROUP | NO_WINDOW
        for flags in (detached | 0x01000000, detached):           # try to break away from our job object first
            try:
                subprocess.Popen(cmd, creationflags=flags, close_fds=True, stdin=subprocess.DEVNULL, env=env,
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                break
            except OSError:
                continue
        for _ in range(60):
            await asyncio.sleep(0.5)
            if await up():
                return True
        return False

    async def chat_stream(self, model: str, messages: list[ChatMessage], options: GenerationOptions,
                          keep_alive: Optional[str] = None,
                          tools: Optional[list[dict]] = None,
                          think: Optional[bool] = None) -> AsyncIterator[StreamEvent]:
        payload = {
            "model": model,
            "messages": [m.to_dict() for m in messages],
            "stream": True,
            "options": build_ollama_options(options),
        }
        if keep_alive:
            payload["keep_alive"] = keep_alive
        if tools:
            payload["tools"] = tools
        if think is not None:
            payload["think"] = think
        await self.ensure_running()
        try:
            async with self._client() as c:
                async with c.stream("POST", "/api/chat", json=payload) as resp:
                    if resp.status_code != 200:
                        body = (await resp.aread()).decode("utf-8", "replace")
                        try:
                            msg = json.loads(body).get("error", body)
                        except json.JSONDecodeError:
                            msg = body
                        if think is not None and "think" in str(msg).lower() and resp.status_code == 400:
                            raise InferenceError(f"{model} rejected the think option: {msg}", 400, "think_unsupported")
                        if "does not support tools" in str(msg):
                            raise InferenceError(f"Model '{model}' does not support native tool calling",
                                                 400, "tools_unsupported")
                        if resp.status_code == 404:
                            raise InferenceError(
                                f"Model '{model}' is not installed in Ollama. Download it from the model "
                                f"menu or run: ollama pull {model}", 404, "model_not_found")
                        raise InferenceError(f"Ollama error {resp.status_code}: {msg}", 502, "engine_error")
                    async for line in resp.aiter_lines():
                        if not line.strip():
                            continue
                        chunk = json.loads(line)
                        if chunk.get("error"):
                            raise InferenceError(f"Ollama: {chunk['error']}", 502, "engine_error")
                        msg = chunk.get("message") or {}
                        if msg.get("thinking"):
                            yield StreamEvent("thinking", msg["thinking"])
                        if msg.get("content"):
                            yield StreamEvent("token", msg["content"])
                        if msg.get("tool_calls"):
                            calls = []
                            for i, tc in enumerate(msg["tool_calls"]):
                                fn = tc.get("function") or {}
                                args = fn.get("arguments") or {}
                                if isinstance(args, str):
                                    try:
                                        args = json.loads(args)
                                    except json.JSONDecodeError:
                                        args = {"_raw": args}
                                calls.append(ToolCall(fn.get("name", ""), args, tc.get("id") or f"call_{i}"))
                            yield StreamEvent("tool_calls", tool_calls=calls)
                        if chunk.get("done"):
                            yield StreamEvent("done", stats=stats_from_final(model, chunk))
                            return
        except httpx.HTTPError as exc:
            raise self._unreachable(exc) from exc

    async def embed(self, model: str, texts: list[str]) -> list[list[float]]:
        """Local embeddings (e.g. nomic-embed-text). Batches to keep requests small."""
        out: list[list[float]] = []
        try:
            async with self._client(300.0) as c:
                for i in range(0, len(texts), 32):
                    r = await c.post("/api/embed", json={"model": model, "input": texts[i:i + 32]})
                    if r.status_code == 404:
                        raise InferenceError(
                            f"Embedding model '{model}' is not installed. Run: ollama pull {model}",
                            404, "model_not_found")
                    r.raise_for_status()
                    out.extend(r.json()["embeddings"])
        except httpx.HTTPError as exc:
            raise self._unreachable(exc) from exc
        return out

    async def pull(self, model: str) -> AsyncIterator[dict]:
        try:
            async with self._client(3600.0) as c:
                async with c.stream("POST", "/api/pull", json={"model": model, "stream": True}) as resp:
                    if resp.status_code != 200:
                        body = (await resp.aread()).decode("utf-8", "replace")
                        raise InferenceError(f"Pull failed ({resp.status_code}): {body}", 502, "pull_failed")
                    async for line in resp.aiter_lines():
                        if line.strip():
                            data = json.loads(line)
                            if data.get("error"):
                                raise InferenceError(f"Pull failed: {data['error']}", 502, "pull_failed")
                            yield data
        except httpx.HTTPError as exc:
            raise self._unreachable(exc) from exc

    async def delete(self, model: str) -> None:
        try:
            async with self._client(30.0) as c:
                r = await c.request("DELETE", "/api/delete", json={"model": model})
                if r.status_code == 404:
                    raise InferenceError(f"Model '{model}' not found", 404, "model_not_found")
                r.raise_for_status()
        except httpx.HTTPError as exc:
            raise self._unreachable(exc) from exc

    async def capabilities(self, model: str) -> list[str]:
        """What a model can do, from Ollama ('completion', 'vision', 'tools', 'thinking'...). [] if unknown."""
        try:
            async with self._client(15.0) as c:
                r = await c.post("/api/show", json={"model": model})
                if r.status_code != 200:
                    return []
                return list(r.json().get("capabilities") or [])
        except httpx.HTTPError:
            return []

    async def unload(self, model: str) -> None:
        """Free a model's VRAM now instead of waiting for keep_alive to run out."""
        try:
            async with self._client(30.0) as c:
                await c.post("/api/generate", json={"model": model, "keep_alive": 0})
        except httpx.HTTPError:
            pass

    async def preload(self, model: str, keep_alive: Optional[str] = None,
                      options: Optional[GenerationOptions] = None) -> bool:
        """Load a model into VRAM ahead of time, so the first message doesn't wait for it. Pass the same
        options chats use (context size, GPU layers), or Ollama reloads the model on the first message."""
        body = {"model": model}
        if keep_alive:
            body["keep_alive"] = keep_alive
        if options is not None:
            opts = {k: v for k, v in build_ollama_options(options).items() if k in ("num_ctx", "num_gpu", "num_thread")}
            if opts:
                body["options"] = opts
        try:
            async with self._client(300.0) as c:
                r = await c.post("/api/generate", json=body)
                self.last_preload_error = "" if r.status_code == 200 else r.text[:2000]
                return r.status_code == 200
        except httpx.HTTPError as e:
            self.last_preload_error = str(e)
            return False
