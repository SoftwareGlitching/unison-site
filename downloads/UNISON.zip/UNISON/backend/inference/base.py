"""
Unified model interface.

Every inference engine UNISON supports implements ModelBackend. The rest of the platform
(API, chat service, later agents and tools) only talks to this interface, so the engine or
the model can be swapped without touching anything else.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import AsyncIterator, Optional, Protocol


class InferenceError(Exception):
    """Raised when the engine cannot serve a request (not running, model missing, ...)."""

    def __init__(self, message: str, status: int = 503, code: str = "inference_unavailable"):
        super().__init__(message)
        self.status = status
        self.code = code


@dataclass
class ToolCall:
    name: str
    arguments: dict
    id: str = ""

    def to_dict(self) -> dict:
        return {"function": {"name": self.name, "arguments": self.arguments}}


@dataclass
class ChatMessage:
    role: str          # system | user | assistant | tool
    content: str
    tool_calls: Optional[list[ToolCall]] = None
    tool_name: Optional[str] = None
    images: Optional[list[str]] = None      # base64 PNG/JPEG for vision models

    def to_dict(self) -> dict:
        d: dict = {"role": self.role, "content": self.content}
        if self.images:
            d["images"] = self.images
        if self.tool_calls:
            d["tool_calls"] = [c.to_dict() for c in self.tool_calls]
        if self.tool_name:
            d["tool_name"] = self.tool_name
        return d


@dataclass
class GenerationOptions:
    temperature: Optional[float] = None
    top_p: Optional[float] = None
    top_k: Optional[int] = None
    repeat_penalty: Optional[float] = None
    num_ctx: Optional[int] = None
    max_tokens: Optional[int] = None
    seed: Optional[int] = None
    stop: Optional[list[str]] = None


@dataclass
class GenerationStats:
    model: str = ""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    tokens_per_second: float = 0.0
    prompt_tokens_per_second: float = 0.0
    load_ms: float = 0.0
    total_ms: float = 0.0
    done_reason: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class StreamEvent:
    type: str                              # token | thinking | tool_calls | done | error
    content: str = ""
    stats: Optional[GenerationStats] = None
    tool_calls: Optional[list[ToolCall]] = None


@dataclass
class ModelInfo:
    name: str
    size_bytes: int = 0
    family: str = ""
    parameter_size: str = ""
    quantization: str = ""
    modified_at: str = ""
    details: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


class ModelBackend(Protocol):
    name: str

    async def health(self) -> dict: ...

    async def list_models(self) -> list[ModelInfo]: ...

    async def loaded_models(self) -> list[dict]: ...

    def chat_stream(self, model: str, messages: list[ChatMessage], options: GenerationOptions,
                    keep_alive: Optional[str] = None,
                    tools: Optional[list[dict]] = None,
                    think: Optional[bool] = None) -> AsyncIterator[StreamEvent]: ...

    async def embed(self, model: str, texts: list[str]) -> list[list[float]]: ...

    def pull(self, model: str) -> AsyncIterator[dict]: ...

    async def delete(self, model: str) -> None: ...
