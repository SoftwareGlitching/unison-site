"""
Find tool calls that a model wrote as text instead of using native tool calling.

Small local models often emit calls as `<tool_call>{...}</tool_call>`, as a ```json code block, or as a
bare JSON object, and then keep writing and *invent the result*. This parser accepts all three forms,
only for known tool names, and returns just the text written BEFORE the first call, so made-up results
after the call are discarded. The real result then comes from actually running the tool.
"""
from __future__ import annotations

import json
import re
import uuid
from typing import Iterable, Optional

from ..inference.base import ToolCall

_TAGGED = re.compile(r"<tool_call>\s*(.*?)\s*(?:</tool_call>|$)", re.S)
_FENCED = re.compile(r"```[ \t]*(?:json|tool_call|tool|javascript|js)?[ \t]*\n(.*?)```", re.S)
_OBJ_START = re.compile(r'[\[{]\s*\{?\s*"(?:name|function|tool|action)"\s*:')
_decoder = json.JSONDecoder()


def _normalize(obj) -> list[tuple[str, dict]]:
    items = obj if isinstance(obj, list) else [obj]
    out = []
    for o in items:
        if not isinstance(o, dict):
            continue
        fn = o.get("function") if isinstance(o.get("function"), dict) else {}
        name = o.get("name") or fn.get("name") or o.get("tool") or o.get("action")
        args = o.get("arguments", o.get("parameters", o.get("args", fn.get("arguments", fn.get("parameters")))))
        if isinstance(args, str):
            try:
                args = json.loads(args)
            except json.JSONDecodeError:
                args = {}
        if args is None:
            # {"name": "click", "x": 1, "y": 2} style: everything else is the arguments
            args = {k: v for k, v in o.items() if k not in ("name", "tool", "action", "function", "type")}
        if isinstance(name, str) and name and isinstance(args, dict):
            out.append((name, args))
    return out


def _try_json(text: str):
    text = text.strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    # tolerate trailing prose / a missing closing fence
    for start in range(len(text)):
        if text[start] in "{[":
            try:
                obj, _ = _decoder.raw_decode(text[start:])
                return obj
            except json.JSONDecodeError:
                return None
    return None


def extract_tool_calls(content: str, known: Optional[Iterable[str]] = None) -> tuple[str, list[ToolCall]]:
    """Returns (text before the first call, calls). Text after the calls is dropped."""
    allowed = set(known) if known is not None else None
    found: list[tuple[int, str, dict]] = []

    def add(pos: int, obj) -> bool:
        ok = False
        for name, args in _normalize(obj):
            if allowed is None or name in allowed:
                found.append((pos, name, args))
                ok = True
        return ok

    for m in _TAGGED.finditer(content):
        add(m.start(), _try_json(m.group(1)))
    if not found:
        for m in _FENCED.finditer(content):
            add(m.start(), _try_json(m.group(1)))
    if not found:
        for m in _OBJ_START.finditer(content):
            try:
                obj, _ = _decoder.raw_decode(content[m.start():])
            except json.JSONDecodeError:
                continue
            add(m.start(), obj)
            if found:
                # keep scanning after this object only
                continue
    if not found:
        return content.strip(), []
    first = min(p for p, _, _ in found)
    seen, calls = set(), []
    for _, name, args in sorted(found, key=lambda f: f[0]):
        key = name + json.dumps(args, sort_keys=True)
        if key in seen:
            continue
        seen.add(key)
        calls.append(ToolCall(name, args, f"call_{uuid.uuid4().hex[:8]}"))
    return content[:first].strip(), calls
