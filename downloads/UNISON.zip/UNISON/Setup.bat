@echo off
rem UNISON setup. Opens the setup window (UNISON.exe). "Setup.bat -Text" runs the old text-only setup.
cd /d "%~dp0"
if /i "%~1"=="-Text" goto text
if not "%~1"=="" goto textargs
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0desktop\build.ps1" -IfNeeded
if exist "%~dp0UNISON.exe" (
  start "" "%~dp0UNISON.exe" --setup
  exit /b 0
)
echo.
echo The setup window couldn't be built on this PC, so the text setup runs instead.
:text
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\setup.ps1"
exit /b %errorlevel%
:textargs
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\setup.ps1" %*
