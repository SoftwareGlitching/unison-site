@echo off
rem Manage API keys:  apikey.bat create "My app"  |  apikey.bat list  |  apikey.bat revoke <id>
cd /d "%~dp0.."
".venv\Scripts\python.exe" scripts\apikey.py %*
