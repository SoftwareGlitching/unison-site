"""Screen control must run on a model that can see. A text-only brain (e.g. 'unison' built on a text model)
can't read screenshots and only produces 'no valid action' replies - the bug behind 'it can't control my screen'."""
import asyncio
import unittest

from tests.helpers import IsolatedSettings  # noqa: I001 - must come first (sets up httpx in the sandbox)
from backend.computer import service
from backend.inference.ollama_backend import OllamaBackend
from tests.fake_ollama import FakeOllama


class PickVisionModelTests(unittest.TestCase):
    def pick(self, fake, requested=None):
        return asyncio.run(service.pick_vision_model(OllamaBackend(fake.url), requested))

    def test_text_brain_is_swapped_for_the_vision_model(self):
        caps = {"unison:latest": ["completion", "tools", "thinking"], "qwen3-vl:8b": ["completion", "vision", "tools"]}
        with IsolatedSettings(), FakeOllama(models=("unison:latest", "qwen3-vl:8b"), capabilities=caps) as fake:
            self.assertEqual(self.pick(fake, "unison:latest"), ("qwen3-vl:8b", ""))

    def test_a_brain_that_can_see_is_used_directly(self):
        caps = {"unison:latest": ["completion", "vision", "tools"]}
        with IsolatedSettings(), FakeOllama(models=("unison:latest",), capabilities=caps) as fake:
            self.assertEqual(self.pick(fake, "unison:latest")[0], "unison:latest")

    def test_clear_message_when_no_vision_model(self):
        caps = {"unison:latest": ["completion"]}
        with IsolatedSettings(), FakeOllama(models=("unison:latest",), capabilities=caps) as fake:
            model, why = self.pick(fake, "unison:latest")
        self.assertIsNone(model)
        self.assertIn("ollama pull qwen3-vl:8b", why)

    def test_other_models_are_unloaded_first(self):
        with IsolatedSettings(), FakeOllama(models=("unison:latest", "qwen3-vl:8b")) as fake:
            asyncio.run(service.free_vram_for(OllamaBackend(fake.url), "qwen3-vl:8b"))
            unloads = [r["body"]["model"] for r in fake.requests if r["path"] == "/api/generate"]
        self.assertEqual(unloads, ["unison:latest"])


if __name__ == "__main__":
    unittest.main()
