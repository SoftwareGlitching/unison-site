@echo off
rem Fixes slow replies (keeps the brain loaded) and measures UNISON's speed. Results: logs\speed.log
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\speed_fix.ps1"
