"""
Tool registry, permission policy and audit log.

Permission modes per tool:  auto (runs immediately) | ask (user approves each call) | deny.
Defaults: reading is auto, changing files and opening things is ask, terminal commands are
classified per command (safe → auto, risky → ask, dangerous → always blocked), MCP tools are ask.
Your overrides live in config/unison.json → tools.permissions.
"""
from __future__ import annotations

import asyncio
import inspect
import json
import time
from typing import Optional

from ..core.config import LOG_DIR, settings
from .base import Tool, ToolError, ToolResult
from . import filesystem, terminal

MODES = ("auto", "ask", "deny")
MAX_RESULT_TO_MODEL = 14_000


def audit(event: dict) -> None:
    event = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), **event}
    with open(LOG_DIR / "audit.log", "a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False, default=str) + "\n")


def _short(args: dict) -> dict:
    out = {}
    for k, v in (args or {}).items():
        if isinstance(v, str) and len(v) > 300:
            out[k] = v[:300] + f"... ({len(v)} chars)"
        else:
            out[k] = v
    return out


class ToolRegistry:
    def __init__(self) -> None:
        self.tools: dict[str, Tool] = {}
        for t in filesystem.TOOLS + terminal.TOOLS:
            self.register(t)

    def register(self, tool: Tool) -> None:
        self.tools[tool.name] = tool

    def unregister_source(self, source: str) -> None:
        for name in [n for n, t in self.tools.items() if t.source == source]:
            del self.tools[name]

    def get(self, name: str) -> Optional[Tool]:
        return self.tools.get(name)

    def enabled(self) -> list[Tool]:
        return [t for t in self.tools.values() if self.mode_setting(t) != "deny"]

    def schemas(self) -> list[dict]:
        return [t.schema() for t in self.enabled()]

    # ---------------- permissions ----------------
    def mode_setting(self, tool: Tool) -> str:
        overrides = settings.get("tools", "permissions") or {}
        m = overrides.get(tool.name)
        return m if m in MODES else tool.default_mode

    def set_mode(self, name: str, mode: str) -> None:
        if name not in self.tools:
            raise ToolError(f"Unknown tool {name}")
        if mode not in MODES + ("default",):
            raise ToolError(f"Mode must be one of {MODES}")
        overrides = dict(settings.get("tools", "permissions") or {})
        if mode == "default":
            overrides.pop(name, None)
        else:
            overrides[name] = mode
        settings.set("tools", "permissions", overrides)

    def decide(self, tool: Tool, args: dict) -> tuple[str, str]:
        """Returns (auto|ask|deny, reason)."""
        mode = self.mode_setting(tool)
        if tool.name == "run_command":
            verdict, why = terminal.classify(args.get("command") or "")
            if verdict == "blocked":
                return "deny", why
            if mode == "deny":
                return "deny", "terminal is turned off in Settings"
            if mode == "auto":
                return "auto", "you allowed all non-dangerous commands"
            return ("auto", why) if verdict == "safe" else ("ask", why)
        if mode == "classify":
            mode = "ask"
        reasons = {"auto": "allowed automatically", "ask": "needs your approval", "deny": "turned off in Settings"}
        return mode, reasons[mode]

    def preview(self, tool: Tool, args: dict) -> dict:
        if not tool.preview:
            return {"kind": "action", "summary": f"{tool.name}({json.dumps(_short(args), ensure_ascii=False)})"}
        try:
            return tool.preview(args)
        except ToolError as e:
            return {"kind": "error", "summary": str(e)}

    # ---------------- execution ----------------
    async def execute(self, name: str, args: dict) -> ToolResult:
        tool = self.get(name)
        if not tool:
            return ToolResult(False, f"Unknown tool '{name}'. Available: {', '.join(self.tools)}")
        started = time.time()
        try:
            if inspect.iscoroutinefunction(tool.handler):
                result = await tool.handler(args)
            else:
                result = await asyncio.to_thread(tool.handler, args)
        except ToolError as e:
            result = ToolResult(False, f"Error: {e}")
        except Exception as e:  # noqa: BLE001 - surface any failure to the model
            result = ToolResult(False, f"Error: {type(e).__name__}: {e}")
        if len(result.output) > MAX_RESULT_TO_MODEL:
            half = MAX_RESULT_TO_MODEL // 2
            result.output = (result.output[:half] + "\n... (output shortened) ...\n" + result.output[-half:])
        audit({"tool": name, "args": _short(args), "ok": result.ok, "ms": round((time.time() - started) * 1000)})
        return result

    def describe_for_prompt(self) -> str:
        lines = []
        for t in self.enabled():
            props = t.parameters.get("properties", {})
            req = set(t.parameters.get("required", []))
            params = ", ".join(f"{k}{'' if k in req else '?'}: {v.get('type', 'string')}" for k, v in props.items())
            lines.append(f"- {t.name}({params}): {t.description}")
        return "\n".join(lines)


registry = ToolRegistry()
