@echo off
rem UNISON first-run setup: inspects your PC, installs what's missing, downloads the model, tests everything.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\setup.ps1" %*
