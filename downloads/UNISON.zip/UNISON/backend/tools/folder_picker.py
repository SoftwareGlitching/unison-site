"""Opens the normal Windows "choose a folder" window on this PC and returns what the user picked."""
from __future__ import annotations

import subprocess
import sys
from typing import Optional

PICK_TIMEOUT = 600   # the user has 10 minutes to choose

# Modern Explorer-style picker via tkinter (python.org builds include it), shown on top of other windows.
_TK = r"""
import sys, tkinter
from tkinter import filedialog
root = tkinter.Tk()
root.withdraw()
root.attributes("-topmost", True)
root.update()
start = sys.argv[1] if len(sys.argv) > 1 else ""
path = filedialog.askdirectory(parent=root, title="Choose a folder for UNISON to work in", initialdir=start or None, mustexist=True)
root.destroy()
print(path or "")
"""

# Fallback: the classic Windows folder dialog through PowerShell.
_PS = r"""
Add-Type -AssemblyName System.Windows.Forms
$d = New-Object System.Windows.Forms.FolderBrowserDialog
$d.Description = 'Choose a folder for UNISON to work in'
$d.ShowNewFolderButton = $true
$owner = New-Object System.Windows.Forms.Form -Property @{TopMost = $true}
if ($d.ShowDialog($owner) -eq [System.Windows.Forms.DialogResult]::OK) { $d.SelectedPath }
"""


def _run(args: list[str]) -> Optional[str]:
    flags = 0x08000000 if sys.platform == "win32" else 0   # no console window
    r = subprocess.run(args, capture_output=True, text=True, timeout=PICK_TIMEOUT, creationflags=flags)
    if r.returncode != 0:
        return None
    return (r.stdout or "").strip().splitlines()[-1].strip() if (r.stdout or "").strip() else ""


def pick_folder(start: str = "") -> Optional[str]:
    """The chosen folder, '' if the user cancelled, or None if no dialog could be shown."""
    if sys.platform != "win32":
        return None
    base = getattr(sys, "_base_executable", "") or sys.executable
    for args in ([base, "-c", _TK, start],
                 ["powershell.exe", "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-Command", _PS]):
        try:
            out = _run(args)
        except (OSError, subprocess.TimeoutExpired):
            continue
        if out is not None:
            return out.replace("/", "\\")
    return None
