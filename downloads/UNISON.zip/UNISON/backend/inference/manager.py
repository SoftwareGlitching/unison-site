"""
Model manager: owns the inference backend, the active model, sampling defaults and live
performance numbers (measured from real generations, never estimated).
"""
from __future__ import annotations

import time
from collections import deque
from typing import AsyncIterator, Optional

from ..core.config import settings
from .base import ChatMessage, GenerationOptions, GenerationStats, InferenceError, StreamEvent
from .ollama_backend import OllamaBackend


# How hard UNISON works your graphics card. Higher effort = faster replies but more GPU memory and power.
EFFORTS = {
    "eco": {"label": "Eco", "num_gpu": 28, "num_ctx": 4096, "keep_alive": "15m",
            "about": "About half the brain on the GPU, the rest on the processor. Leaves the GPU free for games "
                     "and other apps; replies are slower."},
    "balanced": {"label": "Balanced", "num_gpu": None, "num_ctx": 8192, "keep_alive": "1h",
                 "about": "The whole brain on the GPU: fast replies. Unloads after an hour of no use."},
    "max": {"label": "Max", "num_gpu": None, "num_ctx": 16384, "keep_alive": "4h",
            "about": "Fastest, with a longer memory for big code files. Uses the most GPU memory and stays loaded."},
}


def effort() -> str:
    e = settings.get("inference", "effort") or "balanced"
    return e if e in EFFORTS else "balanced"


def keep_alive() -> str:
    """How long the brain stays in VRAM after the last message (from the effort setting)."""
    return EFFORTS[effort()]["keep_alive"]


class ModelManager:
    def __init__(self, backend=None):
        self.backend = backend or OllamaBackend(
            settings.get("inference", "ollama_url", "http://127.0.0.1:11434"),
            float(settings.get("inference", "request_timeout_seconds", 600)))
        self.active_generations = 0
        self.last_stats: Optional[GenerationStats] = None
        self.brain: dict = {"model": None, "state": "idle", "since": 0.0, "error": ""}
        self.history: deque[dict] = deque(maxlen=100)
        self.started_at = time.time()
        self._no_think: dict[str, bool] = {}

    # ---------- model selection ----------
    @property
    def active_model(self) -> str:
        m = settings.get("inference", "active_model") or ""
        if not m:
            m = settings.models_config().get("active_model", "")
        return m

    async def set_active_model(self, name: str) -> None:
        installed = {m.name for m in await self.backend.list_models()}
        if name not in installed:
            raise InferenceError(f"Model '{name}' is not installed. Download it first.", 404, "model_not_found")
        settings.set("inference", "active_model", name)
        self.warm_up_soon(name)

    async def warm_up(self, name: Optional[str] = None) -> bool:
        """Load the brain into VRAM now (at startup / after switching), so 'hi' gets an instant answer."""
        model = name or self.active_model
        if not model or not hasattr(self.backend, "preload"):
            return False
        self.brain = {"model": model, "state": "loading", "since": time.time(), "error": ""}
        try:
            if hasattr(self.backend, "ensure_running") and not await self.backend.ensure_running():
                self.brain.update(state="error", since=time.time(), error="Ollama isn't running and couldn't be started.")
                return False
            ok = await self.backend.preload(model, keep_alive(), self.default_options())
            self.brain.update(state="ready" if ok else "error", since=time.time(), error="" if ok else "The brain didn't load.")
            return ok
        except Exception as e:  # noqa: BLE001
            self.brain.update(state="error", since=time.time(), error=str(e))
            return False

    def warm_up_soon(self, name: Optional[str] = None) -> None:
        import asyncio
        try:
            from ..computer.service import current as screen_task
            if screen_task() is not None:
                return   # the screen model has the GPU; the brain comes back when the task ends
        except Exception:  # noqa: BLE001
            pass
        if self.brain.get("state") == "loading" and self.brain.get("model") == (name or self.active_model):
            return   # already on it
        try:
            asyncio.get_running_loop().create_task(self.warm_up(name))
        except RuntimeError:
            pass

    async def brain_status(self, may_load: bool = True) -> dict:
        """Is the brain in VRAM and ready to answer? Starts loading it if it isn't - unless may_load is False
        (a screen task is using the GPU for the vision model: loading the brain would evict it mid-task)."""
        model = self.active_model
        if not model:
            return {"model": None, "state": "none", "ready": True, "seconds": 0, "error": ""}
        loaded = False
        if hasattr(self.backend, "loaded_models"):
            names = {m.get("name") for m in await self.backend.loaded_models()}
            loaded = model in names or f"{model}:latest" in names or any(n and n.split(":")[0] == model for n in names)
        if loaded:
            if self.brain.get("state") != "loading":
                self.brain = {"model": model, "state": "ready", "since": time.time(), "error": ""}
            return {"model": model, "state": "ready", "ready": True, "seconds": 0, "error": ""}
        if not may_load:
            return {"model": model, "state": "paused", "ready": True, "seconds": 0, "error": ""}
        st = self.brain
        if st.get("state") == "error" and st.get("model") == model and time.time() - st.get("since", 0) < 20:
            return {"model": model, "state": "error", "ready": False, "seconds": 0, "error": st.get("error", "")}
        if self.brain.get("state") != "loading" or self.brain.get("model") != model:
            self.warm_up_soon(model)
            self.brain = {"model": model, "state": "loading", "since": time.time(), "error": ""}
        st = self.brain
        return {"model": model, "state": st["state"], "ready": False,
                "seconds": round(time.time() - st.get("since", time.time())), "error": st.get("error", "")}

    async def resolve_model(self, requested: Optional[str]) -> str:
        """Pick the model for a request: explicit choice, else the active model, else any installed one."""
        if requested and requested not in ("unison", "default"):
            return requested
        if self.active_model:
            return self.active_model
        models = await self.backend.list_models()
        if not models:
            raise InferenceError("No models are installed. Run Setup.bat or download one from the model menu.",
                                 404, "no_models")
        return models[0].name

    # ---------- generation ----------
    def default_options(self, **overrides) -> GenerationOptions:
        g = settings.data.get("inference", {})
        opts = GenerationOptions(
            temperature=g.get("temperature"), top_p=g.get("top_p"), top_k=g.get("top_k"),
            repeat_penalty=g.get("repeat_penalty"), num_ctx=g.get("num_ctx"))
        for k, v in overrides.items():
            if v is not None and hasattr(opts, k):
                setattr(opts, k, v)
        # The effort setting decides how much of the GPU the brain gets: context size (its memory) and how many
        # layers sit on the GPU. A context bigger than the profile allows would spill out of VRAM and crawl.
        prof = EFFORTS[effort()]
        cap = int(prof["num_ctx"])
        opts.num_ctx = min(int(opts.num_ctx or cap), cap)
        if opts.num_gpu is None:
            opts.num_gpu = prof["num_gpu"]
        return opts

    def system_prompt(self, model: str) -> str:
        tpl = settings.get("assistant", "system_prompt", "") or ""
        return tpl.replace("{model}", model)

    async def stream(self, model: str, messages: list[ChatMessage],
                     options: GenerationOptions, tools: Optional[list[dict]] = None) -> AsyncIterator[StreamEvent]:
        self.active_generations += 1
        started = time.time()
        # Thinking models (Qwen3...) reason silently before answering unless told not to. For chat that
        # only adds delay, so it's off by default (inference.think). Models without the switch reject it
        # once; we remember that and stop sending it.
        want = settings.get("inference", "think", False)
        think = None if (want is None or self._no_think.get(model)) else bool(want)
        try:
            try:
                async for ev in self._stream_once(model, messages, options, tools, think, started):
                    yield ev
            except InferenceError as e:
                if think is None or e.code != "think_unsupported":
                    raise
                self._no_think[model] = True
                async for ev in self._stream_once(model, messages, options, tools, None, started):
                    yield ev
        finally:
            self.active_generations -= 1

    async def _stream_once(self, model, messages, options, tools, think, started) -> AsyncIterator[StreamEvent]:
        async for ev in self.backend.chat_stream(model, messages, options, keep_alive(),
                                                 tools=tools, think=think):
            if ev.type == "done" and ev.stats:
                self.last_stats = ev.stats
                self.history.append({"at": time.time(), "wall_ms": round((time.time() - started) * 1000),
                                     **ev.stats.to_dict()})
            yield ev

    def status(self) -> dict:
        tps = [h["tokens_per_second"] for h in self.history if h.get("tokens_per_second")]
        return {
            "active_model": self.active_model,
            "engine": getattr(self.backend, "name", "unknown"),
            "state": "generating" if self.active_generations else "idle",
            "active_generations": self.active_generations,
            "last": self.last_stats.to_dict() if self.last_stats else None,
            "avg_tokens_per_second": round(sum(tps) / len(tps), 2) if tps else None,
            "generations_since_start": len(self.history),
        }


manager = ModelManager()
