"""Tool definitions shared by built-in tools and tools that come from MCP servers."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Optional, Union


class ToolError(Exception):
    """A tool could not do what was asked. The message is shown to the model and the user."""


@dataclass
class ToolResult:
    ok: bool
    output: str                         # text returned to the model
    data: dict = field(default_factory=dict)   # extra details for the UI (diff, exit code, ...)


Handler = Callable[[dict], Union[ToolResult, Awaitable[ToolResult]]]
Preview = Callable[[dict], dict]


@dataclass
class Tool:
    name: str
    description: str
    parameters: dict                    # JSON Schema for the arguments
    risk: str                           # read | write | exec | launch | external
    handler: Handler
    preview: Optional[Preview] = None   # what the approval card shows (diff, command, ...)
    source: str = "builtin"             # builtin | mcp:<server>
    default_mode: str = "ask"           # auto | ask | deny | classify

    def schema(self) -> dict:
        return {"type": "function",
                "function": {"name": self.name, "description": self.description, "parameters": self.parameters}}

    def summary(self) -> dict[str, Any]:
        return {"name": self.name, "description": self.description, "risk": self.risk,
                "source": self.source, "default_mode": self.default_mode, "parameters": self.parameters}


def obj(properties: dict, required: list[str]) -> dict:
    return {"type": "object", "properties": properties, "required": required}


def s(desc: str) -> dict:
    return {"type": "string", "description": desc}


def i(desc: str) -> dict:
    return {"type": "integer", "description": desc}


def b(desc: str) -> dict:
    return {"type": "boolean", "description": desc}
