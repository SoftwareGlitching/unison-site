# One-click repair: applies every fix, cleans up extra models, rebuilds UNISON, checks it and reopens it.
# Chats, settings and your license are kept. Results are saved to logs\fix-unison.log.
param([switch]$Yes)
. (Join-Path $PSScriptRoot "common.ps1")
Set-Location $Root
New-Item -ItemType Directory -Force -Path (Join-Path $Root "logs") | Out-Null
try { Start-Transcript -Path (Join-Path $Root "logs\fix-unison.log") | Out-Null } catch { }
Write-Host ""
Write-Host "  U N I S O N   fix-up" -ForegroundColor Cyan

# ------------------------------------------------------------------ 1. close everything
Write-Step "1/7" "Closing UNISON and Ollama"
Get-Process -Name "UNISON" -ErrorAction SilentlyContinue | ForEach-Object { & taskkill /PID $_.Id /T /F 2>$null | Out-Null }
Get-Process -Name "ollama app", "ollama" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
Write-Ok "Closed"

# ------------------------------------------------------------------ 2. Ollama: hidden, gentle, survives closed windows
Write-Step "2/7" "Ollama settings"
$want = [ordered]@{ OLLAMA_FLASH_ATTENTION = "1"; OLLAMA_KV_CACHE_TYPE = "q8_0"; OLLAMA_MAX_LOADED_MODELS = "2"; OLLAMA_NUM_PARALLEL = "1" }
foreach ($k in $want.Keys) { [Environment]::SetEnvironmentVariable($k, $want[$k], "User"); Set-Item -Path "Env:$k" -Value $want[$k] }
[Environment]::SetEnvironmentVariable("OLLAMA_KEEP_ALIVE", $null, "User")     # UNISON's effort setting decides this now
$startup = Join-Path ([Environment]::GetFolderPath("Startup")) "Ollama.lnk"
if (Test-Path $startup) {
    Write-Host "   Ollama's own app opens a big window at sign-in, and closing that window shuts Ollama down."
    Write-Host "   UNISON starts Ollama by itself, hidden, so that app isn't needed."
    if ($Yes -or (Ask-YesNo "Stop the Ollama app window from opening when you sign in?" $true)) {
        $keep = Join-Path $Root "data\backups"
        New-Item -ItemType Directory -Force -Path $keep | Out-Null
        Move-Item -Force $startup (Join-Path $keep "Ollama-startup.lnk")
        Write-Ok "Done (the shortcut is kept in data\backups if you ever want it back)"
    }
}
if (-not (Start-OllamaIfNeeded)) { Write-Bad "Ollama didn't start. Reinstall it from ollama.com, then run this again."; Read-Host "Press Enter to close"; exit 1 }
Write-Ok "Ollama running in the background (no window)"

# ------------------------------------------------------------------ 3. models: just the UNISON brain
Write-Step "3/7" "Models"
$ollama = Find-OllamaExe
$names = @(& $ollama list 2>$null | Select-Object -Skip 1 | ForEach-Object { ($_ -split "\s+")[0] } | Where-Object { $_ })
$base = (Get-Content (Join-Path $Root "config\unison.Modelfile") -ErrorAction SilentlyContinue | Where-Object { $_ -match "^FROM\s+(\S+)" } | ForEach-Object { $Matches[1] } | Select-Object -First 1)
$keep = @("unison", "unison:latest", "nomic-embed-text", "nomic-embed-text:latest")
if ($base) { $keep += $base }
$extra = $names | Where-Object { $keep -notcontains $_ }
if (-not ($names | Where-Object { $_ -like "unison*" })) {
    Write-Warn2 "UNISON's brain isn't installed - run Upgrade-Brain.bat after this."
} elseif ($extra) {
    Write-Host "   UNISON only needs its brain now (it does chat, coding, agent work AND screen control)."
    Write-Host "   Extra models taking up space: $($extra -join ', ')"
    if ($Yes -or (Ask-YesNo "Delete these extra models? (they can be downloaded again any time)" $true)) {
        foreach ($m in $extra) { & $ollama rm $m | Out-Null; Write-Ok "Deleted $m" }
    }
} else { Write-Ok "Only the UNISON brain is installed" }

# ------------------------------------------------------------------ 4. settings
Write-Step "4/7" "Settings"
& $VenvPy -c @"
from backend.core.config import settings
settings.set('inference', 'active_model', 'unison')
if not settings.get('inference', 'effort'):
    settings.set('inference', 'effort', 'balanced')
settings.set('computer', 'use_brain', True)
print('   brain: unison | effort:', settings.get('inference', 'effort'), '| screen control: the brain')
"@
Write-Ok "Settings updated"

# ------------------------------------------------------------------ 5. rebuild the app
Write-Step "5/7" "Rebuilding the app"
Push-Location (Join-Path $Root "frontend")
& npm.cmd install --no-fund --no-audit --loglevel=error
& npm.cmd run build
$webOk = ($LASTEXITCODE -eq 0)
Pop-Location
if ($webOk) { Write-Ok "Interface rebuilt" } else { Write-Bad "The interface rebuild failed (see above)." }
& (Join-Path $Root "desktop\build.ps1")
if (Test-Path (Join-Path $Root "UNISON.exe")) { Write-Ok "Launcher ready" }

# ------------------------------------------------------------------ 6. check it all works
Write-Step "6/7" "Checking"
& $VenvPy (Join-Path $PSScriptRoot "selfcheck.py")
$checkOk = ($LASTEXITCODE -eq 0)

# ------------------------------------------------------------------ 7. open
Write-Step "7/7" "Opening UNISON"
$app = Join-Path $Root "UNISON.exe"
if (Test-Path $app) { Start-Process -FilePath $app -WorkingDirectory $Root } else { Start-Process -FilePath (Join-Path $Root "Start-UNISON.bat") -WorkingDirectory $Root }
Write-Host ""
if ($checkOk) { Write-Host "  All fixed. UNISON is opening - it waits on 'Loading the brain' until it's ready." -ForegroundColor Green }
else { Write-Host "  Done, but some checks failed (above). Tell Claude: 'check the fix log'." -ForegroundColor Yellow }
try { Stop-Transcript | Out-Null } catch { }
Write-Host "   (you can close this window - Ollama keeps running)"
if (-not $Yes) { Start-Sleep -Seconds 8 }
