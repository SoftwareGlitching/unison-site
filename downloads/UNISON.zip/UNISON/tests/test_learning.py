"""UNISON learns from 👍/👎 right away (no GPU training), stays within a GPU-safe context, and finds real Python."""
import os
import sys
import tempfile
import unittest
from pathlib import Path

from tests.helpers import IsolatedSettings  # noqa: I001
from backend.database.db import Database
from backend.training import lessons


class LessonTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self.tmp.name) / "t.db")
        lessons.reset_cache()

    def tearDown(self):
        lessons.reset_cache()
        self.tmp.cleanup()

    def chat(self, user, reply):
        cid = self.db.create_conversation("t")["id"]
        self.db.add_message(cid, "user", user)
        return self.db.add_message(cid, "assistant", reply, "m")["id"]

    def test_no_ratings_no_section(self):
        self.assertEqual(lessons.build(self.db), "")

    def test_thumbs_down_note_and_correction_become_lessons(self):
        mid = self.chat("your gay as fucc", "Ouch, that's pretty harsh. I try to be respectful...")
        self.db.set_feedback(mid, -1, correction="Rude. Accurate? Debatable. What do you need?", note="don't lecture me")
        text = lessons.build(self.db)
        self.assertIn("Lessons from the user's ratings", text)
        self.assertIn("don't lecture me", text)
        self.assertIn("Rude. Accurate? Debatable.", text)
        self.assertIn("your gay as fucc", text)

    def test_thumbs_up_becomes_style_example(self):
        mid = self.chat("hey", "Not much - living rent-free in your PC 😎")
        self.db.set_feedback(mid, 1)
        self.assertIn("rent-free", lessons.build(self.db))

    def test_bare_thumbs_down_is_ignored(self):
        mid = self.chat("x", "y")
        self.db.set_feedback(mid, -1)
        self.assertEqual(lessons.build(self.db), "")

    def test_lessons_reach_the_system_prompt(self):
        from backend.agents import prompts
        mid = self.chat("hi", "hello")
        self.db.set_feedback(mid, -1, note="be funnier")
        orig = lessons.section
        lessons.section = lambda db=None: lessons.build(self.db)
        try:
            with IsolatedSettings():
                self.assertIn("be funnier", prompts.base_prompt("m"))
                self.assertIn("be funnier", prompts.agent_prompt("m"))
        finally:
            lessons.section = orig


class GpuSafetyTests(unittest.TestCase):
    def test_effort_sets_context_and_gpu_layers(self):
        from backend.core.config import settings
        from backend.inference.manager import ModelManager, keep_alive
        with IsolatedSettings():
            m = ModelManager.__new__(ModelManager)
            settings.set("inference", "num_ctx", 16384)   # what crashed a 12 GB card
            self.assertEqual(m.default_options().num_ctx, 16384)         # balanced (default)
            self.assertIsNone(m.default_options().num_gpu)
            self.assertEqual(m.default_options(num_ctx=32768).num_ctx, 16384)
            self.assertEqual(m.default_options(num_ctx=4096).num_ctx, 4096)
            settings.set("inference", "effort", "eco")
            from unittest import mock
            with mock.patch("backend.inference.manager.free_ram_gb", return_value=12.0):
                o = m.default_options()
            self.assertEqual((o.num_ctx, o.num_gpu), (8192, 36))
            self.assertEqual(keep_alive(), "15m")
            settings.set("inference", "effort", "max")
            self.assertEqual(m.default_options().num_ctx, 24576)
            self.assertEqual(keep_alive(), "4h")
            settings.set("inference", "effort", "nonsense")
            self.assertEqual(m.default_options().num_ctx, 16384)


class RealPythonTests(unittest.TestCase):
    def test_real_python_goes_first_on_windows(self):
        from backend.tools import terminal
        orig = sys.platform
        try:
            terminal.sys.platform = "win32"
            env = terminal._command_env()
        finally:
            terminal.sys.platform = orig
        base = os.path.dirname(getattr(sys, "_base_executable", "") or sys.executable)
        self.assertTrue(env["PATH"].startswith(base))
        self.assertEqual(env["PYTHONUTF8"], "1")


if __name__ == "__main__":
    unittest.main()


class KeepAliveTests(unittest.TestCase):
    def test_keep_alive_follows_effort(self):
        from backend.core.config import settings
        from backend.inference.manager import keep_alive
        with IsolatedSettings():
            self.assertEqual(keep_alive(), "1h")
            settings.set("inference", "effort", "max")
            self.assertEqual(keep_alive(), "4h")

    def test_ensure_running_when_engine_is_up(self):
        import asyncio
        from backend.inference.ollama_backend import OllamaBackend
        from tests.fake_ollama import FakeOllama
        with FakeOllama() as fake:
            self.assertTrue(asyncio.run(OllamaBackend(fake.url).ensure_running()))


class BrainStatusTests(unittest.TestCase):
    def test_reports_loading_then_ready(self):
        import asyncio
        from backend.core.config import settings
        from backend.inference.manager import ModelManager
        from backend.inference.ollama_backend import OllamaBackend
        from tests.fake_ollama import FakeOllama
        with IsolatedSettings(), FakeOllama(models=("unison:latest", "other:1b")) as fake:
            settings.set("inference", "active_model", "unison:latest")
            mgr = ModelManager(OllamaBackend(fake.url))

            async def go():
                first = await mgr.brain_status()          # fake /api/ps lists unison:latest -> ready
                return first
            self.assertTrue(asyncio.run(go())["ready"])
            settings.set("inference", "active_model", "other:1b")

            async def go2():
                st = await mgr.brain_status()             # not loaded -> starts loading
                await asyncio.sleep(0.3)
                return st, mgr.brain
            st, brain = asyncio.run(go2())
            self.assertFalse(st["ready"])
            self.assertEqual(st["state"], "loading")
            preloads = [r for r in fake.requests if r["path"] == "/api/generate" and r["body"].get("model") == "other:1b"]
            self.assertTrue(preloads)
