"""UNISON HTTP API (v1)."""
from __future__ import annotations

import json
import time
import uuid
from typing import AsyncIterator

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import StreamingResponse

from .. import __version__
from ..core.chat_service import ChatService, fit_context
from ..core.config import CONFIG_DIR, ROOT, settings
from ..agents.approvals import broker
from ..core.system_metrics import system_metrics
from ..database.db import get_db
from ..inference.base import ChatMessage, InferenceError, ToolCall
from ..inference.manager import manager
from ..security.auth import authenticate, create_api_key, local_only, rate_limited
from .schemas import (ChatRequest, CreateKeyRequest, InferenceSettings, OAChatRequest, PullRequest,
                      RenameRequest, SetModelRequest)

router = APIRouter(prefix="/v1")

SSE_HEADERS = {"Cache-Control": "no-cache", "X-Accel-Buffering": "no"}


def sse(obj) -> str:
    return f"data: {json.dumps(obj, ensure_ascii=False)}\n\n"


async def _primed(agen: AsyncIterator):
    """Pull the first item before the response starts, so setup errors become real HTTP errors."""
    try:
        first = await agen.__anext__()
    except StopAsyncIteration:
        first = None
    return first, agen


def _err_payload(e: InferenceError) -> dict:
    return {"error": {"code": e.code, "message": str(e)}}


# =====================================================================================
# Health & system
# =====================================================================================
@router.get("/health", tags=["system"])
async def health():
    engine = await manager.backend.health()
    active = manager.active_model
    installed = None
    if engine.get("ok"):
        try:
            installed = active in {m.name for m in await manager.backend.list_models()}
        except InferenceError:
            installed = None
    ok = bool(engine.get("ok")) and bool(installed)
    return {
        "status": "ok" if ok else "degraded",
        "unison_version": __version__,
        "engine": engine,
        "active_model": active or None,
        "active_model_installed": installed,
        "bound_to": f"{settings.get('server', 'host')}:{settings.get('server', 'port')}",
    }


@router.get("/system/metrics", tags=["system"], dependencies=[Depends(authenticate)])
async def metrics():
    return {
        "system": system_metrics(),
        "inference": manager.status(),
        "loaded_models": await manager.backend.loaded_models(),
        "timestamp": time.time(),
    }


@router.get("/system/hardware", tags=["system"], dependencies=[Depends(authenticate)])
async def hardware():
    hw_path = CONFIG_DIR / "hardware.json"
    report = ROOT / "docs" / "HARDWARE_REPORT.md"
    return {
        "hardware": json.loads(hw_path.read_text(encoding="utf-8-sig")) if hw_path.exists() else None,
        "report_markdown": report.read_text(encoding="utf-8") if report.exists() else None,
    }


# =====================================================================================
# Models
# =====================================================================================
@router.get("/models", tags=["models"], dependencies=[Depends(authenticate)])
async def list_models():
    cfg = settings.models_config()
    tier_of = {t["tag"]: name for name, t in (cfg.get("tiers") or {}).items()}
    active = manager.active_model
    models = await manager.backend.list_models()
    return {
        "object": "list",
        "active_model": active,
        "data": [{
            "id": m.name,
            "object": "model",
            "created": 0,
            "owned_by": "local",
            "unison": {
                "foundation_model": m.name,
                "engine": manager.backend.name,
                "family": m.family,
                "parameter_size": m.parameter_size,
                "quantization": m.quantization,
                "size_bytes": m.size_bytes,
                "tier": tier_of.get(m.name),
                "active": m.name == active,
                "adapters": [],  # LoRA adapters arrive with the training system (Phase 6)
            },
        } for m in models],
    }


@router.get("/models/recommended", tags=["models"], dependencies=[Depends(authenticate)])
async def recommended_models():
    cfg = settings.models_config()
    try:
        installed = {m.name for m in await manager.backend.list_models()}
    except InferenceError:
        installed = set()
    tiers = []
    for name in ("lightweight", "balanced", "advanced"):
        t = (cfg.get("tiers") or {}).get(name)
        if t:
            tiers.append({**t, "installed": t["tag"] in installed, "default": name == cfg.get("default_tier")})
    return {"tiers": tiers, "warnings": cfg.get("warnings", []), "active_model": manager.active_model}


@router.post("/models/active", tags=["models"], dependencies=[Depends(local_only)])
async def set_active(req: SetModelRequest):
    await manager.set_active_model(req.model)
    return {"active_model": manager.active_model}


@router.post("/models/pull", tags=["models"], dependencies=[Depends(local_only)])
async def pull_model(req: PullRequest):
    from ..computer.service import VISION_MODELS
    allowed = {m["tag"] for m in settings.models_config().get("catalog", [])}
    allowed |= {settings.models_config().get("embedding_model", {}).get("tag"), "nomic-embed-text", *VISION_MODELS}
    if req.model not in allowed:
        raise HTTPException(400, {"code": "not_in_catalog",
                                  "message": "Only catalog models can be downloaded from the app. "
                                             f"Use 'ollama pull {req.model}' for others."})
    first, agen = await _primed(manager.backend.pull(req.model))

    async def gen():
        try:
            if first:
                yield sse(first)
            async for p in agen:
                yield sse(p)
            yield sse({"status": "success", "done": True})
        except InferenceError as e:
            yield sse(_err_payload(e))
    return StreamingResponse(gen(), media_type="text/event-stream", headers=SSE_HEADERS)


@router.delete("/models/{name:path}", tags=["models"], dependencies=[Depends(local_only)])
async def delete_model(name: str):
    if name == manager.active_model:
        raise HTTPException(400, {"code": "model_active", "message": "Switch to another model before deleting this one"})
    await manager.backend.delete(name)
    return {"deleted": name}


@router.get("/settings/inference", tags=["settings"], dependencies=[Depends(authenticate)])
async def get_inference_settings():
    g = settings.data.get("inference", {})
    return {k: g.get(k) for k in ("temperature", "top_p", "top_k", "repeat_penalty", "num_ctx", "keep_alive",
                                  "active_model", "ollama_url")}


@router.patch("/settings/inference", tags=["settings"], dependencies=[Depends(local_only)])
async def patch_inference_settings(body: InferenceSettings):
    for k, v in body.model_dump(exclude_none=True).items():
        settings.set("inference", k, v)
    return await get_inference_settings()


# =====================================================================================
# Chat — UNISON native (stores conversations)
# =====================================================================================
@router.post("/chat", tags=["chat"])
async def chat(req: ChatRequest, request: Request, ident: dict = Depends(rate_limited)):
    service = ChatService(get_db(), manager)
    opts = manager.default_options(**req.options.model_dump(exclude_none=True))
    use_tools = req.tools if req.tools is not None else bool(settings.get("tools", "agent_default", True))
    agen = service.run(conversation_id=req.conversation_id, content=req.message, model=req.model,
                       regenerate=req.regenerate, system=req.system, options=opts, tools=use_tools)
    first, agen = await _primed(agen)

    if not req.stream:
        events = [first] if first else []
        async for ev in agen:
            events.append(ev)
        start = next(e for e in events if e["type"] == "start")
        done = next(e for e in events if e["type"] == "done")
        saved = [e for e in events if e["type"] == "assistant_saved"]
        return {
            "conversation_id": start["conversation_id"],
            "model": start["model"],
            "message_id": done["message_id"],
            "content": saved[-1]["content"] if saved else "",
            "tool_calls": [{k: e[k] for k in ("name", "args", "decision")} for e in events if e["type"] == "tool_call"],
            "sources": next((e["items"] for e in events if e["type"] == "sources"), []),
            "stats": done["stats"],
        }

    async def gen():
        cid = req.conversation_id
        try:
            if first:
                yield sse(first)
            async for ev in agen:
                if ev.get("type") == "start":
                    cid = ev["conversation_id"]
                yield sse(ev)
        except InferenceError as e:
            from ..core.chat_service import log_error
            log_error(req.model or "", e)
            yield sse({"type": "error", **_err_payload(e)["error"]})
        finally:
            broker.cancel_for(cid)
            await agen.aclose()
    return StreamingResponse(gen(), media_type="text/event-stream", headers=SSE_HEADERS)


# =====================================================================================
# Chat — OpenAI-compatible (stateless)
# =====================================================================================
FINISH = {"stop": "stop", "length": "length", "load": "stop", "unload": "stop"}


@router.post("/chat/completions", tags=["openai-compatible"])
async def chat_completions(req: OAChatRequest, request: Request, ident: dict = Depends(rate_limited)):
    if getattr(request.state, "guest", None):
        # Website guests: always the owner's active model, short replies, no client-side tool calling.
        req.model = None
        req.tools = None
        cap = int(settings.get("remote", "guest_max_tokens", 1024))
        req.max_tokens = min(req.max_tokens or cap, cap)
        req.max_completion_tokens = min(req.max_completion_tokens or cap, cap)
        sys_m = [m for m in req.messages if m.role in ("system", "developer")][:2]
        req.messages = sys_m + [m for m in req.messages if m.role not in ("system", "developer")][-24:]
    # Client-defined tools follow OpenAI semantics: the model asks, the CLIENT runs the tool and sends the
    # result back. (UNISON's own tools run server-side through POST /v1/chat with tools=true.)
    client_tools = [t for t in (req.tools or []) if t.get("type", "function") == "function"] or None
    model = await manager.resolve_model(req.model)
    stop = [req.stop] if isinstance(req.stop, str) else req.stop
    opts = manager.default_options(temperature=req.temperature, top_p=req.top_p,
                                   max_tokens=req.max_completion_tokens or req.max_tokens, seed=req.seed, stop=stop)
    msgs: list[ChatMessage] = []
    call_names: dict[str, str] = {}
    for m in req.messages:
        if m.role == "assistant" and m.tool_calls:
            calls = []
            for tc in m.tool_calls:
                args = tc.function.arguments
                if isinstance(args, str):
                    try:
                        args = json.loads(args or "{}")
                    except json.JSONDecodeError:
                        args = {}
                calls.append(ToolCall(tc.function.name, args or {}, tc.id or ""))
                if tc.id:
                    call_names[tc.id] = tc.function.name
            msgs.append(ChatMessage("assistant", m.text(), tool_calls=calls))
        elif m.role == "tool":
            msgs.append(ChatMessage("tool", m.text(), tool_name=call_names.get(m.tool_call_id or "", m.name)))
        else:
            msgs.append(ChatMessage("system" if m.role == "developer" else m.role, m.text()))
    sys_msgs = [m for m in msgs if m.role == "system"]
    rest = [m for m in msgs if m.role != "system"]
    system = ChatMessage("system", "\n\n".join(m.content for m in sys_msgs)) if sys_msgs \
        else ChatMessage("system", manager.system_prompt(model))
    messages = fit_context(system, rest, opts.num_ctx or 8192)

    cid = "chatcmpl-" + uuid.uuid4().hex[:24]
    created = int(time.time())
    first, agen = await _primed(manager.stream(model, messages, opts, tools=client_tools))

    def oa_calls(calls) -> list[dict]:
        return [{"index": n, "id": c.id or f"call_{uuid.uuid4().hex[:12]}", "type": "function",
                 "function": {"name": c.name, "arguments": json.dumps(c.arguments)}} for n, c in enumerate(calls)]

    def chunk(delta: dict, finish=None, usage=None) -> dict:
        c = {"id": cid, "object": "chat.completion.chunk", "created": created, "model": model,
             "choices": [{"index": 0, "delta": delta, "finish_reason": finish}]}
        if usage is not None:
            c["usage"] = usage
        return c

    def usage_of(stats) -> dict:
        if not stats:
            return {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
        return {"prompt_tokens": stats.prompt_tokens, "completion_tokens": stats.completion_tokens,
                "total_tokens": stats.prompt_tokens + stats.completion_tokens}

    if not req.stream:
        text, stats, calls = [], None, []
        events = ([first] if first else [])
        async for ev in agen:
            events.append(ev)
        for ev in events:
            if ev.type == "token":
                text.append(ev.content)
            elif ev.type == "tool_calls" and ev.tool_calls:
                calls.extend(ev.tool_calls)
            elif ev.type == "done":
                stats = ev.stats
        message = {"role": "assistant", "content": "".join(text) or (None if calls else "")}
        if calls:
            message["tool_calls"] = oa_calls(calls)
        return {
            "id": cid, "object": "chat.completion", "created": created, "model": model,
            "choices": [{"index": 0, "message": message,
                         "finish_reason": "tool_calls" if calls else FINISH.get(stats.done_reason if stats else "stop", "stop")}],
            "usage": usage_of(stats),
            "unison": {"engine": manager.backend.name, "stats": stats.to_dict() if stats else None},
        }

    include_usage = bool(req.stream_options and req.stream_options.include_usage)

    async def gen():
        stats = None
        calls = []
        try:
            yield sse(chunk({"role": "assistant", "content": ""}))
            pending = [first] if first else []
            async def events():
                for p in pending:
                    yield p
                async for e in agen:
                    yield e
            async for ev in events():
                if ev.type == "token":
                    yield sse(chunk({"content": ev.content}))
                elif ev.type == "tool_calls" and ev.tool_calls:
                    calls.extend(ev.tool_calls)
                elif ev.type == "done":
                    stats = ev.stats
            if calls:
                yield sse(chunk({"tool_calls": oa_calls(calls)}))
            yield sse(chunk({}, "tool_calls" if calls else FINISH.get(stats.done_reason if stats else "stop", "stop")))
            if include_usage:
                u = {"id": cid, "object": "chat.completion.chunk", "created": created, "model": model,
                     "choices": [], "usage": usage_of(stats)}
                yield sse(u)
        except InferenceError as e:
            yield sse(_err_payload(e))
        finally:
            await agen.aclose()
        yield "data: [DONE]\n\n"
    return StreamingResponse(gen(), media_type="text/event-stream", headers=SSE_HEADERS)


# =====================================================================================
# Conversations
# =====================================================================================
@router.get("/conversations", tags=["conversations"], dependencies=[Depends(authenticate)])
async def list_conversations(search: str = ""):
    return {"data": get_db().list_conversations(search.strip())}


@router.get("/conversations/{cid}", tags=["conversations"], dependencies=[Depends(authenticate)])
async def get_conversation(cid: str):
    conv = get_db().get_conversation(cid)
    if not conv:
        raise HTTPException(404, {"code": "not_found", "message": "Conversation not found"})
    return {**conv, "messages": get_db().messages(cid), "feedback": get_db().feedback_for(cid)}


@router.patch("/conversations/{cid}", tags=["conversations"], dependencies=[Depends(authenticate)])
async def rename_conversation(cid: str, body: RenameRequest):
    if not get_db().get_conversation(cid):
        raise HTTPException(404, {"code": "not_found", "message": "Conversation not found"})
    get_db().rename_conversation(cid, body.title)
    return get_db().get_conversation(cid)


@router.delete("/conversations/{cid}", tags=["conversations"], dependencies=[Depends(authenticate)])
async def delete_conversation(cid: str):
    if not get_db().delete_conversation(cid):
        raise HTTPException(404, {"code": "not_found", "message": "Conversation not found"})
    return {"deleted": cid}


# =====================================================================================
# API keys (manageable only from this computer)
# =====================================================================================
@router.get("/keys", tags=["security"], dependencies=[Depends(local_only)])
async def list_keys():
    return {"data": get_db().list_api_keys()}


@router.post("/keys", tags=["security"], dependencies=[Depends(local_only)])
async def new_key(body: CreateKeyRequest):
    key, rec = create_api_key(body.name)
    return {**rec, "key": key, "note": "Store this key now. UNISON keeps only a hash and cannot show it again."}


@router.delete("/keys/{kid}", tags=["security"], dependencies=[Depends(local_only)])
async def revoke_key(kid: str):
    if not get_db().revoke_api_key(kid):
        raise HTTPException(404, {"code": "not_found", "message": "Key not found"})
    return {"revoked": kid}
