"""Tool calls written as text, including the exact output qwen2.5-coder:7b produced in the user's self-test."""
import unittest

from tests.helpers import ROOT  # noqa: F401

from backend.core.toolparse import extract_tool_calls

KNOWN = {"write_file", "read_file", "list_dir", "run_command", "click", "type", "key", "done"}

REAL_SELFTEST_OUTPUT = '''```json
{
  "name": "write_file",
  "arguments": {
    "path": "unison-selftest/hello.txt",
    "content": "UNISON-OK"
  }
}
```

```json
{
  "name": "read_file",
  "arguments": {
    "path": "unison-selftest/hello.txt"
  }
}
```

After creating the file, it contains:

```
UNISON-OK
```'''


class ToolParseTests(unittest.TestCase):
    def test_real_qwen_output_is_two_calls_and_the_invented_result_is_dropped(self):
        text, calls = extract_tool_calls(REAL_SELFTEST_OUTPUT, KNOWN)
        self.assertEqual([c.name for c in calls], ["write_file", "read_file"])
        self.assertEqual(calls[0].arguments, {"path": "unison-selftest/hello.txt", "content": "UNISON-OK"})
        self.assertEqual(text, "")   # "After creating the file, it contains" never reaches the user

    def test_tagged(self):
        text, calls = extract_tool_calls('Ok.\n<tool_call>{"name": "list_dir", "arguments": {"path": "."}}</tool_call> done!', KNOWN)
        self.assertEqual(text, "Ok.")
        self.assertEqual(calls[0].name, "list_dir")

    def test_unclosed_tag_and_string_arguments(self):
        _, calls = extract_tool_calls('<tool_call>{"name": "read_file", "arguments": "{\\"path\\": \\"a.py\\"}"}', KNOWN)
        self.assertEqual(calls[0].arguments, {"path": "a.py"})

    def test_bare_json_inline(self):
        text, calls = extract_tool_calls('Let me run it: {"name": "run_command", "arguments": {"command": "python a.py"}} and then', KNOWN)
        self.assertEqual(text, "Let me run it:")
        self.assertEqual(calls[0].arguments["command"], "python a.py")

    def test_flat_action_and_function_wrapper(self):
        _, calls = extract_tool_calls('{"action": "click", "x": 500, "y": 300}', KNOWN)
        self.assertEqual((calls[0].name, calls[0].arguments), ("click", {"x": 500, "y": 300}))
        _, calls = extract_tool_calls('{"function": {"name": "key", "arguments": {"keys": "ctrl+s"}}}', KNOWN)
        self.assertEqual(calls[0].arguments, {"keys": "ctrl+s"})

    def test_unknown_names_and_normal_json_are_not_calls(self):
        code = 'Here is a config:\n```json\n{"name": "my-game", "version": "1.0.0"}\n```'
        text, calls = extract_tool_calls(code, KNOWN)
        self.assertEqual(calls, [])
        self.assertEqual(text, code)

    def test_duplicates_collapse(self):
        _, calls = extract_tool_calls('<tool_call>{"name":"done","arguments":{}}</tool_call><tool_call>{"name":"done","arguments":{}}</tool_call>', KNOWN)
        self.assertEqual(len(calls), 1)


if __name__ == "__main__":
    unittest.main()
