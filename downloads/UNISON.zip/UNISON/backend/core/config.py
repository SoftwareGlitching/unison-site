"""
UNISON configuration.

Layers, lowest to highest priority:
  1. config/unison.default.json   (shipped defaults)
  2. config/unison.json           (your settings; written by setup and by the app)
  3. environment variables / .env (UNISON_* — secrets and deployment overrides)
"""
from __future__ import annotations

import copy
import json
import os
import threading
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
CONFIG_DIR = ROOT / "config"
DATA_DIR = ROOT / "data"
LOG_DIR = ROOT / "logs"
FRONTEND_DIST = ROOT / "frontend" / "dist"

DEFAULT_FILE = CONFIG_DIR / "unison.default.json"
USER_FILE = CONFIG_DIR / "unison.json"
MODELS_FILE = CONFIG_DIR / "models.json"

_ENV_MAP = {
    "UNISON_HOST": ("server", "host", str),
    "UNISON_PORT": ("server", "port", int),
    "UNISON_SSL_CERTFILE": ("server", "ssl_certfile", str),
    "UNISON_SSL_KEYFILE": ("server", "ssl_keyfile", str),
    "UNISON_OLLAMA_URL": ("inference", "ollama_url", str),
    "UNISON_MODEL": ("inference", "active_model", str),
    "UNISON_REQUIRE_API_KEY": ("auth", "require_api_key", lambda v: v.strip().lower() in ("1", "true", "yes")),
}

_lock = threading.RLock()


def load_dotenv(path: Path = ROOT / ".env") -> None:
    """Minimal .env reader (KEY=VALUE lines). Existing environment variables win."""
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key.strip(), value)


def _deep_merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in over.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def _read_json(path: Path) -> dict:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8-sig") or "{}")


class Settings:
    def __init__(self) -> None:
        self.reload()

    def reload(self) -> None:
        with _lock:
            load_dotenv()
            data = _deep_merge(_read_json(DEFAULT_FILE), _read_json(USER_FILE))
            for env, (section, key, cast) in _ENV_MAP.items():
                if os.environ.get(env):
                    data.setdefault(section, {})[key] = cast(os.environ[env])
            self.data = data

    def get(self, section: str, key: str, default: Any = None) -> Any:
        return self.data.get(section, {}).get(key, default)

    def set(self, section: str, key: str, value: Any) -> None:
        """Persist a single setting to config/unison.json."""
        with _lock:
            user = _read_json(USER_FILE)
            user.setdefault(section, {})[key] = value
            USER_FILE.parent.mkdir(parents=True, exist_ok=True)
            tmp = USER_FILE.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(user, indent=2), encoding="utf-8")
            os.replace(tmp, USER_FILE)
            self.data.setdefault(section, {})[key] = value

    def models_config(self) -> dict:
        return _read_json(MODELS_FILE)

    @property
    def is_loopback(self) -> bool:
        return self.get("server", "host") in ("127.0.0.1", "localhost", "::1")


settings = Settings()

for d in (DATA_DIR, LOG_DIR):
    d.mkdir(parents=True, exist_ok=True)
