"""Public site build: placeholders, Google files, buy link, version.json, and a clean download zip."""
import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from tests.helpers import ROOT  # noqa: F401

from scripts.configure_site import build, site_url


class SiteTests(unittest.TestCase):
    def test_build_for_perkypop_site_repo(self):
        with tempfile.TemporaryDirectory() as d:
            out = Path(d) / "_site"
            info = build("PerkyPop/unison-site", out, google_verify="abc123",
                         purchase_url="https://perkypop.gumroad.com/l/unison")
            url = "https://perkypop.github.io/unison-site/"
            self.assertEqual(info["url"], url)
            html = (out / "index.html").read_text(encoding="utf-8")
            self.assertNotIn("YOUR_GITHUB_USERNAME", html)
            self.assertNotIn("YOUR_DOWNLOAD_URL", html)
            self.assertIn(f'<link rel="canonical" href="{url}"', html)
            self.assertIn(f'const DOWNLOAD = "{url}downloads/UNISON.zip"', html)
            self.assertIn('const PURCHASE = "https://perkypop.gumroad.com/l/unison"', html)
            self.assertIn('<meta name="google-site-verification" content="abc123" />', html)
            self.assertNotIn("open source", html.lower())
            self.assertIn(f"Sitemap: {url}sitemap.xml", (out / "robots.txt").read_text())
            self.assertIn(f"<loc>{url}</loc>", (out / "sitemap.xml").read_text())
            v = json.loads((out / "version.json").read_text())
            self.assertEqual(v["download"], url + "downloads/UNISON.zip")
            self.assertTrue((out / "og.png").exists())

    def test_without_purchase_url_button_says_soon(self):
        with tempfile.TemporaryDirectory() as d:
            build("PerkyPop/unison-site", Path(d) / "s")
            html = (Path(d) / "s" / "index.html").read_text()
            self.assertIn('const PURCHASE = "YOUR_PURCHASE_URL"', html)   # JS shows "Licenses available soon"
            with self.assertRaises(ValueError):
                build("PerkyPop/unison-site", Path(d) / "t", purchase_url="javascript:alert(1)")

    def test_download_zip_has_no_owner_tools_or_private_files(self):
        with tempfile.TemporaryDirectory() as d:
            info = build("PerkyPop/unison-site", Path(d) / "s", with_zip=True)
            names = zipfile.ZipFile(Path(d) / "s" / "downloads" / "UNISON.zip").namelist()
            self.assertGreater(info["zip_files"], 50)
            self.assertIn("UNISON/Setup.bat", names)
            self.assertIn("UNISON/backend/licensing/license.py", names)
            self.assertIn("UNISON/LICENSE", names)
            for bad in ("UNISON/scripts/license_admin.py", "UNISON/License-Admin.bat", "UNISON/config/unison.json"):
                self.assertNotIn(bad, names)
            self.assertFalse([n for n in names if n.endswith((".db", ".pem", ".log")) or "/node_modules/" in n
                              or "/.venv/" in n or "/site/" in n or "/.git/" in n])

    def test_user_pages_repo_and_bad_input(self):
        self.assertEqual(site_url("PerkyPop/perkypop.github.io"), "https://perkypop.github.io/")
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError):
                build("not a repo", Path(d) / "x")
            build("A/b", Path(d) / "y", google_verify='"><script>x</script>')
            self.assertNotIn("<script>x", (Path(d) / "y" / "index.html").read_text())


if __name__ == "__main__":
    unittest.main()
