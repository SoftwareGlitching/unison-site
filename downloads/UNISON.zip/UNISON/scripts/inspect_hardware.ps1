# UNISON hardware inspection.
# Collects Windows version, CPU, RAM, GPUs + VRAM, CUDA, disks and installed tools,
# and writes them to config\hardware.json. Read-only: changes nothing on the system.
param(
    [string]$OutFile = (Join-Path (Split-Path -Parent $PSScriptRoot) "config\hardware.json")
)

$ErrorActionPreference = "Continue"

function Round1([double]$v) { return [math]::Round($v, 1) }

function Get-ToolVersion([string]$exe, [string[]]$argList, [string]$pattern) {
    $cmd = Get-Command $exe -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $cmd) { return $null }
    # Windows ships "python.exe" stubs that only open the Microsoft Store.
    if ($cmd.Source -like "*\WindowsApps\*" -and $exe -like "python*") { return $null }
    try {
        $out = & $cmd.Source @argList 2>&1 | Out-String
        if ($LASTEXITCODE -ne 0 -and -not $out) { return $null }
        $m = [regex]::Match($out, $pattern)
        if ($m.Success) { return $m.Groups[1].Value }
        return $out.Trim().Split("`n")[0]
    } catch { return $null }
}

function Find-Blender {
    $found = Get-Command blender -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($found) { return $found.Source }
    $roots = @("$env:ProgramFiles\Blender Foundation", "${env:ProgramFiles(x86)}\Steam\steamapps\common\Blender")
    foreach ($r in $roots) {
        if (Test-Path $r) {
            $exe = Get-ChildItem -Path $r -Filter blender.exe -Recurse -Depth 2 -ErrorAction SilentlyContinue |
                   Sort-Object FullName -Descending | Select-Object -First 1
            if ($exe) { return $exe.FullName }
        }
    }
    return $null
}

function Find-Ollama {
    $cmd = Get-Command ollama -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($cmd) { return $cmd.Source }
    $p = Join-Path $env:LOCALAPPDATA "Programs\Ollama\ollama.exe"
    if (Test-Path $p) { return $p }
    return $null
}

function Get-Vendor([string]$name, [string]$pnp) {
    $s = "$name $pnp"
    if ($s -match "NVIDIA|VEN_10DE") { return "nvidia" }
    if ($s -match "AMD|Radeon|ATI|VEN_1002") { return "amd" }
    if ($s -match "Intel|VEN_8086") { return "intel" }
    return "other"
}

Write-Host "Inspecting hardware..." -ForegroundColor Cyan

$os  = Get-CimInstance Win32_OperatingSystem
$cs  = Get-CimInstance Win32_ComputerSystem
$cpu = @(Get-CimInstance Win32_Processor)

$cores = ($cpu | Measure-Object -Property NumberOfCores -Sum).Sum
$threads = ($cpu | Measure-Object -Property NumberOfLogicalProcessors -Sum).Sum

# ---- GPUs ---------------------------------------------------------------------------------
# Win32_VideoController.AdapterRAM is a 32-bit field (caps at 4 GB), so read the driver's
# 64-bit qwMemorySize from the registry, and prefer nvidia-smi for NVIDIA cards.
$regVram = @{}
$classKey = "HKLM:\SYSTEM\ControlSet001\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"
Get-ChildItem $classKey -ErrorAction SilentlyContinue | ForEach-Object {
    $p = Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue
    if ($p -and $p.DriverDesc) {
        $q = $p."HardwareInformation.qwMemorySize"
        if ($q) { $regVram[$p.DriverDesc] = [double]$q }
    }
}

$gpus = @()
foreach ($vc in Get-CimInstance Win32_VideoController) {
    if ($vc.Name -match "Microsoft Basic|Remote Display|Virtual") { continue }
    $bytes = 0
    if ($regVram.ContainsKey($vc.Name)) { $bytes = $regVram[$vc.Name] }
    elseif ($vc.AdapterRAM) { $bytes = [double]$vc.AdapterRAM }
    $gpus += [ordered]@{
        name    = $vc.Name
        vendor  = Get-Vendor $vc.Name $vc.PNPDeviceID
        vram_gb = Round1 ($bytes / 1GB)
        driver  = $vc.DriverVersion
    }
}

$cudaVersion = $null
$nvsmi = Get-Command nvidia-smi -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $nvsmi -and (Test-Path "$env:SystemRoot\System32\nvidia-smi.exe")) {
    $nvsmi = Get-Item "$env:SystemRoot\System32\nvidia-smi.exe"
}
if ($nvsmi) {
    $path = if ($nvsmi.Source) { $nvsmi.Source } else { $nvsmi.FullName }
    try {
        $rows = & $path --query-gpu=name,memory.total,driver_version --format=csv,noheader,nounits 2>$null
        foreach ($row in $rows) {
            $parts = $row.Split(",") | ForEach-Object { $_.Trim() }
            if ($parts.Count -ge 2) {
                $existing = $gpus | Where-Object { $_.name -eq $parts[0] } | Select-Object -First 1
                $vram = Round1 ([double]$parts[1] / 1024)
                if ($existing) { $existing.vram_gb = $vram; $existing.driver = $parts[2] }
                else { $gpus += [ordered]@{ name = $parts[0]; vendor = "nvidia"; vram_gb = $vram; driver = $parts[2] } }
            }
        }
        $banner = & $path 2>$null | Out-String
        $m = [regex]::Match($banner, "CUDA Version:\s*([0-9.]+)")
        if ($m.Success) { $cudaVersion = $m.Groups[1].Value }
    } catch { }
}

# ---- Disks -------------------------------------------------------------------------------
$disks = @()
foreach ($d in Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3") {
    $disks += [ordered]@{ drive = $d.DeviceID; free_gb = Round1 ($d.FreeSpace / 1GB); size_gb = Round1 ($d.Size / 1GB) }
}
$projectDrive = (Split-Path -Qualifier $PSScriptRoot)

# ---- Tools -------------------------------------------------------------------------------
$pyVersion = $null
$py = Get-Command py -ErrorAction SilentlyContinue
if ($py) { $pyVersion = Get-ToolVersion "py" @("--version") "Python ([0-9.]+)" }
if (-not $pyVersion) { $pyVersion = Get-ToolVersion "python" @("--version") "Python ([0-9.]+)" }

$ollamaPath = Find-Ollama
$ollamaVersion = $null
if ($ollamaPath) {
    try { $o = & $ollamaPath --version 2>&1 | Out-String; $m = [regex]::Match($o, "([0-9]+\.[0-9]+\.[0-9]+)"); if ($m.Success) { $ollamaVersion = $m.Groups[1].Value } } catch { }
}
$blender = Find-Blender
$blenderVersion = $null
if ($blender) { $m = [regex]::Match($blender, "Blender ([0-9.]+)"); if ($m.Success) { $blenderVersion = $m.Groups[1].Value } else { $blenderVersion = "installed" } }

$tools = [ordered]@{
    python  = $pyVersion
    git     = Get-ToolVersion "git" @("--version") "git version ([0-9.]+)"
    node    = Get-ToolVersion "node" @("--version") "v([0-9.]+)"
    npm     = Get-ToolVersion "npm.cmd" @("--version") "([0-9.]+)"
    cmake   = Get-ToolVersion "cmake" @("--version") "cmake version ([0-9.]+)"
    blender = $blenderVersion
    ollama  = $ollamaVersion
    winget  = Get-ToolVersion "winget" @("--version") "v([0-9.]+)"
}

$result = [ordered]@{
    collected_at      = (Get-Date).ToString("yyyy-MM-dd HH:mm")
    os_caption        = $os.Caption
    os_version        = $os.Version
    os_build          = $os.BuildNumber
    cpu_name          = ($cpu | Select-Object -First 1).Name.Trim()
    cpu_cores         = [int]$cores
    cpu_logical_cores = [int]$threads
    ram_gb            = Round1 ($cs.TotalPhysicalMemory / 1GB)
    gpus              = @($gpus)
    cuda_version      = $cudaVersion
    disks             = @($disks)
    project_drive     = $projectDrive
    tools             = $tools
    paths             = [ordered]@{ blender = $blender; ollama = $ollamaPath }
}

New-Item -ItemType Directory -Force -Path (Split-Path -Parent $OutFile) | Out-Null
$result | ConvertTo-Json -Depth 6 | Out-File -FilePath $OutFile -Encoding utf8

Write-Host ""
Write-Host ("  Windows : {0} (build {1})" -f $result.os_caption, $result.os_build)
Write-Host ("  CPU     : {0}  [{1} cores / {2} threads]" -f $result.cpu_name, $cores, $threads)
Write-Host ("  RAM     : {0} GB" -f $result.ram_gb)
if ($gpus.Count -eq 0) { Write-Host "  GPU     : none detected" }
foreach ($g in $gpus) { Write-Host ("  GPU     : {0} ({1}, {2} GB VRAM)" -f $g.name, $g.vendor, $g.vram_gb) }
Write-Host ("  CUDA    : {0}" -f $(if ($cudaVersion) { $cudaVersion } else { "not available" }))
foreach ($d in $disks) { Write-Host ("  Disk {0} : {1} GB free" -f $d.drive, $d.free_gb) }
foreach ($k in $tools.Keys) { Write-Host ("  {0,-8}: {1}" -f $k, $(if ($tools[$k]) { $tools[$k] } else { "not found" })) }
Write-Host ""
Write-Host "Saved $OutFile" -ForegroundColor DarkGray
