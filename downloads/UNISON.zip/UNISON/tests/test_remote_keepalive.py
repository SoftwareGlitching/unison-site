"""Website/phone chats through the public link: the reply starts at once and keeps the connection alive while
the brain loads, so phones and the tunnel don't drop it; problems arrive as an error event; all is logged."""
import asyncio
import json
import unittest
from types import SimpleNamespace

from tests.helpers import IsolatedSettings  # noqa: I001
from backend.api import routes
from backend.api.schemas import OAChatRequest
from backend.inference.base import GenerationStats, InferenceError, StreamEvent


class FakeManager:
    def __init__(self, delay=0.0, fail=False):
        self.delay, self.fail = delay, fail
        self.backend = SimpleNamespace(name="fake")

    async def resolve_model(self, m):
        return "unison:latest"

    def default_options(self, **kw):
        from backend.inference.base import GenerationOptions
        return GenerationOptions(num_ctx=8192, **{k: v for k, v in kw.items() if v is not None})

    def system_prompt(self, m):
        return "You are UNISON."

    async def stream(self, model, msgs, opts, tools=None):
        await asyncio.sleep(self.delay)                 # loading the brain / waiting its turn
        if self.fail:
            raise InferenceError("Ollama isn't running", 503, "engine_offline")
        yield StreamEvent("token", "Hey Jake!")
        yield StreamEvent("done", stats=GenerationStats(model=model, completion_tokens=3))


def run_chat(mgr):
    async def go():
        orig_mgr, orig_sr, orig_ka = routes.manager, routes.StreamingResponse, routes.KEEPALIVE_SECONDS
        routes.manager, routes.StreamingResponse, routes.KEEPALIVE_SECONDS = mgr, (lambda gen, **k: gen), 0.05
        try:
            req = OAChatRequest(messages=[{"role": "user", "content": "hi"}], stream=True)
            request = SimpleNamespace(state=SimpleNamespace(guest="key1", guest_plan="pro"), client=SimpleNamespace(host="100.1.2.3"))
            gen = await routes.chat_completions(req, request, ident={})
            return [part async for part in gen]
        finally:
            routes.manager, routes.StreamingResponse, routes.KEEPALIVE_SECONDS = orig_mgr, orig_sr, orig_ka
    return asyncio.run(asyncio.wait_for(go(), 10))


class KeepAliveTests(unittest.TestCase):
    def test_slow_brain_gets_keepalives_then_the_reply(self):
        with IsolatedSettings():
            parts = run_chat(FakeManager(delay=0.3))
        self.assertTrue(parts[0].startswith("data: "))                      # starts at once
        self.assertGreaterEqual(sum(p.startswith(": still working") for p in parts), 2)
        text = "".join(json.loads(p[6:])["choices"][0]["delta"].get("content", "")
                       for p in parts if p.startswith("data: {") and "choices" in p)
        self.assertEqual(text, "Hey Jake!")
        self.assertEqual(parts[-1], "data: [DONE]\n\n")

    def test_engine_problem_becomes_an_error_event(self):
        with IsolatedSettings():
            parts = run_chat(FakeManager(fail=True))
        errs = [json.loads(p[6:]) for p in parts if p.startswith("data: {") and '"error"' in p]
        self.assertTrue(errs and "Ollama" in errs[0]["error"]["message"])

    def test_remote_chats_are_logged_start_and_end(self):
        from backend.core.config import LOG_DIR
        log = LOG_DIR / "remote.log"
        before = log.read_text(encoding="utf-8") if log.exists() else ""
        with IsolatedSettings():
            run_chat(FakeManager())
        new = log.read_text(encoding="utf-8")[len(before):].splitlines()
        events = [json.loads(x)["event"] for x in new]
        self.assertEqual(events[-2:], ["start", "done"])


if __name__ == "__main__":
    unittest.main()


class AppChatKeepAliveTests(unittest.TestCase):
    def test_keepalive_helper_and_early_close(self):
        async def slow():
            await asyncio.sleep(0.25)
            yield {"type": "token"}
            await asyncio.sleep(5)          # never reached: the client goes away
            yield {"type": "late"}

        async def go():
            orig = routes.KEEPALIVE_SECONDS
            routes.KEEPALIVE_SECONDS = 0.05
            try:
                agen = slow()
                ka = routes._keepalive(agen)
                seen = []
                async for item in ka:
                    seen.append(item)
                    if item and item["type"] == "token":
                        break
                await ka.aclose()
                await agen.aclose()          # must not raise "already running"
                return seen
            finally:
                routes.KEEPALIVE_SECONDS = orig
        seen = asyncio.run(asyncio.wait_for(go(), 5))
        self.assertGreaterEqual(seen.count(None), 2)
        self.assertEqual(seen[-1], {"type": "token"})
