# Fixes slow replies: lets Ollama keep the brain AND the tiny knowledge-search model loaded together (with only
# one allowed, every message swapped the 8 GB brain out of VRAM and back), restarts Ollama and UNISON, then
# measures the speed. Results go to logs\speed.log.
. (Join-Path $PSScriptRoot "common.ps1")
Set-Location $Root
try { Start-Transcript -Path (Join-Path $Root "logs\speed.log") | Out-Null } catch { }
Write-Host ""
Write-Host "  U N I S O N   speed fix" -ForegroundColor Cyan

Write-Step "1/4" "Closing UNISON"
Get-Process -Name "UNISON" -ErrorAction SilentlyContinue | ForEach-Object { & taskkill /PID $_.Id /T /F 2>$null | Out-Null }
Write-Ok "Closed"

Write-Step "2/4" "Ollama settings"
$want = [ordered]@{ OLLAMA_MAX_LOADED_MODELS = "2"; OLLAMA_FLASH_ATTENTION = "1"; OLLAMA_KV_CACHE_TYPE = "q8_0";
                   OLLAMA_NUM_PARALLEL = "1"; OLLAMA_KEEP_ALIVE = "2h" }
foreach ($k in $want.Keys) {
    [Environment]::SetEnvironmentVariable($k, $want[$k], "User")
    Set-Item -Path "Env:$k" -Value $want[$k]
    Write-Host ("   {0} = {1}" -f $k, $want[$k])
}
Get-Process -Name "ollama app", "ollama" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
if (-not (Start-OllamaIfNeeded)) { Write-Bad "Ollama didn't restart. Open Ollama from the Start menu, then run this again."; Read-Host "Press Enter to close"; exit 1 }
Write-Ok "Ollama restarted with the new settings"

Write-Step "3/4" "Speed test (the first reply includes loading the brain)"
& $VenvPy (Join-Path $PSScriptRoot "brain_check.py") unison
$ollama = Find-OllamaExe
Write-Host ""
& $ollama ps

Write-Step "4/4" "Opening UNISON"
$app = Join-Path $Root "UNISON.exe"
if (Test-Path $app) { Start-Process -FilePath $app -WorkingDirectory $Root } else { Start-Process -FilePath (Join-Path $Root "Start-UNISON.bat") -WorkingDirectory $Root }
Write-Ok "Done - say hi in a new chat."
try { Stop-Transcript | Out-Null } catch { }
Write-Host "   (you can close this window - Ollama keeps running)"
Start-Sleep -Seconds 3
