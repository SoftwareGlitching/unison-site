"""License activation."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from ..core.config import settings
from ..licensing import license as lic
from ..security.auth import local_only

router = APIRouter(prefix="/v1/license", tags=["license"])


class KeyBody(BaseModel):
    key: str = Field(..., min_length=10, max_length=4000)


@router.get("/status")
async def license_status():
    s = lic.status()
    return {**s, "purchase_url": settings.get("site", "purchase_url") or settings.get("site", "url") or ""}


@router.post("/activate", dependencies=[Depends(local_only)])
async def activate(body: KeyBody):
    try:
        return lic.activate(body.key)
    except lic.LicenseError as e:
        raise HTTPException(400, {"code": "invalid_license", "message": str(e)})


@router.post("/deactivate", dependencies=[Depends(local_only)])
async def deactivate():
    return lic.deactivate()
