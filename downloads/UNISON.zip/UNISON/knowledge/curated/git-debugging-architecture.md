# Git, debugging method and software architecture

## Git everyday commands
- Start: `git init`, add a `.gitignore` first (node_modules/, .venv/, __pycache__/, build/, *.rbxl lock files...).
- Look: `git status`, `git diff` (unstaged), `git diff --staged`, `git log --oneline -n 20`.
- Save: `git add -A` then `git commit -m "Add shop remote validation"` (always `-m`; an editor would hang an agent).
- Branch: `git switch -c feature/shop`, `git switch main`, `git merge feature/shop`.
- Undo safely: `git restore file` (discard unstaged edits), `git restore --staged file` (unstage),
  `git revert <commit>` (new commit undoing an old one). `git reset --hard` and `git push --force`
  destroy work — only with the user's explicit OK.
- Remote: `git remote add origin <url>`, `git push -u origin main`, `git pull --rebase`.
- Commit small, focused changes with messages that say why.

## Debugging method
1. Reproduce: find the exact steps/input that fail. Write it down as a test if possible.
2. Read the whole error: message, file, line, and the call stack.
3. Form one hypothesis, then check it with evidence (print/log the values, read the code path), not guesses.
4. Shrink the problem: comment out halves, try minimal input, `git bisect` to find the commit that broke it.
5. Fix the cause, not the symptom (e.g. why is it nil? rather than adding `if x then`).
6. Re-run the reproduction and the existing tests; add a test for the bug.
7. Luau: `print`/`warn` with context, `debug.traceback()`; Output window shows the script and line.
   Python: `breakpoint()`, `logging`, `python -X dev`. JS: `console.log`, `node --inspect`.

## Architecture principles
- Separate responsibilities: input → logic → data → presentation. Game logic shouldn't live in UI code.
- One module = one job with a small public API; hide internals.
- Data flows one way where possible (server state → client display), events flow back as requests.
- Configuration (prices, speeds, spawn rates) in one config module, not scattered magic numbers.
- Make illegal states unrepresentable (enums/state machines instead of many booleans).
- Prefer composition over deep inheritance.
- Design for failure: every network/disk call can fail; decide what the player sees when it does.
- Roblox game skeleton:
  - `ServerScriptService/Services/*` (DataService, ShopService, RoundService) each `:Init()`/`:Start()`,
  - `ReplicatedStorage/Shared/*` (Config, types, pure utility modules),
  - `ReplicatedStorage/Remotes` folder with all RemoteEvents,
  - `StarterPlayerScripts/Controllers/*` (UIController, InputController, CameraController).
- API design: nouns for resources (`/players/{id}`), verbs via HTTP methods, consistent errors
  (`{"error": {"code", "message"}}`), version the API (`/v1`), validate every input server-side.
