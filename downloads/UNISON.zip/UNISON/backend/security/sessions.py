"""
Password sign-in and signed session tokens (standard library only).

- The password is stored only as a PBKDF2-HMAC-SHA256 hash with a random salt.
- A login returns a session token: base64(payload).base64(HMAC-SHA256(secret, payload)). The payload
  carries an expiry. Nothing in the token is secret; it can't be forged without the server secret.
- Rotating the server secret (logout-all) invalidates every existing token at once.
- When a password is set, the middleware in main.py requires a valid token (or an API key) on every
  /v1 request, local or remote. This is what makes remote access over Tailscale safe to leave on.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import time
from typing import Optional

from ..core.config import settings

PBKDF2_ROUNDS = 240_000
TOKEN_DAYS = 30
MIN_PASSWORD = 6


def _b64(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _unb64(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


# ---------------- password ----------------
def password_set() -> bool:
    return bool((settings.get("auth", "password") or {}).get("hash"))


def set_password(password: str) -> None:
    password = (password or "").strip()
    if len(password) < MIN_PASSWORD:
        raise ValueError(f"Password must be at least {MIN_PASSWORD} characters.")
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ROUNDS)
    settings.set("auth", "password", {"algo": "pbkdf2_sha256", "rounds": PBKDF2_ROUNDS,
                                      "salt": _b64(salt), "hash": _b64(digest)})
    rotate_secret()   # new password invalidates old sessions


def verify_password(password: str) -> bool:
    rec = settings.get("auth", "password") or {}
    if not rec.get("hash"):
        return False
    try:
        digest = hashlib.pbkdf2_hmac("sha256", (password or "").encode("utf-8"),
                                     _unb64(rec["salt"]), int(rec.get("rounds", PBKDF2_ROUNDS)))
    except Exception:  # noqa: BLE001
        return False
    return hmac.compare_digest(_b64(digest), rec["hash"])


def clear_password() -> None:
    settings.set("auth", "password", {})
    rotate_secret()


# ---------------- session tokens ----------------
def _secret() -> bytes:
    hexkey = settings.get("auth", "session_secret")
    if not hexkey:
        hexkey = secrets.token_hex(32)
        settings.set("auth", "session_secret", hexkey)
    return bytes.fromhex(hexkey)


def rotate_secret() -> None:
    settings.set("auth", "session_secret", secrets.token_hex(32))


def issue_token(days: int = TOKEN_DAYS) -> str:
    payload = _b64(json.dumps({"iat": int(time.time()), "exp": int(time.time()) + days * 86400}).encode())
    sig = _b64(hmac.new(_secret(), payload.encode(), hashlib.sha256).digest())
    return f"{payload}.{sig}"


def verify_token(token: Optional[str]) -> bool:
    if not token or token.count(".") != 1:
        return False
    payload, sig = token.split(".")
    expected = _b64(hmac.new(_secret(), payload.encode(), hashlib.sha256).digest())
    if not hmac.compare_digest(sig, expected):
        return False
    try:
        data = json.loads(_unb64(payload))
    except Exception:  # noqa: BLE001
        return False
    return int(data.get("exp", 0)) > time.time()
