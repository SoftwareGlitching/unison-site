import { useEffect, useRef, useState } from "react";
import {
  api,
  indexKnowledge,
  pullModel,
  type EvalSummary,
  type KnowledgeStatus,
  type MCPServerInfo,
  type ToolInfo,
} from "../lib/api";
import { SettingsPanel } from "./SettingsPanel";
import { auth, license, type LicenseStatus } from "../lib/api";

function PasswordSection() {
  const [set, setSet] = useState<boolean | null>(null);
  const [pw, setPw] = useState("");
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  useEffect(() => {
    auth.status().then((s) => setSet(s.password_set)).catch(() => setSet(null));
  }, []);
  const save = async () => {
    setErr("");
    setMsg("");
    try {
      await auth.change(pw);
      setPw("");
      setSet(true);
      setMsg("Saved. Other devices were signed out.");
    } catch (e: any) {
      setErr(e.message);
    }
  };
  return (
    <section>
      <h4>Sign-in password</h4>
      <p className="hint">
        {set
          ? "Used to sign in here and on your phone. Changing it signs out every other device."
          : "No password yet. Set one before you turn on remote access so your phone has to sign in."}
      </p>
      <div className="row">
        <input
          className="text grow"
          type="password"
          placeholder={set ? "New password (min 6)" : "Create a password (min 6)"}
          value={pw}
          onChange={(e) => setPw(e.target.value)}
        />
        <button className="pop-action" disabled={pw.length < 6} onClick={save}>
          {set ? "change" : "set password"}
        </button>
      </div>
      {msg && <div className="small ok-t">{msg}</div>}
      {err && <div className="pop-error">{err}</div>}
    </section>
  );
}

type Tab = "pc" | "knowledge" | "mcp" | "training" | "sampling" | "share";

const TABS: { id: Tab; label: string }[] = [
  { id: "pc", label: "PC access" },
  { id: "knowledge", label: "Knowledge" },
  { id: "training", label: "Training" },
  { id: "mcp", label: "MCP" },
  { id: "sampling", label: "Sampling" },
  { id: "share", label: "Share" },
];

// --------------------------------------------------------------------------- Share & updates
function ShareTab() {
  const [lic, setLic] = useState<LicenseStatus | null>(null);
  useEffect(() => {
    license.status().then(setLic).catch(() => setLic(null));
  }, []);
  const [site, setSite] = useState<Awaited<ReturnType<typeof api.site>> | null>(null);
  const [copied, setCopied] = useState(false);
  const [update, setUpdate] = useState("");
  useEffect(() => {
    api.site().then(setSite).catch(() => setSite(null));
  }, []);
  const copy = async () => {
    if (!site?.url) return;
    try {
      await navigator.clipboard.writeText(site.url);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = site.url;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };
  const check = async () => {
    if (!site?.version_url) return;
    setUpdate("checking…");
    try {
      // Only runs when you click: reads the version number published on the UNISON website.
      const r = await fetch(site.version_url, { cache: "no-store" });
      if (!r.ok) return setUpdate("No version published yet.");
      const j = await r.json();
      const latest = String(j.version || "").replace(/^v/, "");
      const mine = site.version;
      const newer = latest.localeCompare(mine, undefined, { numeric: true }) > 0;
      setUpdate(newer ? `Version ${latest} is available (you have ${mine}). Download it, extract over your folder and run Update.bat.` : `You're up to date (${mine}).`);
    } catch {
      setUpdate("Couldn't reach GitHub.");
    }
  };
  if (!site) return <div className="tab-body dim small">loading…</div>;
  return (
    <div className="tab-body">
      <section>
        <h4>Share UNISON</h4>
        <p className="hint">Anyone can download UNISON from its website and run it on their own Windows PC.</p>
        {site.url ? (
          <>
            <div className="row">
              <code className="grow">{site.url}</code>
              <button className="pop-action" onClick={copy}>{copied ? "copied" : "copy link"}</button>
              <a className="pop-action" href={site.url} target="_blank" rel="noreferrer">open</a>
            </div>
            <a className="approve share-dl" href={site.download} target="_blank" rel="noreferrer">
              ⤓ Download for Windows
            </a>
          </>
        ) : (
          <div className="dim small">No website configured (config → site.url).</div>
        )}
      </section>
      {lic && (
        <section>
          <h4>License</h4>
          <p className="hint">
            {lic.activated
              ? `Licensed to ${lic.to} · ${lic.plan} · ${lic.expires ? "expires " + new Date(lic.expires * 1000).toLocaleDateString() : "never expires"}${lic.locked_to_this_pc ? " · this PC only" : ""}`
              : lic.problem || "Not activated"}
          </p>
          <div className="small dim">Machine ID: <code>{lic.machine_id}</code></div>
        </section>
      )}
      <section>
        <h4>Updates</h4>
        <p className="hint">You have UNISON {site.version}.</p>
        <button className="pop-action" disabled={!site.version_url} onClick={check}>check for updates</button>
        {update && <div className="small" style={{ marginTop: 6 }}>{update}</div>}
      </section>
    </div>
  );
}

const when = (t: number) => new Date(t * 1000).toLocaleString();

// --------------------------------------------------------------------------- PC access
function PcTab() {
  const [ws, setWs] = useState<{ data: string[]; default: string; suggestions: { desktop: string | null } } | null>(null);
  const [tools, setTools] = useState<ToolInfo[]>([]);
  const [path, setPath] = useState("");
  const [err, setErr] = useState("");
  const [backups, setBackups] = useState<{ id: string; original: string; reason: string; at: number }[]>([]);
  const [agent, setAgent] = useState<boolean | null>(null);
  const [screen, setScreen] = useState<Awaited<ReturnType<typeof api.computer>> | null>(null);
  const [auto, setAuto] = useState(false);
  const [pull, setPull] = useState("");

  const load = async () => {
    try {
      const [w, t, b, a] = await Promise.all([api.workspaces(), api.tools(), api.backups(), api.agentSettings()]);
      setWs(w);
      setTools(t);
      setBackups(b.slice(0, 15));
      setAgent(a.agent_default);
      setScreen(await api.computer().catch(() => null));
      setAuto((await api.autonomous()).enabled);
    } catch (e: any) {
      setErr(e.message);
    }
  };

  const download = async (tag: string) => {
    setPull("starting…");
    try {
      await pullModel(tag, (p) => {
        if (p.error) throw new Error(p.error.message);
        setPull(p.total && p.completed ? `${p.status} ${Math.round((100 * p.completed) / p.total)}%` : p.status ?? "");
      }, new AbortController().signal);
      await api.setVisionModel(tag);
      setPull("");
      load();
    } catch (e: any) {
      setPull("");
      setErr(e.message);
    }
  };
  useEffect(() => {
    load();
  }, []);

  const run = async (fn: () => Promise<unknown>) => {
    setErr("");
    try {
      await fn();
      await load();
    } catch (e: any) {
      setErr(e.message);
    }
  };

  return (
    <div className="tab-body">
      <section>
        <h4>Agent mode</h4>
        <label className="toggle">
          <input
            type="checkbox"
            checked={!!agent}
            onChange={(e) => run(() => api.saveAgentSettings({ agent_default: e.target.checked }))}
          />
          Let UNISON use tools by default (you can switch it per message in the chat box)
        </label>
        <label className="toggle">
          <input type="checkbox" checked={auto} onChange={(e) => run(() => api.setAutonomous(e.target.checked))} />
          <span><b>Autonomous</b>: approve file changes and commands automatically (dangerous commands stay blocked,
          every change is backed up)</span>
        </label>
      </section>

      <PasswordSection />

      <section>
        <h4>Screen control</h4>
        {!screen && <div className="dim small">loading…</div>}
        {screen && !screen.supported && <div className="dim small">{screen.problem}</div>}
        {screen && screen.supported && (
          <>
            <p className="hint">
              In <b>screen</b> mode a local vision model looks at your screen and uses the mouse and keyboard. Press
              Esc or push the mouse into the top-left corner to stop it at any time.
            </p>
            <div className="row">
              <span className="grow">vision model</span>
              <select value={screen.vision_model} onChange={(e) => api.setVisionModel(e.target.value).then(load)}>
                {screen.choices.map((c) => (
                  <option key={c} value={c}>
                    {c} {screen.installed_vision_models.includes(c) ? "" : "(not downloaded)"}
                  </option>
                ))}
              </select>
              {!screen.vision_model_installed && (
                <button className="pop-action" disabled={!!pull} onClick={() => download(screen.vision_model)}>download</button>
              )}
            </div>
            {pull && <div className="small dim">{pull}</div>}
          </>
        )}
      </section>

      <section>
        <h4>Workspaces</h4>
        <p className="hint">UNISON can only read, write and run things inside these folders. The first one is the default.</p>
        {ws?.data.map((w, i) => (
          <div className="row" key={w}>
            <code className="grow">{w}</code>
            {i === 0 ? (
              <span className="tier-tag">default</span>
            ) : (
              <button className="pop-action" onClick={() => run(() => api.defaultWorkspace(w))}>
                make default
              </button>
            )}
            <button className="pop-action" onClick={() => run(() => api.removeWorkspace(w))}>
              remove
            </button>
          </div>
        ))}
        <div className="row">
          <input className="text grow" placeholder="C:\\Users\\you\\Desktop\\my-game" value={path} onChange={(e) => setPath(e.target.value)} />
          <button className="pop-action" disabled={!path.trim()} onClick={() => run(async () => { await api.addWorkspace(path.trim()); setPath(""); })}>
            add folder
          </button>
        </div>
        {ws?.suggestions.desktop && !ws.data.includes(ws.suggestions.desktop) && (
          <button className="pop-action" onClick={() => run(() => api.addWorkspace(ws.suggestions.desktop!))}>
            add my Desktop ({ws.suggestions.desktop})
          </button>
        )}
      </section>

      <section>
        <h4>Tool permissions</h4>
        <p className="hint">
          auto = runs without asking · ask = you approve each use · off = UNISON can't use it. Dangerous terminal commands
          (formatting drives, registry edits, disabling security…) are always blocked.
        </p>
        {tools.map((t) => (
          <div className="row" key={t.name}>
            <span className="grow">
              <code>{t.name}</code> <span className="dim small">{t.source !== "builtin" ? t.source : t.risk}</span>
            </span>
            <select
              value={t.mode === "classify" ? "classify" : t.mode}
              onChange={(e) => run(() => api.setToolMode(t.name, e.target.value === "classify" ? "default" : e.target.value))}
            >
              {t.default_mode === "classify" && <option value="classify">smart (safe=auto, else ask)</option>}
              <option value="auto">auto</option>
              <option value="ask">ask</option>
              <option value="deny">off</option>
            </select>
          </div>
        ))}
      </section>

      <section>
        <h4>Undo file changes</h4>
        <p className="hint">Every file UNISON changes or deletes is backed up first.</p>
        {backups.length === 0 && <div className="dim small">No backups yet.</div>}
        {backups.map((b) => (
          <div className="row" key={b.id}>
            <span className="grow small">
              <code>{b.original}</code> <span className="dim">{b.reason} · {when(b.at)}</span>
            </span>
            <button className="pop-action" onClick={() => confirm(`Restore ${b.original} to this backup?`) && run(() => api.restoreBackup(b.id))}>
              restore
            </button>
          </div>
        ))}
      </section>
      {err && <div className="pop-error">{err}</div>}
    </div>
  );
}

// --------------------------------------------------------------------------- Knowledge
function KnowledgeTab() {
  const [st, setSt] = useState<KnowledgeStatus | null>(null);
  const [ws, setWs] = useState<string[]>([]);
  const [progress, setProgress] = useState("");
  const [busy, setBusy] = useState(false);
  const [q, setQ] = useState("");
  const [hits, setHits] = useState<{ title: string; score: number; text: string }[]>([]);
  const [err, setErr] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const load = async () => {
    try {
      const [k, w] = await Promise.all([api.knowledge(), api.workspaces()]);
      setSt(k);
      setWs(w.data);
    } catch (e: any) {
      setErr(e.message);
    }
  };
  useEffect(() => {
    load();
  }, []);

  const index = async (body: { target: "curated" | "workspace"; path?: string }) => {
    setBusy(true);
    setErr("");
    setProgress("starting…");
    try {
      await indexKnowledge(
        body,
        (p) => {
          if (p.error) throw new Error(p.error.message);
          if (p.done === true) setProgress(`done: ${p.indexed} file(s) indexed, ${p.unchanged} unchanged, ${p.removed} removed`);
          else setProgress(`${p.done}/${p.total} ${p.file}`);
        },
        new AbortController().signal,
      );
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
      load();
    }
  };

  const upload = async (files: FileList | null) => {
    if (!files) return;
    for (const f of Array.from(files)) {
      try {
        const r = await api.addDocument(f.name, await f.text());
        setProgress(r.indexed ? `added ${f.name} (${r.chunks} chunks)` : `saved ${f.name}; ${r.problem}`);
      } catch (e: any) {
        setErr(e.message);
      }
    }
    if (fileRef.current) fileRef.current.value = "";
    load();
  };

  return (
    <div className="tab-body">
      <p className="hint">
        The knowledge base is looked up while UNISON answers (retrieval). It makes facts and your project code available to
        the model; it doesn't change the model's weights — that's what fine-tuning in the Training tab is for.
      </p>
      {st && !st.embedding_ready && <div className="banner warn">{st.problem}. Open the model menu or run Update.bat.</div>}
      {st && (
        <section>
          <h4>
            {st.sources} files · {st.chunks} chunks <span className="dim small">({st.embedding_model})</span>
          </h4>
          <label className="toggle">
            <input
              type="checkbox"
              checked={st.auto_retrieve}
              onChange={async (e) => {
                await api.saveAgentSettings({ auto_retrieve: e.target.checked });
                load();
              }}
            />
            Look up relevant notes automatically for every message
          </label>
          {st.collections.map((c) => (
            <div className="row" key={c.collection}>
              <span className="grow small">
                <code>{c.collection === "knowledge" ? "Curated + your notes" : c.collection}</code>{" "}
                <span className="dim">
                  {c.files} files · {c.chunks} chunks · {when(c.updated_at)}
                </span>
              </span>
              <button className="pop-action" onClick={async () => { await api.deleteCollection(c.collection); load(); }}>
                remove
              </button>
            </div>
          ))}
        </section>
      )}
      <section>
        <h4>Index</h4>
        <div className="row wrap">
          <button className="pop-action" disabled={busy || !st?.embedding_ready} onClick={() => index({ target: "curated" })}>
            index programming notes
          </button>
          {ws.map((w) => (
            <button key={w} className="pop-action" disabled={busy || !st?.embedding_ready} onClick={() => index({ target: "workspace", path: w })}>
              index code in {w.split(/[\\/]/).pop()}
            </button>
          ))}
          <button className="pop-action" disabled={!st?.embedding_ready} onClick={() => fileRef.current?.click()}>
            add notes (.md/.txt)
          </button>
          <input ref={fileRef} type="file" accept=".md,.txt,.markdown" multiple hidden onChange={(e) => upload(e.target.files)} />
        </div>
        {progress && <div className="small dim">{progress}</div>}
      </section>
      <section>
        <h4>Test a search</h4>
        <div className="row">
          <input className="text grow" placeholder="e.g. how to save player data" value={q} onChange={(e) => setQ(e.target.value)} />
          <button className="pop-action" disabled={!q.trim()} onClick={async () => setHits(await api.searchKnowledge(q))}>
            search
          </button>
        </div>
        {hits.map((h, i) => (
          <div className="hit" key={i}>
            <div className="small">
              <code>{h.title}</code> <span className="dim">score {h.score}</span>
            </div>
            <pre>{h.text.slice(0, 400)}</pre>
          </div>
        ))}
      </section>
      {err && <div className="pop-error">{err}</div>}
    </div>
  );
}

// --------------------------------------------------------------------------- Training
function TrainingTab() {
  const [data, setData] = useState<{ feedback: { thumbs_up: number; thumbs_down: number; corrections: number; exports: string[] }; evaluations: EvalSummary[] } | null>(null);
  const [msg, setMsg] = useState("");
  const load = () => api.training().then(setData).catch((e) => setMsg(e.message));
  useEffect(() => {
    load();
  }, []);
  const cats = Array.from(new Set((data?.evaluations ?? []).flatMap((e) => Object.keys(e.categories))));

  return (
    <div className="tab-body">
      <section>
        <h4>Teach UNISON with feedback</h4>
        <p className="hint">
          Rate replies with 👍 / 👎 and write corrections. Export them as a dataset for fine-tuning (LoRA). A few hundred good
          examples are needed before training makes a measurable difference.
        </p>
        {data && (
          <div className="stats-row">
            <div><b>{data.feedback.thumbs_up}</b><span>good</span></div>
            <div><b>{data.feedback.thumbs_down}</b><span>bad</span></div>
            <div><b>{data.feedback.corrections}</b><span>corrections</span></div>
          </div>
        )}
        <button
          className="pop-action"
          onClick={async () => {
            try {
              const r = await api.exportTraining();
              setMsg(Object.entries(r.files).map(([k, v]) => `${k}: ${v.examples} examples → ${v.path}`).join("\n"));
              load();
            } catch (e: any) {
              setMsg(e.message);
            }
          }}
        >
          export training dataset
        </button>
        {msg && <pre className="small">{msg}</pre>}
      </section>
      <section>
        <h4>Benchmark</h4>
        <p className="hint">
          Run <code>scripts\eval.bat</code> to score the model on real programming tasks (code is executed against tests).
          Run it before and after any change so you can see if UNISON actually got better.
        </p>
        {data && data.evaluations.length === 0 && <div className="dim small">No benchmark runs yet.</div>}
        {data && data.evaluations.length > 0 && (
          <div className="table-wrap">
            <table className="eval">
              <thead>
                <tr>
                  <th>when</th>
                  <th>model</th>
                  <th>notes</th>
                  <th>score</th>
                  {cats.map((c) => (
                    <th key={c}>{c}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.evaluations.map((e) => (
                  <tr key={e.file}>
                    <td>{e.created.slice(5, 16)}</td>
                    <td><code>{e.model}</code></td>
                    <td>{e.knowledge ? "on" : "off"}</td>
                    <td><b>{e.score}%</b></td>
                    {cats.map((c) => (
                      <td key={c}>{e.categories[c] ? `${e.categories[c].passed}/${e.categories[c].total}` : ""}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}

// --------------------------------------------------------------------------- MCP
function McpTab() {
  const [servers, setServers] = useState<MCPServerInfo[]>([]);
  const [form, setForm] = useState({ name: "", command: "", args: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const load = () => api.mcpServers().then(setServers).catch((e) => setErr(e.message));
  useEffect(() => {
    load();
  }, []);
  const act = async (fn: () => Promise<MCPServerInfo[]>) => {
    setErr("");
    setBusy(true);
    try {
      setServers(await fn());
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="tab-body">
      <p className="hint">
        MCP servers add extra tools (databases, browsers, GitHub, Blender…). Every MCP tool asks for your approval by default.
      </p>
      {servers.length === 0 && <div className="dim small">No MCP servers configured.</div>}
      {servers.map((s) => (
        <div className="mcp" key={s.name}>
          <div className="row">
            <b className="grow">{s.name}</b>
            <span className={`tier-tag st-${s.status}`}>{s.status}</span>
            {s.status === "running" ? (
              <button className="pop-action" disabled={busy} onClick={() => act(() => api.mcpAction(s.name, "stop"))}>stop</button>
            ) : (
              <button className="pop-action" disabled={busy} onClick={() => act(() => api.mcpAction(s.name, "start"))}>start</button>
            )}
            <button className="pop-action" disabled={busy} onClick={() => confirm(`Remove ${s.name}?`) && act(() => api.deleteMcp(s.name))}>remove</button>
          </div>
          <code className="small">{s.command} {s.args.join(" ")}</code>
          {s.tools.length > 0 && <div className="small dim">tools: {s.tools.join(", ")}</div>}
          {s.error && <div className="pop-error">{s.error}</div>}
        </div>
      ))}
      <section>
        <h4>Add a server (stdio)</h4>
        <input className="text" placeholder="name, e.g. sqlite" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <input className="text" placeholder="command, e.g. npx or uvx" value={form.command} onChange={(e) => setForm({ ...form, command: e.target.value })} />
        <textarea
          className="text"
          rows={3}
          placeholder={"arguments, one per line, e.g.\n-y\n@modelcontextprotocol/server-memory"}
          value={form.args}
          onChange={(e) => setForm({ ...form, args: e.target.value })}
        />
        <button
          className="pop-action"
          disabled={busy || !form.name.trim() || !form.command.trim()}
          onClick={() =>
            act(async () => {
              const r = await api.addMcpServer({
                name: form.name.trim(),
                command: form.command.trim(),
                args: form.args.split("\n").map((x) => x.trim()).filter(Boolean),
                enabled: true,
              });
              setForm({ name: "", command: "", args: "" });
              return r;
            })
          }
        >
          add and start
        </button>
      </section>
      {err && <div className="pop-error">{err}</div>}
    </div>
  );
}

export function SettingsDrawer({ onClose, initial }: { onClose: () => void; initial?: Tab | "share" }) {
  const [tab, setTab] = useState<Tab>(initial ?? "pc");
  return (
    <div className="drawer-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <aside className="drawer">
        <div className="drawer-head">
          <span>Settings</span>
          <button className="icon-btn" onClick={onClose} aria-label="Close">
            ×
          </button>
        </div>
        <nav className="tabs">
          {TABS.map((t) => (
            <button key={t.id} className={tab === t.id ? "on" : ""} onClick={() => setTab(t.id)}>
              {t.label}
            </button>
          ))}
        </nav>
        <div className="drawer-body">
          {tab === "pc" && <PcTab />}
          {tab === "knowledge" && <KnowledgeTab />}
          {tab === "training" && <TrainingTab />}
          {tab === "mcp" && <McpTab />}
          {tab === "sampling" && <SettingsPanel embedded onClose={onClose} />}
          {tab === "share" && <ShareTab />}
        </div>
      </aside>
    </div>
  );
}
