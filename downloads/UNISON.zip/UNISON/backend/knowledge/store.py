"""
UNISON knowledge base: local retrieval-augmented generation (RAG).

- Embeddings come from a local embedding model served by Ollama (default `nomic-embed-text`).
- Vectors live in data/knowledge.db (SQLite) and are searched with exact cosine similarity (NumPy),
  which is fast for the tens of thousands of chunks a personal knowledge base holds.
- Adding documents here makes knowledge AVAILABLE at answer time. It does not change the model's
  weights; that is what fine-tuning (LoRA) is for.
"""
from __future__ import annotations

import hashlib
import os
import sqlite3
import threading
import time
from pathlib import Path
from typing import AsyncIterator, Callable, Optional

import numpy as np

from ..core.config import DATA_DIR, ROOT, settings
from ..inference.base import InferenceError
from ..tools.sandbox import SKIP_DIRS, Workspaces
from .chunker import TEXT_EXTENSIONS, chunk_file

KNOWLEDGE_DIR = ROOT / "knowledge"
MAX_FILE_BYTES = 300_000

SCHEMA = """
CREATE TABLE IF NOT EXISTS sources (
    id INTEGER PRIMARY KEY,
    kind TEXT NOT NULL,             -- knowledge | project
    collection TEXT NOT NULL,       -- curated | user | <workspace path>
    path TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    sha TEXT NOT NULL,
    chunks INTEGER NOT NULL DEFAULT 0,
    embed_model TEXT NOT NULL,
    updated_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS chunks (
    id INTEGER PRIMARY KEY,
    source_id INTEGER NOT NULL REFERENCES sources(id) ON DELETE CASCADE,
    idx INTEGER NOT NULL,
    heading TEXT,
    text TEXT NOT NULL,
    start_line INTEGER,
    end_line INTEGER,
    emb BLOB NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_chunks_source ON chunks(source_id);
"""


def embedding_model() -> str:
    return (settings.get("knowledge", "embedding_model")
            or (settings.models_config().get("embedding_model") or {}).get("tag")
            or "nomic-embed-text")


def _prefix(model: str, kind: str) -> str:
    # nomic-embed expects task prefixes; other models don't need them.
    if "nomic" in model:
        return "search_query: " if kind == "query" else "search_document: "
    return ""


class KnowledgeStore:
    def __init__(self, path: Path, backend=None):
        self.path = path
        self.backend = backend
        self._lock = threading.RLock()
        self.conn = sqlite3.connect(str(path), check_same_thread=False, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA foreign_keys=ON")
        self.conn.executescript(SCHEMA)
        self._cache: Optional[tuple[np.ndarray, list[int]]] = None

    def _backend(self):
        if self.backend is None:
            from ..inference.manager import manager
            self.backend = manager.backend
        return self.backend

    # ------------------------------------------------------------------ embedding
    async def embed(self, texts: list[str], kind: str) -> np.ndarray:
        model = embedding_model()
        vecs = await self._backend().embed(model, [_prefix(model, kind) + t for t in texts])
        arr = np.asarray(vecs, dtype=np.float32)
        norms = np.linalg.norm(arr, axis=1, keepdims=True)
        norms[norms == 0] = 1
        return arr / norms

    async def available(self) -> tuple[bool, str]:
        model = embedding_model()
        try:
            names = {m.name for m in await self._backend().list_models()}
        except InferenceError as e:
            return False, str(e)
        if model in names or f"{model}:latest" in names:
            return True, ""
        return False, f"Embedding model '{model}' is not installed (ollama pull {model})"

    # ------------------------------------------------------------------ ingest
    async def ingest_file(self, path: Path, kind: str, collection: str, title: Optional[str] = None) -> int:
        """(Re)index one file. Returns the number of chunks written (0 if unchanged/skipped)."""
        try:
            if path.stat().st_size > MAX_FILE_BYTES:
                return 0
            raw = path.read_bytes()
        except OSError:
            return 0
        if b"\0" in raw[:4096]:
            return 0
        sha = hashlib.sha1(raw).hexdigest()
        model = embedding_model()
        key = str(path.resolve())
        with self._lock:
            row = self.conn.execute("SELECT id, sha, embed_model FROM sources WHERE path=?", (key,)).fetchone()
        if row and row["sha"] == sha and row["embed_model"] == model:
            return 0
        text = raw.decode("utf-8-sig", errors="replace")
        pieces = chunk_file(text, path.suffix)
        if not pieces:
            return 0
        label = title or path.name
        header = f"File: {label}\n"
        vecs = await self.embed([header + (f"Section: {c.heading}\n" if c.heading else "") + c.text for c in pieces],
                                "document")
        with self._lock:
            self.conn.execute("BEGIN")
            try:
                if row:
                    self.conn.execute("DELETE FROM sources WHERE id=?", (row["id"],))
                cur = self.conn.execute(
                    "INSERT INTO sources(kind, collection, path, title, sha, chunks, embed_model, updated_at) "
                    "VALUES(?,?,?,?,?,?,?,?)", (kind, collection, key, label, sha, len(pieces), model, time.time()))
                sid = cur.lastrowid
                self.conn.executemany(
                    "INSERT INTO chunks(source_id, idx, heading, text, start_line, end_line, emb) VALUES(?,?,?,?,?,?,?)",
                    [(sid, n, c.heading, c.text, c.start_line, c.end_line, vecs[n].tobytes())
                     for n, c in enumerate(pieces)])
                self.conn.execute("COMMIT")
            except BaseException:
                self.conn.execute("ROLLBACK")
                raise
            self._cache = None
        return len(pieces)

    async def ingest_folder(self, folder: Path, kind: str, collection: str,
                            progress: Optional[Callable[[dict], None]] = None) -> dict:
        files = []
        for dirpath, dirnames, filenames in os.walk(folder):
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".")]
            for f in filenames:
                p = Path(dirpath) / f
                if p.suffix.lower() in TEXT_EXTENSIONS and not Workspaces.is_sensitive_file(p):
                    files.append(p)
        stats = {"files": len(files), "indexed": 0, "unchanged": 0, "chunks": 0, "removed": 0}
        for n, p in enumerate(files, 1):
            added = await self.ingest_file(p, kind, collection, title=os.path.relpath(p, folder))
            if added:
                stats["indexed"] += 1
                stats["chunks"] += added
            else:
                stats["unchanged"] += 1
            if progress:
                progress({"done": n, "total": len(files), "file": os.path.relpath(p, folder)})
        # Forget files that were deleted from this folder.
        keep = {str(p.resolve()) for p in files}
        with self._lock:
            rows = self.conn.execute("SELECT id, path FROM sources WHERE collection=?", (collection,)).fetchall()
            gone = [r["id"] for r in rows if r["path"] not in keep]
            for sid in gone:
                self.conn.execute("DELETE FROM sources WHERE id=?", (sid,))
            if gone:
                self._cache = None
        stats["removed"] = len(gone)
        return stats

    # ------------------------------------------------------------------ search
    def _matrix(self) -> tuple[np.ndarray, list[int]]:
        with self._lock:
            if self._cache is None:
                rows = self.conn.execute("SELECT id, emb FROM chunks").fetchall()
                if rows:
                    mat = np.vstack([np.frombuffer(r["emb"], dtype=np.float32) for r in rows])
                else:
                    mat = np.zeros((0, 1), dtype=np.float32)
                self._cache = (mat, [r["id"] for r in rows])
            return self._cache

    async def search(self, query: str, k: int = 5, min_score: float = 0.0,
                     collections: Optional[list[str]] = None) -> list[dict]:
        mat, ids = self._matrix()
        if not ids:
            return []
        q = (await self.embed([query], "query"))[0]
        if mat.shape[1] != q.shape[0]:
            return []  # index built with another embedding model; re-index needed
        scores = mat @ q
        order = np.argsort(-scores)
        out = []
        with self._lock:
            for idx in order[: max(k * 6, 30)]:
                if scores[idx] < min_score:
                    break
                r = self.conn.execute(
                    "SELECT c.text, c.heading, c.start_line, c.end_line, s.path, s.title, s.kind, s.collection "
                    "FROM chunks c JOIN sources s ON s.id=c.source_id WHERE c.id=?", (ids[idx],)).fetchone()
                if not r or (collections and r["collection"] not in collections):
                    continue
                out.append({"score": round(float(scores[idx]), 3), "text": r["text"], "heading": r["heading"],
                            "path": r["path"], "title": r["title"], "kind": r["kind"],
                            "collection": r["collection"], "lines": [r["start_line"], r["end_line"]]})
                if len(out) >= k:
                    break
        return out

    # ------------------------------------------------------------------ admin
    def sources(self) -> list[dict]:
        with self._lock:
            return [dict(r) for r in self.conn.execute(
                "SELECT id, kind, collection, path, title, chunks, embed_model, updated_at FROM sources "
                "ORDER BY collection, title")]

    def collections(self) -> list[dict]:
        with self._lock:
            return [dict(r) for r in self.conn.execute(
                "SELECT collection, kind, COUNT(*) AS files, SUM(chunks) AS chunks, MAX(updated_at) AS updated_at "
                "FROM sources GROUP BY collection, kind ORDER BY kind, collection")]

    def delete_collection(self, collection: str) -> int:
        with self._lock:
            n = self.conn.execute("DELETE FROM sources WHERE collection=?", (collection,)).rowcount
            self._cache = None
            return n

    def delete_source(self, sid: int) -> bool:
        with self._lock:
            ok = self.conn.execute("DELETE FROM sources WHERE id=?", (sid,)).rowcount > 0
            self._cache = None
            return ok

    def counts(self) -> dict:
        with self._lock:
            s = self.conn.execute("SELECT COUNT(*) FROM sources").fetchone()[0]
            c = self.conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
        return {"sources": s, "chunks": c}


_store: Optional[KnowledgeStore] = None


def get_store() -> KnowledgeStore:
    global _store
    if _store is None:
        _store = KnowledgeStore(DATA_DIR / "knowledge.db")
    return _store


def format_context(hits: list[dict]) -> str:
    blocks = []
    for n, h in enumerate(hits, 1):
        where = h["title"] + (f" (lines {h['lines'][0]}-{h['lines'][1]})" if h["kind"] == "project" else "")
        if h.get("heading"):
            where += f" — {h['heading']}"
        blocks.append(f"[{n}] {where}\n{h['text']}")
    return "\n\n".join(blocks)
