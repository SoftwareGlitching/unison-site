@echo off
rem Give UNISON a much smarter brain: its own "unison" model built on Qwen3, sized for your GPU.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\upgrade_brain.ps1" %*
