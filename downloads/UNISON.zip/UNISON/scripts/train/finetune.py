"""
Fine-tune UNISON's brain (Gemma 4 12B) on the coding set with Unsloth: 4-bit QLoRA, so it fits a 12 GB card.
Saves a LoRA adapter (small, ~200 MB) with checkpoints you can resume from, then optionally a merged model.

  python finetune.py --data datasets/training/unison-code-standard.jsonl --out models/unison-code
  python finetune.py ... --resume            continue after a crash / reboot from the last checkpoint

Runs in the separate training environment (.train-venv), never in UNISON's own.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

BASE = "unsloth/gemma-4-12B-it"


def log(msg: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--base", default=BASE)
    ap.add_argument("--seq", type=int, default=2048)
    ap.add_argument("--epochs", type=float, default=1.0)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--rank", type=int, default=16)
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--merge", action="store_true", help="also save a merged 16-bit model (needs ~25 GB disk)")
    ap.add_argument("--merge-only", action="store_true", help="skip training: merge the saved adapter into a full model")
    a = ap.parse_args()
    if a.merge_only:
        return merge_only(Path(a.out), a.seq)

    os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")
    import torch
    if not torch.cuda.is_available():
        log("XX  PyTorch can't see the NVIDIA graphics card. Update the NVIDIA driver and run Train-UNISON.bat again.")
        return 2
    gpu = torch.cuda.get_device_properties(0)
    log(f"GPU: {gpu.name}, {gpu.total_memory / 2**30:.1f} GB")

    from unsloth import FastModel
    from unsloth.chat_templates import get_chat_template, train_on_responses_only
    from datasets import load_dataset
    from trl import SFTConfig, SFTTrainer

    log(f"Loading {a.base} in 4-bit (first time downloads ~8 GB)...")
    model, tokenizer = FastModel.from_pretrained(model_name=a.base, max_seq_length=a.seq, load_in_4bit=True,
                                                 full_finetuning=False)
    model = FastModel.get_peft_model(
        model, finetune_vision_layers=False, finetune_language_layers=True, finetune_attention_modules=True,
        finetune_mlp_modules=True, r=a.rank, lora_alpha=a.rank, lora_dropout=0, bias="none", random_state=3407,
        use_gradient_checkpointing="unsloth")
    tokenizer = get_chat_template(tokenizer, chat_template="gemma-4")

    ds = load_dataset("json", data_files=a.data, split="train")

    def fmt(batch):
        texts = [tokenizer.apply_chat_template(m, tokenize=False, add_generation_prompt=False).removeprefix("<bos>")
                 for m in batch["messages"]]
        return {"text": texts}
    ds = ds.map(fmt, batched=True, remove_columns=[c for c in ds.column_names if c != "messages"])
    log(f"{len(ds)} training examples")

    out = Path(a.out)
    ckpt = out / "checkpoints"
    trainer = SFTTrainer(
        model=model, tokenizer=tokenizer, train_dataset=ds, eval_dataset=None,
        args=SFTConfig(dataset_text_field="text", max_seq_length=a.seq, per_device_train_batch_size=1,
                       gradient_accumulation_steps=8, warmup_steps=10, num_train_epochs=a.epochs,
                       learning_rate=a.lr, logging_steps=5, optim="adamw_8bit", weight_decay=0.001,
                       lr_scheduler_type="cosine", seed=3407, output_dir=str(ckpt), save_steps=50,
                       save_total_limit=3, report_to="none", dataset_num_proc=1))
    # learn only the answers, not the questions
    trainer = train_on_responses_only(trainer, instruction_part="<|turn>user\n", response_part="<|turn>model\n")

    resume = a.resume and ckpt.exists() and any(ckpt.glob("checkpoint-*"))
    log("Training" + (" (resuming from the last checkpoint)" if resume else "") + "... progress below.")
    started = time.time()
    stats = trainer.train(resume_from_checkpoint=True if resume else None)
    log(f"Training finished in {(time.time() - started) / 3600:.1f} h, final loss {stats.training_loss:.3f}")

    adapter = out / "adapter"
    model.save_pretrained(str(adapter))
    tokenizer.save_pretrained(str(adapter))
    log(f"Saved the LoRA adapter -> {adapter}")
    if a.merge:
        merged = out / "merged"
        log("Saving the merged model (16-bit, big)...")
        model.save_pretrained_merged(str(merged), tokenizer, save_method="merged_16bit")
        log(f"Saved -> {merged}")
    (out / "trained.json").write_text(json.dumps({
        "base": a.base, "data": a.data, "examples": len(ds), "seq": a.seq, "rank": a.rank, "lr": a.lr,
        "epochs": a.epochs, "loss": stats.training_loss, "hours": round((time.time() - started) / 3600, 2),
        "finished": time.strftime("%Y-%m-%dT%H:%M:%S")}, indent=2), encoding="utf-8")
    return 0


def merge_only(out: Path, seq: int) -> int:
    """Base + saved adapter -> one merged 16-bit model folder that Ollama can import."""
    from unsloth import FastModel
    adapter = out / "adapter"
    if not adapter.exists():
        log(f"XX  No adapter at {adapter} - train first.")
        return 2
    log("Loading the base model + your trained adapter...")
    model, tokenizer = FastModel.from_pretrained(model_name=str(adapter), max_seq_length=seq, load_in_4bit=True)
    merged = out / "merged"
    log("Merging and saving (16-bit, ~24 GB)...")
    model.save_pretrained_merged(str(merged), tokenizer, save_method="merged_16bit")
    log(f"Saved -> {merged}")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:  # noqa: BLE001
        msg = str(e)
        if "out of memory" in msg.lower():
            log("XX  The graphics card ran out of memory. Close games/other apps and run again; Train-UNISON.bat retries "
                "with a shorter example length automatically.")
            sys.exit(3)
        raise
