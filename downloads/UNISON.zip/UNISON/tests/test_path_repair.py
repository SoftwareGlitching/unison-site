"""Paths a model gets slightly wrong still land in the right workspace (OneDrive Desktop, repeated names)."""
import tempfile
import unittest
from pathlib import Path

from tests.helpers import IsolatedSettings  # noqa: I001
from backend.core.config import settings
from backend.tools.base import ToolError
from backend.tools.sandbox import workspaces


class PathRepairTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "OneDrive" / "Desktop" / "python shooter"
        self.root.mkdir(parents=True)

    def tearDown(self):
        self.tmp.cleanup()

    def test_wrong_desktop_is_rerooted(self):
        with IsolatedSettings():
            settings.set("tools", "workspaces", [str(self.root)])
            wrong = Path(self.tmp.name) / "Desktop" / "python shooter" / "game" / "main.py"
            self.assertEqual(workspaces.resolve(str(wrong)), (self.root / "game" / "main.py").resolve())

    def test_repeated_workspace_name_is_dropped(self):
        with IsolatedSettings():
            settings.set("tools", "workspaces", [str(self.root)])
            self.assertEqual(workspaces.resolve("python shooter/main.py"), (self.root / "main.py").resolve())
            self.assertEqual(workspaces.resolve("main.py"), (self.root / "main.py").resolve())

    def test_unrelated_paths_still_refused(self):
        with IsolatedSettings():
            settings.set("tools", "workspaces", [str(self.root)])
            with self.assertRaises(ToolError):
                workspaces.resolve(str(Path(self.tmp.name) / "elsewhere" / "x.py"))
            with self.assertRaises(ToolError):
                workspaces.resolve("../../x.py")

    def test_added_folder_becomes_default(self):
        other = Path(self.tmp.name) / "other"
        other.mkdir()
        with IsolatedSettings():
            settings.set("tools", "workspaces", [str(other)])
            workspaces.add(str(self.root), make_default=True)
            self.assertEqual(workspaces.default, self.root.resolve())


if __name__ == "__main__":
    unittest.main()
