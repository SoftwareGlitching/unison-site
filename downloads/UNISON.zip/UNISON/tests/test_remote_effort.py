"""Phone/website chats run with the PC's effort setting (Eco = part of the brain on the GPU, small context)."""
import asyncio
import unittest
from types import SimpleNamespace

from tests.helpers import IsolatedSettings  # noqa: I001
from backend.api import routes
from backend.api.schemas import OAChatRequest
from backend.core.config import settings
from backend.inference.base import GenerationStats, StreamEvent
from backend.inference.manager import ModelManager


class CapturingBackend:
    name = "fake"

    def __init__(self):
        self.calls = []

    async def chat_stream(self, model, messages, options, keep_alive=None, tools=None, think=None):
        self.calls.append({"options": options, "keep_alive": keep_alive})
        yield StreamEvent("token", "hi")
        yield StreamEvent("done", stats=GenerationStats(model=model, completion_tokens=1))


def remote_chat(mgr, plan="owner"):
    async def go():
        orig_mgr, orig_sr = routes.manager, routes.StreamingResponse
        routes.manager, routes.StreamingResponse = mgr, (lambda gen, **k: gen)
        try:
            mgr.resolve_model = lambda m: asyncio.sleep(0, "unison:latest")
            req = OAChatRequest(messages=[{"role": "user", "content": "hey"}], stream=True)
            request = SimpleNamespace(state=SimpleNamespace(guest="key1", guest_plan=plan), client=SimpleNamespace(host="100.1.2.3"))
            gen = await routes.chat_completions(req, request, ident={})
            return [p async for p in gen]
        finally:
            routes.manager, routes.StreamingResponse = orig_mgr, orig_sr
    return asyncio.run(asyncio.wait_for(go(), 10))


class RemoteEffortTests(unittest.TestCase):
    def check(self, effort, num_gpu, num_ctx, keep):
        with IsolatedSettings():
            settings.set("inference", "effort", effort)
            settings.set("inference", "num_ctx", 8192)        # an old saved context no longer shrinks it
            backend = CapturingBackend()
            remote_chat(ModelManager(backend))
            call = backend.calls[-1]
            self.assertEqual(call["options"].num_gpu, num_gpu)
            self.assertEqual(call["options"].num_ctx, num_ctx)
            self.assertEqual(call["keep_alive"], keep)

    def test_eco_on_the_pc_means_eco_on_the_phone(self):
        from unittest import mock
        with mock.patch("backend.inference.manager.free_ram_gb", return_value=12.0):
            self.check("eco", 36, 8192, "15m")

    def test_balanced_and_max(self):
        self.check("balanced", None, 16384, "1h")
        self.check("max", None, 24576, "4h")


class LowRamTests(unittest.TestCase):
    def test_eco_moves_onto_the_gpu_when_ram_is_short(self):
        from unittest import mock
        from backend.inference import manager as m
        with mock.patch.object(m, "free_ram_gb", return_value=4.2):
            self.assertEqual(m.gpu_layers_for(36), 42)
        with mock.patch.object(m, "free_ram_gb", return_value=2.0):
            self.assertIsNone(m.gpu_layers_for(36))
        self.assertIsNone(m.gpu_layers_for(None))

    def test_ram_failure_retries_with_everything_on_the_gpu(self):
        from unittest import mock
        from backend.inference import manager as m
        from backend.inference.base import InferenceError

        class FailOnce(CapturingBackend):
            async def chat_stream(self, model, messages, options, keep_alive=None, tools=None, think=None):
                self.calls.append({"options": options, "keep_alive": keep_alive, "num_gpu": options.num_gpu})
                if len(self.calls) == 1:
                    raise InferenceError("llama runner process has terminated: unable to allocate CUDA_Host buffer", 500, "engine_error")
                yield StreamEvent("token", "hi")
                yield StreamEvent("done", stats=GenerationStats(model=model, completion_tokens=1))

        with IsolatedSettings(), mock.patch.object(m, "free_ram_gb", return_value=12.0):
            settings.set("inference", "effort", "eco")
            backend = FailOnce()
            mgr = ModelManager(backend)
            parts = remote_chat(mgr)
            self.assertEqual([c["num_gpu"] for c in backend.calls], [36, None])
            self.assertTrue(any('"hi"' in p for p in parts))
            self.assertTrue(mgr.all_on_gpu)
            self.assertIsNone(mgr.default_options().num_gpu)     # stays on the GPU after that



class PcSafetyTests(unittest.TestCase):
    def test_threads_capped_by_effort(self):
        from unittest import mock
        from backend.inference import manager as m
        from backend.inference.ollama_backend import build_ollama_options
        with IsolatedSettings(), mock.patch.object(m, "free_ram_gb", return_value=12.0):
            mgr = ModelManager(CapturingBackend())
            for eff, n in (("eco", 4), ("balanced", 6), ("max", 8)):
                settings.set("inference", "effort", eff)
                self.assertEqual(build_ollama_options(mgr.default_options())["num_thread"], n)

    def test_low_ram_unloads_idle_brain_and_it_rests(self):
        from unittest import mock
        from backend.core import memwatch
        from backend.inference import manager as m

        class B(CapturingBackend):
            unloaded = []

            async def unload(self, model):
                self.unloaded.append(model)

            async def loaded_models(self):
                return []

        with IsolatedSettings():
            settings.set("inference", "active_model", "unison")
            mgr = ModelManager(B())
            with mock.patch.object(m, "manager", mgr):
                note = asyncio.run(memwatch.guard({"pc_free_mb": 800, "ollama": 6000}))
                self.assertIn("unloaded", note)
                self.assertEqual(B.unloaded, ["unison"])
                st = asyncio.run(mgr.brain_status())
                self.assertEqual((st["state"], st["ready"]), ("resting", True))   # Send still works
                self.assertIsNone(asyncio.run(memwatch.guard({"pc_free_mb": 8000, "ollama": 6000})))

    def test_hot_gpu_waits_then_continues(self):
        from unittest import mock
        from backend.core import memwatch
        temps = iter([90, 85, 70])
        real_sleep = asyncio.sleep
        with mock.patch.object(memwatch, "gpu_temp", side_effect=lambda: next(temps)), \
             mock.patch.object(memwatch.asyncio, "sleep", new=lambda s: real_sleep(0)):
            asyncio.run(memwatch.wait_if_hot())
        self.assertRaises(StopIteration, next, temps)       # read three times: hot, still hot, cool


if __name__ == "__main__":
    unittest.main()
