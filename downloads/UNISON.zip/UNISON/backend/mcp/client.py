"""
Model Context Protocol (MCP) client for stdio servers.

UNISON launches each configured server as a child process and speaks JSON-RPC 2.0 over its
stdin/stdout (one JSON message per line). Tools the server offers are added to UNISON's tool
registry as `<server>__<tool>` and always go through UNISON's permission checks (default: ask).

Servers are configured in config/mcp.json:
{
  "servers": {
    "filesystem": {"command": "npx", "args": ["-y", "@modelcontextprotocol/server-filesystem", "C:\\\\Projects"],
                   "env": {}, "enabled": false}
  }
}
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
from collections import deque
from pathlib import Path
from typing import Any, Optional

from .. import __version__
from ..core.config import CONFIG_DIR
from ..tools.base import Tool, ToolResult
from ..tools.registry import audit, registry
from ..tools.sandbox import workspaces

PROTOCOL_VERSION = "2025-06-18"
MCP_CONFIG = CONFIG_DIR / "mcp.json"


class MCPError(Exception):
    pass


def safe_name(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]", "_", text)[:64]


def _resolve_command(command: str, args: list[str]) -> list[str]:
    exe = shutil.which(command) or command
    if sys.platform == "win32" and exe.lower().endswith((".cmd", ".bat")):
        return ["cmd.exe", "/d", "/c", exe, *args]
    return [exe, *args]


class MCPServer:
    def __init__(self, name: str, command: str, args: Optional[list[str]] = None,
                 env: Optional[dict] = None, cwd: Optional[str] = None):
        self.name = name
        self.command = command
        self.args = list(args or [])
        self.env = env or {}
        self.cwd = cwd
        self.proc: Optional[subprocess.Popen] = None
        self.loop: Optional[asyncio.AbstractEventLoop] = None
        self._next_id = 1
        self._pending: dict[int, asyncio.Future] = {}
        self._lock = threading.Lock()
        self.stderr_tail: deque[str] = deque(maxlen=50)
        self.server_info: dict = {}
        self.tools: list[dict] = []
        self.status = "stopped"
        self.error = ""

    # ------------------------------------------------------------------ lifecycle
    async def start(self, timeout: float = 60.0) -> None:
        self.loop = asyncio.get_running_loop()
        self.status = "starting"
        cmd = _resolve_command(self.command, self.args)
        flags = 0x08000000 if sys.platform == "win32" else 0  # no console window
        try:
            self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                         cwd=self.cwd, env={**os.environ, **self.env}, creationflags=flags)
        except OSError as e:
            self.status, self.error = "failed", f"Could not start '{self.command}': {e}"
            raise MCPError(self.error) from e
        threading.Thread(target=self._read_stdout, daemon=True).start()
        threading.Thread(target=self._read_stderr, daemon=True).start()
        try:
            self.server_info = await self.request("initialize", {
                "protocolVersion": PROTOCOL_VERSION,
                "capabilities": {"roots": {"listChanged": False}},
                "clientInfo": {"name": "unison", "version": __version__},
            }, timeout)
            self.notify("notifications/initialized")
            await self.refresh_tools()
            self.status, self.error = "running", ""
        except Exception as e:
            self.stop()
            self.status = "failed"
            tail = " | ".join(list(self.stderr_tail)[-5:])
            self.error = f"{e}" + (f" (server said: {tail})" if tail else "")
            raise MCPError(self.error) from e

    def stop(self) -> None:
        was_running = self.status == "running"
        self.status = "stopping"
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.stdin.close()
                self.proc.terminate()
                self.proc.wait(timeout=5)
            except Exception:  # noqa: BLE001
                self.proc.kill()
        if self.proc:
            for pipe in (self.proc.stdout, self.proc.stderr):
                try:
                    if pipe:
                        pipe.close()
                except Exception:  # noqa: BLE001
                    pass
        for fut in self._pending.values():
            if not fut.done() and self.loop:
                self.loop.call_soon_threadsafe(fut.set_exception, MCPError("server stopped"))
        self._pending.clear()
        self.status = "stopped" if was_running or self.status == "stopping" else self.status

    # ------------------------------------------------------------------ io threads
    def _read_stdout(self) -> None:
        assert self.proc and self.proc.stdout
        for raw in self.proc.stdout:
            line = raw.decode("utf-8", "replace").strip()
            if not line:
                continue
            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                self.stderr_tail.append(f"(non-JSON stdout) {line[:200]}")
                continue
            if self.loop:
                self.loop.call_soon_threadsafe(self._dispatch, msg)
        if self.loop:
            self.loop.call_soon_threadsafe(self._on_exit)

    def _read_stderr(self) -> None:
        assert self.proc and self.proc.stderr
        for raw in self.proc.stderr:
            self.stderr_tail.append(raw.decode("utf-8", "replace").rstrip()[:500])

    def _on_exit(self) -> None:
        if self.status in ("running", "starting"):
            self.status = "failed"
            self.error = "server process exited" + (f": {self.stderr_tail[-1]}" if self.stderr_tail else "")
        for fut in list(self._pending.values()):
            if not fut.done():
                fut.set_exception(MCPError(self.error or "server exited"))
        self._pending.clear()

    def _dispatch(self, msg: dict) -> None:
        if "id" in msg and ("result" in msg or "error" in msg):
            fut = self._pending.pop(msg["id"], None)
            if fut and not fut.done():
                if "error" in msg:
                    err = msg["error"] or {}
                    fut.set_exception(MCPError(f"{err.get('message', 'error')} (code {err.get('code')})"))
                else:
                    fut.set_result(msg["result"])
        elif "method" in msg and "id" in msg:
            self._answer_server_request(msg)
        # notifications from the server (logging, progress, list_changed) are ignored for now

    def _answer_server_request(self, msg: dict) -> None:
        if msg["method"] == "roots/list":
            roots = [{"uri": Path(w).resolve().as_uri(), "name": Path(w).name} for w in workspaces.list()]
            self._send({"jsonrpc": "2.0", "id": msg["id"], "result": {"roots": roots}})
        elif msg["method"] == "ping":
            self._send({"jsonrpc": "2.0", "id": msg["id"], "result": {}})
        else:
            self._send({"jsonrpc": "2.0", "id": msg["id"],
                        "error": {"code": -32601, "message": f"UNISON does not support {msg['method']}"}})

    def _send(self, obj: dict) -> None:
        if not self.proc or self.proc.poll() is not None or not self.proc.stdin:
            raise MCPError(f"MCP server '{self.name}' is not running")
        data = (json.dumps(obj) + "\n").encode("utf-8")
        with self._lock:
            self.proc.stdin.write(data)
            self.proc.stdin.flush()

    # ------------------------------------------------------------------ rpc
    def notify(self, method: str, params: Optional[dict] = None) -> None:
        msg: dict[str, Any] = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            msg["params"] = params
        self._send(msg)

    async def request(self, method: str, params: Optional[dict] = None, timeout: float = 120.0) -> dict:
        rid = self._next_id
        self._next_id += 1
        fut = asyncio.get_running_loop().create_future()
        self._pending[rid] = fut
        msg: dict[str, Any] = {"jsonrpc": "2.0", "id": rid, "method": method}
        if params is not None:
            msg["params"] = params
        self._send(msg)
        try:
            return await asyncio.wait_for(fut, timeout)
        except asyncio.TimeoutError as e:
            self._pending.pop(rid, None)
            raise MCPError(f"'{method}' timed out after {timeout:.0f}s") from e

    async def refresh_tools(self) -> list[dict]:
        tools, cursor = [], None
        for _ in range(20):
            res = await self.request("tools/list", {"cursor": cursor} if cursor else {})
            tools += res.get("tools", [])
            cursor = res.get("nextCursor")
            if not cursor:
                break
        self.tools = tools
        return tools

    async def call_tool(self, name: str, arguments: dict, timeout: float = 300.0) -> ToolResult:
        res = await self.request("tools/call", {"name": name, "arguments": arguments or {}}, timeout)
        parts = []
        for c in res.get("content", []):
            t = c.get("type")
            if t == "text":
                parts.append(c.get("text", ""))
            elif t == "resource":
                r = c.get("resource", {})
                parts.append(r.get("text") or f"[resource {r.get('uri')}]")
            elif t == "image":
                parts.append(f"[image {c.get('mimeType', '')}, {len(c.get('data', ''))} bytes base64]")
            else:
                parts.append(f"[{t} content]")
        if res.get("structuredContent") and not parts:
            parts.append(json.dumps(res["structuredContent"], indent=2))
        return ToolResult(not res.get("isError", False), "\n".join(parts) or "(no output)")

    def info(self) -> dict:
        return {"name": self.name, "status": self.status, "error": self.error, "command": self.command,
                "args": self.args, "tools": [t.get("name") for t in self.tools],
                "server": (self.server_info or {}).get("serverInfo", {}),
                "stderr_tail": list(self.stderr_tail)[-10:]}


class MCPManager:
    def __init__(self) -> None:
        self.servers: dict[str, MCPServer] = {}

    # ---------------- config ----------------
    def load_config(self) -> dict:
        if not MCP_CONFIG.exists():
            return {"servers": {}}
        return json.loads(MCP_CONFIG.read_text(encoding="utf-8-sig") or '{"servers": {}}')

    def save_config(self, cfg: dict) -> None:
        MCP_CONFIG.write_text(json.dumps(cfg, indent=2), encoding="utf-8")

    def upsert(self, name: str, command: str, args: list[str], env: Optional[dict] = None, enabled: bool = True) -> dict:
        name = safe_name(name)
        cfg = self.load_config()
        cfg.setdefault("servers", {})[name] = {"command": command, "args": args, "env": env or {}, "enabled": enabled}
        self.save_config(cfg)
        return cfg["servers"][name]

    def remove(self, name: str) -> None:
        cfg = self.load_config()
        cfg.get("servers", {}).pop(name, None)
        self.save_config(cfg)

    # ---------------- lifecycle ----------------
    async def start(self, name: str) -> MCPServer:
        conf = self.load_config().get("servers", {}).get(name)
        if not conf:
            raise MCPError(f"No MCP server named '{name}' in config/mcp.json")
        await self.stop(name)
        srv = MCPServer(name, conf["command"], conf.get("args"), conf.get("env"), conf.get("cwd"))
        self.servers[name] = srv
        await srv.start()
        self._register(srv)
        audit({"mcp": name, "event": "started", "tools": len(srv.tools)})
        return srv

    async def stop(self, name: str) -> None:
        srv = self.servers.pop(name, None)
        registry.unregister_source(f"mcp:{name}")
        if srv:
            await asyncio.to_thread(srv.stop)
            audit({"mcp": name, "event": "stopped"})

    async def start_enabled(self) -> None:
        for name, conf in self.load_config().get("servers", {}).items():
            if conf.get("enabled"):
                try:
                    await self.start(name)
                except MCPError:
                    pass  # status shows the error in the app

    async def stop_all(self) -> None:
        for name in list(self.servers):
            await self.stop(name)

    def status(self) -> list[dict]:
        cfg = self.load_config().get("servers", {})
        out = []
        for name, conf in cfg.items():
            srv = self.servers.get(name)
            info = srv.info() if srv else {"name": name, "status": "stopped", "error": "", "tools": [],
                                             "command": conf.get("command"), "args": conf.get("args", [])}
            info["enabled"] = bool(conf.get("enabled"))
            out.append(info)
        return out

    def _register(self, srv: MCPServer) -> None:
        registry.unregister_source(f"mcp:{srv.name}")
        for t in srv.tools:
            tool_name = t.get("name", "")
            full = safe_name(f"{srv.name}__{tool_name}")

            async def handler(args: dict, _srv=srv, _tool=tool_name) -> ToolResult:
                return await _srv.call_tool(_tool, args)

            schema = t.get("inputSchema") or {"type": "object", "properties": {}}
            desc = (t.get("description") or tool_name).strip()
            registry.register(Tool(full, f"[{srv.name} MCP] {desc}"[:1000], schema, "external", handler,
                                   source=f"mcp:{srv.name}", default_mode="ask"))


mcp_manager = MCPManager()
