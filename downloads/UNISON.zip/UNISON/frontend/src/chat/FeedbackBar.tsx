import { useState } from "react";
import { api } from "../lib/api";

/** 👍 / 👎 on a reply. A thumbs-down can say what was wrong and/or what UNISON should have said: UNISON
 *  reads these as lessons on its very next reply (backend/training/lessons.py), and they're kept for fine-tuning. */
export function FeedbackBar({
  messageId,
  rating,
  onChange,
}: {
  messageId: string;
  rating: number | null;
  onChange: (rating: number | null) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [text, setText] = useState("");
  const [note, setNote] = useState("");
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");

  const rate = async (r: 1 | -1) => {
    setError("");
    try {
      if (rating === r) {
        await api.clearFeedback(messageId);
        onChange(null);
        setEditing(false);
        return;
      }
      await api.feedback(messageId, r);
      onChange(r);
      setEditing(r === -1);
    } catch (e: any) {
      setError(e.message);
    }
  };

  const saveCorrection = async () => {
    try {
      await api.feedback(messageId, -1, text.trim(), note.trim());
      setEditing(false);
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } catch (e: any) {
      setError(e.message);
    }
  };

  return (
    <>
      <button className={`fb ${rating === 1 ? "on" : ""}`} title="Good answer - UNISON keeps doing this" onClick={() => rate(1)}>
        👍
      </button>
      <button className={`fb ${rating === -1 ? "on bad" : ""}`} title="Bad answer" onClick={() => rate(-1)}>
        👎
      </button>
      {error && <span className="bad-t">{error}</span>}
      {saved && <span className="small ok-t">Got it - UNISON will remember</span>}
      {editing && (
        <div className="correction">
          <input
            className="approval-note"
            placeholder="What was wrong? (e.g. too long, don't lecture me, wrong answer)"
            value={note}
            maxLength={300}
            onChange={(e) => setNote(e.target.value)}
          />
          <textarea
            rows={3}
            placeholder="Optional: what should UNISON have said instead?"
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
          <div className="approval-actions">
            <button className="approve" onClick={saveCorrection} disabled={!text.trim() && !note.trim()}>
              Teach UNISON
            </button>
            <button className="deny" onClick={() => setEditing(false)}>
              Skip
            </button>
          </div>
        </div>
      )}
    </>
  );
}
