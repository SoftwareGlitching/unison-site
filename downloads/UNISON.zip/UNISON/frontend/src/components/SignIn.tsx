import { useEffect, useRef, useState } from "react";
import { auth } from "../lib/api";

/**
 * Sign-in gate. Shows:
 *  - a "create a password" screen on first run (only possible from the PC), or
 *  - a password prompt, when a password is already set.
 * Calls onDone() once a session token is stored.
 */
export function SignIn({ onDone }: { onDone: () => void }) {
  const [mode, setMode] = useState<"loading" | "setup" | "login" | "cant_set">("loading");
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [code, setCode] = useState("");
  const [needCode, setNeedCode] = useState(false);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const ref = useRef<HTMLInputElement>(null);

  useEffect(() => {
    auth
      .status()
      .then((s) => {
        setNeedCode(!!s.code_required);
        setMode(s.password_set ? "login" : s.can_set_here ? "setup" : "cant_set");
      })
      .catch((e) => setErr(e.message));
  }, []);

  useEffect(() => {
    ref.current?.focus();
  }, [mode]);

  const submit = async () => {
    setErr("");
    if (mode === "setup") {
      if (pw.length < 6) return setErr("Use at least 6 characters.");
      if (pw !== pw2) return setErr("The two passwords don't match.");
    }
    setBusy(true);
    try {
      if (mode === "setup") await auth.setup(pw);
      else await auth.login(pw, needCode ? code : undefined);
      onDone();
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="signin">
      <div className="signin-card">
        <svg viewBox="0 0 32 32" className="brand-mark" aria-hidden>
          <circle cx="12" cy="16" r="7" />
          <circle cx="20" cy="16" r="7" className="second" />
        </svg>
        <div className="signin-title">UNISON</div>

        {mode === "loading" && <div className="dim">connecting…</div>}

        {mode === "cant_set" && (
          <p className="dim">
            This UNISON needs a password, and it can only be created on the PC it runs on. Open UNISON there once
            to set it, then sign in here.
          </p>
        )}

        {(mode === "setup" || mode === "login") && (
          <>
            <p className="signin-sub">
              {mode === "setup"
                ? "Create a password. You'll use it to sign in here and on your phone."
                : needCode ? "Enter your password and the code from your phone." : "Enter your password."}
            </p>
            <input
              ref={ref}
              type="password"
              className="signin-input"
              placeholder="Password"
              value={pw}
              autoComplete={mode === "setup" ? "new-password" : "current-password"}
              onChange={(e) => setPw(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && mode === "login" && !needCode && submit()}
            />
            {mode === "login" && needCode && (
              <>
                <div className="signin-label">6-digit code from your authenticator app</div>
                <input
                  className="signin-input code"
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  placeholder="000000"
                  maxLength={7}
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/[^0-9]/g, "").slice(0, 6))}
                  onKeyDown={(e) => e.key === "Enter" && submit()}
                />
              </>
            )}
            {mode === "setup" && (
              <input
                type="password"
                className="signin-input"
                placeholder="Repeat password"
                value={pw2}
                autoComplete="new-password"
                onChange={(e) => setPw2(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && submit()}
              />
            )}
            {err && <div className="signin-err">{err}</div>}
            <button className="signin-btn" disabled={busy || !pw || (mode === "login" && needCode && code.length !== 6)} onClick={submit}>
              {busy ? "…" : mode === "setup" ? "Create password & continue" : "Sign in"}
            </button>
            <div className="signin-foot">{needCode ? "2-step sign-in is on for this link" : "Runs entirely on your computer · nothing is sent to the cloud"}</div>
          </>
        )}
        {err && mode === "loading" && <div className="signin-err">{err}</div>}
      </div>
    </div>
  );
}
