"""
SQLite storage for UNISON's structured data (conversations, messages, API keys).
Everything lives in data/unison.db on your machine.
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator, Optional

from ..core.config import DATA_DIR

SCHEMA_VERSION = 2

SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL DEFAULT 'New conversation',
    model TEXT,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    model TEXT,
    stats TEXT,
    created_at REAL NOT NULL,
    seq INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conversation_id, seq);
CREATE TABLE IF NOT EXISTS feedback (
    id TEXT PRIMARY KEY,
    message_id TEXT NOT NULL,
    conversation_id TEXT NOT NULL,
    rating INTEGER NOT NULL,          -- 1 good, -1 bad
    correction TEXT,                  -- what the reply should have been (optional)
    note TEXT,
    created_at REAL NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_feedback_msg ON feedback(message_id);
CREATE TABLE IF NOT EXISTS api_keys (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    prefix TEXT NOT NULL,
    key_hash TEXT NOT NULL UNIQUE,
    created_at REAL NOT NULL,
    last_used_at REAL,
    revoked INTEGER NOT NULL DEFAULT 0
);
"""


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:20]}"


class Database:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(str(path), check_same_thread=False, isolation_level=None)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.executescript(SCHEMA)
        self._migrate()
        self._conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES('schema_version', ?)", (str(SCHEMA_VERSION),))

    def _migrate(self) -> None:
        cols = {r[1] for r in self._conn.execute("PRAGMA table_info(messages)")}
        for col in ("tool_calls", "tool_name", "meta"):
            if col not in cols:
                self._conn.execute(f"ALTER TABLE messages ADD COLUMN {col} TEXT")

    @contextmanager
    def tx(self) -> Iterator[sqlite3.Connection]:
        with self._lock:
            self._conn.execute("BEGIN")
            try:
                yield self._conn
                self._conn.execute("COMMIT")
            except BaseException:
                self._conn.execute("ROLLBACK")
                raise

    def query(self, sql: str, params: tuple = ()) -> list[sqlite3.Row]:
        with self._lock:
            return self._conn.execute(sql, params).fetchall()

    # ---------------- conversations ----------------
    def create_conversation(self, title: str = "New conversation", model: Optional[str] = None) -> dict:
        now = time.time()
        cid = new_id("conv")
        with self.tx() as c:
            c.execute("INSERT INTO conversations(id, title, model, created_at, updated_at) VALUES(?,?,?,?,?)",
                      (cid, title, model, now, now))
        return self.get_conversation(cid)

    def get_conversation(self, cid: str) -> Optional[dict]:
        rows = self.query("SELECT * FROM conversations WHERE id=?", (cid,))
        return dict(rows[0]) if rows else None

    def list_conversations(self, search: str = "", limit: int = 200) -> list[dict]:
        if search:
            like = f"%{search}%"
            rows = self.query(
                """SELECT DISTINCT c.* FROM conversations c LEFT JOIN messages m ON m.conversation_id=c.id
                   WHERE c.title LIKE ? OR m.content LIKE ? ORDER BY c.updated_at DESC LIMIT ?""",
                (like, like, limit))
        else:
            rows = self.query("SELECT * FROM conversations ORDER BY updated_at DESC LIMIT ?", (limit,))
        return [dict(r) for r in rows]

    def rename_conversation(self, cid: str, title: str) -> None:
        with self.tx() as c:
            c.execute("UPDATE conversations SET title=?, updated_at=? WHERE id=?", (title[:200], time.time(), cid))

    def delete_conversation(self, cid: str) -> bool:
        with self.tx() as c:
            cur = c.execute("DELETE FROM conversations WHERE id=?", (cid,))
            return cur.rowcount > 0

    # ---------------- messages ----------------
    def add_message(self, cid: str, role: str, content: str, model: Optional[str] = None,
                    stats: Optional[dict] = None, tool_calls: Optional[list] = None,
                    tool_name: Optional[str] = None, meta: Optional[dict] = None) -> dict:
        now = time.time()
        mid = new_id("msg")
        with self.tx() as c:
            seq = c.execute("SELECT COALESCE(MAX(seq), 0) + 1 FROM messages WHERE conversation_id=?", (cid,)).fetchone()[0]
            c.execute("INSERT INTO messages(id, conversation_id, role, content, model, stats, created_at, seq, "
                      "tool_calls, tool_name, meta) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                      (mid, cid, role, content, model, json.dumps(stats) if stats else None, now, seq,
                       json.dumps(tool_calls) if tool_calls else None, tool_name,
                       json.dumps(meta, default=str) if meta else None))
            c.execute("UPDATE conversations SET updated_at=?, model=COALESCE(?, model) WHERE id=?", (now, model, cid))
        return {"id": mid, "conversation_id": cid, "role": role, "content": content, "model": model,
                "stats": stats, "created_at": now, "seq": seq, "tool_calls": tool_calls,
                "tool_name": tool_name, "meta": meta}

    def messages(self, cid: str) -> list[dict]:
        rows = self.query("SELECT * FROM messages WHERE conversation_id=? ORDER BY seq", (cid,))
        out = []
        for r in rows:
            d = dict(r)
            for k in ("stats", "tool_calls", "meta"):
                d[k] = json.loads(d[k]) if d.get(k) else None
            out.append(d)
        return out

    def get_message(self, mid: str) -> Optional[dict]:
        rows = self.query("SELECT * FROM messages WHERE id=?", (mid,))
        if not rows:
            return None
        d = dict(rows[0])
        for k in ("stats", "tool_calls", "meta"):
            d[k] = json.loads(d[k]) if d.get(k) else None
        return d

    def delete_last_assistant(self, cid: str) -> bool:
        """Used by 'regenerate': drop everything after the last user message (reply + tool steps)."""
        with self.tx() as c:
            last_user = c.execute("SELECT MAX(seq) FROM messages WHERE conversation_id=? AND role='user'",
                                  (cid,)).fetchone()[0]
            if last_user is None:
                return False
            n = c.execute("DELETE FROM messages WHERE conversation_id=? AND seq>?", (cid, last_user)).rowcount
            return n > 0

    # ---------------- feedback (training data) ----------------
    def set_feedback(self, message_id: str, rating: int, correction: Optional[str] = None,
                     note: Optional[str] = None) -> dict:
        msg = self.get_message(message_id)
        if not msg or msg["role"] != "assistant":
            raise KeyError("assistant message not found")
        fid = new_id("fb")
        with self.tx() as c:
            c.execute("DELETE FROM feedback WHERE message_id=?", (message_id,))
            c.execute("INSERT INTO feedback(id, message_id, conversation_id, rating, correction, note, created_at) "
                      "VALUES(?,?,?,?,?,?,?)", (fid, message_id, msg["conversation_id"], rating, correction, note, time.time()))
        return {"id": fid, "message_id": message_id, "rating": rating}

    def clear_feedback(self, message_id: str) -> None:
        with self.tx() as c:
            c.execute("DELETE FROM feedback WHERE message_id=?", (message_id,))

    def feedback_rows(self) -> list[dict]:
        return [dict(r) for r in self.query("SELECT * FROM feedback ORDER BY created_at")]

    def feedback_for(self, cid: str) -> dict[str, dict]:
        return {r["message_id"]: dict(r) for r in self.query("SELECT * FROM feedback WHERE conversation_id=?", (cid,))}

    # ---------------- API keys ----------------
    def add_api_key(self, name: str, prefix: str, key_hash: str) -> dict:
        kid = new_id("key")
        with self.tx() as c:
            c.execute("INSERT INTO api_keys(id, name, prefix, key_hash, created_at) VALUES(?,?,?,?,?)",
                      (kid, name, prefix, key_hash, time.time()))
        return {"id": kid, "name": name, "prefix": prefix}

    def find_api_key(self, key_hash: str) -> Optional[dict]:
        rows = self.query("SELECT * FROM api_keys WHERE key_hash=? AND revoked=0", (key_hash,))
        if not rows:
            return None
        with self.tx() as c:
            c.execute("UPDATE api_keys SET last_used_at=? WHERE id=?", (time.time(), rows[0]["id"]))
        return dict(rows[0])

    def list_api_keys(self) -> list[dict]:
        return [dict(r) for r in self.query(
            "SELECT id, name, prefix, created_at, last_used_at, revoked FROM api_keys ORDER BY created_at DESC")]

    def revoke_api_key(self, kid: str) -> bool:
        with self.tx() as c:
            return c.execute("UPDATE api_keys SET revoked=1 WHERE id=?", (kid,)).rowcount > 0


_db: Optional[Database] = None


def get_db() -> Database:
    global _db
    if _db is None:
        _db = Database(DATA_DIR / "unison.db")
    return _db
