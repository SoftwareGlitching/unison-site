import { useEffect, useState } from "react";
import { api, type Health, type Metrics } from "../lib/api";

function Cell({ label, value, tone }: { label: string; value: string; tone?: "ok" | "warn" | "bad" | "live" }) {
  return (
    <div className={`tel-cell ${tone ?? ""}`}>
      <span className="tel-label">{label}</span>
      <span className="tel-value">{value}</span>
    </div>
  );
}

const gb = (b: number) => (b / 1e9).toFixed(1);

/** Live readings from /v1/system/metrics. Anything the system can't measure shows as "n/a". */
export function Telemetry({ refreshKey }: { refreshKey: number }) {
  const [m, setM] = useState<Metrics | null>(null);
  const [h, setH] = useState<Health | null>(null);
  const [offline, setOffline] = useState(false);

  useEffect(() => {
    let alive = true;
    const tick = async () => {
      try {
        const [mm, hh] = await Promise.all([api.metrics(), api.health()]);
        if (!alive) return;
        setM(mm);
        setH(hh);
        setOffline(false);
      } catch {
        if (alive) setOffline(true);
      }
    };
    tick();
    const id = setInterval(tick, 2000);
    return () => {
      alive = false;
      clearInterval(id);
    };
  }, [refreshKey]);

  if (offline) {
    return (
      <div className="telemetry">
        <Cell label="server" value="unreachable" tone="bad" />
      </div>
    );
  }
  const gpu = m?.system.gpus[0];
  const loaded = m?.loaded_models.find((x) => x.name === m.inference.active_model) ?? m?.loaded_models[0];
  const tps = m?.inference.last?.tokens_per_second;
  const engineOk = h?.engine.ok;
  const placement = loaded
    ? loaded.gpu_percent >= 99
      ? "GPU"
      : loaded.gpu_percent <= 0
        ? "CPU"
        : `${Math.round(loaded.gpu_percent)}% GPU`
    : "not loaded";

  return (
    <div className="telemetry">
      <Cell
        label="engine"
        value={engineOk ? `ollama ${h?.engine.version ?? ""}` : "offline"}
        tone={engineOk ? "ok" : "bad"}
      />
      <Cell
        label="state"
        value={m?.inference.state ?? "…"}
        tone={m?.inference.state === "generating" ? "live" : undefined}
      />
      <Cell label="tok/s" value={tps ? tps.toFixed(1) : "n/a"} />
      <Cell label="model mem" value={loaded ? `${gb(loaded.size_bytes)} GB · ${placement}` : placement} />
      <Cell
        label="vram"
        value={
          gpu && gpu.vram_used_mb != null && gpu.vram_total_mb != null
            ? `${(gpu.vram_used_mb / 1024).toFixed(1)}/${(gpu.vram_total_mb / 1024).toFixed(1)} GB`
            : "n/a"
        }
      />
      <Cell label="gpu" value={gpu?.utilization_percent != null ? `${gpu.utilization_percent}%` : "n/a"} />
      <Cell
        label="ram"
        value={m ? `${m.system.ram_used_gb.toFixed(1)}/${m.system.ram_total_gb.toFixed(0)} GB` : "…"}
        tone={m && m.system.ram_percent > 90 ? "warn" : undefined}
      />
      <Cell label="cpu" value={m ? `${Math.round(m.system.cpu_percent)}%` : "…"} />
    </div>
  );
}
