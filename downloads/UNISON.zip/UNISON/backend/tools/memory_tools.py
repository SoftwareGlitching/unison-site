"""Agent-mode tools for UNISON's long-term memory (see backend/core/memory.py)."""
from __future__ import annotations

from .base import Tool, ToolError, ToolResult


def _db():
    from ..database.db import get_db
    return get_db()


def remember(a: dict) -> ToolResult:
    from ..core import memory
    text = (a.get("fact") or "").strip()
    if not text:
        raise ToolError("fact is required")
    row = memory.add(_db(), text, "agent")
    return ToolResult(True, f"Remembered: {text}" if row else f"Already known: {text}")


def recall_chats(a: dict) -> ToolResult:
    from ..core import memory
    query = (a.get("query") or "").strip()
    if not query:
        raise ToolError("query is required")
    hits = memory.recall(_db(), query, k=6)
    if not hits:
        return ToolResult(True, f"No earlier conversation mentions '{query}'.")
    return ToolResult(True, "\n".join(f"[{h['when']}, \"{h['title']}\", {'user' if h['role'] == 'user' else 'UNISON'}] {h['text']}"
                                      for h in hits))


def _obj(props: dict, required: list[str]) -> dict:
    return {"type": "object", "properties": props, "required": required}


TOOLS = [
    Tool("remember",
         "Save a lasting fact about the user or their projects to long-term memory (kept across chats), e.g. "
         "\"Their Roblox game is called Sky Wars and uses Rojo\". Only for things worth knowing next time.",
         _obj({"fact": {"type": "string", "description": "The fact, in third person, one sentence"}}, ["fact"]),
         "read", remember, default_mode="auto"),
    Tool("recall_chats",
         "Search the user's earlier conversations with you (e.g. to find the game you built last week or what "
         "they said about a project).",
         _obj({"query": {"type": "string", "description": "Words to look for"}}, ["query"]),
         "read", recall_chats, default_mode="auto"),
]
