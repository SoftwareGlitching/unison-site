"""Split documents and source code into overlapping chunks that keep line numbers."""
from __future__ import annotations

import re
from dataclasses import dataclass

TARGET_CHARS = 1600
CODE_OVERLAP_LINES = 6

TEXT_EXTENSIONS = {
    ".md", ".markdown", ".txt", ".rst",
    ".py", ".lua", ".luau", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".cs", ".cpp", ".cc", ".c", ".h", ".hpp",
    ".java", ".kt", ".go", ".rs", ".swift", ".gd", ".shader", ".glsl", ".hlsl", ".sql",
    ".json", ".toml", ".yaml", ".yml", ".ini", ".cfg", ".xml", ".html", ".htm", ".css", ".scss",
    ".sh", ".ps1", ".bat", ".cmd", ".csproj", ".sln", ".gradle", ".cmake",
}
DOC_EXTENSIONS = {".md", ".markdown", ".txt", ".rst"}


@dataclass
class Chunk:
    text: str
    start_line: int
    end_line: int
    heading: str = ""


def chunk_markdown(text: str) -> list[Chunk]:
    lines = text.splitlines()
    sections: list[tuple[str, int, list[str]]] = []
    heading, start, buf = "", 1, []
    trail: list[str] = []
    for n, line in enumerate(lines, 1):
        m = re.match(r"^(#{1,4})\s+(.*)", line)
        if m:
            if any(x.strip() for x in buf):
                sections.append((heading, start, buf))
            level = len(m.group(1))
            trail = trail[:level - 1] + [m.group(2).strip()]
            heading, start, buf = " > ".join(trail), n, [line]
        else:
            buf.append(line)
    if any(x.strip() for x in buf):
        sections.append((heading, start, buf))

    chunks: list[Chunk] = []
    for heading, start, body in sections:
        cur, cur_start, size = [], start, 0
        for off, line in enumerate(body):
            if size + len(line) > TARGET_CHARS and cur and (not line.strip() or size > TARGET_CHARS * 1.4):
                chunks.append(Chunk("\n".join(cur).strip(), cur_start, cur_start + len(cur) - 1, heading))
                cur, cur_start, size = [], start + off, 0
            cur.append(line)
            size += len(line) + 1
        if "".join(cur).strip():
            chunks.append(Chunk("\n".join(cur).strip(), cur_start, cur_start + len(cur) - 1, heading))
    return chunks


def chunk_code(text: str) -> list[Chunk]:
    lines = text.splitlines()
    chunks: list[Chunk] = []
    i = 0
    while i < len(lines):
        size, j = 0, i
        while j < len(lines) and (size + len(lines[j]) <= TARGET_CHARS or j == i):
            size += len(lines[j]) + 1
            j += 1
        # Prefer to end at a blank line or a top-level definition near the boundary.
        if j < len(lines):
            for k in range(j, max(i + 5, j - 15), -1):
                if not lines[k - 1].strip() or re.match(r"^(def |class |function |local function |export |public |"
                                                         r"private |func |fn |module\.)", lines[k] if k < len(lines) else ""):
                    j = k
                    break
        body = "\n".join(lines[i:j]).strip()
        if body:
            chunks.append(Chunk(body, i + 1, j))
        if j >= len(lines):
            break
        i = max(j - CODE_OVERLAP_LINES, i + 1)
    return chunks


def chunk_file(text: str, suffix: str) -> list[Chunk]:
    if suffix.lower() in DOC_EXTENSIONS:
        return chunk_markdown(text)
    return chunk_code(text)
