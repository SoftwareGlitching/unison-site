"""Real system metrics: CPU and RAM from psutil, GPU from nvidia-smi when an NVIDIA card is present.
Values that cannot be measured are returned as null, never estimated."""
from __future__ import annotations

import shutil
import subprocess
import sys
import time

import psutil

from .config import ROOT

_gpu_cache: tuple[float, list] = (0.0, [])
_NVSMI = shutil.which("nvidia-smi")
_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0  # don't flash a console window on Windows


def gpu_metrics() -> list[dict]:
    global _gpu_cache
    if not _NVSMI:
        return []
    if time.time() - _gpu_cache[0] < 1.0:
        return _gpu_cache[1]
    try:
        out = subprocess.run(
            [_NVSMI, "--query-gpu=name,utilization.gpu,memory.used,memory.total,temperature.gpu",
             "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=3, creationflags=_NO_WINDOW).stdout
    except (OSError, subprocess.SubprocessError):
        return []
    gpus = []
    for line in out.strip().splitlines():
        p = [x.strip() for x in line.split(",")]
        if len(p) < 4:
            continue

        def num(v):
            try:
                return float(v)
            except ValueError:
                return None
        gpus.append({
            "name": p[0],
            "utilization_percent": num(p[1]),
            "vram_used_mb": num(p[2]),
            "vram_total_mb": num(p[3]),
            "temperature_c": num(p[4]) if len(p) > 4 else None,
        })
    _gpu_cache = (time.time(), gpus)
    return gpus


def system_metrics() -> dict:
    vm = psutil.virtual_memory()
    disk = psutil.disk_usage(str(ROOT))
    return {
        "cpu_percent": psutil.cpu_percent(interval=None),
        "cpu_count": psutil.cpu_count(),
        "ram_used_gb": round((vm.total - vm.available) / 1e9, 2),
        "ram_total_gb": round(vm.total / 1e9, 2),
        "ram_percent": vm.percent,
        "disk_free_gb": round(disk.free / 1e9, 1),
        "gpus": gpu_metrics(),
        "gpu_metrics_source": "nvidia-smi" if _NVSMI else None,
    }
