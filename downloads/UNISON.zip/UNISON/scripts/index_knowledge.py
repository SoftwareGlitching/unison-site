"""Index UNISON's knowledge folder (and optionally a project folder) into the local vector store.

  index_knowledge.bat                 the curated programming notes + your own notes in knowledge\\user
  index_knowledge.bat C:\\path\\to\\project
"""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from backend.knowledge.store import KNOWLEDGE_DIR, get_store  # noqa: E402


async def main() -> int:
    store = get_store()
    ok, why = await store.available()
    if not ok:
        print(why)
        return 1
    if len(sys.argv) > 1:
        folder, kind, collection = Path(sys.argv[1]).resolve(), "project", str(Path(sys.argv[1]).resolve())
    else:
        folder, kind, collection = KNOWLEDGE_DIR, "knowledge", "knowledge"

    def progress(p):
        print(f"\r  {p['done']}/{p['total']}  {p['file'][:70]:<70}", end="", flush=True)

    stats = await store.ingest_folder(folder, kind, collection, progress)
    print(f"\nIndexed {stats['indexed']} file(s), {stats['chunks']} chunk(s); {stats['unchanged']} unchanged, "
          f"{stats['removed']} removed. Total in knowledge base: {store.counts()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
