# HTML and CSS for real websites

## Page skeleton (every page)
```html
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Page name · Site name</title>
  <meta name="description" content="One sentence about this page">
  <link rel="stylesheet" href="css/style.css">
  <script src="js/app.js" defer></script>
</head>
<body>
  <a class="skip" href="#main">Skip to content</a>
  <header class="site-header">...</header>
  <main id="main">...</main>
  <footer class="site-footer">...</footer>
</body>
</html>
```
- Semantic tags: `header`, `nav`, `main`, `section`, `article`, `aside`, `footer`, `figure/figcaption`.
  One `h1` per page, headings in order (h2 under h1...).
- Every `img` has `alt` (empty `alt=""` only for decoration) plus `width`/`height` to stop layout jumps,
  and `loading="lazy"` below the fold.
- Forms: every input has a `<label for>`; use `type="email"`, `type="tel"`, `required`, `autocomplete`
  (`name`, `email`, `street-address`, `postal-code`, `cc-number` only on real payment pages).
- Buttons that do things are `<button type="button">`; links that go places are `<a href>`.
- Shared header/footer on a static multi-page site: copy the same markup into each page, or inject it
  from `js/layout.js` (`document.querySelector("header").outerHTML = ...`). Mark the current page with
  `aria-current="page"` on its nav link.

## CSS foundations
```css
*, *::before, *::after { box-sizing: border-box; }
:root {
  --bg: #0f1115; --surface: #171a21; --text: #e9ecf1; --muted: #9aa3b2;
  --brand: #7c5cff; --brand-ink: #fff; --radius: 14px; --gap: 16px;
  --shadow: 0 10px 30px rgb(0 0 0 / .25);
  --font: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
}
body { margin: 0; font: 16px/1.6 var(--font); background: var(--bg); color: var(--text); }
img { max-width: 100%; display: block; }
.container { width: min(1200px, 100% - 32px); margin-inline: auto; }
:focus-visible { outline: 3px solid var(--brand); outline-offset: 2px; }
@media (prefers-reduced-motion: reduce) { * { animation: none !important; transition: none !important; } }
```
- Theme with CSS variables; dark mode with `@media (prefers-color-scheme: dark)` or a `[data-theme]` attribute.
- Fluid type: `font-size: clamp(2rem, 5vw, 3.5rem)` for big headings.
- Mobile first: base styles for phones, then `@media (min-width: 768px)` and `(min-width: 1100px)`.

## Layout recipes
- Sticky header: `.site-header { position: sticky; top: 0; z-index: 50; backdrop-filter: blur(12px);
  background: rgb(15 17 21 / .8); border-bottom: 1px solid rgb(255 255 255 / .06); }`
- Header row: `display: flex; align-items: center; justify-content: space-between; gap: 16px;`
  logo left, nav centre/right, icons (search, account, cart with a count badge) right.
- Product grid: `display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 20px;`
- Two columns that stack on phones: `grid-template-columns: 1fr; @media (min-width: 900px) { grid-template-columns: 2fr 1fr; }`
- Centre anything: `display: grid; place-items: center;`
- Card: `background: var(--surface); border-radius: var(--radius); overflow: hidden; box-shadow: var(--shadow);
  transition: transform .2s; } .card:hover { transform: translateY(-4px); }`
- Aspect-ratio images: `aspect-ratio: 4 / 3; object-fit: cover; width: 100%;`
- Badge on an icon: parent `position: relative`, badge `position: absolute; top: -6px; right: -8px;
  min-width: 18px; height: 18px; border-radius: 999px; font-size: 11px; display: grid; place-items: center;`

## Mobile navigation (hamburger)
```html
<button class="menu-btn" aria-expanded="false" aria-controls="nav" aria-label="Menu">☰</button>
<nav id="nav" class="nav">...</nav>
```
```css
.menu-btn { display: none; }
@media (max-width: 767px) {
  .menu-btn { display: inline-grid; }
  .nav { position: fixed; inset: 64px 0 auto 0; flex-direction: column; background: var(--surface);
         transform: translateY(-120%); transition: transform .25s; }
  .nav.open { transform: none; }
}
```
```js
const btn = document.querySelector(".menu-btn"), nav = document.getElementById("nav");
btn.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  btn.setAttribute("aria-expanded", open);
});
```

## Polish that makes a site look professional
- Consistent spacing scale (4/8/12/16/24/32/48/64 px) and at most 2 fonts.
- Real hierarchy: big bold hero headline, short subline, one primary button (filled) + one secondary (outline).
- Hover and focus states on everything clickable; `cursor: pointer`; transitions 150-250 ms.
- Images with no network: inline SVG, CSS gradients (`linear-gradient(135deg, #7c5cff, #22d3ee)`), emoji,
  or pixel art from make_sprite. Never link to images that might not exist.
- Toast messages ("Added to cart") instead of `alert()`.
- Check at 360 px wide (phone) and 1280 px (desktop); nothing may overflow sideways.
