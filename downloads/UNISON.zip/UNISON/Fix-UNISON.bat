@echo off
rem One-click repair: applies all fixes, removes extra models, rebuilds and checks UNISON, then opens it.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\fix_unison.ps1" %*
