"""File tools. Reads are free inside workspaces; every change shows a diff, needs approval
(by default) and is backed up first so it can be undone."""
from __future__ import annotations

import difflib
import fnmatch
import os
import re
import shutil
from pathlib import Path

from .base import Tool, ToolError, ToolResult, b, i, obj, s
from .sandbox import SKIP_DIRS, backup, workspaces

MAX_READ_BYTES = 400_000
MAX_WRITE_BYTES = 2_000_000
MAX_LIST = 400


def _is_binary(path: Path) -> bool:
    try:
        with open(path, "rb") as f:
            return b"\0" in f.read(4096)
    except OSError:
        return False


def _read_text(path: Path) -> str:
    raw = path.read_bytes()
    for enc in ("utf-8-sig", "utf-16") if raw[:2] in (b"\xff\xfe", b"\xfe\xff") else ("utf-8-sig",):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1")


def _write_text(path: Path, text: str, like: Path | None = None) -> None:
    """Write text, keeping the existing file's line endings (CRLF on most Windows files)."""
    newline = "\n"
    if like and like.exists():
        try:
            if b"\r\n" in like.read_bytes()[:65536]:
                newline = "\r\n"
        except OSError:
            pass
    text = text.replace("\r\n", "\n")
    if newline == "\r\n":
        text = text.replace("\n", "\r\n")
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(text)


def unified_diff(old: str, new: str, name: str) -> str:
    d = difflib.unified_diff(old.replace("\r\n", "\n").splitlines(keepends=True),
                             new.replace("\r\n", "\n").splitlines(keepends=True),
                             fromfile=f"a/{name}", tofile=f"b/{name}", n=3)
    out = "".join(d)
    return out if len(out) < 60_000 else out[:60_000] + "\n... (diff truncated)\n"


def _diff_stats(diff: str) -> dict:
    add = sum(1 for l in diff.splitlines() if l.startswith("+") and not l.startswith("+++"))
    rem = sum(1 for l in diff.splitlines() if l.startswith("-") and not l.startswith("---"))
    return {"added": add, "removed": rem}


# ------------------------------------------------------------------------- read-only
def list_dir(a: dict) -> ToolResult:
    root = workspaces.resolve(a.get("path"))
    if not root.is_dir():
        raise ToolError(f"Not a folder: {root}")
    depth = max(1, min(int(a.get("depth") or 2), 4))
    lines, count = [], 0

    def walk(d: Path, level: int, prefix: str):
        nonlocal count
        try:
            entries = sorted(d.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
        except PermissionError:
            lines.append(f"{prefix}(no permission)")
            return
        for e in entries:
            if count >= MAX_LIST:
                return
            count += 1
            if e.is_dir():
                if e.name in SKIP_DIRS:
                    lines.append(f"{prefix}{e.name}/  (skipped)")
                    continue
                lines.append(f"{prefix}{e.name}/")
                if level < depth:
                    walk(e, level + 1, prefix + "  ")
            else:
                try:
                    size = e.stat().st_size
                except OSError:
                    size = 0
                lines.append(f"{prefix}{e.name}  ({size:,} B)")

    walk(root, 1, "")
    head = f"{root}\n"
    tail = f"\n... stopped after {MAX_LIST} entries" if count >= MAX_LIST else ""
    return ToolResult(True, head + ("\n".join(lines) or "(empty folder)") + tail)


def read_file(a: dict) -> ToolResult:
    p = workspaces.resolve(a.get("path"))
    if not p.is_file():
        raise ToolError(f"File not found: {p}")
    if p.stat().st_size > MAX_READ_BYTES and not a.get("start_line"):
        raise ToolError(f"File is {p.stat().st_size:,} bytes; read it in parts with start_line/end_line.")
    if _is_binary(p):
        raise ToolError(f"{p.name} is a binary file and can't be read as text.")
    lines = _read_text(p).splitlines()
    start = max(1, int(a.get("start_line") or 1))
    end = min(len(lines), int(a.get("end_line") or (start + 1999)))
    body = "\n".join(f"{n:>5}| {lines[n - 1]}" for n in range(start, end + 1))
    more = f"\n... ({len(lines) - end} more lines; continue with start_line={end + 1})" if end < len(lines) else ""
    return ToolResult(True, f"{p}  (lines {start}-{end} of {len(lines)})\n{body}{more}")


def find_files(a: dict) -> ToolResult:
    root = workspaces.resolve(a.get("path"))
    pattern = a.get("pattern") or "*"
    hits = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for f in filenames:
            rel = os.path.relpath(os.path.join(dirpath, f), root)
            if fnmatch.fnmatch(f.lower(), pattern.lower()) or fnmatch.fnmatch(rel.lower().replace("\\", "/"), pattern.lower()):
                hits.append(rel)
                if len(hits) >= 200:
                    break
        if len(hits) >= 200:
            break
    return ToolResult(True, f"{len(hits)} file(s) under {root} matching '{pattern}':\n" + "\n".join(hits))


def search_text(a: dict) -> ToolResult:
    root = workspaces.resolve(a.get("path"))
    query = a.get("query") or ""
    if not query:
        raise ToolError("query is required")
    glob = a.get("glob") or "*"
    try:
        rx = re.compile(query if a.get("regex") else re.escape(query), 0 if a.get("case_sensitive") else re.I)
    except re.error as e:
        raise ToolError(f"Bad regex: {e}") from e
    hits = []
    files = [root] if root.is_file() else None
    if files is None:
        files = []
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
            files += [Path(dirpath) / f for f in filenames if fnmatch.fnmatch(f.lower(), glob.lower())]
    for f in files:
        if len(hits) >= 150:
            break
        try:
            if f.stat().st_size > MAX_READ_BYTES or _is_binary(f) or workspaces.is_sensitive_file(f):
                continue
            for n, line in enumerate(_read_text(f).splitlines(), 1):
                if rx.search(line):
                    hits.append(f"{os.path.relpath(f, root) if root.is_dir() else f.name}:{n}: {line.strip()[:200]}")
                    if len(hits) >= 150:
                        break
        except OSError:
            continue
    return ToolResult(True, f"{len(hits)} match(es) for '{query}':\n" + "\n".join(hits))


# ------------------------------------------------------------------------- changes
def _plan_write(a: dict) -> tuple[Path, str, str]:
    p = workspaces.resolve(a.get("path"), write=True)
    content = a.get("content")
    if content is None:
        raise ToolError("content is required")
    if len(content.encode("utf-8")) > MAX_WRITE_BYTES:
        raise ToolError("Content too large (2 MB limit)")
    if p.is_dir():
        raise ToolError(f"{p} is a folder")
    old = _read_text(p) if p.exists() and not _is_binary(p) else ""
    if p.exists() and _is_binary(p):
        raise ToolError(f"{p.name} is binary; refusing to overwrite it with text")
    return p, old, content


def preview_write(a: dict) -> dict:
    p, old, new = _plan_write(a)
    diff = unified_diff(old, new, p.name)
    return {"kind": "diff", "path": str(p), "new_file": not p.exists(), "diff": diff, **_diff_stats(diff)}


def write_file(a: dict) -> ToolResult:
    p, old, new = _plan_write(a)
    existed = p.exists()
    bid = backup(p, "write_file") if existed else None
    _write_text(p, new, like=p if existed else None)
    diff = unified_diff(old, new, p.name)
    st = _diff_stats(diff)
    verb = "Updated" if existed else "Created"
    return ToolResult(True, f"{verb} {p} (+{st['added']} -{st['removed']} lines)" + (f"; backup {bid}" if bid else ""),
                      {"path": str(p), "diff": diff, "backup": bid, **st})


def _plan_edit(a: dict) -> tuple[Path, str, str, int]:
    p = workspaces.resolve(a.get("path"), write=True)
    if not p.is_file():
        raise ToolError(f"File not found: {p}. Use write_file to create it.")
    old_text, new_text = a.get("old_text"), a.get("new_text")
    if not old_text:
        raise ToolError("old_text is required (copy it exactly from read_file output, without line numbers)")
    if new_text is None:
        raise ToolError("new_text is required")
    text = _read_text(p)
    norm = text.replace("\r\n", "\n")
    target = old_text.replace("\r\n", "\n")
    count = norm.count(target)
    if count == 0:
        # Tolerate trailing-whitespace differences line by line.
        def strip_lines(x: str) -> str:
            return "\n".join(line.rstrip() for line in x.split("\n"))
        if strip_lines(norm).count(strip_lines(target)) >= 1:
            norm, target = strip_lines(norm), strip_lines(target)
            count = norm.count(target)
    if count == 0:
        raise ToolError("old_text was not found in the file. Read the file again and copy the exact text.")
    if count > 1 and not a.get("replace_all"):
        raise ToolError(f"old_text appears {count} times; include more surrounding lines or set replace_all=true.")
    new = norm.replace(target, new_text.replace("\r\n", "\n"), -1 if a.get("replace_all") else 1)
    return p, norm, new, count


def preview_edit(a: dict) -> dict:
    p, old, new, _ = _plan_edit(a)
    diff = unified_diff(old, new, p.name)
    return {"kind": "diff", "path": str(p), "new_file": False, "diff": diff, **_diff_stats(diff)}


def edit_file(a: dict) -> ToolResult:
    p, old, new, count = _plan_edit(a)
    bid = backup(p, "edit_file")
    _write_text(p, new, like=p)
    diff = unified_diff(old, new, p.name)
    st = _diff_stats(diff)
    return ToolResult(True, f"Edited {p} ({count if a.get('replace_all') else 1} replacement(s), "
                            f"+{st['added']} -{st['removed']} lines); backup {bid}",
                      {"path": str(p), "diff": diff, "backup": bid, **st})


def preview_delete(a: dict) -> dict:
    p = workspaces.resolve(a.get("path"), write=True)
    if not p.exists():
        raise ToolError(f"Not found: {p}")
    return {"kind": "delete", "path": str(p), "is_dir": p.is_dir()}


def delete_path(a: dict) -> ToolResult:
    p = workspaces.resolve(a.get("path"), write=True)
    if not p.exists():
        raise ToolError(f"Not found: {p}")
    if any(p == w.resolve() for w in workspaces.list()):
        raise ToolError("Refusing to delete a workspace root")
    if p.is_dir():
        if any(p.iterdir()):
            raise ToolError("Folder is not empty. Delete the files inside first (each is backed up).")
        p.rmdir()
        return ToolResult(True, f"Deleted empty folder {p}")
    bid = backup(p, "delete_path")
    p.unlink()
    return ToolResult(True, f"Deleted {p}; backup {bid} (restorable)", {"backup": bid})


def make_dir(a: dict) -> ToolResult:
    p = workspaces.resolve(a.get("path"), write=True)
    p.mkdir(parents=True, exist_ok=True)
    return ToolResult(True, f"Folder ready: {p}")


def copy_path(a: dict) -> ToolResult:
    src = workspaces.resolve(a.get("source"))
    dst = workspaces.resolve(a.get("destination"), write=True)
    if dst.exists():
        raise ToolError(f"Destination exists: {dst}")
    if src.is_dir():
        shutil.copytree(src, dst, ignore=shutil.ignore_patterns(*SKIP_DIRS))
    else:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
    return ToolResult(True, f"Copied {src} -> {dst}")


def preview_copy(a: dict) -> dict:
    return {"kind": "action", "summary": f"Copy {a.get('source')} → {a.get('destination')}"}


TOOLS = [
    Tool("list_dir", "List files and folders in a workspace folder as a tree. Start here to understand a project.",
         obj({"path": s("Folder path, relative to the default workspace or absolute. Default '.'"),
              "depth": i("How many levels deep, 1-4 (default 2)")}, []),
         "read", list_dir, default_mode="auto"),
    Tool("read_file", "Read a text/code file with line numbers. Use start_line/end_line for large files.",
         obj({"path": s("File path"), "start_line": i("First line (1-based)"), "end_line": i("Last line")}, ["path"]),
         "read", read_file, default_mode="auto"),
    Tool("find_files", "Find files by name pattern (glob, e.g. '*.lua' or 'src/**/*.ts').",
         obj({"pattern": s("Glob pattern"), "path": s("Folder to search (default '.')")}, ["pattern"]),
         "read", find_files, default_mode="auto"),
    Tool("search_text", "Search inside files for text or a regex. Returns file:line: text.",
         obj({"query": s("Text or regex"), "path": s("Folder or file (default '.')"),
              "glob": s("Only files matching this name pattern, e.g. '*.py'"), "regex": b("Treat query as regex"),
              "case_sensitive": b("Match case")}, ["query"]),
         "read", search_text, default_mode="auto"),
    Tool("write_file", "Create a new file or replace a whole file with the given content. For small changes to an "
                       "existing file use edit_file instead.",
         obj({"path": s("File path"), "content": s("The complete file content")}, ["path", "content"]),
         "write", write_file, preview_write),
    Tool("edit_file", "Replace an exact piece of text in an existing file. old_text must match the file exactly "
                      "(copy it from read_file without the line-number prefix) and should be unique.",
         obj({"path": s("File path"), "old_text": s("Exact text to replace"), "new_text": s("Replacement text"),
              "replace_all": b("Replace every occurrence")}, ["path", "old_text", "new_text"]),
         "write", edit_file, preview_edit),
    Tool("delete_path", "Delete a file (backed up first, restorable) or an empty folder.",
         obj({"path": s("File or empty folder to delete")}, ["path"]),
         "write", delete_path, preview_delete),
    Tool("make_dir", "Create a folder (and any missing parent folders).",
         obj({"path": s("Folder path")}, ["path"]), "write", make_dir, default_mode="auto"),
    Tool("copy_path", "Copy a file or folder to a new location inside the workspaces.",
         obj({"source": s("Existing file or folder"), "destination": s("New path (must not exist)")},
             ["source", "destination"]), "write", copy_path, preview_copy),
]
