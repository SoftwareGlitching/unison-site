# Blender Python (bpy) for asset creation

## Running scripts
- Inside Blender: Scripting workspace → Text Editor → Run Script.
- Headless from a terminal: `blender --background --python make_crate.py` (add a .blend path first to
  open a file: `blender scene.blend --background --python script.py`). Arguments after `--` are left for
  your script: `blender -b -P script.py -- --out C:\exports\crate.fbx` → read `sys.argv[sys.argv.index("--") + 1:]`.
- `bpy.data` holds data (meshes, materials, objects); `bpy.context` is what's active/selected;
  `bpy.ops` are operators (like clicking UI buttons) and depend on context; data API calls are more reliable.

## Clean scene and create objects
```python
import bpy, bmesh
from mathutils import Vector

bpy.ops.object.select_all(action="SELECT")
bpy.ops.object.delete()

bpy.ops.mesh.primitive_cube_add(size=2, location=(0, 0, 1))
crate = bpy.context.active_object
crate.name = "Crate"

# Modifiers
bevel = crate.modifiers.new("Bevel", type="BEVEL")
bevel.width = 0.05
bevel.segments = 3
crate.modifiers.new("WeightedNormal", type="WEIGHTED_NORMAL")
bpy.ops.object.shade_smooth()
```
Building a mesh from raw data (no operators):
```python
verts = [(0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0)]
faces = [(0, 1, 2, 3)]
mesh = bpy.data.meshes.new("Quad")
mesh.from_pydata(verts, [], faces)
mesh.update()
obj = bpy.data.objects.new("Quad", mesh)
bpy.context.collection.objects.link(obj)
```
bmesh for procedural edits:
```python
bm = bmesh.new()
bmesh.ops.create_cube(bm, size=1.0)
bmesh.ops.bevel(bm, geom=bm.edges[:], offset=0.05, segments=2, affect="EDGES")
bm.to_mesh(mesh)
bm.free()
```

## Materials (Principled BSDF)
```python
mat = bpy.data.materials.new("Wood")
mat.use_nodes = True
bsdf = mat.node_tree.nodes["Principled BSDF"]
bsdf.inputs["Base Color"].default_value = (0.42, 0.26, 0.12, 1.0)
bsdf.inputs["Roughness"].default_value = 0.7
crate.data.materials.append(mat)
```
Image texture:
```python
nodes, links = mat.node_tree.nodes, mat.node_tree.links
tex = nodes.new("ShaderNodeTexImage")
tex.image = bpy.data.images.load(r"C:\textures\wood.png")
links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
```
Socket names changed in Blender 4.x for some inputs (e.g. "Specular" → "Specular IOR Level",
"Emission" → "Emission Color"); look them up with `[s.name for s in bsdf.inputs]` if a key fails.

## UVs, lighting, camera, render
```python
bpy.context.view_layer.objects.active = crate
bpy.ops.object.mode_set(mode="EDIT")
bpy.ops.mesh.select_all(action="SELECT")
bpy.ops.uv.smart_project(angle_limit=1.15)   # radians in 4.x (~66°)
bpy.ops.object.mode_set(mode="OBJECT")

light = bpy.data.objects.new("Sun", bpy.data.lights.new("Sun", type="SUN"))
light.data.energy = 3
bpy.context.collection.objects.link(light)

cam = bpy.data.objects.new("Cam", bpy.data.cameras.new("Cam"))
cam.location = (5, -5, 4)
cam.rotation_euler = (Vector((0, 0, 1)) - cam.location).to_track_quat("-Z", "Y").to_euler()
bpy.context.collection.objects.link(cam)
scene = bpy.context.scene
scene.camera = cam
scene.render.engine = "BLENDER_EEVEE_NEXT"  # 4.2+; "BLENDER_EEVEE" in older versions, or "CYCLES"
scene.render.filepath = r"C:\renders\crate.png"
bpy.ops.render.render(write_still=True)
```

## Export
```python
bpy.ops.object.select_all(action="DESELECT")
crate.select_set(True)
bpy.ops.export_scene.fbx(filepath=r"C:\exports\crate.fbx", use_selection=True,
                         use_mesh_modifiers=True, apply_unit_scale=True, global_scale=1.0,
                         axis_forward="-Z", axis_up="Y", object_types={"MESH"})
bpy.ops.export_scene.gltf(filepath=r"C:\exports\crate.glb", export_format="GLB", use_selection=True)
bpy.ops.wm.save_as_mainfile(filepath=r"C:\scenes\crate.blend")
```
`bpy.ops.wm.obj_export(filepath=..., export_selected_objects=True)` is the OBJ exporter in 4.x.

## Game-ready / Roblox notes
- Apply scale and rotation before export (`bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)`).
- Roblox imports FBX/OBJ/GLTF via the 3D Importer; 1 Blender metre is treated differently from 1 stud
  depending on import settings, so check size in Studio and adjust `global_scale` once, then reuse it.
- Roblox caps triangles per imported mesh (tens of thousands; check current docs) — keep props low-poly,
  use bevel + weighted normals instead of dense geometry, and bake detail into textures.
- One material per MeshPart works best; use SurfaceAppearance for PBR maps (color, normal, roughness, metalness).
- Name objects clearly; exported object names become MeshPart names.
