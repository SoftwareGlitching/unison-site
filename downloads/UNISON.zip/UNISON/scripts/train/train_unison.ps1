# Train UNISON on code: builds a coding dataset from open sources + your own ratings, fine-tunes the Gemma 4 brain
# on your graphics card (4-bit QLoRA), installs it as the model "unison-code", benchmarks it against the current
# brain, and switches to it ONLY if it scores better. Safe to stop and run again: it resumes where it left off.
#   -Size quick|standard|big   (2,000 / 8,000 / 25,000 examples; roughly 1 h / 4-6 h / overnight+ on an RTX 3060)
#   -Yes                       accept the defaults (no questions)
#   -SkipEval                  install the trained brain without benchmarking (not recommended)
param([string]$Size = "", [switch]$Yes, [switch]$SkipEval)

. (Join-Path (Split-Path -Parent $PSScriptRoot) "common.ps1")
Set-Location $Root
New-Item -ItemType Directory -Force -Path (Join-Path $Root "logs") | Out-Null
try { Start-Transcript -Path (Join-Path $Root "logs\train-unison.log") -Append | Out-Null } catch { }

function Stop-Train([string]$msg, [int]$code = 1) {
    Write-Bad $msg
    Write-Host "   Details: logs\train-unison.log  (tell Claude: 'check the training log')"
    Restart-Unison
    try { Stop-Transcript | Out-Null } catch { }
    if (-not $Yes) { Read-Host "Press Enter to close" }
    exit $code
}
function Restart-Unison {
    Start-OllamaIfNeeded | Out-Null
    $app = Join-Path $Root "UNISON.exe"
    if (Test-Path $app) { Start-Process -FilePath $app -WorkingDirectory $Root -ErrorAction SilentlyContinue }
}

Write-Host ""
Write-Host "  U N I S O N   training (coding)" -ForegroundColor Cyan
Write-Host "  Teaches UNISON's brain from open coding datasets (Python, JavaScript/TypeScript, HTML/CSS, C#, C++, Lua...)"
Write-Host "  plus every reply you rated thumbs-up and every correction you wrote."
Write-Host ""

# ------------------------------------------------------------------ 1. size
if ($Size -and @("quick", "standard", "big") -notcontains $Size) { Write-Warn2 "Unknown size '$Size' - asking instead."; $Size = "" }
if (-not $Size) {
    Write-Host "   How big a training run?"
    Write-Host "     1) quick     2,000 examples  ~1 hour     (try it out)"
    Write-Host "     2) standard  8,000 examples  ~4-6 hours  (recommended - run it overnight)"
    Write-Host "     3) big      25,000 examples  ~15+ hours  (biggest improvement)"
    $c = if ($Yes) { "2" } else { Read-Host "   Choose 1, 2 or 3 [2]" }
    $Size = @{ "1" = "quick"; "3" = "big" }[$c]; if (-not $Size) { $Size = "standard" }
}
Write-Ok "Training size: $Size"

# ------------------------------------------------------------------ 2. checks
Write-Step "1/7" "Checking this PC"
$smi = Get-Command nvidia-smi -ErrorAction SilentlyContinue
if (-not $smi) { Stop-Train "No NVIDIA graphics card found (nvidia-smi is missing). Training needs an NVIDIA GPU." }
$vramMb = [int](& nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits | Select-Object -First 1)
if ($vramMb -lt 11000) { Stop-Train "This graphics card has $([math]::Round($vramMb/1024)) GB; training the 12B brain needs 12 GB." }
Write-Ok "Graphics card: $([math]::Round($vramMb/1024)) GB"
# the big downloads (training tools ~6 GB, base model ~8 GB, checkpoints) go to the drive with the most free space
$drive = Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Free -gt 0 } | Sort-Object Free -Descending | Select-Object -First 1
$freeGb = [math]::Round($drive.Free / 1GB)
if ($freeGb -lt 35) { Stop-Train "Training needs about 35 GB of free disk space; the emptiest drive ($($drive.Name):) has $freeGb GB." }
$work = "$($drive.Name):\UNISON-training"
New-Item -ItemType Directory -Force -Path $work | Out-Null
$env:HF_HOME = Join-Path $work "hf-cache"
$env:HF_HUB_DISABLE_SYMLINKS_WARNING = "1"
$env:PYTHONUTF8 = "1"
Write-Ok "Training files go to $work ($freeGb GB free)"

# ------------------------------------------------------------------ 3. training tools (separate from UNISON's own Python)
Write-Step "2/7" "Training tools (first run only, ~6 GB download)"
$tv = Join-Path $Root ".train-venv"
$tpy = Join-Path $tv "Scripts\python.exe"
if (-not (Test-Path $tpy)) {
    $py = Find-Python
    if (-not $py) { Stop-Train "Python 3.11-3.13 is needed (Setup.bat installs it)." }
    & $py -m venv $tv
    if (-not (Test-Path $tpy)) { Stop-Train "Couldn't create the training environment." }
}
$ok = (& $tpy -c "import torch, unsloth; print(torch.cuda.is_available())" 2>$null | Select-Object -Last 1)
if ($ok -ne "True") {
    & $tpy -m pip install --upgrade pip --disable-pip-version-check -q
    $torchOk = $false
    foreach ($cu in @("cu128", "cu126", "cu124")) {
        Write-Host "   Installing PyTorch for CUDA ($cu)..."
        & $tpy -m pip install torch torchvision --index-url "https://download.pytorch.org/whl/$cu" --disable-pip-version-check -q
        if ((& $tpy -c "import torch; print(torch.cuda.is_available())" 2>$null | Select-Object -Last 1) -eq "True") { $torchOk = $true; break }
    }
    if (-not $torchOk) { Stop-Train "PyTorch can't use the graphics card. Update the NVIDIA driver (nvidia.com/drivers) and run this again." }
    Write-Host "   Installing Unsloth (fast, low-memory fine-tuning)..."
    & $tpy -m pip install unsloth --disable-pip-version-check -q
    & $tpy -c "import triton" 2>$null
    if ($LASTEXITCODE -ne 0) { & $tpy -m pip install triton-windows --disable-pip-version-check -q }
    $ok = (& $tpy -c "import torch, unsloth; print(torch.cuda.is_available())" 2>$null | Select-Object -Last 1)
    if ($ok -ne "True") { Stop-Train "The training tools didn't install correctly (see the log above)." }
}
Write-Ok "Training tools ready"

# ------------------------------------------------------------------ 4. dataset
Write-Step "3/7" "Building the coding dataset"
$data = Join-Path $Root "datasets\training\unison-code-$Size.jsonl"
if ((Test-Path $data) -and -not $Yes -and (Ask-YesNo "A $Size dataset already exists. Reuse it?" $true)) {
    Write-Ok "Reusing $data"
} else {
    & $tpy (Join-Path $PSScriptRoot "build_dataset.py") --size $Size
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path $data)) { Stop-Train "Couldn't build the dataset." }
}

# ------------------------------------------------------------------ 5. train
Write-Step "4/7" "Training (the long part - leave the PC on; you can stop it and run this again to resume)"
Write-Host "   Closing UNISON and Ollama so the graphics card is free..."
Get-Process -Name "UNISON" -ErrorAction SilentlyContinue | ForEach-Object { & taskkill /PID $_.Id /T /F 2>$null | Out-Null }
Get-Process -Name "ollama app", "ollama" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 3
$out = Join-Path $work "unison-code"
$ft = Join-Path $PSScriptRoot "finetune.py"
$adapter = Join-Path $out "adapter"
if ((Test-Path (Join-Path $adapter "adapter_config.json")) -and (Test-Path (Join-Path $out "trained.json")) -and -not $Yes -and
    (Ask-YesNo "A trained brain from an earlier run exists. Use it instead of training again?" $false)) {
    Write-Ok "Using the earlier training"
} else {
    & $tpy $ft --data $data --out $out --resume
    if ($LASTEXITCODE -eq 3) {
        Write-Warn2 "Out of graphics memory - retrying with shorter examples (1,024 tokens)."
        & $tpy $ft --data $data --out $out --seq 1024 --resume
    }
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path (Join-Path $adapter "adapter_config.json"))) {
        Stop-Train "Training stopped before finishing. Run Train-UNISON.bat again to resume from the last checkpoint."
    }
}
Write-Ok "Training done"

# ------------------------------------------------------------------ 6. install as "unison-code"
Write-Step "5/7" "Installing the trained brain as 'unison-code'"
if (-not (Start-OllamaIfNeeded)) { Stop-Train "Ollama didn't start." }
$ollama = Find-OllamaExe
$base = (Get-Content (Join-Path $Root "config\unison.Modelfile") -ErrorAction SilentlyContinue |
         Where-Object { $_ -match "^FROM\s+(\S+)" } | ForEach-Object { $Matches[1] } | Select-Object -First 1)
if (-not $base) { $base = "gemma4:12b" }
$persona = (Get-Content (Join-Path $Root "scripts\brain\persona.txt") -Raw -Encoding UTF8).Trim()
$mf = Join-Path $work "unison-code.Modelfile"
$route = ""
# a) the small adapter on top of the brain you already have (keeps screen control / image understanding)
$text = "FROM $base`nADAPTER $adapter`nPARAMETER temperature 0.6`nPARAMETER top_p 0.9`nPARAMETER top_k 40`nPARAMETER repeat_penalty 1.05`nSYSTEM `"`"`"$persona`"`"`"`n"
[IO.File]::WriteAllText($mf, $text, (New-Object Text.UTF8Encoding $false))
& $ollama create unison-code -f $mf
if ($LASTEXITCODE -eq 0) { $route = "adapter" }
else {
    # b) merge into one full model and let Ollama import + compress it
    Write-Warn2 "Ollama couldn't use the adapter directly - merging it into a full model instead (needs ~25 GB, ~30 min)."
    Get-Process -Name "ollama" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    & $tpy $ft --data $data --out $out --merge-only
    if ($LASTEXITCODE -ne 0) { Stop-Train "Merging the trained brain failed." }
    Start-OllamaIfNeeded | Out-Null
    $text = "FROM $(Join-Path $out 'merged')`nPARAMETER temperature 0.6`nPARAMETER top_p 0.9`nPARAMETER top_k 40`nPARAMETER repeat_penalty 1.05`nSYSTEM `"`"`"$persona`"`"`"`n"
    [IO.File]::WriteAllText($mf, $text, (New-Object Text.UTF8Encoding $false))
    & $ollama create unison-code -q q4_K_M -f $mf
    if ($LASTEXITCODE -ne 0) { Stop-Train "Ollama couldn't import the trained brain." }
    $route = "merged"
}
& $VenvPy (Join-Path $Root "scripts\brain_check.py") unison-code
if ($LASTEXITCODE -ne 0) { Stop-Train "The trained brain didn't answer properly, so UNISON keeps using the current one." }
Write-Ok "Installed 'unison-code' ($route)"

# ------------------------------------------------------------------ 7. benchmark: old vs new
$switch = $true
if (-not $SkipEval) {
    Write-Step "6/7" "Benchmark: does the trained brain code better? (runs real coding tasks, ~20-40 min)"
    $oldJ = Join-Path $work "eval-old.json"; $newJ = Join-Path $work "eval-new.json"
    & $VenvPy (Join-Path $Root "scripts\eval.py") --model unison --yes --no-knowledge --json-out $oldJ
    & $VenvPy (Join-Path $Root "scripts\eval.py") --model unison-code --yes --no-knowledge --json-out $newJ
    if ((Test-Path $oldJ) -and (Test-Path $newJ)) {
        $old = Get-Content $oldJ -Raw | ConvertFrom-Json; $new = Get-Content $newJ -Raw | ConvertFrom-Json
        Write-Host ("   current brain: {0}%   trained brain: {1}%" -f $old.score, $new.score)
        $switch = ([double]$new.score -gt [double]$old.score)
    } else { Write-Warn2 "The benchmark didn't finish; keeping the current brain to be safe."; $switch = $false }
}

# ------------------------------------------------------------------ 8. switch (only if better)
Write-Step "7/7" "Finishing"
if ($switch) {
    $vision = if ($route -eq "merged") { "unison" } else { "" }
    & $VenvPy -c @"
import sys
from backend.core.config import settings
settings.set('inference', 'active_model', 'unison-code')
if sys.argv[1]:
    settings.set('computer', 'use_brain', False)        # the merged brain can't see images: screen control keeps the old one
    settings.set('computer', 'vision_model', sys.argv[1])
"@ $vision
    Write-Ok "UNISON now uses your trained brain 'unison-code'. The old one is kept - switch back any time in the model menu."
} else {
    Write-Warn2 "The trained brain didn't beat the current one, so UNISON keeps the current brain."
    Write-Host "   'unison-code' is still installed - try it from the model menu. A bigger run (-Size big) usually helps more."
}
Restart-Unison
try { Stop-Transcript | Out-Null } catch { }
Write-Host ""
Write-Host "  Done. Rate replies with thumbs up/down and run this again later - every run learns from them." -ForegroundColor Green
if (-not $Yes) { Read-Host "Press Enter to close" }
