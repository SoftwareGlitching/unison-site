import { useEffect, useRef, useState } from "react";
import { api, type InstalledModel } from "../lib/api";

const sizeGB = (b: number) => `${(b / 1e9).toFixed(1)} GB`;
type Effort = { id: string; label: string; about: string };

/** The brain + how hard it works the GPU. Only UNISON's own brain is shown; other Ollama models are tucked
 *  away under "Other models" (they're usually leftovers like the old screen model or the embedding model). */
export function ModelMenu({ onChanged }: { onChanged: () => void }) {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("");
  const [installed, setInstalled] = useState<InstalledModel[]>([]);
  const [effort, setEffort] = useState("balanced");
  const [efforts, setEfforts] = useState<Effort[]>([]);
  const [showOthers, setShowOthers] = useState(false);
  const [error, setError] = useState("");
  const boxRef = useRef<HTMLDivElement>(null);

  const load = async () => {
    try {
      const m = await api.models();
      setActive(m.active_model);
      setInstalled(m.data);
      setError("");
    } catch (e: any) {
      setError(e.message);
    }
    try {
      const e = await api.effort();
      setEffort(e.effort);
      setEfforts(e.choices);
    } catch {
      /* older server */
    }
  };

  useEffect(() => {
    load();
  }, []);

  useEffect(() => {
    const close = (e: MouseEvent) => {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  const choose = async (tag: string) => {
    try {
      await api.setModel(tag);
      setActive(tag);
      setOpen(false);
      onChanged();
    } catch (e: any) {
      setError(e.message);
    }
  };

  const pickEffort = async (id: string) => {
    try {
      const r = await api.setEffort(id);
      setEffort(r.effort);
      onChanged();   // the app shows "Loading the brain…" while it reloads with the new GPU settings
    } catch (e: any) {
      setError(e.message);
    }
  };

  const isBrain = (id: string) => id.split(":")[0] === "unison";
  const brains = installed.filter((m) => isBrain(m.id));
  const others = installed.filter((m) => !isBrain(m.id) && !/embed/i.test(m.id));
  const effortLabel = efforts.find((e) => e.id === effort)?.label ?? "Balanced";
  const shownName = isBrain(active) ? "UNISON" : active || "no model";

  return (
    <div className="model-menu" ref={boxRef}>
      <button className="model-button" onClick={() => setOpen(!open)} title="Brain and effort">
        <span className="dot" />
        <span className="model-name">{shownName}</span>
        <span className="tier-tag">{effortLabel}</span>
        <span className="caret">▾</span>
      </button>
      {open && (
        <div className="model-pop">
          <div className="pop-section">Brain</div>
          {brains.length === 0 && <div className="pop-empty">UNISON's brain isn't installed yet - run Upgrade-Brain.bat.</div>}
          {brains.map((m) => (
            <button key={m.id} className={`pop-row ${m.id === active || active === "unison" ? "on" : ""}`} onClick={() => choose(m.id)}>
              <span className="pop-main">UNISON</span>
              <span className="pop-meta">chat, coding, agent and screen control · {sizeGB(m.unison.size_bytes)}</span>
            </button>
          ))}

          {efforts.length > 0 && (
            <>
              <div className="pop-section">Effort - how hard it works your graphics card</div>
              <div className="effort-row">
                {efforts.map((e) => (
                  <button key={e.id} className={`effort-btn ${e.id === effort ? "on" : ""}`} onClick={() => pickEffort(e.id)}>
                    {e.label}
                  </button>
                ))}
              </div>
              <div className="pop-reason">{efforts.find((e) => e.id === effort)?.about}</div>
            </>
          )}

          {others.length > 0 && (
            <>
              <button className="pop-section link-btn" onClick={() => setShowOthers(!showOthers)}>
                {showOthers ? "▾" : "▸"} Other models ({others.length})
              </button>
              {showOthers && others.map((m) => (
                <button key={m.id} className={`pop-row ${m.id === active ? "on" : ""}`} onClick={() => choose(m.id)}>
                  <span className="pop-main">{m.id}</span>
                  <span className="pop-meta">{m.unison.parameter_size} · {sizeGB(m.unison.size_bytes)}</span>
                </button>
              ))}
            </>
          )}
          {error && <div className="pop-error">{error}</div>}
        </div>
      )}
    </div>
  );
}
