@echo off
rem Free up disk space safely: unused AI models, old model files, caches, temp files. Asks before each step.
set "UROOT=%~dp0"
if not exist "%UROOT%scripts\clean_space.ps1" set "UROOT=%~dp0..\"
cd /d "%UROOT%"
powershell -NoProfile -ExecutionPolicy Bypass -File "%UROOT%scripts\clean_space.ps1" %*
