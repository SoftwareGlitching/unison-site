# models

Used from later phases of UNISON. Ollama keeps model weights in its own folder (%USERPROFILE%\.ollama\models).
