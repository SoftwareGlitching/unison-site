# Publishing and selling UNISON

UNISON is proprietary. The setup uses two GitHub repos:

| Repo | Visibility | What's in it |
|---|---|---|
| `SoftwareGlitching/unison` | **Private** | The full source, including the owner tools. Only you (and Claude, if allowed) can see it. |
| `SoftwareGlitching/unison-site` | Public | Only the website and `downloads/UNISON.zip`. Served free at https://softwareglitching.github.io/unison-site/ |

Anyone can download the zip, but UNISON won't run without a license key that you create.
The download is built **without** `License-Admin.bat`, your settings, chats, password or logs.

## One-time setup

1. **Your signing key** (at your PC): run `Update.bat` (it offers this) or `License-Admin.bat setup`.
   - It creates `%USERPROFILE%\UNISON-owner\license-private.pem`. **Back it up** (USB stick or password manager).
     Never upload it or paste it anywhere: whoever has it can make keys.
   - It unlocks your own PC and prints your **public key** — that one is safe to share. Send it to Claude
     so the public download accepts your keys.
2. **Make the source private:** github.com/SoftwareGlitching/unison → Settings → General → Danger Zone →
   **Change visibility → Make private**.
3. **Create the site repo:** https://github.com/new → name `unison-site` → **Public** → Create (empty).
   Then allow Claude on it: https://github.com/apps/claude/installations/select_target → PerkyPop →
   add `unison-site`.
4. **Turn on the website** (after Claude has pushed it): `unison-site` → Settings → Pages →
   Source **Deploy from a branch** → Branch **main** / **(root)** → Save.

## Building the site yourself (optional)

```
.venv\Scripts\python scripts\configure_site.py --repo SoftwareGlitching/unison-site --out _site --zip ^
    --purchase-url https://your-store-link
```
Upload the contents of `_site` to the `unison-site` repo. `--zip` builds the download; `version.json`
is what the app's "check for updates" reads.

## Selling keys

Pick a store that takes payment and emails the buyer: Gumroad, Lemon Squeezy, Payhip or a Stripe Payment
Link. Put its link in `--purchase-url` (it becomes the **Get a license key** button). When someone buys:

- `License-Admin.bat new "Buyer Name"` → a key for any PC, never expires, or
- `License-Admin.bat new "Buyer Name" --machine ABCD-1234-EF56-7890` → only works on their PC (they copy the
  Machine ID from the activation screen; ask for it at checkout), or
- add `--days 30` for a trial / monthly key.

Email them the key. Keys are checked offline.

## What a license key can and can't do

It stops casual sharing: no key, no UNISON; a machine-locked key won't work on another PC; expired keys stop
working. But UNISON runs on the buyer's own computer as readable Python/JavaScript, so a skilled person could
edit out the check. Your protection is the license terms (LICENSE) plus the key. Compiling UNISON into
a Windows .exe (e.g. with Nuitka) makes that much harder; that's a possible next step.

## Getting found on Google

Google only ever sees the **website**, never your PC or your UNISON server.

1. https://search.google.com/search-console → Add property → URL prefix →
   `https://softwareglitching.github.io/unison-site/` → **HTML tag** → copy the code inside `content="..."`.
2. Send the code to Claude (or rebuild the site with `--google-verify CODE`), then click **Verify**.
3. Search Console → Sitemaps → submit `sitemap.xml`.

New sites usually appear within days to a couple of weeks. Links from YouTube, Reddit, Discord or your Roblox
group help a lot.
