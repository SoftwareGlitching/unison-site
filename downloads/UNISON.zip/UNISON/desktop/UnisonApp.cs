// UNISON for Windows - the app people install.
//
//   First run   a setup wizard: license key -> installs everything (runs scripts\setup.ps1 -Gui) -> done.
//   After that  starts Ollama and the UNISON server hidden (no console windows), opens UNISON in its own
//               window, and lives in the tray by the clock.
//
// Built on each PC by desktop\build.ps1 with the C# compiler that ships with Windows (.NET Framework 4.x).
// That compiler only knows C# 5, so: no $"..." strings, no ?. operator, no => members, no nameof.
// Keep every non-ASCII character as a \u escape.
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Net;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
#if WEBVIEW2
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
#endif

[assembly: AssemblyTitle("UNISON")]
[assembly: AssemblyDescription("UNISON - private AI on your PC")]
[assembly: AssemblyProduct("UNISON")]
[assembly: AssemblyCompany("PerkyPop")]
[assembly: AssemblyCopyright("(c) 2026 PerkyPop")]
[assembly: AssemblyVersion("0.7.0.0")]
[assembly: AssemblyFileVersion("0.7.0.0")]

namespace Unison
{
    // ------------------------------------------------------------------ paths, config, small helpers
    static class App
    {
        public static readonly string Root = AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\', '/');
        public const string SiteUrl = "https://softwareglitching.github.io/unison-site/";
        public static Icon AppIcon;

        public static string P(params string[] parts) { return Path.Combine(Root, Path.Combine(parts)); }
        public static string VenvPy { get { return P(".venv", "Scripts", "python.exe"); } }

        public static string LogsDir
        {
            get { string d = P("logs"); try { Directory.CreateDirectory(d); } catch { } return d; }
        }

        public static string DataDir
        {
            get
            {
                string d = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "UNISON");
                try { Directory.CreateDirectory(d); } catch { }
                return d;
            }
        }

        public static bool LooksLikeUnisonFolder()
        {
            return File.Exists(P("scripts", "setup.ps1")) && Directory.Exists(P("backend"));
        }

        /// Same rule as scripts\start.ps1: a moved folder can lose the hidden marker, so recreate it when
        /// UNISON is clearly installed (Python environment + built app).
        public static bool IsSetUp()
        {
            string marker = P(".setup-complete");
            bool built = File.Exists(VenvPy) && File.Exists(P("frontend", "dist", "index.html"));
            if (!File.Exists(marker) && built)
            {
                try { File.WriteAllText(marker, DateTime.Now.ToString("s")); } catch { }
            }
            return File.Exists(marker) && File.Exists(VenvPy);
        }

        public static int Port()
        {
            foreach (string f in new[] { P("config", "unison.json"), P("config", "unison.default.json") })
            {
                try
                {
                    Match m = Regex.Match(File.ReadAllText(f), "\"server\"\\s*:\\s*\\{[^}]*?\"port\"\\s*:\\s*(\\d+)");
                    if (m.Success) return int.Parse(m.Groups[1].Value);
                }
                catch { }
            }
            return 8770;
        }

        public static string Url { get { return "http://127.0.0.1:" + Port() + "/"; } }

        public static bool HasLicenseSaved()
        {
            try { return Regex.IsMatch(File.ReadAllText(P("config", "unison.json")), "\"key\"\\s*:\\s*\"UNISON-"); }
            catch { return false; }
        }

        public static bool HttpOk(string url, int timeoutMs)
        {
            try
            {
                var req = (HttpWebRequest)WebRequest.Create(url);
                req.Timeout = timeoutMs;
                req.ReadWriteTimeout = timeoutMs;
                req.Proxy = null;
                req.KeepAlive = false;
                using (var resp = (HttpWebResponse)req.GetResponse()) { return (int)resp.StatusCode < 500; }
            }
            catch (WebException ex)
            {
                var r = ex.Response as HttpWebResponse;
                bool ok = r != null && (int)r.StatusCode < 500;
                if (r != null) r.Close();
                return ok;
            }
            catch { return false; }
        }

        public static void KillTree(int pid)
        {
            try
            {
                var psi = new ProcessStartInfo("taskkill", "/PID " + pid + " /T /F");
                psi.CreateNoWindow = true;
                psi.UseShellExecute = false;
                using (var p = Process.Start(psi)) { p.WaitForExit(8000); }
            }
            catch { }
        }

        /// Opens a URL, file or folder the way double-clicking would.
        public static void Open(string target)
        {
            try { Process.Start(target); } catch { }
        }

        /// Runs one of UNISON's scripts in a normal console window (for the interactive ones, like remote access).
        public static void RunScriptWindow(string script, string args)
        {
            try
            {
                var psi = new ProcessStartInfo("powershell.exe",
                    "-NoProfile -ExecutionPolicy Bypass -File \"" + P("scripts", script) + "\"" +
                    (string.IsNullOrEmpty(args) ? "" : " " + args));
                psi.WorkingDirectory = Root;
                psi.UseShellExecute = true;
                Process.Start(psi);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Couldn't start " + script + ": " + ex.Message, "UNISON", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        /// Opens UNISON in Edge's (or Chrome's) app mode - a plain window with no tabs or address bar.
        /// Used when the embedded window (WebView2) isn't available.
        public static void OpenAppWindow(string url)
        {
            string browser = FindBrowser();
            if (browser != null)
            {
                try
                {
                    var psi = new ProcessStartInfo(browser,
                        "--app=" + url + " --user-data-dir=\"" + Path.Combine(DataDir, "AppWindow") + "\"" +
                        " --no-first-run --no-default-browser-check --window-size=1280,860");
                    psi.UseShellExecute = false;
                    Process.Start(psi);
                    return;
                }
                catch { }
            }
            Open(url);
        }

        static string FindBrowser()
        {
            string pf86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
            string pf = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            string la = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string[] candidates = {
                Path.Combine(pf86, "Microsoft\\Edge\\Application\\msedge.exe"),
                Path.Combine(pf, "Microsoft\\Edge\\Application\\msedge.exe"),
                Path.Combine(pf, "Google\\Chrome\\Application\\chrome.exe"),
                Path.Combine(pf86, "Google\\Chrome\\Application\\chrome.exe"),
                Path.Combine(la, "Google\\Chrome\\Application\\chrome.exe"),
            };
            foreach (string f in candidates) { if (File.Exists(f)) return f; }
            return null;
        }

        public static string Shorten(string s, int max)
        {
            if (s == null) return "";
            return s.Length <= max ? s : s.Substring(0, max - 3) + "...";
        }

        public static void LogCrash(Exception ex)
        {
            try
            {
                File.AppendAllText(Path.Combine(LogsDir, "desktop.log"),
                    "==== " + DateTime.Now.ToString("s") + "\r\n" + (ex == null ? "unknown error" : ex.ToString()) + "\r\n");
            }
            catch { }
        }
    }

    // ------------------------------------------------------------------ per-user settings (window size, tray tips)
    static class Prefs
    {
        static Dictionary<string, string> data;
        static string FilePath { get { return Path.Combine(App.DataDir, "desktop-settings.txt"); } }

        static void Load()
        {
            if (data != null) return;
            data = new Dictionary<string, string>();
            try
            {
                foreach (string line in File.ReadAllLines(FilePath))
                {
                    int i = line.IndexOf('=');
                    if (i > 0) data[line.Substring(0, i)] = line.Substring(i + 1);
                }
            }
            catch { }
        }

        public static string Get(string key, string fallback)
        {
            Load();
            string v;
            return data.TryGetValue(key, out v) ? v : fallback;
        }

        public static bool GetBool(string key, bool fallback) { return Get(key, fallback ? "1" : "0") == "1"; }

        public static void Set(string key, string value)
        {
            Load();
            data[key] = value;
            try
            {
                var sb = new StringBuilder();
                foreach (var kv in data) sb.Append(kv.Key).Append('=').Append(kv.Value).Append("\r\n");
                File.WriteAllText(FilePath, sb.ToString());
            }
            catch { }
        }

        public static void SetBool(string key, bool value) { Set(key, value ? "1" : "0"); }
    }

    // ------------------------------------------------------------------ Start menu / desktop / startup shortcuts
    static class Shortcuts
    {
        public static string StartMenu { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs), "UNISON.lnk"); } }
        public static string Desktop { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "UNISON.lnk"); } }
        public static string Startup { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Startup), "UNISON.lnk"); } }

        public static bool Make(string lnkPath, string args)
        {
            object shell = null, lnk = null;
            try
            {
                string exe = Application.ExecutablePath;
                Type t = Type.GetTypeFromProgID("WScript.Shell");
                shell = Activator.CreateInstance(t);
                lnk = t.InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, shell, new object[] { lnkPath });
                Type lt = lnk.GetType();
                lt.InvokeMember("TargetPath", BindingFlags.SetProperty, null, lnk, new object[] { exe });
                lt.InvokeMember("Arguments", BindingFlags.SetProperty, null, lnk, new object[] { args ?? "" });
                lt.InvokeMember("WorkingDirectory", BindingFlags.SetProperty, null, lnk, new object[] { App.Root });
                lt.InvokeMember("Description", BindingFlags.SetProperty, null, lnk, new object[] { "UNISON - private AI on your PC" });
                lt.InvokeMember("IconLocation", BindingFlags.SetProperty, null, lnk, new object[] { exe + ",0" });
                lt.InvokeMember("Save", BindingFlags.InvokeMethod, null, lnk, null);
                return true;
            }
            catch { return false; }
            finally
            {
                if (lnk != null) { try { Marshal.FinalReleaseComObject(lnk); } catch { } }
                if (shell != null) { try { Marshal.FinalReleaseComObject(shell); } catch { } }
            }
        }

        /// Every start: a Start-menu entry, and old shortcuts (that pointed at Start-UNISON.bat) moved to the app.
        public static void Ensure()
        {
            if (!File.Exists(StartMenu)) Make(StartMenu, "");
            if (File.Exists(Desktop)) Make(Desktop, "");
            if (File.Exists(Startup)) Make(Startup, "--background");
        }

        public static bool StartsWithWindows { get { return File.Exists(Startup); } }

        public static void SetStartWithWindows(bool on)
        {
            if (on) Make(Startup, "--background");
            else { try { File.Delete(Startup); } catch { } }
        }
    }

    // ------------------------------------------------------------------ look and feel
    static class Theme
    {
        public static readonly Color Bg = Color.FromArgb(11, 14, 17);
        public static readonly Color Panel = Color.FromArgb(17, 22, 27);
        public static readonly Color Panel2 = Color.FromArgb(22, 29, 35);
        public static readonly Color Line = Color.FromArgb(38, 49, 59);
        public static readonly Color Text = Color.FromArgb(226, 232, 238);
        public static readonly Color Dim = Color.FromArgb(140, 152, 164);
        public static readonly Color Faint = Color.FromArgb(86, 98, 112);
        public static readonly Color Accent = Color.FromArgb(103, 232, 201);
        public static readonly Color Accent2 = Color.FromArgb(124, 196, 255);
        public static readonly Color Ink = Color.FromArgb(4, 32, 26);
        public static readonly Color Bad = Color.FromArgb(255, 122, 122);
        public static readonly Color Warn = Color.FromArgb(242, 180, 90);

        public static Font F(float pt, FontStyle style) { return new Font("Segoe UI", pt, style, GraphicsUnit.Point); }
        public static Font F(float pt) { return F(pt, FontStyle.Regular); }
        public static Font Mono(float pt) { return new Font("Consolas", pt, FontStyle.Regular, GraphicsUnit.Point); }

        public static Button Btn(string text, bool primary)
        {
            var b = new Button();
            b.Text = text;
            b.FlatStyle = FlatStyle.Flat;
            b.UseVisualStyleBackColor = false;
            b.Cursor = Cursors.Hand;
            b.Font = F(10f, FontStyle.Bold);
            b.Size = new Size(132, 38);
            b.BackColor = primary ? Accent : Panel2;
            b.ForeColor = primary ? Ink : Text;
            b.FlatAppearance.BorderSize = primary ? 0 : 1;
            b.FlatAppearance.BorderColor = Line;
            b.FlatAppearance.MouseOverBackColor = primary ? Color.FromArgb(140, 240, 215) : Line;
            b.FlatAppearance.MouseDownBackColor = primary ? Color.FromArgb(80, 200, 170) : Panel;
            return b;
        }

        public static Label Lbl(string text, Font font, Color color, int x, int y, int w, int h)
        {
            var l = new Label();
            l.AutoSize = false;
            l.UseMnemonic = false;
            l.Text = text;
            l.Font = font;
            l.ForeColor = color;
            l.BackColor = Color.Transparent;
            l.Location = new Point(x, y);
            l.Size = new Size(w, h);
            return l;
        }

        public static LinkLabel Link(string text, int x, int y, int w)
        {
            var l = new LinkLabel();
            l.AutoSize = false;
            l.UseMnemonic = false;
            l.Text = text;
            l.Font = F(9.5f);
            l.LinkColor = Accent2;
            l.ActiveLinkColor = Accent;
            l.VisitedLinkColor = Accent2;
            l.LinkBehavior = LinkBehavior.HoverUnderline;
            l.BackColor = Color.Transparent;
            l.Location = new Point(x, y);
            l.Size = new Size(w, 22);
            return l;
        }

        /// The UNISON mark: two overlapping rings.
        public static void DrawMark(Graphics g, RectangleF r, float stroke)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            float d = Math.Min(r.Height * 0.8f, r.Width * 0.55f);
            float cx = r.X + r.Width / 2f, cy = r.Y + r.Height / 2f, off = d * 0.29f;
            using (var p1 = new Pen(Accent, stroke))
            using (var p2 = new Pen(Color.FromArgb(140, Accent), stroke))
            {
                g.DrawEllipse(p1, cx - off - d / 2f, cy - d / 2f, d, d);
                g.DrawEllipse(p2, cx + off - d / 2f, cy - d / 2f, d, d);
            }
        }
    }

    /// Paints the UNISON mark.
    class Mark : Control
    {
        public Mark(Color background)
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = background;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(BackColor);
            Theme.DrawMark(e.Graphics, new RectangleF(2, 2, Width - 4, Height - 4), Math.Max(2f, Height / 13f));
        }
    }

    /// A thin progress bar. Value 0..1, or below 0 for an animated "working" bar.
    class Bar : Control
    {
        float value = -1f, phase;
        readonly System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();

        public Bar()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.Line;
            timer.Interval = 30;
            timer.Tick += delegate
            {
                phase += 0.012f;
                if (phase > 1.2f) phase = -0.4f;
                if (value < 0) Invalidate();
            };
            timer.Start();
        }

        public float Value
        {
            get { return value; }
            set { this.value = value; Invalidate(); }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(Theme.Line);
            using (var b = new SolidBrush(Theme.Accent))
            {
                if (value >= 0) e.Graphics.FillRectangle(b, 0, 0, Width * Math.Min(1f, value), Height);
                else e.Graphics.FillRectangle(b, Width * phase, 0, Width * 0.35f, Height);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) timer.Dispose();
            base.Dispose(disposing);
        }
    }

    /// Dark window base: scales with the display (125%, 150%...) and asks Windows for a dark title bar.
    class DarkForm : Form
    {
        public DarkForm()
        {
            SuspendLayout();
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            BackColor = Theme.Bg;
            ForeColor = Theme.Text;
            Font = Theme.F(9.5f);
            Text = "UNISON";
            if (App.AppIcon != null) Icon = App.AppIcon;
        }

        /// Call at the end of a derived constructor, after adding controls (they're scaled here).
        protected void FinishLayout()
        {
            ResumeLayout(false);
            PerformLayout();
        }

        [DllImport("dwmapi.dll")]
        static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            try
            {
                int on = 1;
                if (DwmSetWindowAttribute(Handle, 20, ref on, 4) != 0) DwmSetWindowAttribute(Handle, 19, ref on, 4);
            }
            catch { }
        }
    }

    // ------------------------------------------------------------------ the splash shown while UNISON starts
    class Splash : DarkForm
    {
        readonly Label status, detail;
        readonly Bar bar;
        readonly Button retry, log, quit;
        public Action OnRetry, OnQuit;

        [DllImport("user32.dll")] static extern bool ReleaseCapture();
        [DllImport("user32.dll")] static extern IntPtr SendMessage(IntPtr h, int msg, IntPtr w, IntPtr l);

        public Splash()
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(440, 276);
            BackColor = Theme.Panel;
            ShowInTaskbar = true;

            var mark = new Mark(Theme.Panel);
            mark.SetBounds(186, 30, 68, 52);
            var title = Theme.Lbl("U N I S O N", Theme.F(15f, FontStyle.Bold), Theme.Text, 0, 88, 440, 34);
            title.TextAlign = ContentAlignment.MiddleCenter;
            status = Theme.Lbl("Starting...", Theme.F(10f), Theme.Dim, 20, 128, 400, 26);
            status.TextAlign = ContentAlignment.MiddleCenter;
            bar = new Bar();
            bar.SetBounds(70, 164, 300, 4);
            detail = Theme.Lbl("", Theme.F(8.5f), Theme.Faint, 24, 160, 392, 52);
            detail.TextAlign = ContentAlignment.TopCenter;
            retry = Theme.Btn("Try again", true);
            log = Theme.Btn("Open log", false);
            quit = Theme.Btn("Quit", false);
            retry.SetBounds(296, 222, 120, 36);
            log.SetBounds(160, 222, 120, 36);
            quit.SetBounds(24, 222, 120, 36);
            retry.Click += delegate { var a = OnRetry; if (a != null) a(); };
            quit.Click += delegate { var a = OnQuit; if (a != null) a(); };
            log.Click += delegate { App.Open(Path.Combine(App.LogsDir, "server.log")); };
            Controls.AddRange(new Control[] { mark, title, status, bar, detail, retry, log, quit });
            foreach (Control c in new Control[] { this, mark, title, status, detail }) c.MouseDown += Drag;
            Reset();
            FinishLayout();
        }

        void Drag(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;
            ReleaseCapture();
            SendMessage(Handle, 0xA1, (IntPtr)2, IntPtr.Zero);   // WM_NCLBUTTONDOWN on the caption
        }

        public void Reset()
        {
            status.ForeColor = Theme.Dim;
            status.Text = "Starting...";
            detail.Text = "";
            detail.Visible = false;
            bar.Visible = true;
            retry.Visible = log.Visible = quit.Visible = false;
        }

        public void SetStatus(string s)
        {
            status.ForeColor = Theme.Dim;
            status.Text = s;
        }

        public void ShowError(string message, string details)
        {
            status.ForeColor = Theme.Bad;
            status.Text = message;
            detail.Text = App.Shorten((details ?? "").Trim(), 260);
            detail.Visible = true;
            bar.Visible = false;
            retry.Visible = log.Visible = quit.Visible = true;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            using (var p = new Pen(Theme.Line)) e.Graphics.DrawRectangle(p, 0, 0, ClientSize.Width - 1, ClientSize.Height - 1);
        }
    }

    // ------------------------------------------------------------------ runs Ollama + the UNISON server, hidden
    class Server
    {
        Process proc;
        StreamWriter log;
        readonly object gate = new object();
        readonly Queue<string> tail = new Queue<string>();
        volatile bool stopping, ready;
        public Action Crashed;

        public string LogPath { get { return Path.Combine(App.LogsDir, "server.log"); } }

        void Write(string line)
        {
            if (line == null) return;
            lock (gate)
            {
                tail.Enqueue(line);
                while (tail.Count > 30) tail.Dequeue();
                try { if (log != null) log.WriteLine(line); } catch { }
            }
        }

        public string Tail(int n)
        {
            lock (gate)
            {
                string[] a = tail.ToArray();
                int start = Math.Max(0, a.Length - n);
                return string.Join("\n", a, start, a.Length - start);
            }
        }

        static string FindOllama()
        {
            string local = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs\\Ollama\\ollama.exe");
            if (File.Exists(local)) return local;
            foreach (string dir in (Environment.GetEnvironmentVariable("PATH") ?? "").Split(';'))
            {
                try
                {
                    string d = dir.Trim().Trim('"');
                    if (d.Length == 0) continue;
                    string f = Path.Combine(d, "ollama.exe");
                    if (File.Exists(f)) return f;
                }
                catch { }
            }
            return null;
        }

        static string ExitCodeOf(Process p)
        {
            try { return p.ExitCode.ToString(); } catch { return "?"; }
        }

        /// Runs on a worker thread. Returns null once UNISON answers, otherwise a message for the user.
        public string Start(Action<string> status)
        {
            stopping = false;
            ready = false;
            string health = App.Url + "v1/health";
            status("Looking for a running UNISON...");
            if (App.HttpOk(health, 1500)) return null;   // already running (for example from Start-UNISON.bat -Console)

            status("Starting the AI engine...");
            string ollamaUrl = "http://127.0.0.1:11434/api/version";
            if (!App.HttpOk(ollamaUrl, 1500))
            {
                string exe = FindOllama();
                if (exe == null) return "Ollama, UNISON's AI engine, isn't installed. Run Setup.bat again.";
                try
                {
                    string trayApp = Path.Combine(Path.GetDirectoryName(exe), "ollama app.exe");
                    var psi = File.Exists(trayApp) ? new ProcessStartInfo(trayApp) : new ProcessStartInfo(exe, "serve");
                    psi.UseShellExecute = false;
                    psi.CreateNoWindow = true;
                    psi.WindowStyle = ProcessWindowStyle.Hidden;
                    Process.Start(psi);
                }
                catch (Exception ex) { return "Couldn't start Ollama: " + ex.Message; }
                bool up = false;
                for (int i = 0; i < 60 && !up; i++)
                {
                    Thread.Sleep(500);
                    up = App.HttpOk(ollamaUrl, 1000);
                }
                if (!up) return "Ollama didn't start. Open the Ollama app from the Start menu, then try again.";
            }

            status("Starting UNISON...");
            if (!File.Exists(App.VenvPy)) return "UNISON's Python environment is missing. Run Setup.bat again.";
            try
            {
                lock (gate)
                {
                    tail.Clear();
                    log = new StreamWriter(LogPath, true, new UTF8Encoding(false));
                    log.AutoFlush = true;
                    log.WriteLine("");
                    log.WriteLine("==== UNISON started " + DateTime.Now.ToString("s") + " ====");
                }
                var psi = new ProcessStartInfo(App.VenvPy, "-m backend.run");
                psi.WorkingDirectory = App.Root;
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;
                psi.StandardOutputEncoding = Encoding.UTF8;
                psi.StandardErrorEncoding = Encoding.UTF8;
                psi.EnvironmentVariables["PYTHONUNBUFFERED"] = "1";
                psi.EnvironmentVariables["PYTHONIOENCODING"] = "utf-8";
                var p = new Process();
                p.StartInfo = psi;
                p.EnableRaisingEvents = true;
                p.OutputDataReceived += (s, e) => Write(e.Data);
                p.ErrorDataReceived += (s, e) => Write(e.Data);
                p.Exited += (s, e) =>
                {
                    Write("==== UNISON server stopped (exit code " + ExitCodeOf(p) + ") ====");
                    bool unexpected = !stopping && ready && proc == p;
                    if (proc == p) proc = null;
                    if (unexpected) { var c = Crashed; if (c != null) c(); }
                };
                p.Start();
                p.BeginOutputReadLine();
                p.BeginErrorReadLine();
                proc = p;
            }
            catch (Exception ex) { return "Couldn't start UNISON: " + ex.Message; }

            for (int i = 0; i < 240; i++)
            {
                if (App.HttpOk(health, 1000)) { ready = true; return null; }
                Process p = proc;
                if (p == null || p.HasExited) return "UNISON stopped while starting.";
                Thread.Sleep(500);
            }
            return "UNISON is taking too long to start.";
        }

        public void Stop()
        {
            stopping = true;
            ready = false;
            Process p = proc;
            proc = null;
            if (p != null)
            {
                try { if (!p.HasExited) App.KillTree(p.Id); } catch { }
            }
            lock (gate)
            {
                try { if (log != null) log.Dispose(); } catch { }
                log = null;
            }
        }
    }

    // ------------------------------------------------------------------ the main window (UNISON's interface)
#if WEBVIEW2
    /// Everything that touches WebView2 lives here, so a missing component only fails inside a try/catch.
    static class Web2
    {
        static bool loaderSet;

        [MethodImpl(MethodImplOptions.NoInlining)]
        public static Control Create(Form host, string url, Action<string> failed)
        {
            if (!loaderSet)
            {
                loaderSet = true;
                try { CoreWebView2Environment.SetLoaderDllFolderPath(App.P("desktop", "bin")); } catch { }
            }
            var wv = new WebView2();
            wv.CreationProperties = new CoreWebView2CreationProperties();
            wv.CreationProperties.UserDataFolder = Path.Combine(App.DataDir, "WebView2");
            wv.DefaultBackgroundColor = Theme.Bg;
            wv.Dock = DockStyle.Fill;
            wv.CoreWebView2InitializationCompleted += (s, e) =>
            {
                if (!e.IsSuccess)
                {
                    failed(e.InitializationException != null ? e.InitializationException.Message : "WebView2 didn't start");
                    return;
                }
                CoreWebView2 core = wv.CoreWebView2;
                core.Settings.IsStatusBarEnabled = false;
                // Links that open a new window (help pages, the website) go to the normal browser.
                core.NewWindowRequested += (s2, e2) => { e2.Handled = true; App.Open(e2.Uri); };
                core.DocumentTitleChanged += (s3, e3) =>
                {
                    string t = core.DocumentTitle;
                    host.Text = (string.IsNullOrEmpty(t) || t == "UNISON") ? "UNISON" : t + " - UNISON";
                };
            };
            host.Controls.Add(wv);
            wv.Source = new Uri(url);
            return wv;
        }
    }
#endif

    class MainWindow : DarkForm
    {
        static bool webBroken;
        public bool Embedded { get; private set; }
        public bool ForceClose;
        readonly string url;

        public MainWindow(string url)
        {
            this.url = url;
            Text = "UNISON";
            StartPosition = FormStartPosition.Manual;
            MinimumSize = new Size(760, 520);
            FinishLayout();
#if WEBVIEW2
            if (!webBroken)
            {
                try
                {
                    Web2.Create(this, url, OnWebFailed);
                    Embedded = true;
                }
                catch (Exception ex)
                {
                    App.LogCrash(ex);
                    webBroken = true;
                }
            }
#endif
            if (!Embedded) App.OpenAppWindow(url);
        }

        void OnWebFailed(string why)
        {
            // The WebView2 runtime is missing or broken on this PC: use an Edge app window instead.
            webBroken = true;
            App.LogCrash(new Exception("WebView2: " + why));
            App.OpenAppWindow(url);
            ForceClose = true;
            BeginInvoke(new Action(Close));
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            Rectangle wa = Screen.PrimaryScreen.WorkingArea;
            int w = Math.Min(1280, (int)(wa.Width * 0.9)), h = Math.Min(880, (int)(wa.Height * 0.9));
            var r = new Rectangle(wa.X + (wa.Width - w) / 2, wa.Y + (wa.Height - h) / 2, w, h);
            bool max = false;
            string[] s = Prefs.Get("window", "").Split(',');
            int x, y, sw, sh;
            if (s.Length == 5 && int.TryParse(s[0], out x) && int.TryParse(s[1], out y) &&
                int.TryParse(s[2], out sw) && int.TryParse(s[3], out sh) && sw >= 400 && sh >= 300)
            {
                var saved = new Rectangle(x, y, sw, sh);
                foreach (Screen sc in Screen.AllScreens)
                {
                    if (sc.WorkingArea.IntersectsWith(saved)) { r = saved; max = s[4] == "1"; break; }
                }
            }
            Bounds = r;
            if (max) WindowState = FormWindowState.Maximized;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (Embedded && Visible)
            {
                Rectangle b = WindowState == FormWindowState.Normal ? Bounds : RestoreBounds;
                Prefs.Set("window", string.Format("{0},{1},{2},{3},{4}", b.X, b.Y, b.Width, b.Height,
                    WindowState == FormWindowState.Maximized ? 1 : 0));
            }
            base.OnFormClosing(e);
        }
    }

    // ------------------------------------------------------------------ tray icon: owns the server and the window
    class TrayApp : ApplicationContext
    {
        readonly NotifyIcon tray = new NotifyIcon();
        readonly Server server = new Server();
        readonly Control ui = new Control();
        Splash splash;
        MainWindow window;
        ToolStripMenuItem keepItem;
        bool background, quitting, running, starting;

        public TrayApp(bool background)
        {
            this.background = background;
            IntPtr handle = ui.Handle;   // a hidden control, used to get back onto the UI thread

            var menu = new ContextMenuStrip();
            var openItem = new ToolStripMenuItem("Open UNISON", null, delegate { ShowWindow(); });
            openItem.Font = new Font(openItem.Font, FontStyle.Bold);
            menu.Items.Add(openItem);
            menu.Items.Add(new ToolStripMenuItem("Open in my web browser", null, delegate { App.Open(App.Url); }));
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(new ToolStripMenuItem("Remote access (phone / work)...", null, delegate { App.RunScriptWindow("remote.ps1", ""); }));
            menu.Items.Add(new ToolStripMenuItem("Restart UNISON", null, delegate { Restart(); }));
            menu.Items.Add(new ToolStripMenuItem("Open the UNISON folder", null, delegate { App.Open(App.Root); }));
            menu.Items.Add(new ToolStripMenuItem("Open the server log", null, delegate { App.Open(server.LogPath); }));
            menu.Items.Add(new ToolStripSeparator());
            keepItem = new ToolStripMenuItem("Keep running in the tray when I close the window");
            keepItem.CheckOnClick = true;
            keepItem.Checked = Prefs.GetBool("keepInTray", true);
            keepItem.CheckedChanged += delegate { Prefs.SetBool("keepInTray", keepItem.Checked); };
            var autoItem = new ToolStripMenuItem("Start UNISON when I sign in to Windows");
            autoItem.CheckOnClick = true;
            autoItem.Checked = Shortcuts.StartsWithWindows;
            autoItem.CheckedChanged += delegate { Shortcuts.SetStartWithWindows(autoItem.Checked); };
            menu.Items.Add(keepItem);
            menu.Items.Add(autoItem);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(new ToolStripMenuItem("Quit UNISON", null, delegate { Quit(); }));

            tray.ContextMenuStrip = menu;
            Icon small = null;
            try
            {
                string ico = App.P("desktop", "unison.ico");
                if (File.Exists(ico)) small = new Icon(ico, SystemInformation.SmallIconSize);
            }
            catch { }
            tray.Icon = small ?? App.AppIcon ?? SystemIcons.Application;
            tray.Text = "UNISON";
            tray.Visible = true;
            tray.MouseClick += (s, e) => { if (e.Button == MouseButtons.Left) ShowWindow(); };
            tray.BalloonTipClicked += delegate { ShowWindow(); };

            server.Crashed = () => Ui(() =>
            {
                if (quitting) return;
                running = false;
                SetTip("stopped");
                tray.ShowBalloonTip(8000, "UNISON stopped unexpectedly",
                    "Click here to start it again. Details are in logs\\server.log.", ToolTipIcon.Warning);
            });

            try { Shortcuts.Ensure(); } catch { }
            BeginStart();
        }

        public void RequestShow() { Ui(() => { background = false; ShowWindow(); }); }

        void Ui(Action a)
        {
            try { if (ui.IsHandleCreated && !ui.IsDisposed) ui.BeginInvoke(a); } catch { }
        }

        void SetTip(string state) { tray.Text = App.Shorten("UNISON - " + state, 63); }

        Splash GetSplash()
        {
            if (splash == null || splash.IsDisposed)
            {
                splash = new Splash();
                splash.OnRetry = () => { splash.Reset(); background = false; BeginStart(); };
                splash.OnQuit = Quit;
            }
            return splash;
        }

        void BeginStart()
        {
            if (starting || quitting) return;
            starting = true;
            running = false;
            SetTip("starting");
            if (!background)
            {
                var s = GetSplash();
                s.Reset();
                s.Show();
                s.Activate();
            }
            var t = new Thread(() =>
            {
                string err;
                try
                {
                    err = server.Start(msg => Ui(() =>
                    {
                        if (splash != null && !splash.IsDisposed) splash.SetStatus(msg);
                    }));
                }
                catch (Exception ex) { App.LogCrash(ex); err = "Something went wrong starting UNISON: " + ex.Message; }
                Ui(() => Started(err));
            });
            t.IsBackground = true;
            t.Start();
        }

        void Started(string err)
        {
            starting = false;
            if (quitting) return;
            if (err != null)
            {
                SetTip("not running");
                var s = GetSplash();
                s.Show();
                s.ShowError(err, server.Tail(3));
                s.Activate();
                return;
            }
            running = true;
            SetTip("running");
            if (splash != null && !splash.IsDisposed) { splash.Close(); splash = null; }
            if (background)
            {
                background = false;   // started with Windows: stay quiet in the tray
                return;
            }
            ShowWindow();
        }

        void ShowWindow()
        {
            if (quitting) return;
            if (starting)
            {
                var s = GetSplash();
                s.Show();
                s.Activate();
                return;
            }
            if (!running)
            {
                BeginStart();
                return;
            }
            if (window == null || window.IsDisposed)
            {
                window = new MainWindow(App.Url);
                if (!window.Embedded)
                {
                    window.Dispose();   // it opened as an Edge app window instead
                    window = null;
                    return;
                }
                window.FormClosing += OnWindowClosing;
                window.Show();
            }
            else
            {
                window.Show();
                if (window.WindowState == FormWindowState.Minimized) window.WindowState = FormWindowState.Normal;
            }
            window.Activate();
        }

        void OnWindowClosing(object sender, FormClosingEventArgs e)
        {
            var w = (MainWindow)sender;
            if (quitting || w.ForceClose || e.CloseReason != CloseReason.UserClosing) return;
            if (keepItem.Checked)
            {
                e.Cancel = true;   // keep the page loaded so reopening is instant
                w.Hide();
                if (!Prefs.GetBool("trayTipShown", false))
                {
                    Prefs.SetBool("trayTipShown", true);
                    tray.ShowBalloonTip(7000, "UNISON is still running",
                        "It's in the tray by the clock. Click the icon to open it, or right-click to quit.", ToolTipIcon.Info);
                }
            }
            else
            {
                Ui(Quit);
            }
        }

        void Restart()
        {
            if (starting || quitting) return;
            if (window != null && !window.IsDisposed) { window.ForceClose = true; window.Close(); }
            window = null;
            server.Stop();
            background = false;
            BeginStart();
        }

        void Quit()
        {
            if (quitting) return;
            quitting = true;
            try { if (window != null && !window.IsDisposed) { window.ForceClose = true; window.Close(); } } catch { }
            try { if (splash != null && !splash.IsDisposed) splash.Close(); } catch { }
            server.Stop();
            tray.Visible = false;
            tray.Dispose();
            ExitThread();
        }
    }

    // ------------------------------------------------------------------ first-run setup wizard
    class SetupWizard : DarkForm
    {
        public bool Succeeded, LaunchAfter;

        static readonly string[] StepKeys = { "1/8", "2/8", "2b", "3/8", "4/8", "5/8", "6/8", "7/8", "8/8" };
        static readonly string[] StepTitles = {
            "Check your hardware", "Python", "License key", "Node.js (builds the interface)", "Ollama AI engine",
            "Pick a model for your PC", "Download the model", "Install and build the app", "Final checks with the real model" };
        const int LicenseStep = 2, DownloadStep = 6;

        readonly Panel pWelcome, pWork, pDone, pFail;
        readonly TextBox keyBox, logBox;
        readonly Label keyNote, workStatus, failMsg, doneTitle, doneText;
        readonly Label[] stepIcons = new Label[9], stepNames = new Label[9];
        readonly Bar bar;
        readonly CheckBox cbShortcuts, cbStart;
        readonly Button btnInstall, btnFinish, btnRetry;
        readonly LinkLabel detailsLink;
        readonly Font stepFont = Theme.F(10f), stepFontBold = Theme.F(10f, FontStyle.Bold);
        readonly ConcurrentQueue<string> lines = new ConcurrentQueue<string>();
        readonly System.Windows.Forms.Timer pump = new System.Windows.Forms.Timer();

        Process proc;
        int step = -1, eofs;
        string failText, lastBad;
        bool doneOk, doneWarn, cancelled;

        public SetupWizard()
        {
            Text = "UNISON Setup";
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(760, 540);

            // header
            var mark = new Mark(Theme.Bg);
            mark.SetBounds(34, 20, 50, 40);
            Controls.Add(mark);
            Controls.Add(Theme.Lbl("UNISON", Theme.F(15f, FontStyle.Bold), Theme.Text, 90, 16, 300, 30));
            Controls.Add(Theme.Lbl("Setup  \u00B7  private AI that runs on this computer", Theme.F(9f), Theme.Dim, 92, 46, 500, 20));
            var rule = new Panel();
            rule.BackColor = Theme.Line;
            rule.SetBounds(0, 79, 760, 1);
            Controls.Add(rule);

            pWelcome = NewPage();
            pWork = NewPage();
            pDone = NewPage();
            pFail = NewPage();

            // ---- welcome
            pWelcome.Controls.Add(Theme.Lbl("Welcome to UNISON", Theme.F(20f, FontStyle.Bold), Theme.Text, 40, 14, 680, 44));
            pWelcome.Controls.Add(Theme.Lbl(
                "Setup gets everything ready on this PC. It usually takes 10 to 30 minutes, mostly downloading " +
                "the AI model. You can keep using your computer while it runs.",
                Theme.F(10.5f), Theme.Dim, 40, 62, 680, 48));
            string[] bullets = {
                "Installs anything missing: Python, Node.js and the Ollama AI engine",
                "Downloads an AI model sized for your graphics card (about 5 to 10 GB)",
                "Builds the app and tests it with the real model" };
            for (int i = 0; i < bullets.Length; i++)
            {
                pWelcome.Controls.Add(Theme.Lbl("\u2713", Theme.F(10.5f, FontStyle.Bold), Theme.Accent, 42, 122 + i * 28, 22, 24));
                pWelcome.Controls.Add(Theme.Lbl(bullets[i], Theme.F(10.5f), Theme.Text, 66, 122 + i * 28, 640, 24));
            }
            pWelcome.Controls.Add(Theme.Lbl("License key", Theme.F(10.5f, FontStyle.Bold), Theme.Text, 40, 222, 300, 24));
            keyBox = new TextBox();
            keyBox.SetBounds(40, 250, 680, 30);
            keyBox.Font = Theme.Mono(11f);
            keyBox.BackColor = Theme.Panel2;
            keyBox.ForeColor = Theme.Text;
            keyBox.BorderStyle = BorderStyle.FixedSingle;
            pWelcome.Controls.Add(keyBox);
            keyNote = Theme.Lbl("", Theme.F(9.5f), Theme.Dim, 40, 286, 680, 40);
            pWelcome.Controls.Add(keyNote);
            var buy = Theme.Link("Don't have a key? Get one on the UNISON website", 40, 328, 420);
            buy.LinkClicked += delegate { App.Open(App.SiteUrl + "#license"); };
            pWelcome.Controls.Add(buy);
            var cancel1 = Theme.Btn("Cancel", false);
            cancel1.Location = new Point(448, 396);
            cancel1.Click += delegate { Close(); };
            btnInstall = Theme.Btn("Install", true);
            btnInstall.Location = new Point(588, 396);
            btnInstall.Click += delegate { Install(); };
            pWelcome.Controls.Add(cancel1);
            pWelcome.Controls.Add(btnInstall);

            // ---- installing
            pWork.Controls.Add(Theme.Lbl("Installing UNISON", Theme.F(20f, FontStyle.Bold), Theme.Text, 40, 14, 680, 44));
            workStatus = Theme.Lbl("Starting...", Theme.F(9.5f), Theme.Dim, 40, 60, 680, 22);
            pWork.Controls.Add(workStatus);
            bar = new Bar();
            bar.SetBounds(40, 88, 680, 5);
            pWork.Controls.Add(bar);
            for (int i = 0; i < StepTitles.Length; i++)
            {
                stepIcons[i] = Theme.Lbl("\u25CB", Theme.F(10f, FontStyle.Bold), Theme.Faint, 42, 108 + i * 28, 24, 24);
                stepNames[i] = Theme.Lbl(StepTitles[i], stepFont, Theme.Faint, 70, 108 + i * 28, 600, 24);
                pWork.Controls.Add(stepIcons[i]);
                pWork.Controls.Add(stepNames[i]);
            }
            logBox = new TextBox();
            logBox.Multiline = true;
            logBox.ReadOnly = true;
            logBox.ScrollBars = ScrollBars.Vertical;
            logBox.WordWrap = true;
            logBox.Font = Theme.Mono(9f);
            logBox.BackColor = Theme.Panel;
            logBox.ForeColor = Theme.Dim;
            logBox.BorderStyle = BorderStyle.FixedSingle;
            logBox.SetBounds(40, 104, 680, 258);
            logBox.Visible = false;
            pWork.Controls.Add(logBox);
            detailsLink = Theme.Link("Show details", 40, 372, 200);
            detailsLink.LinkClicked += delegate { ToggleDetails(); };
            pWork.Controls.Add(detailsLink);
            var cancel2 = Theme.Btn("Cancel", false);
            cancel2.Location = new Point(588, 396);
            cancel2.Click += delegate { CancelWork(); };
            pWork.Controls.Add(cancel2);

            // ---- done
            pDone.Controls.Add(Theme.Lbl("\u2713", Theme.F(30f, FontStyle.Bold), Theme.Accent, 36, 6, 60, 60));
            doneTitle = Theme.Lbl("UNISON is ready", Theme.F(20f, FontStyle.Bold), Theme.Text, 40, 64, 680, 44);
            doneText = Theme.Lbl("", Theme.F(10.5f), Theme.Dim, 40, 110, 680, 70);
            pDone.Controls.Add(doneTitle);
            pDone.Controls.Add(doneText);
            cbShortcuts = NewCheck("Add UNISON to the Start menu and the desktop", 40, 196);
            cbStart = NewCheck("Open UNISON now", 40, 228);
            pDone.Controls.Add(cbShortcuts);
            pDone.Controls.Add(cbStart);
            var doneLog = Theme.Link("Open the setup log", 40, 372, 200);
            doneLog.LinkClicked += delegate { App.Open(App.P("logs", "setup.log")); };
            pDone.Controls.Add(doneLog);
            btnFinish = Theme.Btn("Finish", true);
            btnFinish.Location = new Point(588, 396);
            btnFinish.Click += delegate { Finish(); };
            pDone.Controls.Add(btnFinish);

            // ---- failed
            pFail.Controls.Add(Theme.Lbl("Setup stopped", Theme.F(20f, FontStyle.Bold), Theme.Bad, 40, 14, 680, 44));
            failMsg = Theme.Lbl("", Theme.F(10.5f), Theme.Text, 40, 66, 680, 120);
            pFail.Controls.Add(failMsg);
            pFail.Controls.Add(Theme.Lbl(
                "Nothing is lost: running setup again picks up where it left off (downloads resume). " +
                "The full log is in logs\\setup.log - send it over if you're stuck.",
                Theme.F(9.5f), Theme.Dim, 40, 196, 680, 44));
            var failLog = Theme.Btn("Open log", false);
            failLog.Location = new Point(308, 396);
            failLog.Click += delegate { App.Open(App.P("logs", "setup.log")); };
            var failClose = Theme.Btn("Close", false);
            failClose.Location = new Point(448, 396);
            failClose.Click += delegate { Close(); };
            btnRetry = Theme.Btn("Try again", true);
            btnRetry.Location = new Point(588, 396);
            btnRetry.Click += delegate { Install(); };
            pFail.Controls.Add(failLog);
            pFail.Controls.Add(failClose);
            pFail.Controls.Add(btnRetry);

            pump.Interval = 100;
            pump.Tick += delegate { Pump(); };
            ShowPage(pWelcome);
            ResetKeyNote();
            FinishLayout();
        }

        Panel NewPage()
        {
            var p = new Panel();
            p.SetBounds(0, 80, 760, 460);
            p.BackColor = Theme.Bg;
            p.Visible = false;
            Controls.Add(p);
            return p;
        }

        static CheckBox NewCheck(string text, int x, int y)
        {
            var c = new CheckBox();
            c.Text = text;
            c.Checked = true;
            c.Font = Theme.F(10.5f);
            c.ForeColor = Theme.Text;
            c.BackColor = Theme.Bg;
            c.FlatStyle = FlatStyle.Flat;
            c.FlatAppearance.BorderColor = Theme.Line;
            c.SetBounds(x, y, 600, 28);
            return c;
        }

        void ShowPage(Panel page)
        {
            foreach (Panel p in new[] { pWelcome, pWork, pDone, pFail }) p.Visible = p == page;
            AcceptButton = page == pWelcome ? btnInstall : page == pDone ? btnFinish : page == pFail ? btnRetry : null;
        }

        void ResetKeyNote()
        {
            keyNote.ForeColor = Theme.Dim;
            keyNote.Text = App.HasLicenseSaved()
                ? "This PC is already activated, so you can leave this empty."
                : "Paste the key from your purchase email. It starts with UNISON-";
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            keyBox.Focus();
        }

        void ToggleDetails()
        {
            bool show = !logBox.Visible;
            logBox.Visible = show;
            foreach (Label l in stepIcons) l.Visible = !show;
            foreach (Label l in stepNames) l.Visible = !show;
            detailsLink.Text = show ? "Hide details" : "Show details";
            if (show) { logBox.SelectionStart = logBox.TextLength; logBox.ScrollToCaret(); }
        }

        void Install()
        {
            string key = Regex.Replace(keyBox.Text ?? "", "\\s+", "");
            if (key.Length == 0 && !App.HasLicenseSaved())
            {
                ShowPage(pWelcome);
                keyNote.ForeColor = Theme.Bad;
                keyNote.Text = "Paste your license key first. It starts with UNISON-";
                keyBox.Focus();
                return;
            }
            if (key.Length > 0 && !key.StartsWith("UNISON-"))
            {
                ShowPage(pWelcome);
                keyNote.ForeColor = Theme.Bad;
                keyNote.Text = "That doesn't look like a UNISON license key. It should start with UNISON-";
                keyBox.Focus();
                return;
            }

            ShowPage(pWork);
            SetStep(-1);
            bar.Value = 0;
            logBox.Clear();
            workStatus.Text = "Starting setup...";
            step = -1;
            eofs = 0;
            failText = lastBad = null;
            doneOk = doneWarn = cancelled = false;
            string drained;
            while (lines.TryDequeue(out drained)) { }

            var psi = new ProcessStartInfo("powershell.exe",
                "-NoProfile -ExecutionPolicy Bypass -File \"" + App.P("scripts", "setup.ps1") + "\" -Gui");
            psi.WorkingDirectory = App.Root;
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardInput = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            if (key.Length > 0) psi.EnvironmentVariables["UNISON_LICENSE_KEY"] = key;
            var p = new Process();
            p.StartInfo = psi;
            DataReceivedEventHandler onData = (s, e) =>
            {
                if (e.Data != null) { lines.Enqueue(e.Data); return; }
                if (Interlocked.Increment(ref eofs) == 2)
                {
                    // both output streams are finished: report how it ended
                    try { p.WaitForExit(); lines.Enqueue("@@EXIT " + p.ExitCode); }
                    catch { lines.Enqueue("@@EXIT 1"); }
                }
            };
            p.OutputDataReceived += onData;
            p.ErrorDataReceived += onData;
            try
            {
                p.Start();
                p.StandardInput.Close();   // nothing to type: every question has a default in -Gui mode
                p.BeginOutputReadLine();
                p.BeginErrorReadLine();
                proc = p;
            }
            catch (Exception ex)
            {
                Fail("Couldn't start setup: " + ex.Message);
                return;
            }
            pump.Start();
        }

        void SetStep(int i)
        {
            for (int k = 0; k < stepIcons.Length; k++)
            {
                if (k < i)
                {
                    stepIcons[k].Text = "\u2713";
                    stepIcons[k].ForeColor = Theme.Accent;
                    stepNames[k].ForeColor = Theme.Dim;
                    stepNames[k].Font = stepFont;
                }
                else if (k == i)
                {
                    stepIcons[k].Text = "\u25CF";
                    stepIcons[k].ForeColor = Theme.Accent2;
                    stepNames[k].ForeColor = Theme.Text;
                    stepNames[k].Font = stepFontBold;
                }
                else
                {
                    stepIcons[k].Text = "\u25CB";
                    stepIcons[k].ForeColor = Theme.Faint;
                    stepNames[k].ForeColor = Theme.Faint;
                    stepNames[k].Font = stepFont;
                }
            }
            step = i;
            if (i >= 0) bar.Value = Math.Min(1f, i / (float)StepKeys.Length);
        }

        static readonly Regex Ansi = new Regex("\u001b\\[[0-9;?]*[ -/]*[@-~]");
        static readonly Regex StepLine = new Regex("^\\[(\\d/8|2b)\\]\\s*(.*)$");
        static readonly Regex Percent = new Regex("(\\d{1,3})%");
        static readonly Regex Prefix = new Regex("^(ok|!!|XX)\\s+");

        void Pump()
        {
            var sb = new StringBuilder();
            string raw;
            int n = 0;
            while (n++ < 500 && lines.TryDequeue(out raw))
            {
                string line = Ansi.Replace(raw, "").TrimEnd();
                if (line.StartsWith("@@EXIT "))
                {
                    int code;
                    if (!int.TryParse(line.Substring(7).Trim(), out code)) code = 1;
                    Flush(sb);
                    Finished(code);
                    return;
                }
                if (line.StartsWith("@@FAIL ")) { failText = line.Substring(7).Trim(); continue; }
                if (line.StartsWith("@@DONE ")) { doneOk = true; doneWarn = line.Contains("warn"); continue; }
                string t = line.Trim();
                if (t.Length == 0) continue;

                Match m = StepLine.Match(t);
                if (m.Success)
                {
                    int i = Array.IndexOf(StepKeys, m.Groups[1].Value);
                    if (i >= 0) SetStep(i);
                    sb.Append("\r\n").Append(t).Append("\r\n");
                    workStatus.Text = App.Shorten(m.Groups[2].Value, 110);
                    continue;
                }

                // download progress (ollama pull): update the bar, don't flood the log
                Match pct = Percent.Match(t);
                bool progress = pct.Success && (t.IndexOf("pulling", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                                t.Contains("\u2588") || t.Contains("MB/") || t.Contains("GB/"));
                if (progress)
                {
                    int p = Math.Min(100, int.Parse(pct.Groups[1].Value));
                    if (step == DownloadStep) bar.Value = (DownloadStep + p / 100f) / StepKeys.Length;
                    workStatus.Text = "Downloading the model... " + p + "%";
                    continue;
                }

                sb.Append(t).Append("\r\n");
                if (t.StartsWith("XX")) lastBad = Prefix.Replace(t, "");
                else if (lastBad != null && step == LicenseStep && t.IndexOf("Machine ID", StringComparison.OrdinalIgnoreCase) >= 0) lastBad += " " + t;
                workStatus.Text = App.Shorten(Prefix.Replace(t, ""), 110);
            }
            Flush(sb);
        }

        void Flush(StringBuilder sb)
        {
            if (sb.Length == 0) return;
            logBox.AppendText(sb.ToString());
            if (logBox.TextLength > 400000) logBox.Text = logBox.Text.Substring(logBox.TextLength - 250000);
        }

        void Finished(int code)
        {
            pump.Stop();
            proc = null;
            if (cancelled) { Close(); return; }
            if (code == 0 && (doneOk || App.IsSetUp()))
            {
                SetStep(StepKeys.Length);
                bar.Value = 1f;
                Succeeded = true;
                if (doneWarn)
                {
                    doneTitle.Text = "UNISON is installed";
                    doneText.Text = "Setup finished, but some of the self-tests didn't pass. UNISON will probably still work fine; " +
                                    "the details are in docs\\SELFTEST.md.";
                }
                else
                {
                    doneTitle.Text = "UNISON is ready";
                    doneText.Text = "Every self-test passed with your real model. UNISON runs entirely on this PC - " +
                                    "after today it doesn't even need the internet.";
                }
                ShowPage(pDone);
                return;
            }
            string msg = failText ?? lastBad ?? ("Setup stopped unexpectedly (exit code " + code + ").");
            if (step == LicenseStep)
            {
                // a key problem: back to the key box, with the reason
                ShowPage(pWelcome);
                keyNote.ForeColor = Theme.Bad;
                keyNote.Text = lastBad ?? msg;
                keyBox.Focus();
                keyBox.SelectAll();
                return;
            }
            Fail(msg);
        }

        void Fail(string msg)
        {
            pump.Stop();
            proc = null;
            failMsg.Text = msg;
            ShowPage(pFail);
        }

        void CancelWork()
        {
            Process p = proc;
            if (p == null) { Close(); return; }
            if (MessageBox.Show(this, "Stop setup? You can run it again later - it picks up where it left off.", "UNISON Setup",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            cancelled = true;
            workStatus.Text = "Stopping...";
            try { App.KillTree(p.Id); } catch { }
        }

        void Finish()
        {
            if (cbShortcuts.Checked)
            {
                Shortcuts.Make(Shortcuts.StartMenu, "");
                Shortcuts.Make(Shortcuts.Desktop, "");
            }
            LaunchAfter = cbStart.Checked;
            Close();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (proc != null && !cancelled)
            {
                e.Cancel = true;
                CancelWork();
                return;
            }
            base.OnFormClosing(e);
        }
    }

    // ------------------------------------------------------------------ entry point
    static class Program
    {
        [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] static extern bool SetDllDirectory(string path);

        static Assembly ResolveFromBin(object sender, ResolveEventArgs e)
        {
            try
            {
                string f = App.P("desktop", "bin", new AssemblyName(e.Name).Name + ".dll");
                if (File.Exists(f)) return Assembly.LoadFrom(f);
            }
            catch { }
            return null;
        }

        static void Crash(Exception ex)
        {
            App.LogCrash(ex);
            try
            {
                MessageBox.Show("Something went wrong in UNISON:\n\n" + (ex == null ? "unknown error" : ex.Message) +
                    "\n\nThe details were saved to logs\\desktop.log.", "UNISON", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch { }
        }

        [STAThread]
        static int Main(string[] args)
        {
            try { SetProcessDPIAware(); } catch { }
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.ThreadException += (s, e) => Crash(e.Exception);
            AppDomain.CurrentDomain.UnhandledException += (s, e) => Crash(e.ExceptionObject as Exception);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            try { SetDllDirectory(App.P("desktop", "bin")); } catch { }
            AppDomain.CurrentDomain.AssemblyResolve += ResolveFromBin;
            try
            {
                string ico = App.P("desktop", "unison.ico");
                App.AppIcon = File.Exists(ico) ? new Icon(ico) : Icon.ExtractAssociatedIcon(Application.ExecutablePath);
            }
            catch { }

            if (!App.LooksLikeUnisonFolder())
            {
                MessageBox.Show("UNISON.exe has to stay inside the UNISON folder (next to Setup.bat and the scripts folder).\n\n" +
                    "Move it back there. To start UNISON from somewhere else, use a shortcut instead.",
                    "UNISON", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return 1;
            }

            bool forceSetup = Array.IndexOf(args, "--setup") >= 0;
            bool background = Array.IndexOf(args, "--background") >= 0;

            bool first;
            using (var mutex = new Mutex(true, "Local\\UNISON.Desktop", out first))
            using (var showEvent = new EventWaitHandle(false, EventResetMode.AutoReset, "Local\\UNISON.Desktop.Show"))
            {
                if (!first)
                {
                    showEvent.Set();   // UNISON is already open: bring it to the front instead
                    return 0;
                }
                Action onShow = null;
                var listener = new Thread(() =>
                {
                    try
                    {
                        while (true)
                        {
                            showEvent.WaitOne();
                            Action a = onShow;
                            if (a != null) { try { a(); } catch { } }
                        }
                    }
                    catch { }
                });
                listener.IsBackground = true;
                listener.Start();

                int result = 0;
                if (forceSetup || !App.IsSetUp())
                {
                    var wiz = new SetupWizard();
                    onShow = () =>
                    {
                        if (wiz.IsDisposed || !wiz.IsHandleCreated) return;
                        wiz.BeginInvoke(new Action(() =>
                        {
                            if (wiz.WindowState == FormWindowState.Minimized) wiz.WindowState = FormWindowState.Normal;
                            wiz.Activate();
                        }));
                    };
                    Application.Run(wiz);
                    onShow = null;
                    if (!wiz.LaunchAfter || !App.IsSetUp()) result = wiz.Succeeded ? 0 : 1;
                    else result = -1;
                }
                else result = -1;

                if (result == -1)
                {
                    var app = new TrayApp(background);
                    onShow = app.RequestShow;
                    Application.Run(app);
                    result = 0;
                }
                try { mutex.ReleaseMutex(); } catch { }
                return result;
            }
        }
    }
}
