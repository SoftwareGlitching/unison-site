import { useState } from "react";
import { api } from "../lib/api";

export interface ScreenItem {
  kind: "screen";
  key: string;
  step: number;
  image?: string;
  window?: string;
  thought: string;
  action?: { name: string; description: string; decision: string };
  status: "thinking" | "approval" | "running" | "done" | "failed" | "denied";
  approval?: { actionId: string; image: string; summary: string };
  result?: string;
}

/** One see-think-act step of screen control: what the model saw, what it wants to do, and the outcome. */
export function ScreenStep({ item }: { item: ScreenItem }) {
  const [big, setBig] = useState(false);
  const [sending, setSending] = useState(false);
  const answer = async (ok: boolean) => {
    if (!item.approval) return;
    setSending(true);
    try {
      await api.approve(item.approval.actionId, ok);
    } finally {
      setSending(false);
    }
  };
  const img = item.status === "approval" && item.approval ? item.approval.image : item.image;
  const icon = { thinking: "…", approval: "?", running: "…", done: "✓", failed: "✕", denied: "⊘" }[item.status];
  const thought = item.thought.replace(/<tool_call>[\s\S]*?(<\/tool_call>|$)/g, "").trim();

  return (
    <div className={`tool-card screen-step st-${item.status}`}>
      <div className="tool-head">
        <span className="tool-icon">{icon}</span>
        <span className="tool-name">Step {item.step}</span>
        <span className="tool-sum">{item.action?.description ?? (item.status === "thinking" ? "looking at the screen…" : "")}</span>
        {(item.status === "thinking" || item.status === "running") && <span className="pulse" />}
      </div>
      <div className="screen-body">
        {img && (
          <img
            className={big ? "shot big" : "shot"}
            src={`data:image/jpeg;base64,${img}`}
            alt={`screen at step ${item.step}`}
            onClick={() => setBig(!big)}
            title="Click to enlarge"
          />
        )}
        <div className="screen-text">
          {item.window && <div className="dim small">window: {item.window}</div>}
          {thought && <div className="small">{thought}</div>}
          {item.status === "approval" && (
            <div className="approval">
              <div className="approval-title">Do this on your screen? {item.approval?.summary}</div>
              <div className="approval-actions">
                <button className="approve" disabled={sending} onClick={() => answer(true)}>Approve</button>
                <button className="deny" disabled={sending} onClick={() => answer(false)}>Deny</button>
              </div>
            </div>
          )}
          {item.result && item.status !== "done" && <div className="tool-note">{item.result}</div>}
        </div>
      </div>
    </div>
  );
}
