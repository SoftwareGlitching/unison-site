"""Sprites, 3D (Blender) and open_app tools."""
import os
import stat
import sys
import tempfile
import unittest
from pathlib import Path

from tests.helpers import IsolatedSettings  # noqa: I001
from backend.core.config import settings
from backend.tools import creative
from backend.tools.base import ToolError
from backend.tools.registry import ToolRegistry


class SpriteTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.ws = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_single_sprite(self):
        from PIL import Image
        with IsolatedSettings():
            settings.set("tools", "workspaces", [str(self.ws)])
            r = creative.make_sprite({"path": "hero.png", "scale": 2,
                                      "palette": {"k": "#000000", "s": "#f1c27d"},
                                      "pixels": [".kk.", "kssk", "kssk", ".kk."]})
        self.assertTrue(r.ok)
        im = Image.open(self.ws / "hero.png")
        self.assertEqual(im.size, (8, 8))
        self.assertEqual(im.getpixel((0, 0))[3], 0)                 # '.' is transparent
        self.assertEqual(im.getpixel((2, 2)), (241, 194, 125, 255))  # skin

    def test_animation_sheet(self):
        from PIL import Image
        f1, f2 = ["a.", ".a"], [".a", "a."]
        with IsolatedSettings():
            settings.set("tools", "workspaces", [str(self.ws)])
            r = creative.make_sprite({"path": "walk.png", "palette": {"a": "#ff0000"}, "frames": [f1, f2], "scale": 4})
        self.assertEqual(Image.open(self.ws / "walk.png").size, (16, 8))
        self.assertIn("2 frames", r.output)
        self.assertIn("drawImage", r.output)

    def test_bad_input_is_explained(self):
        with IsolatedSettings():
            settings.set("tools", "workspaces", [str(self.ws)])
            with self.assertRaises(ToolError):
                creative.make_sprite({"path": "x.png", "palette": {}, "pixels": ["zz"]})
            with self.assertRaises(ToolError):
                creative.make_sprite({"path": "x.jpg", "palette": {"a": "#fff"}, "pixels": ["a"]})


class BlenderTests(unittest.TestCase):
    def test_runs_blender_and_reports_new_files(self):
        with tempfile.TemporaryDirectory() as d, IsolatedSettings():
            ws = Path(d) / "ws"
            ws.mkdir()
            fake = Path(d) / "blender"
            # stand-in for Blender: checks it got a script with our helpers, then "exports" a model
            fake.write_text("#!/bin/sh\nscript=\"$6\"\ngrep -q 'def export_fbx' \"$script\" || exit 3\n"
                            "grep -q 'primitive_cube_add' \"$script\" || exit 4\necho made > crate.fbx\necho done\n")
            fake.chmod(fake.stat().st_mode | stat.S_IEXEC)
            settings.set("tools", "workspaces", [str(ws)])
            settings.set("tools", "blender_path", str(fake))
            r = creative.blender_script({"script": "bpy.ops.mesh.primitive_cube_add()\nexport_fbx('crate.fbx')"})
            self.assertTrue(r.ok, r.output)
            self.assertTrue((ws / "crate.fbx").exists())
            self.assertIn("crate.fbx", r.output)

    def test_missing_blender_is_explained(self):
        with IsolatedSettings():
            settings.set("tools", "blender_path", "/nope/blender")
            orig = creative.find_blender
            creative.find_blender = lambda: ""
            try:
                with self.assertRaises(ToolError):
                    creative.blender_script({"script": "pass"})
            finally:
                creative.find_blender = orig


class RegistryTests(unittest.TestCase):
    def test_tools_registered_with_sensible_approval(self):
        reg = ToolRegistry()
        self.assertEqual(reg.tools["blender_script"].default_mode, "ask")   # runs code: the user approves
        self.assertEqual(reg.tools["make_sprite"].default_mode, "auto")
        self.assertIn("open_app", reg.tools)


if __name__ == "__main__":
    unittest.main()
