"""A folder that contains UNISON (e.g. the Desktop) can be a workspace; UNISON's own files stay off-limits."""
import tempfile
import unittest
from pathlib import Path

from tests.helpers import IsolatedSettings  # noqa: I001
from backend.tools.base import ToolError
from backend.tools.sandbox import ROOT, PROJECTS_DIR, workspaces


class ParentWorkspaceTests(unittest.TestCase):
    def test_parent_of_unison_allowed_but_unison_files_blocked(self):
        parent = ROOT.parent
        with IsolatedSettings():
            workspaces.add(str(parent))
            with self.assertRaises(ToolError):
                workspaces.resolve(str(ROOT / "backend" / "main.py"))
            self.assertEqual(workspaces.resolve(str(parent / "some-game")), (parent / "some-game").resolve())

    def test_inside_unison_still_refused_except_projects(self):
        with IsolatedSettings():
            with self.assertRaises(ToolError):
                workspaces.add(str(ROOT / "backend"))
            PROJECTS_DIR.mkdir(exist_ok=True)
            workspaces.add(str(PROJECTS_DIR))

    def test_picker_endpoint_is_local_only(self):
        src = (ROOT / "backend" / "api" / "routes_agent.py").read_text()
        self.assertIn('@router.post("/workspaces/pick", tags=["tools"], dependencies=[Depends(local_only)])', src)


if __name__ == "__main__":
    unittest.main()
