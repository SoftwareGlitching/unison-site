"""
Turn your 👍 / 👎 ratings and corrections into training datasets.

Outputs (in datasets/training/):
  sft-<date>.jsonl          {"messages": [...]}  - supervised fine-tuning examples (good replies + your corrections)
  preferences-<date>.jsonl  {"prompt": [...], "chosen": "...", "rejected": "..."} - for preference training (DPO)
  manifest-<date>.json      counts, base model(s), hashes - dataset versioning

Tool-using turns keep the full trajectory (tool calls and results), so the dataset also teaches tool use.
"""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Optional

from ..core.config import ROOT
from ..database.db import Database

OUT_DIR = ROOT / "datasets" / "training"
CONTEXT_MESSAGES = 16


def _as_chat(m: dict) -> dict:
    d = {"role": m["role"], "content": m["content"]}
    if m.get("tool_calls"):
        d["tool_calls"] = [{"type": "function", "function": {"name": c["name"], "arguments": c.get("arguments") or {}}}
                           for c in m["tool_calls"]]
    if m["role"] == "tool":
        d["name"] = m.get("tool_name")
    return d


def _turn(db: Database, message_id: str) -> Optional[tuple[list[dict], dict]]:
    """Context before the rated reply (starting at a user message) and the reply itself."""
    msg = db.get_message(message_id)
    if not msg:
        return None
    rows = db.messages(msg["conversation_id"])
    idx = next((n for n, r in enumerate(rows) if r["id"] == message_id), None)
    if idx is None:
        return None
    ctx = rows[max(0, idx - CONTEXT_MESSAGES):idx]
    while ctx and ctx[0]["role"] != "user":
        ctx = ctx[1:]
    if not any(r["role"] == "user" for r in ctx):
        return None
    return [_as_chat(r) for r in ctx], msg


def export(db: Database, system_prompt: str = "", out_dir: Optional[Path] = None) -> dict:
    out_dir = out_dir or OUT_DIR
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    sft, prefs, models = [], [], set()
    for fb in db.feedback_rows():
        t = _turn(db, fb["message_id"])
        if not t:
            continue
        ctx, reply = t
        if reply.get("model"):
            models.add(reply["model"])
        head = [{"role": "system", "content": system_prompt}] if system_prompt else []
        if fb["rating"] > 0:
            sft.append({"messages": head + ctx + [_as_chat(reply)], "source": "thumbs_up", "id": fb["message_id"]})
        elif fb.get("correction"):
            sft.append({"messages": head + ctx + [{"role": "assistant", "content": fb["correction"]}],
                        "source": "correction", "id": fb["message_id"]})
            prefs.append({"prompt": head + ctx, "chosen": fb["correction"], "rejected": reply["content"],
                          "id": fb["message_id"]})
        else:
            prefs.append({"prompt": head + ctx, "chosen": None, "rejected": reply["content"],
                          "note": fb.get("note"), "id": fb["message_id"]})

    files = {}
    for name, rows in (("sft", sft), ("preferences", prefs)):
        path = out_dir / f"{name}-{stamp}.jsonl"
        with open(path, "w", encoding="utf-8") as f:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        files[name] = {"path": str(path), "examples": len(rows),
                       "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
    manifest = {"created": stamp, "base_models": sorted(models), "files": files,
                "note": "Collected from UNISON ratings. Fine-tuning needs a few hundred good examples to help "
                        "noticeably; measure with scripts/eval.py before and after."}
    (out_dir / f"manifest-{stamp}.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def stats(db: Database) -> dict:
    rows = db.feedback_rows()
    return {"thumbs_up": sum(1 for r in rows if r["rating"] > 0),
            "thumbs_down": sum(1 for r in rows if r["rating"] < 0),
            "corrections": sum(1 for r in rows if r.get("correction")),
            "exports": sorted(p.name for p in OUT_DIR.glob("manifest-*.json")) if OUT_DIR.exists() else []}
