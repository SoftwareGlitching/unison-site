@echo off
rem Train UNISON on code (fine-tunes the brain on your graphics card). Safe to stop and run again: it resumes.
rem Options: -Size quick^|standard^|big   -Yes   -SkipEval
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\train\train_unison.ps1" %*
