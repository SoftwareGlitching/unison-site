from __future__ import annotations

from typing import Any, Literal, Optional, Union

from pydantic import BaseModel, Field


# ---------------- OpenAI-compatible ----------------
class OAContentPart(BaseModel):
    type: str = "text"
    text: Optional[str] = None


class OAToolCallFunction(BaseModel):
    name: str
    arguments: Union[str, dict, None] = None


class OAToolCall(BaseModel):
    id: Optional[str] = None
    type: str = "function"
    function: OAToolCallFunction


class OAMessage(BaseModel):
    role: Literal["system", "user", "assistant", "tool", "developer"]
    content: Union[str, list[OAContentPart], None] = None
    name: Optional[str] = None
    tool_calls: Optional[list[OAToolCall]] = None
    tool_call_id: Optional[str] = None

    def text(self) -> str:
        if self.content is None:
            return ""
        if isinstance(self.content, str):
            return self.content
        return "".join(p.text or "" for p in self.content if p.type == "text")


class OAStreamOptions(BaseModel):
    include_usage: bool = False


class OAChatRequest(BaseModel):
    model: Optional[str] = None
    messages: list[OAMessage]
    stream: bool = False
    temperature: Optional[float] = Field(None, ge=0, le=2)
    top_p: Optional[float] = Field(None, ge=0, le=1)
    max_tokens: Optional[int] = Field(None, ge=1)
    max_completion_tokens: Optional[int] = Field(None, ge=1)
    stop: Union[str, list[str], None] = None
    seed: Optional[int] = None
    tools: Optional[list[dict[str, Any]]] = None
    stream_options: Optional[OAStreamOptions] = None
    user: Optional[str] = None


# ---------------- UNISON native ----------------
class SamplingOptions(BaseModel):
    temperature: Optional[float] = Field(None, ge=0, le=2)
    top_p: Optional[float] = Field(None, ge=0, le=1)
    top_k: Optional[int] = Field(None, ge=1, le=500)
    repeat_penalty: Optional[float] = Field(None, ge=0.5, le=2)
    num_ctx: Optional[int] = Field(None, ge=512, le=262144)
    max_tokens: Optional[int] = Field(None, ge=1)
    seed: Optional[int] = None


class ChatRequest(BaseModel):
    conversation_id: Optional[str] = None
    message: Optional[str] = None
    model: Optional[str] = None
    regenerate: bool = False
    stream: bool = True
    system: Optional[str] = Field(None, description="Override the system prompt for this request")
    tools: Optional[bool] = Field(None, description="Agent mode: let UNISON use its tools (files, terminal, MCP). "
                                                    "Defaults to the app setting.")
    options: SamplingOptions = SamplingOptions()


class SetModelRequest(BaseModel):
    model: str


class PullRequest(BaseModel):
    model: str


class RenameRequest(BaseModel):
    title: str = Field(..., min_length=1, max_length=200)


class CreateKeyRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=80)


class InferenceSettings(BaseModel):
    temperature: Optional[float] = Field(None, ge=0, le=2)
    top_p: Optional[float] = Field(None, ge=0, le=1)
    top_k: Optional[int] = Field(None, ge=1, le=500)
    repeat_penalty: Optional[float] = Field(None, ge=0.5, le=2)
    num_ctx: Optional[int] = Field(None, ge=512, le=262144)
    keep_alive: Optional[str] = None


class ApprovalAnswer(BaseModel):
    approve: bool
    note: str = ""


class ToolModeRequest(BaseModel):
    mode: Literal["auto", "ask", "deny", "default"]


class ToolExecuteRequest(BaseModel):
    name: str
    arguments: dict = {}
    approved: bool = Field(False, description="Required for tools whose mode is 'ask': confirms the user approved this call")


class WorkspaceRequest(BaseModel):
    path: str


class MCPServerRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=40)
    command: str
    args: list[str] = []
    env: dict[str, str] = {}
    enabled: bool = True


class KnowledgeIndexRequest(BaseModel):
    target: Literal["curated", "workspace", "folder"]
    path: Optional[str] = None


class KnowledgeSearchRequest(BaseModel):
    query: str
    k: int = Field(5, ge=1, le=20)


class KnowledgeDocument(BaseModel):
    name: str = Field(..., min_length=1, max_length=120)
    content: str = Field(..., min_length=1, max_length=2_000_000)


class FeedbackRequest(BaseModel):
    message_id: str
    rating: Literal[1, -1]
    correction: Optional[str] = None
    note: Optional[str] = None


class AgentSettings(BaseModel):
    agent_default: Optional[bool] = None
    auto_retrieve: Optional[bool] = None


class ScreenTaskRequest(BaseModel):
    task: str = Field(..., min_length=1, max_length=4000)
    autopilot: bool = Field(False, description="Run every action without asking (Esc or the top-left corner stops it)")
    model: Optional[str] = None
    minimize_self: bool = True


class VisionModelRequest(BaseModel):
    model: str
