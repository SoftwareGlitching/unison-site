import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from backend.core.model_selection import Hardware, select_models, write_selection, _fits_gpu  # noqa: E402


def tags(sel):
    return {k: v.model.tag for k, v in sel.tiers.items()}


class ModelSelectionTests(unittest.TestCase):
    def test_every_tier_runs_on_gpu_or_says_it_does_not(self):
        for vram in (4, 6, 8, 12, 16, 24):
            sel = select_models(Hardware(ram_gb=32, gpu_vendor="nvidia", vram_gb=vram, cuda_version="12.4"))
            for t in sel.tiers.values():
                self.assertEqual(t.placement == "gpu", _fits_gpu(t.model, vram), (vram, t.model.tag))

    def test_balanced_fits_entirely_on_gpu_when_gpu_has_room(self):
        for vram in (8, 12, 16, 24):
            sel = select_models(Hardware(ram_gb=32, gpu_vendor="nvidia", vram_gb=vram, cuda_version="12.4"))
            self.assertEqual(sel.tiers["balanced"].placement, "gpu", vram)

    def test_8gb_card(self):
        sel = select_models(Hardware(ram_gb=16, gpu_vendor="nvidia", vram_gb=8, cuda_version="12.4"))
        self.assertEqual(tags(sel), {"lightweight": "qwen2.5-coder:1.5b",
                                     "balanced": "qwen2.5-coder:7b",
                                     "advanced": "qwen2.5-coder:14b"})

    def test_12gb_card_with_32gb_ram_uses_moe_for_advanced(self):
        sel = select_models(Hardware(ram_gb=32, gpu_vendor="nvidia", vram_gb=12, cuda_version="12.4"))
        self.assertEqual(tags(sel)["balanced"], "qwen2.5-coder:14b")
        self.assertEqual(tags(sel)["advanced"], "qwen3-coder:30b")
        self.assertEqual(sel.tiers["advanced"].placement, "hybrid")

    def test_cpu_only_never_picks_huge_models(self):
        for ram in (8, 16, 32, 64):
            sel = select_models(Hardware(ram_gb=ram))
            for t in sel.tiers.values():
                self.assertEqual(t.placement, "cpu")
                self.assertLessEqual(t.model.size_gb, 9.0)
            self.assertTrue(any("CPU" in w for w in sel.warnings))

    def test_intel_graphics_treated_as_cpu(self):
        sel = select_models(Hardware(ram_gb=16, gpu_vendor="intel", vram_gb=2))
        self.assertTrue(all(t.placement == "cpu" for t in sel.tiers.values()))

    def test_tiers_are_ordered(self):
        from backend.core.model_selection import CATALOG
        order = {m.tag: i for i, m in enumerate(CATALOG)}
        for vram in (0, 4, 6, 8, 10, 12, 16, 20, 24, 48):
            for ram in (8, 16, 32, 64):
                vendor = "nvidia" if vram else "none"
                sel = select_models(Hardware(ram_gb=ram, gpu_vendor=vendor, vram_gb=vram, cuda_version="12"))
                t = tags(sel)
                self.assertLessEqual(order[t["lightweight"]], order[t["balanced"]], (vram, ram, t))
                self.assertLessEqual(order[t["balanced"]], order[t["advanced"]], (vram, ram, t))

    def test_hardware_json_roundtrip(self):
        raw = {
            "collected_at": "2026-11-09", "os_caption": "Microsoft Windows 11 Home", "os_build": "26100",
            "cpu_name": "AMD Ryzen 5 5600X", "cpu_cores": 6, "cpu_logical_cores": 12, "ram_gb": 31.9,
            "gpus": [{"name": "AMD Radeon(TM) Graphics", "vendor": "amd", "vram_gb": 0.5},
                     {"name": "NVIDIA GeForce RTX 3060", "vendor": "nvidia", "vram_gb": 12}],
            "cuda_version": "12.6", "disks": [{"drive": "C:", "free_gb": 210, "size_gb": 931}],
            "tools": {"python": "3.12.6", "git": None},
        }
        with tempfile.TemporaryDirectory() as d:
            d = Path(d)
            (d / "hw.json").write_text(json.dumps(raw), encoding="utf-8-sig")  # PowerShell writes a BOM
            sel = write_selection(d / "hw.json", d / "models.json", d / "report.md")
            self.assertEqual(sel.hardware.gpu_name, "NVIDIA GeForce RTX 3060")
            cfg = json.loads((d / "models.json").read_text())
            self.assertEqual(cfg["active_model"], cfg["tiers"][cfg["default_tier"]]["tag"])
            report = (d / "report.md").read_text()
            self.assertIn("RTX 3060", report)
            self.assertIn("Apache-2.0", report)


if __name__ == "__main__":
    unittest.main()
