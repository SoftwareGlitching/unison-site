# Knowledge

Notes UNISON can look up while answering (retrieval, not training).

- `curated/` - programming reference notes shipped with UNISON.
- `user/` - your own notes (add files here or upload them in the app), then re-index.

Re-index with `scripts\index_knowledge.bat` or Settings -> Knowledge in the app.
