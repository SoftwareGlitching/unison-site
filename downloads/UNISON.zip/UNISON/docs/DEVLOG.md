# UNISON development log

## 2026-11-09 — Phase 1: working local AI

### Hardware inspection
- The build ran in a cloud workspace linked to the PC (`desktop-n9mq6h1`, Windows x64). That link
  could list folders but had no command shell on the PC, so hardware could not be probed from the
  build side. Inspection therefore runs on the PC itself as the first step of `Setup.bat`
  (`scripts/inspect_hardware.ps1`): OS build, CPU cores/threads, RAM, every GPU with real VRAM
  (registry `qwMemorySize` / `nvidia-smi`, because WMI's `AdapterRAM` caps at 4 GB), CUDA version
  from the driver, free disk, and Python/Git/Node/npm/CMake/Blender/Ollama/winget.
- `backend/core/model_selection.py` turns that into three tiers. Rules: balanced = best model that
  fits entirely in VRAM (weights + ~1.5 GB cache); advanced = up to two steps larger split across
  GPU+RAM (dense ≤ 2.5× VRAM) or the MoE `qwen3-coder:30b` when RAM ≥ 25 GB and VRAM ≥ 6 GB;
  lightweight = one step down. CPU-only caps at 14B. Tested on 10 sample machines.

### Engine choice
- Ollama only (llama.cpp underneath): CUDA, ROCm and CPU fallback without UNISON shipping its own
  CUDA build. One engine, models swappable at runtime. llama.cpp directly would add a build step
  (CMake + CUDA toolkit) for no Phase 1 benefit.
- Catalog checked against current Ollama listings (Aug 2026). All picks Apache-2.0. Qwen2.5-Coder
  3B excluded (Qwen Research license, non-commercial). Thinking-mode models avoided as defaults;
  the backend still streams `thinking` separately if a user installs one.

### Backend
- `inference/base.py` — engine-neutral interface (`ModelBackend`, `ChatMessage`, `GenerationOptions`,
  `GenerationStats`, `StreamEvent`).
- `inference/ollama_backend.py` — streaming NDJSON client, real stats from Ollama's
  `eval_count/eval_duration`, `/api/ps` for how much of the model sits in VRAM, pull and delete.
- `core/chat_service.py` — framework-independent: stores both sides in SQLite, trims old turns to
  fit `num_ctx` while keeping the system prompt, saves partial replies when stopped, regenerate.
- `api/routes.py` — OpenAI-compatible `/v1/chat/completions` (stream + non-stream, `usage`,
  `stream_options.include_usage`), native `/v1/chat`, models, health, metrics, settings,
  conversations, keys. Setup errors (engine down, model missing) return real HTTP status codes;
  errors mid-stream arrive as SSE error events.
- `security/auth.py` — hashed API keys, loopback exemption, token-bucket rate limit, request log
  without bodies. `run.py` refuses non-local binding without keys + TLS.
- `tools` in an OpenAI request returns a clear 400 until Phase 3 rather than being silently ignored.

### Frontend
- React 18 + TypeScript + Vite. Conversation sidebar with search/rename/delete, streaming with
  stop + regenerate, Markdown + GFM tables, syntax highlighting, copy buttons, text/code file
  attachments (≤ 200 KB), model menu with hardware tiers and in-app download progress, sampling
  and context-length controls, and a telemetry strip fed only by `/v1/system/metrics`
  (shows "n/a" where something cannot be measured, e.g. GPU on non-NVIDIA cards).
- Tokens are buffered per animation frame so long replies don't re-render per token.

### Testing
- In the build workspace (no GPU, no network for package installs):
  - 21 automated tests pass: model selection (8) and Ollama client + chat service (13) against
    `tests/fake_ollama.py`, a test double of Ollama's HTTP API. It covers streaming, stats maths,
    option mapping, missing model, engine offline, pull, conversation storage, history sent to
    the model, regenerate, stop-keeps-partial, context trimming, search.
  - Backend compiles; frontend type-checked with stand-in React types (no logic errors; only
    implicit-any warnings that real `@types/react` resolves).
  - **Not runnable here:** FastAPI routes (FastAPI not installable offline), the Vite build,
    PowerShell scripts, a real model. These are exercised on the PC by `Setup.bat`, which builds
    everything and runs `scripts/selftest.py` against the real model, writing the model's actual
    replies to `docs/SELFTEST.md`.
- Phase 1 is only "done" once that self-test passes on the PC.

### Known limits (Phase 1)
- Attachments are text/code only. Images/PDFs come later.
- Context trimming estimates tokens (≈3.5 chars/token); exact counts come with Phase 2.
- GPU utilisation numbers come from `nvidia-smi`; AMD/Intel GPUs show model placement but not
  utilisation.

## 2026-11-09 — v0.2: PC access, knowledge base, training groundwork

Request: "make it able to use/control my PC, start training it to be smart at programming, and let it
program things on my desktop." Phase 1 was reported working by the user.

### What "control the PC" means here
- Tools, not screen control: file tools (list/read/find/search/write/edit/delete/copy/mkdir), a terminal
  tool, open-with-default-app, knowledge search, plus any MCP server's tools. Mouse/keyboard control of
  other apps was deliberately left out: a 7B–14B local model driving a GUI is unreliable and hard to make safe.
- Sandbox (`tools/sandbox.py`): every path is resolved (symlinks, `..`) and must be inside an approved
  workspace; credentials files/folders and UNISON's own files are refused; drive roots and system
  folders can't be workspaces; no writes inside `.git`. The Desktop is found via the Windows shell API
  (handles OneDrive-redirected desktops).
- Permissions (`tools/registry.py`): auto / ask / off per tool. Reads auto; changes ask; terminal is
  classified per command: read-only commands without shell operators auto, everything else asks, a
  blocklist (drive formatting, registry, services, scheduled tasks, Defender/firewall, credentials,
  `iwr | iex`, encoded PowerShell, whole-drive deletes...) is denied even in "auto".
- Every change is backed up first (`data/backups`, restorable); every tool call is in `logs/audit.log`.
- Commands run with no stdin, no console window, a timeout, and the whole process tree is killed on timeout.

### Agent loop (`core/chat_service.py`)
- Uses Ollama native tool calling; if a model has no tool template, it switches to a `<tool_call>{json}</tool_call>`
  text protocol automatically (and remembers that for the model).
- "ask" tools pause the SSE stream with `approval_required`; the app's Approve/Deny posts to
  `/v1/approvals/{id}`; unanswered approvals expire after 15 minutes; closing the stream cancels them.
- Guards: 25 steps max, identical repeated calls refused after twice, tool output trimmed before going
  back to the model, orphaned tool results never start the context window.
- Tool calls and results are stored as messages (schema v2 migration adds columns to existing DBs).

### MCP (`mcp/client.py`)
- Stdio JSON-RPC client using threads (works regardless of the event loop type uvicorn picks on Windows),
  `initialize` → `notifications/initialized` → `tools/list` (paginated) → `tools/call`; answers the
  server's `roots/list` with the workspaces. Tools register as `<server>__<tool>` with mode "ask".

### Knowledge base (`knowledge/`)
- `nomic-embed-text` through Ollama, SQLite storage, exact cosine search with NumPy; markdown chunked by
  headings, code by ~1600-char windows with overlap and line numbers; incremental re-indexing by SHA-1;
  deleted files are dropped; secrets files never indexed.
- 10 original curated notes (Roblox Luau, remotes security, DataStores, NPC/pathfinding/UI/performance,
  Rojo file workflow, Blender bpy, Windows dev environment, Python, JS/TS/C#/C++, Git/debugging/architecture,
  AI fundamentals/MCP) — written for UNISON, not copied from documentation.
- Retrieval is automatic per message (top 4 above similarity 0.55) and shown as "looked up" chips.

### Training groundwork (`training/`)
- 👍/👎 and corrections are stored; export writes SFT and preference (DPO) JSONL plus a versioned manifest,
  keeping tool trajectories so tool use can be trained too.
- Benchmark (24 tasks): Python/JS executed against tests, Luau/Blender API pattern checks, JSON/format
  instruction following, multi-turn recall, and 3 agent tasks in throwaway workspaces (create+run,
  fix failing unit tests, explore a Luau project). Graders verified with known-good and known-bad answers.
- LoRA training itself is not built yet: it depends on the user's GPU/VRAM (hardware report not available
  to me yet) and needs a dataset of a few hundred examples to be worth running.

### Testing in the build workspace
- 52 automated tests pass (was 21): sandbox escapes, secrets, CRLF-preserving edits, backups/restore,
  command classification (safe/ask/blocked), timeouts killing processes, agent write→run→summarise with
  approvals, declined actions, text-protocol fallback, loop guard, regenerate, retrieval injection,
  MCP against a real stdio subprocess, DB migration from v1, graders, an agent benchmark task end to end.
- Route handlers were exercised directly (agent chat, feedback + export, OpenAI tool-call round trip,
  tool execution approvals and blocking, workspaces, knowledge documents) against a FastAPI stand-in,
  because FastAPI itself can't be installed here. The HTTP layer, the React build and PowerShell scripts
  are verified on the PC by Update.bat, whose self-test now also checks the knowledge base and makes the
  real model write and read a file through the agent loop.

## 2026-11-09 — v0.3: self-test fixes, screen control, drive space

### Self-test results from the user's PC (v0.2)
7/9 passed: qwen2.5-coder:7b at ~60 tok/s fully on GPU, knowledge search correct (DataStore question →
roblox-datastores.md, 0.83). Two failures:
- **Agent: "model never called write_file".** The model ignored Ollama's tool channel and wrote the calls as
  ```json blocks, then invented the result ("After creating the file, it contains UNISON-OK").
  Fix: `core/toolparse.py` accepts tagged, fenced and bare-JSON calls for known tool names only, and keeps
  only the text before the first call so invented results are dropped. Agent prompt now says to stop after
  a call. Regression tests use the model's exact output.
- **/v1/chat returned 502.** That status means Ollama itself returned an error mid-request; the self-test
  didn't record its message. Fix: the step is retried twice (transient model-swap errors), every engine
  error is written with Ollama's message to `logs/errors.log`, and the self-test prints error bodies.
  Root cause still unknown until the next run.

### Screen control (`backend/computer/`)
- No automation libraries: Pillow ImageGrab for screenshots; Win32 SendInput via ctypes for mouse,
  keyboard shortcuts and Unicode typing; DPI-aware process so pixels match on scaled displays; focus
  restore via AttachThreadInput (not the Alt-tap trick, which opens menu bars).
- Vision model: qwen3-vl (Ollama ≥0.12.7, sizes 2b/4b/8b/30b; advertised for GUI operation). Coordinates
  requested on a 0–1000 grid (Qwen3-VL's native convention); larger numbers are treated as image pixels
  (Qwen2.5-VL style). `think: false` is sent for speed and dropped automatically if a model rejects it.
- Kill switches: Esc and the top-left-corner failsafe are polled every 40 ms and checked synchronously
  right before each action (a test caught that a polling-only check let one action through).
- The model may not act inside UNISON's own window; typed text is checked against the terminal blocklist.
- Each run is stored as a conversation (steps as tool messages) and every action is in the audit log.
- 10 tests with a simulated desktop: autopilot run, ask mode with deny, self-window protection, blocked
  text, focus restore before typing, Esc and corner stops, invalid replies, pixel-vs-0..1000 coordinates.
  Not testable here: real Windows input/capture and a real vision model — the self-test now checks a
  real screenshot (read-only); actual control is first tried by the user in ask mode.

### Drive space
- `Move-Models.bat` moves Ollama's models to another drive with robocopy, sets `OLLAMA_MODELS` for the
  user and restarts Ollama. Update.bat checks free space on the models drive before offering the vision model.

## 2026-11-09 — v0.3.1: "I'm sorry, but I can't assist with that request."

The user told UNISON (agent mode, qwen2.5-coder:7b) "you should now have a new update and be able to
control my pc" and got a stock refusal. Causes: the prompt never said what UNISON is, which mode it's in,
or that the user owns the machine, so "control my pc" pattern-matched to remote-access abuse; and
retrieval added three DataStore chunks unrelated to the message.
Fixes: an "About yourself" block in every prompt (version, ownership, the three modes, current mode,
what to suggest when another mode is needed); the screen agent's prompt states it operates the user's
own PC at their request; retrieval now needs similarity ≥ 0.62, keeps only hits within 0.08 of the best,
at most two chunks per file, and shows one chip per file. 74 tests pass.

## 2026-11-09 — v0.4: jobs, autonomous mode, remote access

Request: "do anything on my computer with remote access, work while I'm at work, program my games,
remove the limitations."
- **Background jobs** (`agents/jobs.py`, `/v1/jobs`): queued agent or screen tasks run inside the server,
  independent of any browser tab. Events (minus token streams and screenshots, last screenshot kept
  separately) are stored in SQLite; supervised jobs wait up to 8 h for approval from any device;
  autonomous jobs approve themselves; 60-step cap; stop/cancel; jobs running at shutdown are marked
  interrupted on restart. Conversations are titled "Job: …".
- **Autonomous switch** (`tools.autonomous`): "ask" decisions become "auto" in agent chats. The blocklist,
  workspace sandbox, backups and screen kill switches are unchanged — they're what makes leaving a 7–8B
  model unattended survivable.
- **Remote access** (`Enable-Remote.bat`): Tailscale `serve` publishes 127.0.0.1:8770 as HTTPS inside the
  user's tailnet only. UNISON stays loopback-only; a middleware rejects Tailscale identities other than the
  owner's login (saved by the script). Options: no sleep on AC, start minimised at sign-in (`-NoBrowser`).
- **Phone layout:** slide-out conversation list, compact top bar and telemetry, jobs drawer usable on a phone.
- Not changed by this request: the model's raw ability. That's set by model size/hardware and, later,
  fine-tuning — still waiting on the hardware report to size the upgrade.
- Tests: 7 new (autonomous job end-to-end, approval from "another device", stop, queue/cancel, restart →
  interrupted, screen job with autopilot, owner check). Real Tailscale and Windows behaviour verified on the PC.

## 2026-11-10 — v0.5: sign-in, screen launching, download site

- **Sign-in** (`security/sessions.py`, `api/routes_auth.py`): PBKDF2-SHA256 password (240k rounds,
  random salt), HMAC-signed 30-day session tokens, secret rotation on password change / logout-all.
  Middleware: once a password exists, every /v1 call except health and the sign-in endpoints needs a
  session token or API key — this matters because Tailscale `serve` reaches UNISON from 127.0.0.1, so the
  old "loopback is trusted" rule alone would have let a phone in. Remote devices can't create/replace the
  password; logins are limited to 10/min per address. UI: first-run "create password" screen, sign-in
  screen, lock button, change-password section; any 401 returns to the sign-in screen.
  `Enable-Remote.bat` now requires a password before publishing.
- **Screen mode "open Chrome / close a tab"**: `open_app` now launches via ShellExecute (what the Run box
  does; resolves chrome/notepad/explorer through App Paths) with a Win+R fallback, plus aliases
  ("google chrome" → chrome, "edge" → msedge, "roblox studio" → RobloxStudioBeta...). The vision prompt now
  lists browser shortcuts (ctrl+t / ctrl+w / ctrl+l / f5). Screen mode shows a banner when the vision model
  isn't downloaded instead of failing on send. Likely cause of the user's report: the request was typed in
  chat/agent mode, which can't use the mouse, or qwen3-vl wasn't downloaded.
- **Distribution**: `site/index.html` download page (GitHub Pages workflow), `release.yml` builds a clean
  `UNISON.zip` (no chats, settings, password hash, venv or node_modules) on each `v*` tag, MIT LICENSE,
  `docs/PUBLISHING.md`. Release zip build simulated locally.
- Tests: +8 sign-in, +2 screen launching.

## 2026-11-10 — v0.5.1: Google-ready site, Share tab, GitHub repo

- `scripts/configure_site.py` builds `site/` for GitHub Pages: fills the repo/site address from the
  repository name (`PerkyPop/unison` → https://perkypop.github.io/unison/), writes robots.txt and
  sitemap.xml, inserts the Google Search Console tag from the `GOOGLE_SITE_VERIFICATION` repo variable
  (HTML-escaped). Page has canonical URL, Open Graph/Twitter preview (`site/og.png`), and
  SoftwareApplication structured data. pages.yml runs it and enables Pages automatically.
- In-app **Share** tab (sidebar → share): copy/open the download page, a Download button, and a
  click-to-run update check against the latest GitHub release (no background calls).
- The user's "download button isn't in my UI": it lived only on the website; now it's in the app too.
- GitHub: user created PerkyPop/unison; this session can read it but pushing needs the Claude GitHub App
  installed on the repo.

## 2026-11-10 — v0.6: license keys, public work link, closed source

- **Security fix (found while planning the public link):** Tailscale serve/funnel reach UNISON from
  127.0.0.1, so "loopback = the owner at the PC" was wrong for tunnelled requests. New `is_truly_local()`
  (loopback + Host is 127.0.0.1/localhost + no forwarding headers). Password create/replace only truly
  local; owner endpoints from other devices only when a password exists (session checked by middleware);
  tunnelled requests with no password set get 403 for all /v1 calls; API docs hidden remotely; login
  lockout per real client IP (8 fails / 15 min) plus a global remote cap (40 / 15 min).
- **Public link** (`Enable-Remote.bat` option 2 / `-Public`): `tailscale funnel` gives an HTTPS address that
  works in any browser (locked-down work PCs). Requires a 12+ character password. `-Off` resets both.
- **License keys** (`backend/licensing/`): Ed25519-signed keys checked offline; optional expiry and
  Machine-ID lock; middleware returns 402 until activated; activation screen with Machine ID; license info
  in the Share tab. `License-Admin.bat` (owner only, excluded from downloads) creates the signing key outside
  the app folder, writes the public key into `authority.py`, activates the owner's PC, and mints keys.
  Downloads stay locked until the owner's public key is committed.
- **Closed source:** proprietary LICENSE replaces MIT (the two commits that were public for a few hours were
  MIT-licensed), site/README wording, a "Get a license key" section driven by `--purchase-url`. Source repo
  to become private; the public site + zip move to `PerkyPop/unison-site` served by Pages from a branch.
  GitHub workflows removed (Pages on private repos needs a paid plan); `configure_site.py --zip` builds the
  site and a clean download. App update check reads the site's `version.json`.
- Tests: 110 (auth/tunnel rules, lockouts, license crypto + admin setup, clean zip).
