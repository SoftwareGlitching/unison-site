import { useEffect, useState } from "react";
import { license, type LicenseStatus } from "../lib/api";

/** Shown until a valid license key is activated on this PC. */
export function Activate({ onDone }: { onDone: () => void }) {
  const [st, setSt] = useState<LicenseStatus | null>(null);
  const [key, setKey] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    license.status().then(setSt).catch((e) => setErr(e.message));
  }, []);

  const activate = async () => {
    setErr("");
    setBusy(true);
    try {
      const s = await license.activate(key.trim());
      if (s.activated) onDone();
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };

  const copyId = async () => {
    if (!st) return;
    try {
      await navigator.clipboard.writeText(st.machine_id);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* ignore */
    }
  };

  return (
    <div className="signin">
      <div className="signin-card wide">
        <svg viewBox="0 0 32 32" className="brand-mark" aria-hidden>
          <circle cx="12" cy="16" r="7" />
          <circle cx="20" cy="16" r="7" className="second" />
        </svg>
        <div className="signin-title">UNISON</div>
        <p className="signin-sub">Activate UNISON with your license key.</p>
        {st?.problem && st.problem.includes("expired") && <div className="signin-err">{st.problem}</div>}
        <textarea
          className="signin-input key-input"
          rows={3}
          placeholder="UNISON-…"
          value={key}
          onChange={(e) => setKey(e.target.value)}
          spellCheck={false}
          autoFocus
        />
        {err && <div className="signin-err">{err}</div>}
        <button className="signin-btn" disabled={busy || key.trim().length < 20} onClick={activate}>
          {busy ? "…" : "Activate"}
        </button>
        {st && (
          <div className="machine-id">
            <span className="dim">Your Machine ID</span>
            <code>{st.machine_id}</code>
            <button className="link-btn" onClick={copyId}>{copied ? "copied" : "copy"}</button>
          </div>
        )}
        <div className="signin-foot">
          Some keys only work on one computer — send your Machine ID when you buy.
          {st?.purchase_url && (
            <>
              {" "}
              <a href={st.purchase_url} target="_blank" rel="noreferrer">Get a license key</a>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
