@echo off
rem Set or change the password you sign in to UNISON with.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "& { .venv\Scripts\python.exe scripts\password.py set }"
pause
