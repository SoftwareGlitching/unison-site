"""The model must know what UNISON is, which mode it's in, and that the user owns the PC."""
import unittest

from tests.helpers import IsolatedSettings

from backend.agents.prompts import agent_prompt, base_prompt
from backend.core.chat_service import select_hits


class PromptTests(unittest.TestCase):
    def test_agent_prompt_knows_mode_ownership_and_screen_mode(self):
        with IsolatedSettings():
            p = agent_prompt("qwen2.5-coder:7b")
        self.assertIn("The user owns this computer", p)
        self.assertIn("**agent** mode", p)
        self.assertIn("switch to screen mode", p)
        self.assertIn("You are UNISON", p)
        self.assertIn("PerkyPop", p)

    def test_chat_prompt_points_to_agent_and_screen_modes(self):
        p = base_prompt("m")
        self.assertIn("**chat** mode", p)
        self.assertIn("switch to agent mode", p)


class RetrievalSelectionTests(unittest.TestCase):
    def test_dedupes_files_and_drops_weak_hits(self):
        hits = [{"path": "a", "score": 0.80}, {"path": "a", "score": 0.79}, {"path": "a", "score": 0.78},
                {"path": "b", "score": 0.75}, {"path": "c", "score": 0.70}]
        out = select_hits(hits, 4)
        self.assertEqual([h["path"] for h in out], ["a", "a", "b"])   # c is >0.08 below the best

    def test_empty(self):
        self.assertEqual(select_hits([], 4), [])


if __name__ == "__main__":
    unittest.main()
