"""Learning from your ratings, right away and without touching the GPU.

Every 👎 with a note or a correction becomes a short "lesson", and every 👍 a small example of a reply you liked.
The newest few are added to UNISON's instructions, so the next answers already follow them. Nothing is
retrained: this only changes what the model reads, so it costs no GPU time and can be undone by removing a
rating. (For real fine-tuning later, scripts/export_training.py turns the same ratings into datasets.)
"""
from __future__ import annotations

import time
from typing import Optional

MAX_LESSONS = 8
MAX_EXAMPLES = 3
LESSON_CHARS = 280
EXAMPLE_CHARS = 360
_cache: dict = {"key": None, "text": "", "at": 0.0}


def _short(text: Optional[str], n: int) -> str:
    t = " ".join((text or "").split())
    return t if len(t) <= n else t[: n - 1].rstrip() + "…"


def _asked(db, message_id: str) -> str:
    """The user message the rated reply answered."""
    msg = db.get_message(message_id)
    if not msg:
        return ""
    rows = db.messages(msg["conversation_id"])
    idx = next((n for n, r in enumerate(rows) if r["id"] == message_id), None)
    if idx is None:
        return ""
    for r in reversed(rows[:idx]):
        if r["role"] == "user":
            return r["content"]
    return ""


def build(db) -> str:
    """The 'learned from your ratings' section for the system prompt ('' when there are no ratings)."""
    rows = db.feedback_rows()
    if not rows:
        return ""
    lessons, examples = [], []
    for fb in reversed(rows):   # newest first
        if fb["rating"] < 0 and len(lessons) < MAX_LESSONS and (fb.get("note") or fb.get("correction")):
            asked = _short(_asked(db, fb["message_id"]), 120)
            line = f'- When they said "{asked}"' if asked else "- In an earlier chat"
            if fb.get("note"):
                line += f", they disliked the reply: {_short(fb['note'], LESSON_CHARS)}"
            if fb.get("correction"):
                line += f". A better reply would have been: {_short(fb['correction'], LESSON_CHARS)}"
            lessons.append(line)
        elif fb["rating"] > 0 and len(examples) < MAX_EXAMPLES:
            msg = db.get_message(fb["message_id"])
            asked = _short(_asked(db, fb["message_id"]), 160)
            if msg and asked and msg.get("content"):
                examples.append(f'User: {asked}\nYou: {_short(msg["content"], EXAMPLE_CHARS)}')
    parts = []
    if lessons:
        parts.append("Lessons from the user's ratings (follow these - they override your defaults):\n" + "\n".join(lessons))
    if examples:
        parts.append("Replies the user rated 👍 (match this style):\n" + "\n\n".join(examples))
    return "\n\n".join(parts)


def section(db=None) -> str:
    """Cached build(): rebuilt when ratings change, at most every 10 seconds."""
    try:
        if db is None:
            from ..database.db import get_db
            db = get_db()
        now = time.time()
        if now - _cache["at"] < 10 and _cache["key"] is not None:
            return _cache["text"]
        rows = db.query("SELECT COUNT(*) AS n, MAX(created_at) AS t FROM feedback")
        key = (rows[0]["n"], rows[0]["t"]) if rows else None
        if key != _cache["key"]:
            _cache["text"] = build(db)
            _cache["key"] = key
        _cache["at"] = now
        return _cache["text"]
    except Exception:  # noqa: BLE001 - learning is a bonus; never break a chat over it
        return ""


def reset_cache() -> None:
    _cache.update(key=None, text="", at=0.0)
