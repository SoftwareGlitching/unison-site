"""Phone/website chats run with the PC's effort setting (Eco = part of the brain on the GPU, small context)."""
import asyncio
import unittest
from types import SimpleNamespace

from tests.helpers import IsolatedSettings  # noqa: I001
from backend.api import routes
from backend.api.schemas import OAChatRequest
from backend.core.config import settings
from backend.inference.base import GenerationStats, StreamEvent
from backend.inference.manager import ModelManager


class CapturingBackend:
    name = "fake"

    def __init__(self):
        self.calls = []

    async def chat_stream(self, model, messages, options, keep_alive=None, tools=None, think=None):
        self.calls.append({"options": options, "keep_alive": keep_alive})
        yield StreamEvent("token", "hi")
        yield StreamEvent("done", stats=GenerationStats(model=model, completion_tokens=1))


def remote_chat(mgr, plan="owner"):
    async def go():
        orig_mgr, orig_sr = routes.manager, routes.StreamingResponse
        routes.manager, routes.StreamingResponse = mgr, (lambda gen, **k: gen)
        try:
            mgr.resolve_model = lambda m: asyncio.sleep(0, "unison:latest")
            req = OAChatRequest(messages=[{"role": "user", "content": "hey"}], stream=True)
            request = SimpleNamespace(state=SimpleNamespace(guest="key1", guest_plan=plan), client=SimpleNamespace(host="100.1.2.3"))
            gen = await routes.chat_completions(req, request, ident={})
            return [p async for p in gen]
        finally:
            routes.manager, routes.StreamingResponse = orig_mgr, orig_sr
    return asyncio.run(asyncio.wait_for(go(), 10))


class RemoteEffortTests(unittest.TestCase):
    def check(self, effort, num_gpu, num_ctx, keep):
        with IsolatedSettings():
            settings.set("inference", "effort", effort)
            settings.set("inference", "num_ctx", 16384)       # a bigger saved context is still capped by the effort
            backend = CapturingBackend()
            remote_chat(ModelManager(backend))
            call = backend.calls[-1]
            self.assertEqual(call["options"].num_gpu, num_gpu)
            self.assertEqual(call["options"].num_ctx, num_ctx)
            self.assertEqual(call["keep_alive"], keep)

    def test_eco_on_the_pc_means_eco_on_the_phone(self):
        self.check("eco", 28, 4096, "15m")

    def test_balanced_and_max(self):
        self.check("balanced", None, 8192, "1h")
        self.check("max", None, 16384, "4h")


if __name__ == "__main__":
    unittest.main()
