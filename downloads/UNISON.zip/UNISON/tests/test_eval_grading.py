"""Check the benchmark graders with known-good and known-bad answers, so scores mean something."""
import shutil
import unittest

from tests.helpers import ROOT  # noqa: F401  (sets up sys.path)

from backend.training.evaluate import GRADERS, load_tasks

GOOD = {
    "py_fizzbuzz": "```python\ndef fizzbuzz(n):\n    out=[]\n    for i in range(1,n+1):\n        out.append('FizzBuzz' if i%15==0 else 'Fizz' if i%3==0 else 'Buzz' if i%5==0 else str(i))\n    return out\n```",
    "py_palindrome": "```python\ndef is_palindrome(s):\n    t=[c.lower() for c in s if c.isalnum()]\n    return t==t[::-1]\n```",
    "py_merge_intervals": "```python\ndef merge_intervals(iv):\n    out=[]\n    for s,e in sorted(iv):\n        if out and s<=out[-1][1]:\n            out[-1][1]=max(out[-1][1],e)\n        else:\n            out.append([s,e])\n    return out\n```",
    "py_lru_cache": "```python\nfrom collections import OrderedDict\nclass LRUCache:\n    def __init__(self,c):\n        self.c=c; self.d=OrderedDict()\n    def get(self,k):\n        if k not in self.d: return -1\n        self.d.move_to_end(k); return self.d[k]\n    def put(self,k,v):\n        self.d[k]=v; self.d.move_to_end(k)\n        if len(self.d)>self.c: self.d.popitem(last=False)\n```",
    "py_parse_duration": "```python\nimport re\ndef parse_duration(t):\n    m=re.fullmatch(r'(?:(\\d+)h)?(?:(\\d+)m)?(?:(\\d+)s)?',t)\n    if not t or not m or not any(m.groups()): raise ValueError(t)\n    h,mi,s=(int(x or 0) for x in m.groups())\n    return h*3600+mi*60+s\n```",
    "py_top_words": "```python\nimport re\nfrom collections import Counter\ndef top_words(text,n):\n    c=Counter(re.findall('[a-z]+',text.lower()))\n    return sorted(c.items(),key=lambda x:(-x[1],x[0]))[:n]\n```",
    "py_first_index": "```python\ndef first_index(a,t):\n    lo,hi=0,len(a)\n    while lo<hi:\n        m=(lo+hi)//2\n        if a[m]<t: lo=m+1\n        else: hi=m\n    return lo if lo<len(a) and a[lo]==t else -1\n```",
    "py_flatten": "```python\ndef flatten(x):\n    out=[]\n    for i in x:\n        if isinstance(i,(list,tuple)): out.extend(flatten(i))\n        else: out.append(i)\n    return out\n```",
    "py_fix_average": "```python\ndef average(nums):\n    return sum(nums)/len(nums) if nums else 0.0\n```",
    "py_spiral": "```python\ndef spiral_order(m):\n    out=[]\n    m=[list(r) for r in m]\n    while m:\n        out+=m.pop(0)\n        m=[list(r) for r in zip(*m)][::-1]\n    return out\n```",
    "js_chunk": "```javascript\nfunction chunk(a,s){ if(s<1) throw new Error('size'); const o=[]; for(let i=0;i<a.length;i+=s) o.push(a.slice(i,i+s)); return o; }\n```",
    "js_camel": "```javascript\nfunction toCamelCase(t){ const w=t.split(/[\\s_-]+/).filter(Boolean); return w.map((x,i)=>i? x[0].toUpperCase()+x.slice(1).toLowerCase(): x.toLowerCase()).join(''); }\n```",
    "luau_remote_validate": "```lua\nlocal RS = game:GetService('ReplicatedStorage')\nlocal prices = {Sword = 50}\nRS.BuyItem.OnServerEvent:Connect(function(player, itemId)\n\tif typeof(itemId) ~= 'string' then return end\n\tlocal price = prices[itemId]\n\tif not price then return end\n\tlocal coins = player.leaderstats.Coins\n\tif coins.Value < price then return end\n\tcoins.Value -= price\nend)\n```",
    "instr_json": '{"name": "Ada", "level": 5, "spells": ["Fireball", "Shield"]}',
    "instr_bullets": "- Undo mistakes\n- Work with others\n- Track history",
}
BAD = {
    "py_fizzbuzz": "```python\ndef fizzbuzz(n):\n    return [str(i) for i in range(1,n+1)]\n```",
    "py_fix_average": "```python\ndef average(nums):\n    return sum(nums)/len(nums)\n```",
    "instr_json": "```json\n{\"name\": \"Ada\", \"level\": 5, \"spells\": [\"a\", \"b\"]}\n```",
    "instr_bullets": "Here you go:\n- a\n- b\n- c",
    "luau_remote_validate": "```lua\nlocal p = game.Players.LocalPlayer\n```",
}


class GraderTests(unittest.TestCase):
    def setUp(self):
        self.tasks = {t["id"]: t for t in load_tasks()}

    def test_benchmark_is_well_formed(self):
        self.assertGreaterEqual(len(self.tasks), 20)
        for t in self.tasks.values():
            self.assertIn(t["kind"], list(GRADERS) + ["agent"], t["id"])

    def test_good_answers_pass(self):
        for tid, reply in GOOD.items():
            if self.tasks[tid]["kind"] == "js_tests" and not shutil.which("node"):
                continue
            ok, detail = GRADERS[self.tasks[tid]["kind"]](reply, self.tasks[tid])
            self.assertTrue(ok, f"{tid}: {detail}")

    def test_bad_answers_fail(self):
        for tid, reply in BAD.items():
            ok, detail = GRADERS[self.tasks[tid]["kind"]](reply, self.tasks[tid])
            self.assertFalse(ok, tid)


if __name__ == "__main__":
    unittest.main()


class AgentEvalTests(unittest.TestCase):
    def test_agent_task_end_to_end_with_test_double(self):
        import asyncio
        import sys as _sys
        from backend.inference.manager import ModelManager
        from backend.inference.ollama_backend import OllamaBackend
        from backend.training.evaluate import Evaluator
        from tests.fake_ollama import FakeOllama
        from tests.helpers import IsolatedSettings

        def brain(body):
            n = sum(1 for m in body["messages"] if m["role"] == "tool")
            if n == 0:
                return {"tool_calls": [{"function": {"name": "write_file", "arguments": {
                    "path": "calc.py", "content": "def add(a, b):\n    return a + b\n\nprint(add(2, 3))\n"}}}]}
            if n == 1:
                return {"tool_calls": [{"function": {"name": "run_command",
                                                     "arguments": {"command": f'"{_sys.executable}" calc.py'}}}]}
            return {"content": "It printed 5."}

        task = next(t for t in load_tasks() if t["id"] == "agent_create_run")
        with IsolatedSettings(), FakeOllama(responder=brain) as fake:
            ev = Evaluator(ModelManager(OllamaBackend(fake.url)), "test-model:1b", use_knowledge=False, log=lambda m: None)
            r = asyncio.run(ev.run_task(task))
            ev.close()
        self.assertTrue(r["passed"], r["detail"])
        self.assertIn("run_command", r["detail"])
