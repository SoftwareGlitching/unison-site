"""The public half of the UNISON license-signing key (Ed25519, base64url).

Only the owner's private key (kept OFF this computer's UNISON folder and out of GitHub) can create keys
that verify against it. Set by `License-Admin.bat setup` on the owner's PC.
An empty value means no license authority is configured: UNISON stays locked.
"""
PUBLIC_KEY = "mc7Q_9W7pA8dDLBe8HDKLB3-41oN2RyLSejmLKOa174"
