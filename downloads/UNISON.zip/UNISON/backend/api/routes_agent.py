"""API for tools, approvals, workspaces, MCP servers, knowledge base, feedback and training data."""
from __future__ import annotations

import asyncio
import json
import re
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse

from ..agents.approvals import broker
from ..core.config import settings
from ..database.db import get_db
from ..knowledge.store import KNOWLEDGE_DIR, embedding_model, get_store
from ..mcp.client import MCPError, mcp_manager
from ..security.auth import authenticate, local_only, pc_only
from ..tools.base import ToolError
from ..tools.registry import registry
from ..tools.sandbox import desktop_path, list_backups, restore_backup, workspaces
from ..training import dataset, evaluate
from ..computer import service as screen
from .schemas import (ScreenTaskRequest, VisionModelRequest, AgentSettings, ApprovalAnswer, FeedbackRequest, KnowledgeDocument, KnowledgeIndexRequest,
                      KnowledgeSearchRequest, MCPServerRequest, ToolExecuteRequest, ToolModeRequest, WorkspaceRequest)

router = APIRouter(prefix="/v1")
SSE_HEADERS = {"Cache-Control": "no-cache", "X-Accel-Buffering": "no"}


def bad(e: Exception, status: int = 400):
    raise HTTPException(status, {"code": "invalid", "message": str(e)})


# ================================================================= approvals
@router.get("/approvals", tags=["agent"], dependencies=[Depends(local_only)])
async def pending_approvals():
    return {"data": broker.list()}


@router.post("/approvals/{action_id}", tags=["agent"], dependencies=[Depends(local_only)])
async def answer_approval(action_id: str, body: ApprovalAnswer):
    if not broker.resolve(action_id, body.approve, body.note):
        raise HTTPException(404, {"code": "not_pending", "message": "That action is no longer waiting"})
    return {"action_id": action_id, "approved": body.approve}


@router.get("/agent/settings", tags=["agent"], dependencies=[Depends(authenticate)])
async def agent_settings():
    return {"agent_default": bool(settings.get("tools", "agent_default", True)),
            "auto_retrieve": bool(settings.get("knowledge", "auto_retrieve", True))}


@router.patch("/agent/settings", tags=["agent"], dependencies=[Depends(pc_only)])
async def patch_agent_settings(body: AgentSettings):
    if body.agent_default is not None:
        settings.set("tools", "agent_default", body.agent_default)
    if body.auto_retrieve is not None:
        settings.set("knowledge", "auto_retrieve", body.auto_retrieve)
    return await agent_settings()


# ================================================================= tools
@router.get("/tools", tags=["tools"], dependencies=[Depends(authenticate)])
async def list_tools():
    return {"data": [{**t.summary(), "mode": registry.mode_setting(t)} for t in registry.tools.values()]}


@router.patch("/tools/{name}", tags=["tools"], dependencies=[Depends(pc_only)])
async def set_tool_mode(name: str, body: ToolModeRequest):
    try:
        registry.set_mode(name, body.mode)
    except ToolError as e:
        bad(e)
    t = registry.get(name)
    return {**t.summary(), "mode": registry.mode_setting(t)}


@router.post("/tools/execute", tags=["tools"], dependencies=[Depends(local_only)])
async def execute_tool(body: ToolExecuteRequest):
    """Run one UNISON tool directly. Tools set to 'ask' need approved=true (you confirm the user approved)."""
    tool = registry.get(body.name)
    if not tool:
        raise HTTPException(404, {"code": "unknown_tool", "message": f"No tool named {body.name}"})
    decision, reason = registry.decide(tool, body.arguments)
    if decision == "deny":
        raise HTTPException(403, {"code": "denied", "message": reason})
    if decision == "ask" and not body.approved:
        return {"needs_approval": True, "reason": reason, "preview": registry.preview(tool, body.arguments)}
    r = await registry.execute(body.name, body.arguments)
    return {"ok": r.ok, "output": r.output, "data": r.data}


# ================================================================= workspaces & backups
@router.get("/workspaces", tags=["tools"], dependencies=[Depends(authenticate)])
async def get_workspaces():
    d = desktop_path()
    return {"data": [str(w) for w in workspaces.list()], "default": str(workspaces.default),
            "suggestions": {"desktop": str(d) if d else None}}


@router.post("/workspaces", tags=["tools"], dependencies=[Depends(pc_only)])
async def add_workspace(body: WorkspaceRequest):
    try:
        workspaces.add(body.path)
    except ToolError as e:
        bad(e)
    return await get_workspaces()


@router.post("/workspaces/default", tags=["tools"], dependencies=[Depends(pc_only)])
async def default_workspace(body: WorkspaceRequest):
    try:
        workspaces.make_default(body.path)
    except ToolError as e:
        bad(e)
    return await get_workspaces()


@router.post("/workspaces/remove", tags=["tools"], dependencies=[Depends(pc_only)])
async def remove_workspace(body: WorkspaceRequest):
    workspaces.remove(body.path)
    return await get_workspaces()


@router.get("/backups", tags=["tools"], dependencies=[Depends(local_only)])
async def backups():
    return {"data": list_backups()}


@router.post("/backups/{bid}/restore", tags=["tools"], dependencies=[Depends(local_only)])
async def restore(bid: str):
    try:
        return {"restored": restore_backup(bid)}
    except ToolError as e:
        bad(e, 404)


# ================================================================= MCP
@router.get("/mcp/servers", tags=["mcp"], dependencies=[Depends(authenticate)])
async def mcp_servers():
    return {"data": mcp_manager.status()}


@router.post("/mcp/servers", tags=["mcp"], dependencies=[Depends(pc_only)])
async def add_mcp_server(body: MCPServerRequest):
    mcp_manager.upsert(body.name, body.command, body.args, body.env, body.enabled)
    if body.enabled:
        try:
            await mcp_manager.start(re.sub(r"[^A-Za-z0-9_-]", "_", body.name))
        except MCPError:
            pass
    return {"data": mcp_manager.status()}


@router.post("/mcp/servers/{name}/start", tags=["mcp"], dependencies=[Depends(pc_only)])
async def start_mcp(name: str):
    try:
        await mcp_manager.start(name)
    except MCPError as e:
        bad(e)
    return {"data": mcp_manager.status()}


@router.post("/mcp/servers/{name}/stop", tags=["mcp"], dependencies=[Depends(pc_only)])
async def stop_mcp(name: str):
    await mcp_manager.stop(name)
    return {"data": mcp_manager.status()}


@router.delete("/mcp/servers/{name}", tags=["mcp"], dependencies=[Depends(pc_only)])
async def delete_mcp(name: str):
    await mcp_manager.stop(name)
    mcp_manager.remove(name)
    return {"data": mcp_manager.status()}


# ================================================================= knowledge
@router.get("/knowledge", tags=["knowledge"], dependencies=[Depends(authenticate)])
async def knowledge_status():
    store = get_store()
    ok, why = await store.available()
    return {"embedding_model": embedding_model(), "embedding_ready": ok, "problem": why or None,
            **store.counts(), "collections": store.collections(),
            "auto_retrieve": bool(settings.get("knowledge", "auto_retrieve", True))}


@router.post("/knowledge/search", tags=["knowledge"], dependencies=[Depends(authenticate)])
async def knowledge_search(body: KnowledgeSearchRequest):
    return {"data": await get_store().search(body.query, k=body.k)}


@router.post("/knowledge/index", tags=["knowledge"], dependencies=[Depends(local_only)])
async def knowledge_index(body: KnowledgeIndexRequest):
    store = get_store()
    ok, why = await store.available()
    if not ok:
        raise HTTPException(409, {"code": "embedding_missing", "message": why})
    if body.target == "curated":
        folder, kind, collection = KNOWLEDGE_DIR, "knowledge", "knowledge"
    else:
        try:
            folder = workspaces.resolve(body.path or ".")
        except ToolError as e:
            bad(e)
        if not folder.is_dir():
            bad(ValueError(f"Not a folder: {folder}"))
        kind, collection = "project", str(folder)

    queue: asyncio.Queue = asyncio.Queue()

    async def work():
        try:
            stats = await store.ingest_folder(folder, kind, collection, progress=queue.put_nowait)
            await queue.put({"done": True, **stats})
        except Exception as e:  # noqa: BLE001
            await queue.put({"error": {"message": str(e)}})

    task = asyncio.create_task(work())

    async def gen():
        try:
            while True:
                item = await queue.get()
                yield f"data: {json.dumps(item)}\n\n"
                if item.get("done") is True or "error" in item:
                    break
        finally:
            if not task.done():
                await task   # finish indexing even if the page closed
    return StreamingResponse(gen(), media_type="text/event-stream", headers=SSE_HEADERS)


@router.post("/knowledge/documents", tags=["knowledge"], dependencies=[Depends(local_only)])
async def add_document(body: KnowledgeDocument):
    name = re.sub(r"[^A-Za-z0-9 ._-]", "_", Path(body.name).name).strip() or "document.md"
    if Path(name).suffix.lower() not in (".md", ".txt", ".markdown", ".rst"):
        name += ".md"
    dest = KNOWLEDGE_DIR / "user" / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(body.content, encoding="utf-8")
    store = get_store()
    ok, why = await store.available()
    chunks = await store.ingest_file(dest, "knowledge", "knowledge", title=f"user/{name}") if ok else 0
    return {"saved": str(dest), "chunks": chunks, "indexed": ok, "problem": why or None}


@router.delete("/knowledge/collections", tags=["knowledge"], dependencies=[Depends(local_only)])
async def delete_collection(name: str):
    return {"removed_files": get_store().delete_collection(name)}


# ================================================================= feedback & training
@router.post("/feedback", tags=["training"], dependencies=[Depends(authenticate)])
async def give_feedback(body: FeedbackRequest):
    try:
        return get_db().set_feedback(body.message_id, body.rating, body.correction, body.note)
    except KeyError as e:
        raise HTTPException(404, {"code": "not_found", "message": str(e)})


@router.delete("/feedback/{message_id}", tags=["training"], dependencies=[Depends(authenticate)])
async def clear_feedback(message_id: str):
    get_db().clear_feedback(message_id)
    return {"cleared": message_id}


@router.get("/training", tags=["training"], dependencies=[Depends(authenticate)])
async def training_status():
    return {"feedback": dataset.stats(get_db()), "evaluations": evaluate.list_results()[:30]}


@router.post("/training/export", tags=["training"], dependencies=[Depends(local_only)])
async def export_dataset():
    from ..agents.prompts import base_prompt
    from ..inference.manager import manager
    return dataset.export(get_db(), base_prompt(manager.active_model))


# ================================================================= screen control
@router.get("/computer", tags=["computer"], dependencies=[Depends(local_only)])
async def computer_status():
    from ..inference.manager import manager
    ok, why = screen.supported()
    try:
        installed = {m.name for m in await manager.backend.list_models()}
    except Exception:  # noqa: BLE001
        installed = set()
    vm = screen.vision_model()
    return {"supported": ok, "problem": why or None, "vision_model": vm,
            "vision_model_installed": vm in installed or f"{vm}:latest" in installed,
            "running": screen.current() is not None, "choices": screen.VISION_MODELS,
            "installed_vision_models": [m for m in screen.VISION_MODELS if m in installed]}


@router.get("/computer/screenshot", tags=["computer"], dependencies=[Depends(local_only)])
async def computer_screenshot():
    """A small screenshot (base64 JPEG) - checks capture works. Doesn't touch the mouse or keyboard."""
    from ..computer.desktop import make_desktop, scaled, to_b64
    ok, why = screen.supported()
    if not ok:
        raise HTTPException(400, {"code": "unsupported", "message": why})
    d = make_desktop()
    img = await asyncio.to_thread(d.capture)
    fg = d.foreground()
    return {"width": img.width, "height": img.height, "window": fg.title if fg else None,
            "image": to_b64(scaled(img, 480), quality=70)}


@router.post("/computer/model", tags=["computer"], dependencies=[Depends(local_only)])
async def computer_model(body: VisionModelRequest):
    settings.set("computer", "vision_model", body.model)
    return await computer_status()


@router.post("/computer/stop", tags=["computer"], dependencies=[Depends(local_only)])
async def computer_stop():
    stopped = screen.stop_current()
    for p in broker.list():
        if p.get("name") and p.get("step") is not None:
            broker.resolve(p["action_id"], False, "stopped")
    return {"stopped": stopped}


@router.post("/computer/run", tags=["computer"], dependencies=[Depends(local_only)])
async def computer_run(body: ScreenTaskRequest):
    """Let the vision model control the screen. Streams screen / token / action / approval_required /
    action_result / done events. Only one run at a time; only from this PC."""
    from ..computer.agent import ScreenAgent
    from ..computer.desktop import make_desktop
    from ..inference.manager import manager
    ok, why = screen.supported()
    if not ok:
        raise HTTPException(400, {"code": "unsupported", "message": why})
    if screen.current() is not None:
        raise HTTPException(409, {"code": "busy", "message": "A screen task is already running. Stop it first."})
    model = body.model or screen.vision_model()
    try:
        installed = {m.name for m in await manager.backend.list_models()}
    except Exception as e:  # noqa: BLE001
        raise HTTPException(503, {"code": "engine_offline", "message": str(e)})
    if model not in installed and f"{model}:latest" not in installed:
        raise HTTPException(409, {"code": "vision_model_missing",
                                  "message": f"The vision model {model} isn't downloaded. Run Update.bat or: ollama pull {model}"})
    agent = ScreenAgent(make_desktop(), manager.backend, model, broker, autopilot=body.autopilot,
                        minimize_self=body.minimize_self, db=get_db())
    screen.set_current(agent)

    async def gen():
        try:
            async for ev in agent.run(body.task):
                yield f"data: {json.dumps(ev)}\n\n"
        except Exception as e:  # noqa: BLE001
            yield f"data: {json.dumps({'type': 'error', 'message': str(e)})}\n\n"
        finally:
            agent.stop("Connection closed")
            screen.set_current(None)
    return StreamingResponse(gen(), media_type="text/event-stream", headers=SSE_HEADERS)


# ================================================================= share / updates
@router.get("/site", tags=["share"])
async def site_info():
    """Where UNISON is published, so the app can offer a share link and an update check."""
    from .. import __version__
    url = settings.get("site", "url") or ""
    return {"url": url, "version": __version__,
            "download": url + "downloads/UNISON.zip" if url else "",
            "version_url": url + "version.json" if url else ""}
