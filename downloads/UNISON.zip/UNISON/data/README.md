Runtime data (SQLite database) lives here.
