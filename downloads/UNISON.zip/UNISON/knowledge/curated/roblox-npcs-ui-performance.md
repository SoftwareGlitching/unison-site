# Roblox NPCs, animation, UI and performance

## Pathfinding an NPC
```lua
local PathfindingService = game:GetService("PathfindingService")

local function walkTo(humanoid: Humanoid, root: BasePart, target: Vector3)
	local path = PathfindingService:CreatePath({
		AgentRadius = 2, AgentHeight = 5, AgentCanJump = true,
		Costs = { Water = 20 }, -- avoid materials or named PathfindingModifiers
	})
	local ok, err = pcall(function()
		path:ComputeAsync(root.Position, target)
	end)
	if not ok or path.Status ~= Enum.PathStatus.Success then
		warn("No path:", err or path.Status)
		return false
	end
	local waypoints = path:GetWaypoints()
	local blocked = false
	local conn = path.Blocked:Connect(function(blockedIndex)
		blocked = true -- an obstacle appeared on a waypoint ahead; recompute
	end)
	for _, wp in waypoints do
		if blocked then break end
		if wp.Action == Enum.PathWaypointAction.Jump then
			humanoid.Jump = true
		end
		humanoid:MoveTo(wp.Position)
		local reached = humanoid.MoveToFinished:Wait() -- false if it timed out (8s)
		if not reached then break end
	end
	conn:Disconnect()
	if blocked then return walkTo(humanoid, root, target) end
	return true
end
```
- Run NPC brains on the server. Give each NPC's root part `SetNetworkOwner(nil)` so the server simulates it
  smoothly instead of handing physics to a nearby player.
- For chasers, recompute the path every 0.5–1 s toward the target instead of following an old path to the end.
- A simple state machine keeps NPC logic readable: `Idle → Patrol → Chase → Attack → Return`, with one
  function per state returning the next state.

## Animation
```lua
local animator = humanoid:FindFirstChildOfClass("Animator") or Instance.new("Animator", humanoid)
local anim = Instance.new("Animation")
anim.AnimationId = "rbxassetid://123456" -- an animation you own or that the game owner can use
local track = animator:LoadAnimation(anim)
track.Priority = Enum.AnimationPriority.Action
track:Play(0.1) -- fade time
track:GetMarkerReachedSignal("Hit"):Connect(function() end) -- markers set in the Animation Editor
```
- Load each animation once and keep the track; loading every time leaks tracks.
- Player character animations played from a LocalScript replicate to others (the client owns its character).

## UI basics
- Build in `StarterGui` → `ScreenGui` (`ResetOnSpawn = false` for HUDs that should persist).
- Use Scale sizes (`UDim2.fromScale(0.3, 0.1)`) plus `UIAspectRatioConstraint` so UI fits phones and PCs;
  `UIListLayout`/`UIGridLayout` and `UIPadding` for lists; `UIStroke`, `UICorner` for styling.
- Animate with `TweenService:Create(frame, TweenInfo.new(0.25, Enum.EasingStyle.Quad), {Position = ...}):Play()`.
- UI is client-side: buttons fire a RemoteEvent; the server decides what happens.
- `GuiService` / `UserInputService.TouchEnabled` to adapt layouts; `ContextActionService` to bind keys and
  create mobile buttons in one place.

## Performance
- Turn on `Workspace.StreamingEnabled` for big maps so clients only load nearby parts (code must then use
  `WaitForChild` and handle parts streaming out).
- Fewer, larger parts and MeshParts beat thousands of tiny parts; anchor everything that doesn't move.
- Avoid per-frame work on the server for every NPC; batch updates or lower their tick rate when far from players.
- Use events (`Changed`, `GetPropertyChangedSignal`, `Touched`) instead of polling loops.
- On the client, visual effects that every player needs (tweens, particles) can be played locally after a
  single RemoteEvent instead of replicating many property changes from the server.
- Profile with the MicroProfiler (Ctrl+F6) and the Developer Console (F9: memory, script activity).
