"""UNISON Code: whole projects in one call, Windows-friendly commands, game smoke tests, web research."""
import asyncio
import sys
import unittest
from unittest import mock

from tests.helpers import IsolatedSettings  # noqa: I001
from backend.tools import filesystem, terminal, web
from backend.tools.base import ToolError
from backend.core.chat_service import ChatService, wants_build
from backend.inference.base import ChatMessage, ToolCall
from tests.test_agent import MODEL


class WriteFilesTests(unittest.TestCase):
    def test_writes_a_project_with_folders(self):
        with IsolatedSettings() as env:
            r = filesystem.write_files({"files": [
                {"path": "index.html", "content": "<h1>Shop</h1>"},
                {"path": "css/style.css", "content": "body{}"},
                {"path": "js/cart.js", "content": "const Cart = {};"}]})
            self.assertTrue(r.ok)
            self.assertTrue((env.workspace / "css" / "style.css").exists())
            self.assertIn("Wrote 3 file(s)", r.output)

    def test_rejects_bad_input_and_outside_paths(self):
        with IsolatedSettings() as env:
            with self.assertRaises(ToolError):
                filesystem.write_files({"files": []})
            with self.assertRaises(ToolError):
                filesystem.write_files({"files": [{"path": str(env.outside / "x.html"), "content": "x"}]})
            self.assertFalse((env.outside / "x.html").exists())

    def test_new_files_are_auto_but_overwrites_ask(self):
        from backend.tools.registry import ToolRegistry
        reg = ToolRegistry()
        with IsolatedSettings() as env:
            tool = reg.get("write_files")
            self.assertEqual(reg.decide(tool, {"files": [{"path": "a.html", "content": "x"}]})[0], "auto")
            (env.workspace / "a.html").write_text("old")
            self.assertEqual(reg.decide(tool, {"files": [{"path": "a.html", "content": "x"}]})[0], "ask")


class WindowsCommandTests(unittest.TestCase):
    def test_linux_commands_become_cmd(self):
        cases = {"ls -R": "dir /s /b", "ls": "dir", "cat index.html": "type index.html", "pwd": "cd",
                 "ls -la src/js": "dir src\\js", "mkdir -p css/img": "mkdir css\\img"}
        for src, want in cases.items():
            self.assertEqual(terminal.windows_command(src)[0], want, src)
        self.assertEqual(terminal.windows_command("npm install")[0], "npm install")
        self.assertEqual(terminal.windows_command("python main.py"), ("python main.py", ""))

    def test_dangerous_translation_still_blocked(self):
        self.assertEqual(terminal.classify("rm -rf /")[0], "blocked")
        self.assertEqual(terminal.classify(terminal.windows_command("rm -rf C:/")[0])[0], "blocked")


class SmokeTestTests(unittest.TestCase):
    def test_game_that_keeps_running_passes(self):
        with IsolatedSettings() as env:
            (env.workspace / "game.py").write_text("import time\nwhile True: time.sleep(0.1)\n")
            r = terminal.run_command({"command": f'"{sys.executable}" game.py', "smoke_test_seconds": 2})
            self.assertTrue(r.ok, r.output)
            self.assertIn("SMOKE TEST PASSED", r.output)

    def test_crash_fails(self):
        with IsolatedSettings() as env:
            (env.workspace / "bad.py").write_text("raise ValueError('boom')\n")
            r = terminal.run_command({"command": f'"{sys.executable}" bad.py', "smoke_test_seconds": 3})
            self.assertFalse(r.ok)
            self.assertIn("SMOKE TEST FAILED", r.output)


class PastedCodeTests(unittest.TestCase):
    def test_detects_a_pasted_program(self):
        code = "```html\n" + "\n".join(f"<p>{n}</p>" for n in range(40)) + "\n```"
        hist = [ChatMessage("user", "make a site")]
        self.assertTrue(ChatService._pasted_code_instead_of_files(code, hist))
        hist.append(ChatMessage("assistant", "", tool_calls=[ToolCall("write_files", {}, "1")]))
        self.assertFalse(ChatService._pasted_code_instead_of_files(code, hist))
        self.assertFalse(ChatService._pasted_code_instead_of_files("```py\nprint(1)\n```", [ChatMessage("user", "x")]))

    def test_file_requests_build(self):
        for t in ["send me the html as a file", "build it into the workspace your connected to", "save that as index.html"]:
            self.assertTrue(wants_build(t), t)


DDG = '''<div class="result"><a rel="nofollow" class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fwww.python.org%2Fdownloads%2F&amp;rut=x">Download <b>Python</b></a>
<a class="result__snippet" href="#">The latest version is <b>Python 3.14</b>.</a></div>
<div class="result"><a rel="nofollow" class="result__a" href="https://duckduckgo.com/y.js?ad=1">Ad</a></div>
<div class="result"><a rel="nofollow" class="result__a" href="https://docs.python.org/3/whatsnew/">What's New</a>
<a class="result__snippet" href="#">Changes in 3.14</a></div>'''


class WebTests(unittest.TestCase):
    def test_parse_duckduckgo(self):
        res = web.parse_ddg(DDG, 5)
        self.assertEqual([r["url"] for r in res], ["https://www.python.org/downloads/", "https://docs.python.org/3/whatsnew/"])
        self.assertEqual(res[0]["title"], "Download Python")
        self.assertIn("3.14", res[0]["snippet"])

    def test_page_text_drops_scripts_and_menus(self):
        title, text = web.page_text("<html><head><title>Docs</title><script>evil()</script></head><body><nav>menu</nav>"
                                    "<h1>Install</h1><p>Run pip install x</p></body></html>")
        self.assertEqual(title, "Docs")
        self.assertIn("# Install", text)
        self.assertNotIn("evil", text)
        self.assertNotIn("menu", text)

    def test_private_addresses_refused(self):
        for u in ["http://localhost:8770/v1/keys", "http://192.168.1.5/", "file:///c:/x"]:
            with self.assertRaises(ToolError):
                web.fetch(u)

    def test_research_intent(self):
        self.assertTrue(web.wants_research("search the web for the newest version of three.js"))
        self.assertTrue(web.wants_research("what's the latest news on python 3.15"))
        self.assertFalse(web.wants_research("make my button blue"))

    def test_chat_research_reaches_prompt_and_sources(self):
        from tests.fake_ollama import FakeOllama
        from backend.database.db import Database
        from backend.inference.manager import ModelManager
        from backend.inference.ollama_backend import OllamaBackend
        import tempfile
        from pathlib import Path
        seen = {}

        def brain(body):
            seen["system"] = body["messages"][0]["content"]
            return {"content": "Python 3.14 is the latest [1]."}

        fake_ctx = ("[1] Download Python - https://www.python.org/downloads/\nPython 3.14 is out",
                    [{"n": 1, "title": "Download Python", "url": "https://www.python.org/downloads/", "snippet": ""}])
        with IsolatedSettings(), FakeOllama(responder=brain) as fake, tempfile.TemporaryDirectory() as d, \
                mock.patch("backend.core.chat_service.research", return_value=fake_ctx):
            db = Database(Path(d) / "t.db")
            svc = ChatService(db, ModelManager(OllamaBackend(fake.url)), knowledge=None)

            async def go():
                return [e async for e in svc.run(conversation_id=None, content="search for the latest python version",
                                                 model=MODEL)]
            evs = asyncio.run(go())
            db._conn.close()
        self.assertIn("Fresh web results", seen["system"])
        srcs = [e for e in evs if e["type"] == "sources"]
        self.assertEqual(srcs[0]["items"][0]["url"], "https://www.python.org/downloads/")


if __name__ == "__main__":
    unittest.main()
