"""Train-UNISON's dataset builder: language detection, filtering, balancing and your own ratings."""
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from tests.helpers import ROOT  # noqa: F401  (puts the project on sys.path)
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts" / "train"))
import build_dataset as bd  # noqa: E402


class DatasetTests(unittest.TestCase):
    def test_language_detection(self):
        self.assertEqual(bd.detect_lang("make a page", "```html\n<div></div>\n```"), "html")
        self.assertEqual(bd.detect_lang("x", "y", "C#"), "csharp")
        self.assertEqual(bd.detect_lang("write it in c++", "#include <vector>\nint main(){}"), "cpp")
        self.assertEqual(bd.detect_lang("roblox script", "local function onTouched(hit) end"), "lua")
        self.assertEqual(bd.detect_lang("sort a list", "def sort_it(xs):\n    return sorted(xs)"), "python")

    def test_filters_bad_pairs(self):
        self.assertFalse(bd.good_pair("hi", "hello there " * 10))
        self.assertFalse(bd.good_pair("Write a function that adds", "As an AI language model I cannot " * 3))
        self.assertFalse(bd.good_pair("q" * 30, "a" * (bd.MAX_CHARS + 10)))
        self.assertTrue(bd.good_pair("Write a function that adds two numbers", "def add(a, b):\n    return a + b\n" * 3))

    def test_rows_to_chat_examples(self):
        src = {"id": "x/y", "q": "query", "a": "answer", "lang_field": "lang"}
        rows = [{"query": "Write a JS function to debounce calls", "answer": "```js\nfunction debounce(f,ms){let t;return(...a)=>{clearTimeout(t);t=setTimeout(()=>f(...a),ms)}}\n```", "lang": "javascript"},
                {"query": "short", "answer": "nope"}]
        out = bd.from_rows(rows, src, 10)
        self.assertEqual(len(out), 1)
        self.assertEqual(out[0]["lang"], "javascript")
        self.assertEqual([m["role"] for m in out[0]["messages"]], ["system", "user", "assistant"])

    def test_balance_respects_quotas_and_fills_gaps(self):
        pool = [{"lang": "python", "messages": [{}, {"content": f"p{n}"}]} for n in range(500)] + \
               [{"lang": "cpp", "messages": [{}, {"content": f"c{n}"}]} for n in range(10)]
        out = bd.balance(pool, 200, 1)
        self.assertEqual(len(out), 200)
        self.assertEqual(sum(1 for x in out if x["lang"] == "cpp"), 10)   # all it had

    def test_dedupe(self):
        ex = bd.example("Same question here please", "answer " * 10, "s", "python")
        self.assertEqual(len(bd.dedupe([ex, dict(ex)])), 1)

    def test_main_writes_dataset_with_manifest(self):
        fake = lambda src, limit, seed: [bd.example(f"Write {src['id']} task number {n} please", "def f():\n    return 1\n" * 3,
                                                      src["id"], "python") for n in range(30)]
        with tempfile.TemporaryDirectory() as d, mock.patch.object(bd, "OUT", Path(d)), \
                mock.patch.object(bd, "stream_source", side_effect=fake), mock.patch.object(bd, "own_examples", return_value=[]), \
                mock.patch.object(sys, "argv", ["x", "--size", "quick"]):
            self.assertEqual(bd.main(), 0)
            lines = (Path(d) / "unison-code-quick.jsonl").read_text(encoding="utf-8").splitlines()
            man = json.loads((Path(d) / "unison-code-quick.manifest.json").read_text())
        self.assertEqual(len(lines), 120)                    # 4 sources x 30, deduped by question
        self.assertEqual(man["examples"], 120)
        self.assertEqual(len(man["sources"]), 4)


if __name__ == "__main__":
    unittest.main()
