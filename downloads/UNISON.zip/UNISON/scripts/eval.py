"""
Run UNISON's programming benchmark against the local model.

  eval.bat                         active model, knowledge base on
  eval.bat --model qwen2.5-coder:14b
  eval.bat --no-knowledge          measure the model alone
  eval.bat --only python,roblox    some categories
  eval.bat --yes                   don't ask for confirmation

Needs Ollama running (UNISON's server does not need to be running).
"""
from __future__ import annotations

import argparse
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from backend.inference.manager import manager  # noqa: E402
from backend.training.evaluate import Evaluator, load_tasks, previous_for, save_result  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model")
    ap.add_argument("--no-knowledge", action="store_true")
    ap.add_argument("--only", help="comma-separated categories")
    ap.add_argument("--yes", action="store_true")
    a = ap.parse_args()

    tasks = load_tasks()
    if a.only:
        cats = {c.strip() for c in a.only.split(",")}
        tasks = [t for t in tasks if t["category"] in cats]
    model = a.model or manager.active_model
    print(f"Benchmark: {len(tasks)} tasks, model {model}, knowledge {'off' if a.no_knowledge else 'on'}")
    print("This runs code the model writes (in temporary folders, with timeouts) to check it works.")
    if not a.yes and input("Continue? [y/N] ").strip().lower() not in ("y", "yes"):
        return 1

    async def go():
        ev = Evaluator(manager, model, use_knowledge=not a.no_knowledge)
        try:
            return await ev.run(tasks)
        finally:
            ev.close()

    result = asyncio.run(go())
    path = save_result(result)
    prev = previous_for(result["model"], result["knowledge"], exclude=path.name)
    print(f"\nScore: {result['passed']}/{result['total']} = {result['score']}%")
    for cat, c in result["categories"].items():
        before = ""
        if prev and cat in prev["categories"]:
            p = prev["categories"][cat]
            before = f"   (previous run: {p['passed']}/{p['total']})"
        print(f"  {cat:<13} {c['passed']}/{c['total']}{before}")
    if prev:
        delta = result["score"] - prev["score"]
        print(f"\nChange vs previous run ({prev['created']}): {delta:+.1f} points")
    print(f"Saved {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
