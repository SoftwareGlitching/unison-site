"""The Windows app (desktop/UnisonApp.cs) is compiled on each PC by Windows' own C# 5 compiler, so these
checks catch what that compiler would reject, and keep the app and setup.ps1 talking the same language."""
import re
import tempfile
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "desktop" / "UnisonApp.cs"


def strip_code(text: str) -> str:
    """Remove comments, strings and char literals so only code is left."""
    out, i, n = [], 0, len(text)
    while i < n:
        if text.startswith("//", i):
            i = text.find("\n", i)
            i = n if i < 0 else i
            continue
        if text.startswith("/*", i):
            i = text.find("*/", i) + 2
            continue
        c = text[i]
        if c == '"':
            i += 1
            while text[i] != '"':
                i += 2 if text[i] == "\\" else 1
            i += 1
            out.append('""')
            continue
        if c == "'":
            j = i + 1
            j += 2 if text[j] == "\\" else 1
            assert text[j] == "'", f"bad char literal near {text[i:i + 10]!r}"
            i = j + 1
            out.append("''")
            continue
        out.append(c)
        i += 1
    return "".join(out)


class DesktopAppTests(unittest.TestCase):
    def setUp(self):
        self.text = SRC.read_text(encoding="utf-8")
        self.code = strip_code(self.text)

    def test_files_present(self):
        for f in ("desktop/UnisonApp.cs", "desktop/build.ps1", "desktop/unison.ico", "desktop/Build-App.bat"):
            self.assertTrue((ROOT / f).exists(), f)

    def test_ascii_only(self):
        bad = [(i, ch) for i, ch in enumerate(self.text) if ord(ch) > 127]
        self.assertEqual(bad, [], "use \\uXXXX escapes: the Windows compiler may read the file in the wrong code page")

    def test_balanced(self):
        pairs, stack = {")": "(", "]": "[", "}": "{"}, []
        for ch in self.code:
            if ch in "([{":
                stack.append(ch)
            elif ch in ")]}":
                self.assertTrue(stack and stack[-1] == pairs[ch], "unbalanced brackets")
                stack.pop()
        self.assertEqual(stack, [])
        self.assertEqual(self.text.count("#if"), self.text.count("#endif"))

    def test_csharp5_only(self):
        for pattern, what in [(r'\$"', "string interpolation"), (r"\w\?\.", "?. operator"), (r"\?\[", "?[ operator"),
                              (r"\bnameof\s*\(", "nameof"), (r"\bout\s+var\b", "out var"), (r"\bis\s+\w+\s+\w+\s*\)", "pattern matching"),
                              (r"\)\s*=>\s*[^{(;]*;\s*\n\s*(public|private|protected|static|internal|void|bool|string|int)\b", "=> member"),
                              (r"\{\s*get;\s*(private\s+)?set;\s*\}\s*=", "auto-property initializer")]:
            self.assertIsNone(re.search(pattern, self.code), what + " needs C# 6+")
        # expression-bodied members: "Type Name(...) => expr;" at class level
        self.assertIsNone(re.search(r"^\s*(public|private|protected|internal|static)[^\n={]*\)\s*=>", self.code, re.M))

    def test_webview2_isolated(self):
        # WebView2 types may only be used inside #if WEBVIEW2 blocks, or the fallback build won't compile.
        outside = re.sub(r"#if WEBVIEW2.*?#endif", "", self.text, flags=re.S)
        self.assertNotIn("WebView2(", outside.replace("Web2.Create", ""))
        self.assertNotIn("CoreWebView2", outside.replace("\"WebView2:", ""))

    def test_steps_match_setup_script(self):
        keys = re.search(r"StepKeys\s*=\s*\{([^}]*)\}", self.text).group(1)
        app_keys = re.findall(r'"([^"]+)"', keys)
        setup = (ROOT / "scripts" / "setup.ps1").read_text()
        script_keys = re.findall(r'^Write-Step "([^"]+)"', setup, re.M)
        self.assertEqual(app_keys, script_keys)
        titles = re.findall(r'"([^"]+)"', re.search(r"StepTitles\s*=\s*\{([^}]*)\}", self.text).group(1))
        self.assertEqual(len(titles), len(app_keys))

    def test_setup_gui_mode(self):
        setup = (ROOT / "scripts" / "setup.ps1").read_text()
        self.assertIn("[switch]$Gui", setup)
        self.assertIn("@@FAIL", setup)
        self.assertIn("@@DONE", setup)
        self.assertIn("-not $Gui -and $try", setup)   # never waits for a typed key in the window
        self.assertIn('if (-not $Gui) { Read-Host', setup)
        self.assertIn("UNISON_LICENSE_KEY", setup)
        self.assertIn("desktop\\build.ps1", setup)
        for marker in ("@@FAIL ", "@@DONE ", "@@EXIT "):
            self.assertIn(marker, self.text)
        # every Read-Host in setup.ps1 is either guarded or behind -Yes
        for line in setup.splitlines():
            if "Read-Host" in line:
                self.assertTrue("$Gui" in line or "$Yes" in line or "-not $Yes" in setup, line)

    def test_launchers(self):
        start = (ROOT / "Start-UNISON.bat").read_bytes()
        setup = (ROOT / "Setup.bat").read_bytes()
        for b in (start, setup):
            self.assertIn(b"\r\n", b)
            self.assertIn(b"desktop\\build.ps1", b)
            self.assertIn(b"UNISON.exe", b)
        self.assertIn(b"--setup", setup)
        self.assertIn(b"scripts\\setup.ps1", setup)    # text fallback
        self.assertIn(b"scripts\\start.ps1", start)    # console fallback
        self.assertIn(b"--background", start)

    def test_zip_has_app_source_not_binaries(self):
        from scripts.configure_site import build_zip
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "src"
            (root / "desktop" / "bin").mkdir(parents=True)
            (root / "desktop" / "UnisonApp.cs").write_text("x")
            (root / "desktop" / "bin" / "WebView2Loader.dll").write_bytes(b"x")
            (root / "UNISON.exe").write_bytes(b"MZ")
            (root / "Setup.bat").write_text("@echo off\n")
            dest = Path(d) / "u.zip"
            build_zip(dest, root)
            names = zipfile.ZipFile(dest).namelist()
            self.assertIn("UNISON/desktop/UnisonApp.cs", names)
            self.assertNotIn("UNISON/UNISON.exe", names)
            self.assertFalse([n for n in names if "/bin/" in n])


if __name__ == "__main__":
    unittest.main()
