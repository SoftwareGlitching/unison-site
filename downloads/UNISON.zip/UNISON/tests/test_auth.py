"""Password hashing, session tokens, and the sign-in route handlers / middleware gate."""
import time
import unittest

from tests.helpers import IsolatedSettings

from backend.security import sessions


class SessionTests(unittest.TestCase):
    def test_password_roundtrip(self):
        with IsolatedSettings():
            self.assertFalse(sessions.password_set())
            sessions.set_password("hunter2!")
            self.assertTrue(sessions.password_set())
            self.assertTrue(sessions.verify_password("hunter2!"))
            self.assertFalse(sessions.verify_password("wrong"))
            # stored only as a hash
            rec = sessions.settings.get("auth", "password")
            self.assertNotIn("hunter2", str(rec))
            self.assertEqual(rec["algo"], "pbkdf2_sha256")

    def test_too_short_rejected(self):
        with IsolatedSettings():
            with self.assertRaises(ValueError):
                sessions.set_password("abc")

    def test_token_issue_and_verify(self):
        with IsolatedSettings():
            sessions.set_password("longenough")
            tok = sessions.issue_token()
            self.assertTrue(sessions.verify_token(tok))
            self.assertFalse(sessions.verify_token("garbage"))
            self.assertFalse(sessions.verify_token(tok + "x"))
            self.assertFalse(sessions.verify_token(None))

    def test_expired_token_rejected(self):
        with IsolatedSettings():
            sessions.set_password("longenough")
            tok = sessions.issue_token(days=0)
            time.sleep(0.01)
            # exp == iat (0 days) so it is already not in the future
            self.assertFalse(sessions.verify_token(tok))

    def test_rotate_and_change_invalidate_old_tokens(self):
        with IsolatedSettings():
            sessions.set_password("longenough")
            tok = sessions.issue_token()
            self.assertTrue(sessions.verify_token(tok))
            sessions.rotate_secret()
            self.assertFalse(sessions.verify_token(tok))
            # changing the password also rotates the secret
            tok2 = sessions.issue_token()
            sessions.set_password("another-one")
            self.assertFalse(sessions.verify_token(tok2))

    def test_clear_password(self):
        with IsolatedSettings():
            sessions.set_password("longenough")
            sessions.clear_password()
            self.assertFalse(sessions.password_set())
            self.assertFalse(sessions.verify_password("longenough"))


class Req:
    """Minimal request: by default a browser on this PC (127.0.0.1, Host: 127.0.0.1:8770)."""

    def __init__(self, host="127.0.0.1", headers=None, token=None, host_header="127.0.0.1:8770"):
        self.client = type("C", (), {"host": host})()
        h = {"host": host_header} if host_header else {}
        h.update(headers or {})
        if token:
            h["authorization"] = f"Bearer {token}"
        self.headers = {k.lower(): v for k, v in h.items()}


def tunnel(**extra):
    """What a request through Tailscale serve/funnel looks like: TCP from 127.0.0.1, public Host, XFF."""
    return Req(host_header="desktop-n9mq6h1.tail1234.ts.net",
               headers={"x-forwarded-for": "203.0.113.9", **extra.pop("headers", {})}, **extra)


class RequestAuthTests(unittest.TestCase):
    def test_request_authorized_accepts_token(self):
        from backend.security.auth import request_authorized
        with IsolatedSettings():
            sessions.set_password("longenough")
            tok = sessions.issue_token()
            self.assertTrue(request_authorized(Req(token=tok)))
            self.assertFalse(request_authorized(Req()))
            self.assertFalse(request_authorized(Req(token="nope")))

    def test_is_remote_detects_tailscale_header(self):
        from backend.security.auth import is_remote
        self.assertTrue(is_remote(Req(headers={"tailscale-user-login": "me@example.com"})))
        self.assertFalse(is_remote(Req()))

    def test_tunnels_are_never_treated_as_local(self):
        from backend.security.auth import client_ip, is_truly_local
        self.assertTrue(is_truly_local(Req()))
        self.assertTrue(is_truly_local(Req(host_header="localhost:8770")))
        self.assertFalse(is_truly_local(tunnel()))                                    # funnel / serve
        self.assertFalse(is_truly_local(Req(headers={"x-forwarded-for": "1.2.3.4"})))  # any proxy
        self.assertFalse(is_truly_local(Req(host_header="evil.example.com")))         # DNS rebinding
        self.assertFalse(is_truly_local(Req(host="192.168.1.20")))
        self.assertEqual(client_ip(tunnel()), "203.0.113.9")
        self.assertEqual(client_ip(Req()), "127.0.0.1")


class RouteRuleTests(unittest.TestCase):
    def run_(self, coro):
        import asyncio
        return asyncio.run(coro)

    def test_password_cannot_be_set_through_a_tunnel(self):
        from backend.api import routes_auth as ra
        with IsolatedSettings():
            with self.assertRaises(Exception) as ctx:
                self.run_(ra.setup(ra.PasswordBody(password="attacker-pw"), tunnel()))
            self.assertEqual(ctx.exception.status_code, 403)
            self.assertFalse(sessions.password_set())
            with self.assertRaises(Exception):
                self.run_(ra.change(ra.PasswordBody(password="attacker-pw"), tunnel()))
            self.assertFalse(sessions.password_set())
            self.run_(ra.setup(ra.PasswordBody(password="owner-pw-1"), Req()))   # at the PC: fine
            self.assertTrue(sessions.verify_password("owner-pw-1"))

    def test_lockout_after_repeated_wrong_passwords(self):
        from backend.api import routes_auth as ra
        ra.failed = ra.FailedLogins()
        with IsolatedSettings():
            sessions.set_password("right-password")
            for _ in range(ra.MAX_FAILS_PER_IP):
                with self.assertRaises(Exception) as ctx:
                    self.run_(ra.login(ra.PasswordBody(password="nope"), tunnel()))
                self.assertEqual(ctx.exception.status_code, 401)
            with self.assertRaises(Exception) as ctx:   # even the right password is refused now
                self.run_(ra.login(ra.PasswordBody(password="right-password"), tunnel()))
            self.assertEqual(ctx.exception.status_code, 429)
            # a different address and the PC itself are not locked out
            ok = self.run_(ra.login(ra.PasswordBody(password="right-password"), Req()))
            self.assertTrue(sessions.verify_token(ok["token"]))
            other = Req(host_header="x.ts.net", headers={"x-forwarded-for": "198.51.100.7"})
            self.assertTrue(self.run_(ra.login(ra.PasswordBody(password="right-password"), other))["ok"])

    def test_owner_endpoints_from_other_devices_need_a_password(self):
        from backend.security.auth import local_only
        with IsolatedSettings():
            with self.assertRaises(Exception):
                self.run_(local_only(tunnel()))
            self.run_(local_only(Req()))
            sessions.set_password("longenough")
            self.run_(local_only(tunnel()))      # session already checked by the middleware


if __name__ == "__main__":
    unittest.main()
