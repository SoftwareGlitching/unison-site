@echo off
cd /d "%~dp0.."
".venv\Scripts\python.exe" scripts\index_knowledge.py %*
if errorlevel 1 pause
