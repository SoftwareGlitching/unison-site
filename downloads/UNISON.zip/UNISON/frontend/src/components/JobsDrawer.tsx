import { useEffect, useState } from "react";
import { api, type JobSummary } from "../lib/api";
import { Markdown } from "../chat/Markdown";

const STATUS: Record<string, string> = {
  queued: "queued", running: "working", waiting_approval: "needs you", done: "done", failed: "failed",
  stopped: "stopped", interrupted: "interrupted",
};
const ago = (t: number | null) => {
  if (!t) return "";
  const s = Math.round(Date.now() / 1000 - t);
  return s < 60 ? `${s}s ago` : s < 3600 ? `${Math.round(s / 60)}m ago` : s < 86400 ? `${Math.round(s / 3600)}h ago` : new Date(t * 1000).toLocaleDateString();
};

function EventLine({ ev }: { ev: any }) {
  switch (ev.type) {
    case "tool_call":
      return <div className="jev"><span className="tool-name">{ev.name}</span> <span className="dim">{ev.args?.command ?? ev.args?.path ?? ""}</span></div>;
    case "tool_result":
      return <details className="jev"><summary className={ev.ok ? "ok-t" : "bad-t"}>{ev.ok ? "✓" : "✕"} result</summary><pre className="tool-output">{ev.output}</pre></details>;
    case "action":
      return <div className="jev"><span className="tool-name">step {ev.step}</span> {ev.description}</div>;
    case "action_result":
      return ev.ok ? null : <div className="jev bad-t">✕ {ev.message}</div>;
    case "assistant_saved":
      return ev.content ? <div className="jev"><Markdown text={ev.content} /></div> : null;
    case "notice":
    case "error":
      return <div className="jev notice">{ev.message}</div>;
    default:
      return null;
  }
}

function JobDetail({ id, onBack }: { id: string; onBack: () => void }) {
  const [job, setJob] = useState<Awaited<ReturnType<typeof api.job>> | null>(null);
  const [err, setErr] = useState("");
  const load = () => api.job(id).then(setJob).catch((e) => setErr(e.message));
  useEffect(() => {
    load();
    const t = setInterval(load, 2500);
    return () => clearInterval(t);
  }, [id]);
  if (!job) return <div className="tab-body">{err || "loading…"}</div>;
  const pending = job.pending_action ? [...job.events].reverse().find((e) => e.type === "approval_required" && e.action_id === job.pending_action) : null;
  const answer = async (ok: boolean) => {
    if (!job.pending_action) return;
    await api.approve(job.pending_action, ok).catch((e) => setErr(e.message));
    load();
  };
  return (
    <div className="tab-body">
      <button className="link-btn" onClick={onBack}>← all jobs</button>
      <h4 style={{ marginTop: 10 }}>{job.task}</h4>
      <div className="row small">
        <span className={`tier-tag js-${job.status}`}>{STATUS[job.status]}</span>
        <span className="dim">{job.kind} · {job.autonomous ? "autonomous" : "asks first"} · {job.steps} step(s) · {ago(job.started_at ?? job.created_at)}</span>
        <span className="grow" />
        {(job.status === "running" || job.status === "waiting_approval" || job.status === "queued") && (
          <button className="deny" onClick={() => api.stopJob(id).then(load)}>stop</button>
        )}
      </div>
      {pending && (
        <div className="tool-card st-approval" style={{ margin: "10px 0" }}>
          <div className="approval">
            <div className="approval-title">Waiting for you: {pending.name}</div>
            {pending.preview?.kind === "screen" && <img className="shot big" src={`data:image/jpeg;base64,${pending.preview.image}`} alt="planned action" />}
            {pending.preview?.kind === "command" && <pre className="cmd">&gt; {pending.preview.command}</pre>}
            {pending.preview?.kind === "diff" && <pre className="diff">{pending.preview.diff}</pre>}
            {pending.preview?.summary && <div className="pv-line">{pending.preview.summary}</div>}
            <div className="approval-actions">
              <button className="approve" onClick={() => answer(true)}>Approve</button>
              <button className="deny" onClick={() => answer(false)}>Deny</button>
            </div>
          </div>
        </div>
      )}
      {job.last_image && job.kind === "screen" && <img className="shot big" src={`data:image/jpeg;base64,${job.last_image}`} alt="latest screen" />}
      {job.summary && job.status !== "running" && <div className="job-summary"><Markdown text={job.summary} /></div>}
      <div className="jevents">{job.events.map((ev) => <EventLine key={ev.id} ev={ev} />)}</div>
      {err && <div className="pop-error">{err}</div>}
    </div>
  );
}

export function JobsDrawer({ onClose }: { onClose: () => void }) {
  const [jobs, setJobs] = useState<JobSummary[]>([]);
  const [open, setOpen] = useState<string | null>(null);
  const [task, setTask] = useState("");
  const [kind, setKind] = useState<"agent" | "screen">("agent");
  const [autonomous, setAutonomous] = useState(false);
  const [err, setErr] = useState("");
  const load = () => api.jobs().then(setJobs).catch((e) => setErr(e.message));
  useEffect(() => {
    load();
    const t = setInterval(load, 3000);
    return () => clearInterval(t);
  }, []);

  const submit = async () => {
    setErr("");
    try {
      const j = await api.createJob({ task: task.trim(), kind, autonomous });
      setTask("");
      setOpen(j.id);
      load();
    } catch (e: any) {
      setErr(e.message);
    }
  };

  return (
    <div className="drawer-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <aside className="drawer">
        <div className="drawer-head">
          <span>Jobs</span>
          <button className="icon-btn" onClick={onClose} aria-label="Close">×</button>
        </div>
        <div className="drawer-body">
          {open ? (
            <JobDetail id={open} onBack={() => setOpen(null)} />
          ) : (
            <div className="tab-body">
              <p className="hint">
                Jobs keep running on your PC after you close this page — check on them and approve steps from your phone.
              </p>
              <textarea
                className="text"
                rows={4}
                placeholder="e.g. In my Desktop\UNISON Projects\obby folder, add a checkpoint system and a leaderboard, then check the files for errors."
                value={task}
                onChange={(e) => setTask(e.target.value)}
              />
              <div className="row wrap">
                <div className="mode-switch">
                  <button className={kind === "agent" ? "on" : ""} onClick={() => setKind("agent")}>files + terminal</button>
                  <button className={kind === "screen" ? "on" : ""} onClick={() => setKind("screen")}>screen</button>
                </div>
                <label className="toggle" style={{ margin: 0 }}>
                  <input type="checkbox" checked={autonomous} onChange={(e) => setAutonomous(e.target.checked)} />
                  autonomous (don't wait for my approval)
                </label>
                <span className="grow" />
                <button className="approve" disabled={!task.trim()} onClick={submit}>start job</button>
              </div>
              {kind === "screen" && <div className="small dim">Screen jobs need Windows unlocked and awake.</div>}
              {err && <div className="pop-error">{err}</div>}
              <section style={{ marginTop: 18 }}>
                {jobs.length === 0 && <div className="dim small">No jobs yet.</div>}
                {jobs.map((j) => (
                  <button key={j.id} className="job-row" onClick={() => setOpen(j.id)}>
                    <span className={`tier-tag js-${j.status}`}>{STATUS[j.status]}</span>
                    <span className="grow job-task">{j.task}</span>
                    <span className="dim small">{j.steps} · {ago(j.finished_at ?? j.started_at ?? j.created_at)}</span>
                  </button>
                ))}
              </section>
            </div>
          )}
        </div>
      </aside>
    </div>
  );
}
