"""Background jobs API (works through remote access too)."""
from __future__ import annotations

from typing import Literal, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from ..agents.jobs import get_runner
from ..core.config import settings
from ..security.auth import local_only

router = APIRouter(prefix="/v1", tags=["jobs"], dependencies=[Depends(local_only)])


class JobRequest(BaseModel):
    task: str = Field(..., min_length=1, max_length=8000)
    kind: Literal["agent", "screen"] = "agent"
    autonomous: bool = Field(False, description="Approve every action automatically (dangerous commands stay blocked)")
    model: Optional[str] = None


class AutonomousRequest(BaseModel):
    enabled: bool


def runner():
    r = get_runner()
    if r is None:
        raise HTTPException(503, {"code": "jobs_unavailable", "message": "The job runner isn't running"})
    return r


@router.get("/jobs")
async def list_jobs():
    return {"data": runner().store.list()}


@router.post("/jobs")
async def create_job(body: JobRequest):
    if body.kind == "screen":
        from ..computer.service import supported
        ok, why = supported()
        if not ok:
            raise HTTPException(400, {"code": "unsupported", "message": why})
    return runner().submit(body.kind, body.task.strip(), body.autonomous, body.model)


@router.get("/jobs/{jid}")
async def get_job(jid: str):
    job = runner().store.get(jid, with_events=True)
    if not job:
        raise HTTPException(404, {"code": "not_found", "message": "No such job"})
    return job


@router.post("/jobs/{jid}/stop")
async def stop_job(jid: str):
    return {"stopped": runner().stop(jid)}


@router.delete("/jobs/{jid}")
async def delete_job(jid: str):
    r = runner()
    job = r.store.get(jid)
    if job and job["status"] in ("running", "waiting_approval"):
        raise HTTPException(409, {"code": "running", "message": "Stop the job first"})
    return {"deleted": r.store.delete(jid)}


@router.get("/autonomous")
async def get_autonomous():
    return {"enabled": bool(settings.get("tools", "autonomous", False))}


@router.post("/autonomous")
async def set_autonomous(body: AutonomousRequest):
    settings.set("tools", "autonomous", body.enabled)
    return {"enabled": body.enabled}
