"""
Build UNISON's coding training set.

Sources (all openly licensed - no scraped books or copyrighted material):
  - bigcode/self-oss-instruct-sc2-exec-filter-50k   ODC-By   Python tasks, every answer executed and tested
  - nvidia/OpenCodeInstruct                          CC-BY-4.0 Python problems with unit-tested solutions
  - m-a-p/CodeFeedback-Filtered-Instruction          Apache-2.0 many languages (JS/TS, C#, C++, HTML/CSS, SQL...)
  - ise-uiuc/Magicoder-OSS-Instruct-75K              MIT      many languages, built from open-source code
  - your own UNISON chats: replies you rated 👍 and your corrections (counted 3x - they matter most)
  - UNISON's voice examples (datasets/persona)

Languages are balanced so it gets better at everything you use, not just Python.
Writes datasets/training/unison-code-<size>.jsonl  ({"messages": [system, user, assistant]}) and a manifest.

  python build_dataset.py --size standard        quick=2000, standard=8000, big=25000 examples
"""
from __future__ import annotations

import argparse
import hashlib
import json
import random
import re
import sys
import time
from pathlib import Path
from typing import Iterable, Optional

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
OUT = ROOT / "datasets" / "training"

SIZES = {"quick": 2000, "standard": 8000, "big": 25000}
MAX_CHARS = 6000          # ~1.7K tokens: longer examples don't fit the GPU during training

SOURCES = [
    {"id": "bigcode/self-oss-instruct-sc2-exec-filter-50k", "license": "ODC-By", "q": "instruction", "a": "response", "lang": "python"},
    {"id": "nvidia/OpenCodeInstruct", "license": "CC-BY-4.0", "q": "input", "a": "output", "lang": "python"},
    {"id": "m-a-p/CodeFeedback-Filtered-Instruction", "license": "Apache-2.0", "q": "query", "a": "answer", "lang_field": "lang"},
    {"id": "ise-uiuc/Magicoder-OSS-Instruct-75K", "license": "MIT", "q": "problem", "a": "solution", "lang_field": "lang"},
]

# share of the final set per language (whatever a language can't fill goes to the others)
QUOTA = {"python": 0.24, "javascript": 0.18, "html": 0.12, "csharp": 0.12, "cpp": 0.12, "lua": 0.05, "other": 0.17}

LANG_ALIASES = {
    "python": "python", "py": "python", "javascript": "javascript", "js": "javascript", "typescript": "javascript",
    "ts": "javascript", "jsx": "javascript", "tsx": "javascript", "node": "javascript", "html": "html", "css": "html",
    "scss": "html", "csharp": "csharp", "c#": "csharp", "cs": "csharp", "cpp": "cpp", "c++": "cpp", "c": "cpp",
    "lua": "lua", "luau": "lua",
}

SYSTEM = ("You are UNISON, an expert coding assistant made by PerkyPop. Write complete, working, well-structured code "
          "with clear names, handle errors and edge cases, and explain the key idea briefly.")


def detect_lang(question: str, answer: str, hint: Optional[str] = None) -> str:
    if hint:
        h = LANG_ALIASES.get(str(hint).strip().lower())
        if h:
            return h
    fences = re.findall(r"```\s*([\w#+-]+)", answer or "")
    for f in fences:
        h = LANG_ALIASES.get(f.lower())
        if h:
            return h
    text = f"{question}\n{answer}".lower()
    for pat, lang in ((r"<!doctype html|<div|<html|\bcss\b|stylesheet", "html"), (r"\bc#|\.net\b|using system;|console\.writeline", "csharp"),
                      (r"#include\s*<|std::|\bc\+\+", "cpp"), (r"\bluau?\b|local function|roblox", "lua"),
                      (r"\bjavascript\b|\btypescript\b|console\.log|=>\s*{|document\.", "javascript"),
                      (r"\bdef \w+\(|\bimport \w+|\bpython\b", "python")):
        if re.search(pat, text):
            return lang
    return "other"


def clean(text) -> str:
    return re.sub(r"\n{4,}", "\n\n\n", str(text or "")).strip()


def good_pair(q: str, a: str) -> bool:
    if len(q) < 15 or len(a) < 40 or len(q) + len(a) > MAX_CHARS:
        return False
    low = a.lower()
    if any(x in low for x in ("as an ai language model", "i cannot assist", "i'm sorry, but i can't", "openai")):
        return False
    return True


def example(q: str, a: str, source: str, lang: str) -> dict:
    return {"messages": [{"role": "system", "content": SYSTEM}, {"role": "user", "content": q},
                         {"role": "assistant", "content": a}], "source": source, "lang": lang}


def from_rows(rows: Iterable[dict], src: dict, limit: int) -> list[dict]:
    out = []
    for row in rows:
        q, a = clean(row.get(src["q"])), clean(row.get(src["a"]))
        if not good_pair(q, a):
            continue
        lang = src.get("lang") or detect_lang(q, a, row.get(src.get("lang_field", ""), None))
        out.append(example(q, a, src["id"], lang))
        if len(out) >= limit:
            break
    return out


def stream_source(src: dict, limit: int, seed: int) -> list[dict]:
    """Stream a dataset from Hugging Face (only the rows we need are downloaded)."""
    from datasets import load_dataset   # installed in the training environment
    ds = load_dataset(src["id"], split="train", streaming=True)
    ds = ds.shuffle(seed=seed, buffer_size=20000)
    return from_rows(ds, src, limit)


def own_examples() -> list[dict]:
    """Your 👍 replies and corrections from UNISON (counted 3x), plus UNISON's voice examples."""
    out = []
    try:
        from backend.database.db import get_db
        from backend.training import dataset as ds
        res = ds.export(get_db(), SYSTEM, out_dir=OUT / "_own")
        path = Path(res["files"]["sft"]["path"]) if "files" in res else None
        if path and path.exists():
            for line in path.read_text(encoding="utf-8").splitlines():
                ex = json.loads(line)
                msgs = [m for m in ex["messages"] if m["role"] in ("system", "user", "assistant") and m.get("content")]
                if len(msgs) >= 2 and msgs[-1]["role"] == "assistant":
                    if msgs[0]["role"] != "system":
                        msgs.insert(0, {"role": "system", "content": SYSTEM})
                    item = {"messages": msgs, "source": "your-ratings", "lang": detect_lang(msgs[-2]["content"], msgs[-1]["content"])}
                    out += [item] * 3
    except Exception as e:  # noqa: BLE001 - own data is a bonus; the open datasets still work
        print(f"   (couldn't read your ratings: {e})")
    voice = ROOT / "datasets" / "persona" / "unison_voice.jsonl"
    if voice.exists():
        for line in voice.read_text(encoding="utf-8").splitlines():
            if line.strip():
                ex = json.loads(line)
                msgs = [{"role": "system", "content": SYSTEM}] + [m for m in ex["messages"] if m["role"] != "system"]
                out.append({"messages": msgs, "source": "unison-voice", "lang": "chat"})
    return out


def balance(pool: list[dict], total: int, seed: int) -> list[dict]:
    rnd = random.Random(seed)
    by: dict[str, list[dict]] = {}
    for ex in pool:
        by.setdefault(ex["lang"], []).append(ex)
    for v in by.values():
        rnd.shuffle(v)
    picked, leftover = [], []
    for lang, share in QUOTA.items():
        want = int(total * share)
        got = by.get(lang, [])
        picked += got[:want]
        leftover += got[want:]
    rnd.shuffle(leftover)
    picked += leftover[: max(0, total - len(picked))]
    return picked


def dedupe(items: list[dict]) -> list[dict]:
    seen, out = set(), []
    for ex in items:
        h = hashlib.sha1(ex["messages"][1]["content"][:400].lower().encode()).hexdigest()
        if h not in seen:
            seen.add(h)
            out.append(ex)
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--size", choices=list(SIZES), default="standard")
    ap.add_argument("--seed", type=int, default=3407)
    a = ap.parse_args()
    total = SIZES[a.size]
    OUT.mkdir(parents=True, exist_ok=True)
    pool, used = [], []
    per_source = int(total * 0.9)       # stream more than needed so languages can be balanced
    for src in SOURCES:
        print(f"   downloading examples from {src['id']} ({src['license']})...", flush=True)
        try:
            got = stream_source(src, per_source, a.seed)
            pool += got
            used.append({"id": src["id"], "license": src["license"], "examples": len(got)})
            print(f"     ok: {len(got)} examples")
        except Exception as e:  # noqa: BLE001 - one source failing shouldn't stop training
            print(f"     skipped ({type(e).__name__}: {str(e)[:160]})")
    if not pool:
        print("   XX  Couldn't download any training data. Is this PC online?")
        return 1
    pool = dedupe(pool)
    mine = own_examples()
    chosen = balance(pool, max(0, total - len(mine)), a.seed) + mine
    random.Random(a.seed).shuffle(chosen)
    path = OUT / f"unison-code-{a.size}.jsonl"
    with open(path, "w", encoding="utf-8") as f:
        for ex in chosen:
            f.write(json.dumps({"messages": ex["messages"], "source": ex["source"], "lang": ex["lang"]}, ensure_ascii=False) + "\n")
    counts: dict[str, int] = {}
    for ex in chosen:
        counts[ex["lang"]] = counts.get(ex["lang"], 0) + 1
    manifest = {"created": time.strftime("%Y-%m-%dT%H:%M:%S"), "file": path.name, "examples": len(chosen),
                "languages": counts, "sources": used, "your_examples": len(mine)}
    path.with_suffix(".manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"   ok  {len(chosen)} examples -> {path}")
    print("       " + ", ".join(f"{k} {v}" for k, v in sorted(counts.items(), key=lambda x: -x[1])))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
