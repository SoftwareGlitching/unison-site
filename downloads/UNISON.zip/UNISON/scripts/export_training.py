"""Export your ratings and corrections as training datasets (datasets/training/)."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from backend.agents.prompts import base_prompt  # noqa: E402
from backend.database.db import get_db  # noqa: E402
from backend.inference.manager import manager  # noqa: E402
from backend.training.dataset import export  # noqa: E402

if __name__ == "__main__":
    print(json.dumps(export(get_db(), base_prompt(manager.active_model or "the local model")), indent=2))
