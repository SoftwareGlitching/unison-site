@echo off
rem Set or reset the UNISON sign-in password:  Set-Password.bat set   |   Set-Password.bat clear
cd /d "%~dp0.."
".venv\Scripts\python.exe" scripts\password.py %*
if errorlevel 1 pause
