"""
Screen-control agent: a local vision model (default qwen3-vl) looks at screenshots and drives the
mouse and keyboard, one action at a time.

Loop: screenshot → model picks ONE action → (approval, unless autopilot) → do it → wait → repeat,
until the model says done/fail, the user stops it, or MAX_STEPS.

Safety rails (kept on purpose, also in autopilot):
- Stop instantly: press Esc, slam the mouse into the top-left corner, or click Stop in the app.
- The model can't click or type into UNISON's own window (so it can't approve its own actions).
- Typed text that matches the terminal blocklist (formatting drives, registry edits...) is refused.
- Step cap, and every action is logged to logs/audit.log.
"""
from __future__ import annotations

import asyncio
import json
import threading
import time
from dataclasses import dataclass, field
from typing import AsyncIterator, Callable, Optional

from ..agents.approvals import ApprovalBroker
from ..core.toolparse import extract_tool_calls
from ..inference.base import ChatMessage, GenerationOptions, InferenceError
from ..tools.registry import audit
from ..tools.terminal import classify
from .desktop import Desktop, WindowInfo, mark, scaled, to_b64

MAX_STEPS = 40
MODEL_IMAGE_WIDTH = 1280
THUMB_WIDTH = 480
SETTLE_SECONDS = 0.8
MAX_BAD_REPLIES = 3
APPROVAL_TIMEOUT = 600

# Common names → what actually launches the program.
_APP_ALIASES = {
    "chrome": "chrome", "google chrome": "chrome", "browser": "chrome",
    "edge": "msedge", "microsoft edge": "msedge", "firefox": "firefox",
    "notepad": "notepad", "explorer": "explorer", "file explorer": "explorer", "files": "explorer",
    "calculator": "calc", "calc": "calc", "paint": "mspaint", "cmd": "cmd", "command prompt": "cmd",
    "terminal": "wt", "powershell": "powershell", "settings": "ms-settings:", "word": "winword",
    "excel": "excel", "spotify": "spotify", "discord": "discord", "steam": "steam",
    "roblox studio": "RobloxStudioBeta", "studio": "RobloxStudioBeta", "blender": "blender",
    "task manager": "taskmgr",
}

ACTIONS = {
    "click": "click(x, y, button='left'|'right'|'middle') - click a point",
    "double_click": "double_click(x, y) - double-click (open files/icons)",
    "right_click": "right_click(x, y) - open a context menu",
    "move": "move(x, y) - hover",
    "drag": "drag(x1, y1, x2, y2) - drag with the left button",
    "scroll": "scroll(x, y, direction='up'|'down', amount=3) - mouse wheel over a point",
    "type": "type(text) - type text into the focused field (\\n presses Enter)",
    "key": "key(keys) - a key or shortcut, e.g. 'enter', 'ctrl+s', 'ctrl+w', 'ctrl+t', 'alt+tab', 'win'",
    "open_app": "open_app(name) - launch a program by name (e.g. 'chrome', 'notepad', 'explorer', 'calc')",
    "wait": "wait(seconds) - wait for something to load (max 10)",
    "done": "done(summary) - the task is complete",
    "fail": "fail(reason) - the task can't be done (explain why)",
}

SYSTEM = """You control the user's own Windows PC, at their request, by looking at screenshots and choosing ONE
action at a time. The user owns this computer and is watching; operating it for them is your job.

Coordinates: x and y are integers from 0 to 1000, relative to the screenshot: (0, 0) is the top-left
corner and (1000, 1000) the bottom-right. Aim at the centre of the button, field or icon.

Reply with one or two short sentences about what you see and what you'll do, then exactly one action:
<tool_call>
{{"name": "click", "arguments": {{"x": 512, "y": 300}}}}
</tool_call>

Actions:
{actions}

Rules:
- After every action you get a new screenshot. Check the previous action worked before moving on.
- Click a text field before typing into it. Prefer reliable keyboard shortcuts (ctrl+s, ctrl+l, enter).
- To start a program use open_app (e.g. open_app("chrome")); to switch windows use alt+tab or click the taskbar.
- In a web browser: new tab = ctrl+t, close the current tab = ctrl+w, address bar = ctrl+l (then type a URL and press enter), reload = f5. To close a tab, make sure the browser window is in front first.
- Never click or type inside the window titled "UNISON" - that is your own control panel.
- Never type passwords, payment details or other secrets; if the task needs them, use fail and say the
  user should enter them.
- Don't repeat an action that didn't work more than twice; try something else or use fail.
- When the task is finished, use done with a one-sentence summary."""


@dataclass
class StepRecord:
    n: int
    action: str
    args: dict
    ok: bool
    result: str


@dataclass
class RunState:
    stop: threading.Event = field(default_factory=threading.Event)
    reason: str = ""


def describe(name: str, a: dict, px: dict) -> str:
    if name in ("click", "double_click", "right_click", "move"):
        btn = a.get("button", "left") if name == "click" else name.replace("_click", "")
        verb = {"click": f"{btn}-click", "double_click": "double-click", "right_click": "right-click", "move": "move the mouse"}[name]
        return f"{verb} at ({px['x']}, {px['y']})"
    if name == "drag":
        return f"drag from ({px['x1']}, {px['y1']}) to ({px['x2']}, {px['y2']})"
    if name == "scroll":
        return f"scroll {a.get('direction', 'down')} {a.get('amount', 3)} at ({px['x']}, {px['y']})"
    if name == "type":
        t = str(a.get("text", ""))
        return f'type "{t[:120]}{"…" if len(t) > 120 else ""}"'
    if name == "key":
        return f"press {a.get('keys')}"
    if name == "open_app":
        return f"open {a.get('name')} from the Start menu"
    if name == "wait":
        return f"wait {a.get('seconds', 1)}s"
    return name


class ScreenAgent:
    def __init__(self, desktop: Desktop, backend, model: str, approvals: ApprovalBroker, *,
                 autopilot: bool = False, minimize_self: bool = True, db=None,
                 settle: float = SETTLE_SECONDS, sleep: Callable[[float], None] = time.sleep):
        self.desktop = desktop
        self.backend = backend
        self.model = model
        self.approvals = approvals
        self.autopilot = autopilot
        self.minimize_self = minimize_self
        self.db = db
        self.settle = settle
        self.sleep = sleep
        self.state = RunState()
        self.self_window: Optional[WindowInfo] = None
        self.history: list[StepRecord] = []

    # ------------------------------------------------------------------ kill switches
    def stop(self, reason: str = "Stopped by you") -> None:
        if not self.state.stop.is_set():
            self.state.reason = reason
            self.state.stop.set()

    def _check_now(self) -> bool:
        """Synchronous kill-switch check right before touching the mouse/keyboard (no polling delay)."""
        if self.state.stop.is_set():
            return True
        try:
            injecting = time.time() < getattr(self.desktop, "injecting_until", 0)
            if not injecting and self.desktop.key_down_now("esc"):
                self.stop("You pressed Esc")
            x, y = self.desktop.cursor()
            if x <= 2 and y <= 2:
                self.stop("Mouse moved to the top-left corner (emergency stop)")
        except Exception:  # noqa: BLE001
            pass
        return self.state.stop.is_set()

    def _watch(self) -> None:
        """Esc or mouse in the top-left corner stops the run (polled; ignores keys UNISON itself sends)."""
        while not self.state.stop.is_set():
            try:
                injecting = time.time() < getattr(self.desktop, "injecting_until", 0)
                if not injecting and self.desktop.key_down_now("esc"):
                    self.stop("You pressed Esc")
                x, y = self.desktop.cursor()
                if x <= 2 and y <= 2:
                    self.stop("Mouse moved to the top-left corner (emergency stop)")
            except Exception:  # noqa: BLE001
                pass
            time.sleep(0.04)

    # ------------------------------------------------------------------ helpers
    def _to_px(self, v, size: int, model_size: int) -> int:
        v = float(v)
        # Qwen3-VL-style models answer 0-1000; older models (Qwen2.5-VL) answer in image pixels.
        frac = v / 1000.0 if v <= 1000 else v / model_size
        return int(min(max(round(frac * (size - 1)), 3), size - 4))

    def _resolve(self, name: str, a: dict, w: int, h: int, mw: int, mh: int) -> dict:
        px = {}
        for kx, ky in (("x", "y"), ("x1", "y1"), ("x2", "y2")):
            if kx in a or ky in a:
                if kx not in a or ky not in a:
                    raise ValueError(f"{name} needs both {kx} and {ky}")
                px[kx] = self._to_px(a[kx], w, mw)
                px[ky] = self._to_px(a[ky], h, mh)
        needs_xy = {"click", "double_click", "right_click", "move", "scroll"}
        if name in needs_xy and "x" not in px:
            raise ValueError(f"{name} needs x and y (0-1000)")
        if name == "drag" and "x2" not in px:
            raise ValueError("drag needs x1, y1, x2, y2")
        return px

    def _inside_self(self, px: dict) -> bool:
        win = self.self_window
        if not win or (self.autopilot and self.minimize_self):
            return False
        l, t, r, b = win.rect
        return any(l <= px[kx] <= r and t <= px[ky] <= b
                   for kx, ky in (("x", "y"), ("x1", "y1"), ("x2", "y2")) if kx in px)

    def _check(self, name: str, a: dict, px: dict, fg: Optional[WindowInfo]) -> Optional[str]:
        if self._inside_self(px):
            return "That point is inside UNISON's own window. Act on the target app instead."
        if name == "type":
            text = str(a.get("text", ""))
            if not text:
                return "type needs text"
            if classify(text)[0] == "blocked":
                return "That text looks like a dangerous system command; UNISON won't type it."
        if name in ("type", "key") and fg and self.self_window and fg.handle == self.self_window.handle:
            return "UNISON's own window has keyboard focus. Click the target window first (or use open_app)."
        if name == "key" and not str(a.get("keys", "")).strip():
            return "key needs keys, e.g. 'enter'"
        if name == "open_app" and not str(a.get("name", "")).strip():
            return "open_app needs a name"
        return None

    def _execute(self, name: str, a: dict, px: dict, fg: Optional[WindowInfo]) -> str:
        d = self.desktop
        if name in ("type", "key") and fg and (not self.self_window or fg.handle != self.self_window.handle):
            d.focus(fg.handle)   # the app the model saw focused (approving in the browser moved focus)
        if name == "click":
            d.click(px["x"], px["y"], str(a.get("button", "left")), 1)
        elif name == "double_click":
            d.click(px["x"], px["y"], "left", 2)
        elif name == "right_click":
            d.click(px["x"], px["y"], "right", 1)
        elif name == "move":
            d.move(px["x"], px["y"])
        elif name == "drag":
            d.drag(px["x1"], px["y1"], px["x2"], px["y2"])
        elif name == "scroll":
            amount = max(1, min(int(a.get("amount", 3)), 15))
            d.scroll(px["x"], px["y"], amount if str(a.get("direction", "down")).lower() == "up" else -amount)
        elif name == "type":
            d.type_text(str(a["text"]))
        elif name == "key":
            d.press(str(a["keys"]))
        elif name == "open_app":
            app = str(a["name"]).strip()
            launched = False
            # Most reliable: the Run dialog resolves known programs (chrome, notepad, explorer, calc...)
            # through the App Paths registry and launches them directly.
            if hasattr(d, "run_program"):
                launched = d.run_program(_APP_ALIASES.get(app.lower(), app))
            if not launched:
                d.press("win+r")
                self.sleep(0.7)
                d.type_text(_APP_ALIASES.get(app.lower(), app))
                self.sleep(0.4)
                d.press("enter")
            self.sleep(2.0)
        elif name == "wait":
            self.sleep(max(0.0, min(float(a.get("seconds", 1)), 10.0)))
        return "ok"

    def _messages(self, task: str, img_b64: str, w: int, h: int, fg: Optional[WindowInfo]) -> list[ChatMessage]:
        actions = "\n".join(f"- {v}" for v in ACTIONS.values())
        msgs = [ChatMessage("system", SYSTEM.format(actions=actions)), ChatMessage("user", f"Task: {task}")]
        if self.history:
            lines = [f"{s.n}. {s.action}({json.dumps(s.args, ensure_ascii=False)[:160]}) -> {s.result}"
                     for s in self.history[-15:]]
            msgs.append(ChatMessage("user", "Actions so far:\n" + "\n".join(lines)))
        cx, cy = self.desktop.cursor()
        title = fg.title if fg else "(none)"
        msgs.append(ChatMessage(
            "user",
            f"Current screen (real size {w}x{h}). Active window: \"{title}\". "
            f"Mouse at ({round(cx * 1000 / max(w, 1))}, {round(cy * 1000 / max(h, 1))}). What is the next action?",
            images=[img_b64]))
        return msgs

    # ------------------------------------------------------------------ main loop
    async def run(self, task: str) -> AsyncIterator[dict]:
        watcher = threading.Thread(target=self._watch, daemon=True)
        watcher.start()
        status, summary, bad = "max_steps", "", 0
        self.self_window = self.desktop.foreground()
        if self.self_window and "unison" not in self.self_window.title.lower():
            self.self_window = None
        minimized = False
        cid = None
        if self.db is not None:
            from ..core.chat_service import make_title
            cid = self.db.create_conversation(make_title("Screen: " + task), self.model)["id"]
            self.db.add_message(cid, "user", task)
        yield {"type": "start", "conversation_id": cid, "model": self.model, "autopilot": self.autopilot,
               "self_window": self.self_window.title if self.self_window else None}
        try:
            if self.autopilot and self.minimize_self and self.self_window:
                self.desktop.minimize(self.self_window.handle)
                minimized = True
                self.sleep(0.5)
            think_ok = True
            for step in range(1, MAX_STEPS + 1):
                if self.state.stop.is_set():
                    status = "stopped"
                    break
                img = await asyncio.to_thread(self.desktop.capture)
                fg = self.desktop.foreground()
                w, h = img.size
                model_img = scaled(img, MODEL_IMAGE_WIDTH)
                yield {"type": "screen", "step": step, "image": to_b64(scaled(img, THUMB_WIDTH), quality=70),
                       "window": fg.title if fg else ""}

                parts: list[str] = []
                opts = GenerationOptions(temperature=0.1, num_ctx=8192, max_tokens=400)
                try:
                    async for ev in self.backend.chat_stream(self.model, self._messages(task, to_b64(model_img), w, h, fg),
                                                             opts, "30m", think=False if think_ok else None):
                        if self.state.stop.is_set():
                            break
                        if ev.type == "token":
                            parts.append(ev.content)
                            yield {"type": "token", "step": step, "content": ev.content}
                except InferenceError as e:
                    if e.code == "think_unsupported" and think_ok:
                        think_ok = False
                        continue
                    raise
                if self.state.stop.is_set():
                    status = "stopped"
                    break

                text = "".join(parts)
                thought, calls = extract_tool_calls(text, ACTIONS.keys())
                if not calls:
                    bad += 1
                    self.history.append(StepRecord(step, "invalid", {}, False, "no valid action in reply"))
                    yield {"type": "notice", "message": "The model didn't give a valid action; asking again."}
                    if bad >= MAX_BAD_REPLIES:
                        status, summary = "failed", "The model kept replying without a valid action."
                        break
                    continue
                bad = 0
                call = calls[0]
                name, a = call.name, call.arguments
                if name in ("done", "fail"):
                    status = "done" if name == "done" else "failed"
                    summary = str(a.get("summary") or a.get("reason") or thought or "")
                    break

                mw, mh = model_img.size
                try:
                    px = self._resolve(name, a, w, h, mw, mh)
                except (ValueError, TypeError) as e:
                    self.history.append(StepRecord(step, name, a, False, f"invalid: {e}"))
                    yield {"type": "action_result", "step": step, "ok": False, "message": str(e)}
                    continue
                desc = describe(name, a, px)
                problem = self._check(name, a, px, fg)
                yield {"type": "action", "step": step, "name": name, "args": a, "description": desc,
                       "thought": thought, "decision": "deny" if problem else ("auto" if self.autopilot else "ask")}
                if problem:
                    self.history.append(StepRecord(step, name, a, False, problem))
                    yield {"type": "action_result", "step": step, "ok": False, "message": problem}
                    continue

                if not self.autopilot:
                    points = [(px[k], px[k.replace("x", "y")]) for k in ("x", "x1", "x2") if k in px]
                    pending = self.approvals.create({"conversation_id": cid, "step": step, "name": name})
                    yield {"type": "approval_required", "action_id": pending.id, "step": step, "name": name,
                           "preview": {"kind": "screen", "image": mark(img, points), "summary": desc,
                                       "window": fg.title if fg else ""}}
                    answer = await self.approvals.wait(pending, APPROVAL_TIMEOUT)
                    yield {"type": "approval_resolved", "action_id": pending.id, "step": step,
                           "approved": answer["approved"]}
                    if self.state.stop.is_set():
                        status = "stopped"
                        break
                    if not answer["approved"]:
                        note = answer.get("note") or ""
                        self.history.append(StepRecord(step, name, a, False, "user declined" + (f": {note}" if note else "")))
                        yield {"type": "action_result", "step": step, "ok": False, "message": "declined"}
                        continue

                if self._check_now():
                    status = "stopped"
                    break
                try:
                    result = await asyncio.to_thread(self._execute, name, a, px, fg)
                    ok = True
                except Exception as e:  # noqa: BLE001
                    result, ok = f"error: {e}", False
                self.history.append(StepRecord(step, name, a, ok, result))
                audit({"screen": name, "args": a, "px": px, "ok": ok, "autopilot": self.autopilot})
                if cid:
                    self.db.add_message(cid, "assistant", thought, self.model,
                                        tool_calls=[{"id": call.id, "name": name, "arguments": a}])
                    self.db.add_message(cid, "tool", f"{desc}: {result}", self.model, tool_name="screen",
                                        meta={"call_id": call.id, "ok": ok, "args": a})
                yield {"type": "action_result", "step": step, "ok": ok, "message": result}
                await asyncio.to_thread(self.sleep, self.settle)
            if self.state.stop.is_set() and status not in ("done", "failed"):
                status = "stopped"
        finally:
            self.state.stop.set()   # ends the watcher thread
            if minimized and self.self_window:
                try:
                    self.desktop.restore(self.self_window.handle)
                except Exception:  # noqa: BLE001
                    pass
        if status == "stopped":
            summary = self.state.reason or "Stopped"
        elif status == "max_steps":
            summary = f"Stopped after {MAX_STEPS} steps without finishing."
        if cid:
            self.db.add_message(cid, "assistant", f"[{status}] {summary}", self.model, {"done_reason": status})
        yield {"type": "done", "status": status, "summary": summary, "steps": len(self.history),
               "conversation_id": cid}
