"""
Ollama inference backend.

Ollama runs the open-weight model locally (llama.cpp under the hood, CUDA/ROCm when available,
CPU otherwise). UNISON talks to it only over localhost; nothing leaves the machine.
"""
from __future__ import annotations

import json
from typing import AsyncIterator, Optional

import httpx

from .base import (ChatMessage, GenerationOptions, GenerationStats, InferenceError, ModelInfo,
                   StreamEvent, ToolCall)


def _ns_to_ms(v) -> float:
    return round((v or 0) / 1e6, 1)


def stats_from_final(model: str, chunk: dict) -> GenerationStats:
    eval_count = chunk.get("eval_count") or 0
    eval_ns = chunk.get("eval_duration") or 0
    p_count = chunk.get("prompt_eval_count") or 0
    p_ns = chunk.get("prompt_eval_duration") or 0
    return GenerationStats(
        model=model,
        prompt_tokens=p_count,
        completion_tokens=eval_count,
        tokens_per_second=round(eval_count / (eval_ns / 1e9), 2) if eval_ns else 0.0,
        prompt_tokens_per_second=round(p_count / (p_ns / 1e9), 2) if p_ns else 0.0,
        load_ms=_ns_to_ms(chunk.get("load_duration")),
        total_ms=_ns_to_ms(chunk.get("total_duration")),
        done_reason=chunk.get("done_reason") or "stop",
    )


def build_ollama_options(o: GenerationOptions) -> dict:
    opts: dict = {}
    for src, dst in (("temperature", "temperature"), ("top_p", "top_p"), ("top_k", "top_k"),
                     ("repeat_penalty", "repeat_penalty"), ("num_ctx", "num_ctx"), ("seed", "seed"),
                     ("max_tokens", "num_predict"), ("stop", "stop")):
        v = getattr(o, src)
        if v is not None:
            opts[dst] = v
    return opts


class OllamaBackend:
    name = "ollama"

    def __init__(self, base_url: str = "http://127.0.0.1:11434", timeout: float = 600.0):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def _client(self, read_timeout: Optional[float] = None) -> httpx.AsyncClient:
        t = httpx.Timeout(connect=5.0, read=read_timeout or self.timeout, write=30.0, pool=5.0)
        return httpx.AsyncClient(base_url=self.base_url, timeout=t)

    def _unreachable(self, exc: Exception) -> InferenceError:
        return InferenceError(
            f"Cannot reach Ollama at {self.base_url}. Is it running? Start the Ollama app or run "
            f"'ollama serve'. ({type(exc).__name__})", 503, "engine_offline")

    async def health(self) -> dict:
        try:
            async with self._client(5.0) as c:
                r = await c.get("/api/version")
                r.raise_for_status()
                return {"ok": True, "engine": "ollama", "version": r.json().get("version"), "url": self.base_url}
        except Exception as exc:  # noqa: BLE001 - report any failure as offline
            return {"ok": False, "engine": "ollama", "error": str(self._unreachable(exc)), "url": self.base_url}

    async def list_models(self) -> list[ModelInfo]:
        try:
            async with self._client(15.0) as c:
                r = await c.get("/api/tags")
                r.raise_for_status()
        except httpx.HTTPError as exc:
            raise self._unreachable(exc) from exc
        out = []
        for m in r.json().get("models", []):
            d = m.get("details") or {}
            out.append(ModelInfo(
                name=m.get("name") or m.get("model", ""),
                size_bytes=m.get("size") or 0,
                family=d.get("family", ""),
                parameter_size=d.get("parameter_size", ""),
                quantization=d.get("quantization_level", ""),
                modified_at=m.get("modified_at", ""),
                details=d,
            ))
        return out

    async def loaded_models(self) -> list[dict]:
        """Models currently in memory, with how much of each sits in VRAM (real numbers from Ollama)."""
        try:
            async with self._client(5.0) as c:
                r = await c.get("/api/ps")
                r.raise_for_status()
        except httpx.HTTPError:
            return []
        out = []
        for m in r.json().get("models", []):
            size = m.get("size") or 0
            vram = m.get("size_vram") or 0
            out.append({
                "name": m.get("name"),
                "size_bytes": size,
                "vram_bytes": vram,
                "gpu_percent": round(100 * vram / size, 1) if size else 0.0,
                "context_length": m.get("context_length"),
                "expires_at": m.get("expires_at"),
            })
        return out

    async def chat_stream(self, model: str, messages: list[ChatMessage], options: GenerationOptions,
                          keep_alive: Optional[str] = None,
                          tools: Optional[list[dict]] = None,
                          think: Optional[bool] = None) -> AsyncIterator[StreamEvent]:
        payload = {
            "model": model,
            "messages": [m.to_dict() for m in messages],
            "stream": True,
            "options": build_ollama_options(options),
        }
        if keep_alive:
            payload["keep_alive"] = keep_alive
        if tools:
            payload["tools"] = tools
        if think is not None:
            payload["think"] = think
        try:
            async with self._client() as c:
                async with c.stream("POST", "/api/chat", json=payload) as resp:
                    if resp.status_code != 200:
                        body = (await resp.aread()).decode("utf-8", "replace")
                        try:
                            msg = json.loads(body).get("error", body)
                        except json.JSONDecodeError:
                            msg = body
                        if think is not None and "think" in str(msg).lower() and resp.status_code == 400:
                            raise InferenceError(f"{model} rejected the think option: {msg}", 400, "think_unsupported")
                        if "does not support tools" in str(msg):
                            raise InferenceError(f"Model '{model}' does not support native tool calling",
                                                 400, "tools_unsupported")
                        if resp.status_code == 404:
                            raise InferenceError(
                                f"Model '{model}' is not installed in Ollama. Download it from the model "
                                f"menu or run: ollama pull {model}", 404, "model_not_found")
                        raise InferenceError(f"Ollama error {resp.status_code}: {msg}", 502, "engine_error")
                    async for line in resp.aiter_lines():
                        if not line.strip():
                            continue
                        chunk = json.loads(line)
                        if chunk.get("error"):
                            raise InferenceError(f"Ollama: {chunk['error']}", 502, "engine_error")
                        msg = chunk.get("message") or {}
                        if msg.get("thinking"):
                            yield StreamEvent("thinking", msg["thinking"])
                        if msg.get("content"):
                            yield StreamEvent("token", msg["content"])
                        if msg.get("tool_calls"):
                            calls = []
                            for i, tc in enumerate(msg["tool_calls"]):
                                fn = tc.get("function") or {}
                                args = fn.get("arguments") or {}
                                if isinstance(args, str):
                                    try:
                                        args = json.loads(args)
                                    except json.JSONDecodeError:
                                        args = {"_raw": args}
                                calls.append(ToolCall(fn.get("name", ""), args, tc.get("id") or f"call_{i}"))
                            yield StreamEvent("tool_calls", tool_calls=calls)
                        if chunk.get("done"):
                            yield StreamEvent("done", stats=stats_from_final(model, chunk))
                            return
        except httpx.HTTPError as exc:
            raise self._unreachable(exc) from exc

    async def embed(self, model: str, texts: list[str]) -> list[list[float]]:
        """Local embeddings (e.g. nomic-embed-text). Batches to keep requests small."""
        out: list[list[float]] = []
        try:
            async with self._client(300.0) as c:
                for i in range(0, len(texts), 32):
                    r = await c.post("/api/embed", json={"model": model, "input": texts[i:i + 32]})
                    if r.status_code == 404:
                        raise InferenceError(
                            f"Embedding model '{model}' is not installed. Run: ollama pull {model}",
                            404, "model_not_found")
                    r.raise_for_status()
                    out.extend(r.json()["embeddings"])
        except httpx.HTTPError as exc:
            raise self._unreachable(exc) from exc
        return out

    async def pull(self, model: str) -> AsyncIterator[dict]:
        try:
            async with self._client(3600.0) as c:
                async with c.stream("POST", "/api/pull", json={"model": model, "stream": True}) as resp:
                    if resp.status_code != 200:
                        body = (await resp.aread()).decode("utf-8", "replace")
                        raise InferenceError(f"Pull failed ({resp.status_code}): {body}", 502, "pull_failed")
                    async for line in resp.aiter_lines():
                        if line.strip():
                            data = json.loads(line)
                            if data.get("error"):
                                raise InferenceError(f"Pull failed: {data['error']}", 502, "pull_failed")
                            yield data
        except httpx.HTTPError as exc:
            raise self._unreachable(exc) from exc

    async def delete(self, model: str) -> None:
        try:
            async with self._client(30.0) as c:
                r = await c.request("DELETE", "/api/delete", json={"model": model})
                if r.status_code == 404:
                    raise InferenceError(f"Model '{model}' not found", 404, "model_not_found")
                r.raise_for_status()
        except httpx.HTTPError as exc:
            raise self._unreachable(exc) from exc
