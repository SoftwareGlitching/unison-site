"""Sign-in: set a password, log in for a session token, change it, sign out everywhere."""
from __future__ import annotations

import threading
import time
from collections import defaultdict, deque

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from ..security import sessions
from ..security.auth import authenticate, client_ip, is_remote, is_truly_local, local_only

router = APIRouter(prefix="/v1/auth", tags=["sign-in"])

WINDOW = 15 * 60            # seconds
MAX_FAILS_PER_IP = 8        # wrong passwords per address per window
MAX_FAILS_REMOTE = 40       # wrong passwords from all remote addresses per window (stops spraying)


class PasswordBody(BaseModel):
    password: str = Field(..., min_length=1, max_length=256)


class FailedLogins:
    def __init__(self) -> None:
        self.by_ip: dict[str, deque] = defaultdict(deque)
        self.remote: deque = deque()
        self.lock = threading.Lock()

    @staticmethod
    def _trim(q: deque, now: float) -> None:
        while q and now - q[0] > WINDOW:
            q.popleft()

    def blocked(self, ip: str, remote: bool) -> float:
        """Seconds until this address may try again (0 = allowed)."""
        now = time.time()
        with self.lock:
            q = self.by_ip[ip]
            self._trim(q, now)
            self._trim(self.remote, now)
            if len(q) >= MAX_FAILS_PER_IP:
                return WINDOW - (now - q[0])
            if remote and len(self.remote) >= MAX_FAILS_REMOTE:
                return WINDOW - (now - self.remote[0])
        return 0.0

    def fail(self, ip: str, remote: bool) -> None:
        now = time.time()
        with self.lock:
            self.by_ip[ip].append(now)
            if remote:
                self.remote.append(now)

    def success(self, ip: str) -> None:
        with self.lock:
            self.by_ip.pop(ip, None)


failed = FailedLogins()


@router.get("/status")
async def status(request: Request):
    return {"password_set": sessions.password_set(), "remote": is_remote(request),
            "can_set_here": is_truly_local(request)}


@router.post("/setup")
async def setup(body: PasswordBody, request: Request):
    """Create the first password, or replace it — only by someone sitting at the PC."""
    if not is_truly_local(request):
        raise HTTPException(403, {"code": "local_only",
                                  "message": "The password can only be set on the PC that runs UNISON."})
    try:
        sessions.set_password(body.password)
    except ValueError as e:
        raise HTTPException(400, {"code": "weak_password", "message": str(e)})
    return {"ok": True, "token": sessions.issue_token()}


@router.post("/login")
async def login(body: PasswordBody, request: Request):
    ip, remote = client_ip(request), is_remote(request)
    wait = failed.blocked(ip, remote)
    if wait > 0:
        raise HTTPException(429, {"code": "locked_out",
                                  "message": f"Too many wrong passwords. Try again in {int(wait // 60) + 1} min."})
    if not sessions.password_set():
        raise HTTPException(409, {"code": "no_password", "message": "No password is set yet. Set one on the PC first."})
    if not sessions.verify_password(body.password):
        failed.fail(ip, remote)
        raise HTTPException(401, {"code": "wrong_password", "message": "Wrong password."})
    failed.success(ip)
    return {"ok": True, "token": sessions.issue_token()}


@router.post("/change", dependencies=[Depends(authenticate)])
async def change(body: PasswordBody, request: Request):
    # The middleware already required a valid session; changing from another device is allowed
    # because you proved you know the current password when you signed in there.
    if not sessions.password_set() and not is_truly_local(request):
        raise HTTPException(403, {"code": "local_only", "message": "Set the first password on the PC."})
    try:
        sessions.set_password(body.password)   # also signs out other devices
    except ValueError as e:
        raise HTTPException(400, {"code": "weak_password", "message": str(e)})
    return {"ok": True, "token": sessions.issue_token()}


@router.post("/logout_all", dependencies=[Depends(local_only)])
async def logout_all():
    sessions.rotate_secret()
    return {"ok": True}
