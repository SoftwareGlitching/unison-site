"""read_book reads PDF/EPUB/DOCX/TXT in parts and finds passages; books can be added to the library."""
import unittest
import zipfile
from pathlib import Path

from tests.helpers import IsolatedSettings  # noqa: I001
from backend.tools import books
from backend.tools.base import ToolError


def make_docx(path: Path, paras: list[str]):
    ns = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"'
    body = "".join(f"<w:p><w:r><w:t>{p}</w:t></w:r></w:p>" for p in paras)
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("word/document.xml", f'<?xml version="1.0"?><w:document {ns}><w:body>{body}</w:body></w:document>')


def make_epub(path: Path, chapters: list[str]):
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("mimetype", "application/epub+zip")
        z.writestr("META-INF/container.xml", '<?xml version="1.0"?><container xmlns="urn:oasis:names:tc:opendocument:xmlns:container">'
                   '<rootfiles><rootfile full-path="OEBPS/content.opf"/></rootfiles></container>')
        items = "".join(f'<item id="c{n}" href="c{n}.xhtml"/>' for n in range(len(chapters)))
        spine = "".join(f'<itemref idref="c{n}"/>' for n in range(len(chapters)))
        z.writestr("OEBPS/content.opf", f'<package xmlns="http://www.idpf.org/2007/opf"><manifest>{items}</manifest><spine>{spine}</spine></package>')
        for n, text in enumerate(chapters):
            z.writestr(f"OEBPS/c{n}.xhtml", f"<html><body><h1>Chapter</h1><p>{text}</p></body></html>")


class BookTests(unittest.TestCase):
    def test_txt_parts_and_continue(self):
        with IsolatedSettings() as s:
            p = s.workspace / "long.txt"
            p.write_text("\n\n".join(f"Paragraph {n}. " + "word " * 150 for n in range(60)))
            r = books.read_book({"path": "long.txt"})
            self.assertIn("Part 1", r.output)
            self.assertIn("start=", r.output)
            nxt = r.data["next"]
            r2 = books.read_book({"path": "long.txt", "start": nxt})
            self.assertIn(f"Part {nxt}", r2.output)

    def test_docx_and_query(self):
        with IsolatedSettings() as s:
            make_docx(s.workspace / "notes.docx", ["Intro text", "The dragon sleeps under the mountain.", "The end"])
            r = books.read_book({"path": "notes.docx", "query": "dragon"})
            self.assertIn("dragon sleeps", r.output)

    def test_epub_chapters_in_spine_order(self):
        with IsolatedSettings() as s:
            make_epub(s.workspace / "b.epub", ["It was a dark and stormy night " * 3, "Morning came at last " * 3])
            r = books.read_book({"path": "b.epub"})
            self.assertLess(r.output.index("stormy"), r.output.index("Morning"))
            self.assertIn("Chapter 2", r.output)

    def test_pdf_pages(self):
        try:
            from reportlab.pdfgen import canvas
        except ImportError:
            self.skipTest("reportlab not installed")
        with IsolatedSettings() as s:
            p = s.workspace / "b.pdf"
            c = canvas.Canvas(str(p))
            for n in range(3):
                c.drawString(72, 720, f"This is page {n + 1} about spaceships")
                c.showPage()
            c.save()
            r = books.read_book({"path": "b.pdf", "start": 2, "count": 1})
            self.assertIn("Page 2", r.output)
            self.assertIn("page 2 about spaceships", r.output)
            self.assertNotIn("Page 3", r.output.split("(Read")[0])

    def test_unsupported_and_outside(self):
        with IsolatedSettings() as s:
            (s.workspace / "x.exe").write_bytes(b"MZ")
            with self.assertRaises(ToolError):
                books.read_book({"path": "x.exe"})
            with self.assertRaises(ToolError):
                books.read_book({"path": str(s.outside / "y.txt")})


if __name__ == "__main__":
    unittest.main()
