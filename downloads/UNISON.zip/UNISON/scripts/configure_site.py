"""
Build the public website (+ the download zip) into a folder you publish as the public site repo.

  python scripts/configure_site.py --repo SoftwareGlitching/unison-site --out _site [--zip] [--purchase-url URL]
                                   [--google-verify CODE]

- Fills in the site address, download link and buy link in site/index.html.
- Writes robots.txt + sitemap.xml (Google), version.json (the app's update check) and .nojekyll.
- With --zip, also builds downloads/UNISON.zip from this folder WITHOUT the owner tools, your settings,
  chats, password, logs, .venv or node_modules.
"""
from __future__ import annotations

import argparse
import datetime
import html
import re
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PLACEHOLDER_URL = "https://YOUR_GITHUB_USERNAME.github.io/unison/"
PLACEHOLDER_DOWNLOAD = "YOUR_DOWNLOAD_URL"
PLACEHOLDER_PURCHASE = "YOUR_PURCHASE_URL"
ZIP_EXCLUDE_DIRS = {".git", ".github", ".venv", "node_modules", "dist", "__pycache__", "site", "_site", "out", "wrap",
                    "backups", "UNISON-owner", "owner-tools"}
ZIP_EXCLUDE_FILES = {"scripts/license_admin.py", "License-Admin.bat", "tests/test_license.py", ".env",
                     "config/unison.json", "config/hardware.json", "config/models.json", "config/mcp.json",
                     "docs/HARDWARE_REPORT.md", "docs/SELFTEST.md", ".setup-complete"}
VERIFY_MARK = "<!-- google-site-verification -->"


def site_url(repo: str) -> str:
    owner, name = repo.split("/", 1)
    owner_l = owner.lower()
    if name.lower() == f"{owner_l}.github.io":
        return f"https://{owner_l}.github.io/"
    return f"https://{owner_l}.github.io/{name}/"


def build_zip(dest: Path, root: Path = ROOT) -> int:
    """Zip the app for download (inside a top-level UNISON folder). Returns the number of files."""
    import os
    import zipfile
    n = 0
    dest.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
        for dirpath, dirnames, filenames in os.walk(root):
            rel_dir = Path(dirpath).relative_to(root)
            dirnames[:] = [d for d in dirnames if d not in ZIP_EXCLUDE_DIRS]
            for f in filenames:
                rel = (rel_dir / f).as_posix()
                if rel in ZIP_EXCLUDE_FILES or f.endswith((".pyc", ".db", ".db-wal", ".db-shm", ".log", ".pem")):
                    continue
                if rel.startswith(("data/backups", "datasets/training", "knowledge/user", "datasets/eval/results")):
                    continue
                z.write(Path(dirpath) / f, f"UNISON/{rel}")
                n += 1
    return n


def build(repo: str, out: Path, google_verify: str = "", src: Path = ROOT / "site", purchase_url: str = "",
          with_zip: bool = False, version: str = "") -> dict:
    if not re.fullmatch(r"[A-Za-z0-9-]+/[A-Za-z0-9._-]+", repo):
        raise ValueError(f"repo must look like owner/name, got {repo!r}")
    url = site_url(repo)
    download = url + "downloads/UNISON.zip"
    if out.exists():
        shutil.rmtree(out)
    shutil.copytree(src, out)

    index = out / "index.html"
    text = index.read_text(encoding="utf-8")
    text = text.replace(PLACEHOLDER_URL, url).replace(PLACEHOLDER_DOWNLOAD, download)
    if purchase_url:
        if not re.match(r"^https://[^\s\"'<>]+$", purchase_url):
            raise ValueError("purchase url must be an https:// link")
        text = text.replace(PLACEHOLDER_PURCHASE, purchase_url)
    if google_verify:
        code = html.escape(google_verify.strip(), quote=True)
        text = text.replace(VERIFY_MARK, f'<meta name="google-site-verification" content="{code}" />')
    index.write_text(text, encoding="utf-8")

    today = datetime.date.today().isoformat()
    (out / "robots.txt").write_text(f"User-agent: *\nAllow: /\n\nSitemap: {url}sitemap.xml\n", encoding="utf-8")
    (out / "sitemap.xml").write_text(
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
        f"  <url><loc>{url}</loc><lastmod>{today}</lastmod><changefreq>weekly</changefreq><priority>1.0</priority></url>\n"
        "</urlset>\n", encoding="utf-8")
    (out / ".nojekyll").write_text("", encoding="utf-8")
    if not version:
        version = (ROOT / "backend" / "__init__.py").read_text().split('"')[1]
    import json
    (out / "version.json").write_text(json.dumps({"version": version, "download": download}), encoding="utf-8")
    files = build_zip(out / "downloads" / "UNISON.zip") if with_zip else 0
    return {"url": url, "repo": repo, "out": str(out), "verified": bool(google_verify), "version": version,
            "download": download, "zip_files": files}


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True, help="the PUBLIC site repo, e.g. SoftwareGlitching/unison-site")
    ap.add_argument("--out", default="_site")
    ap.add_argument("--google-verify", default="", help="content= value of Google's HTML-tag verification")
    ap.add_argument("--purchase-url", default="", help="where people buy a key (Gumroad, Lemon Squeezy, Stripe link...)")
    ap.add_argument("--zip", action="store_true", help="also build downloads/UNISON.zip")
    a = ap.parse_args()
    print(build(a.repo, Path(a.out), a.google_verify, purchase_url=a.purchase_url, with_zip=a.zip))
