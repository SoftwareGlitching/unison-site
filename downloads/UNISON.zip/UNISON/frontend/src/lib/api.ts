// Thin client for the UNISON API. Same origin in production; proxied by Vite in dev.

export interface Conversation {
  id: string;
  title: string;
  model: string | null;
  created_at: number;
  updated_at: number;
}

export interface Stats {
  model?: string;
  prompt_tokens?: number;
  completion_tokens?: number;
  tokens_per_second?: number;
  load_ms?: number;
  total_ms?: number;
  done_reason?: string;
  wall_ms?: number;
}

export interface StoredMessage {
  id: string;
  role: "user" | "assistant" | "system" | "tool";
  content: string;
  model: string | null;
  stats: Stats | null;
  created_at: number;
  tool_calls: { id: string; name: string; arguments: Record<string, unknown> }[] | null;
  tool_name: string | null;
  meta: { call_id?: string; ok?: boolean; args?: Record<string, unknown>; diff?: string | null; data?: any } | null;
}

export interface Feedback {
  message_id: string;
  rating: number;
  correction: string | null;
}

export interface ToolInfo {
  name: string;
  description: string;
  risk: string;
  source: string;
  default_mode: string;
  mode: string;
}

export interface KnowledgeStatus {
  embedding_model: string;
  embedding_ready: boolean;
  problem: string | null;
  sources: number;
  chunks: number;
  collections: { collection: string; kind: string; files: number; chunks: number; updated_at: number }[];
  auto_retrieve: boolean;
}

export interface MCPServerInfo {
  name: string;
  status: string;
  error: string;
  command: string;
  args: string[];
  tools: string[];
  enabled: boolean;
  stderr_tail?: string[];
}

export interface JobSummary {
  id: string;
  kind: "agent" | "screen";
  task: string;
  model: string | null;
  autonomous: boolean;
  status: "queued" | "running" | "waiting_approval" | "done" | "failed" | "stopped" | "interrupted";
  summary: string | null;
  conversation_id: string | null;
  pending_action: string | null;
  steps: number;
  created_at: number;
  started_at: number | null;
  finished_at: number | null;
}

export interface EvalSummary {
  file: string;
  model: string;
  knowledge: boolean;
  created: string;
  score: number;
  passed: number;
  total: number;
  categories: Record<string, { passed: number; total: number }>;
}

export interface InstalledModel {
  id: string;
  unison: {
    family: string;
    parameter_size: string;
    quantization: string;
    size_bytes: number;
    tier: string | null;
    active: boolean;
  };
}

export interface TierModel {
  tier: string;
  tag: string;
  params: string;
  size_gb: number;
  license: string;
  placement: "gpu" | "hybrid" | "cpu";
  reason: string;
  notes: string;
  installed: boolean;
  default: boolean;
}

export interface Metrics {
  system: {
    cpu_percent: number;
    ram_used_gb: number;
    ram_total_gb: number;
    ram_percent: number;
    gpus: { name: string; utilization_percent: number | null; vram_used_mb: number | null; vram_total_mb: number | null }[];
  };
  inference: {
    active_model: string;
    engine: string;
    state: "idle" | "generating";
    last: Stats | null;
    avg_tokens_per_second: number | null;
  };
  loaded_models: { name: string; gpu_percent: number; size_bytes: number; vram_bytes: number }[];
}

export interface Health {
  status: "ok" | "degraded";
  engine: { ok: boolean; version?: string; error?: string };
  active_model: string | null;
  active_model_installed: boolean | null;
}

export interface InferenceSettings {
  temperature: number;
  top_p: number;
  top_k: number;
  repeat_penalty: number;
  num_ctx: number;
}

export class ApiError extends Error {
  constructor(message: string, public code = "error", public status = 0) {
    super(message);
  }
}

// ---- session token (set after sign-in; sent on every request) ----
const TOKEN_KEY = "unison_token";
let token: string | null = (() => {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
})();

export function setToken(t: string | null) {
  token = t;
  try {
    if (t) localStorage.setItem(TOKEN_KEY, t);
    else localStorage.removeItem(TOKEN_KEY);
  } catch {
    /* private mode: keep it in memory only */
  }
}

/** Called when any request comes back 401 auth_required, so the app can show the sign-in screen. */
let onAuthLost: () => void = () => {};
export function setAuthLostHandler(fn: () => void) {
  onAuthLost = fn;
}

function authHeaders(extra?: HeadersInit): HeadersInit {
  return { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(extra ?? {}) };
}

async function parseError(r: Response): Promise<ApiError> {
  try {
    const body = await r.json();
    const e = body.error ?? body.detail ?? body;
    return new ApiError(e.message ?? JSON.stringify(e), e.code ?? "error", r.status);
  } catch {
    return new ApiError(`${r.status} ${r.statusText}`, "http_error", r.status);
  }
}

async function json<T>(path: string, init?: RequestInit): Promise<T> {
  const r = await fetch(path, { ...init, headers: authHeaders(init?.headers) });
  if (!r.ok) {
    const err = await parseError(r);
    if (r.status === 401 && err.code === "auth_required") onAuthLost();
    if (r.status === 402) onLicenseLost();
    throw err;
  }
  return r.json() as Promise<T>;
}

export interface LicenseStatus {
  activated: boolean;
  machine_id: string;
  authority: boolean;
  to?: string;
  plan?: string;
  expires?: number | null;
  locked_to_this_pc?: boolean;
  problem?: string;
  purchase_url: string;
}

export const license = {
  status: () => json<LicenseStatus>("/v1/license/status"),
  activate: (key: string) => json<LicenseStatus>("/v1/license/activate", { method: "POST", body: JSON.stringify({ key }) }),
  deactivate: () => json<LicenseStatus>("/v1/license/deactivate", { method: "POST" }),
};

/** Called when any request comes back 402 license_required. */
let onLicenseLost: () => void = () => {};
export function setLicenseLostHandler(fn: () => void) {
  onLicenseLost = fn;
}

export const auth = {
  status: () => json<{ password_set: boolean; remote: boolean; can_set_here: boolean }>("/v1/auth/status"),
  setup: (password: string) =>
    json<{ token: string }>("/v1/auth/setup", { method: "POST", body: JSON.stringify({ password }) }).then((r) => {
      setToken(r.token);
      return r;
    }),
  login: (password: string) =>
    json<{ token: string }>("/v1/auth/login", { method: "POST", body: JSON.stringify({ password }) }).then((r) => {
      setToken(r.token);
      return r;
    }),
  change: (password: string) =>
    json<{ token: string }>("/v1/auth/change", { method: "POST", body: JSON.stringify({ password }) }).then((r) => {
      setToken(r.token);
      return r;
    }),
  logout: () => setToken(null),
};

export const api = {
  health: () => json<Health>("/v1/health"),
  metrics: () => json<Metrics>("/v1/system/metrics"),
  conversations: (search = "") =>
    json<{ data: Conversation[] }>(`/v1/conversations?search=${encodeURIComponent(search)}`).then((r) => r.data),
  conversation: (id: string) =>
    json<Conversation & { messages: StoredMessage[]; feedback: Record<string, Feedback> }>(`/v1/conversations/${id}`),
  rename: (id: string, title: string) =>
    json<Conversation>(`/v1/conversations/${id}`, { method: "PATCH", body: JSON.stringify({ title }) }),
  remove: (id: string) => json(`/v1/conversations/${id}`, { method: "DELETE" }),
  models: () => json<{ active_model: string; data: InstalledModel[] }>("/v1/models"),
  recommended: () => json<{ tiers: TierModel[]; warnings: string[] }>("/v1/models/recommended"),
  setModel: (model: string) => json("/v1/models/active", { method: "POST", body: JSON.stringify({ model }) }),
  settings: () => json<InferenceSettings>("/v1/settings/inference"),
  saveSettings: (s: Partial<InferenceSettings>) =>
    json<InferenceSettings>("/v1/settings/inference", { method: "PATCH", body: JSON.stringify(s) }),

  // agent & tools
  agentSettings: () => json<{ agent_default: boolean; auto_retrieve: boolean }>("/v1/agent/settings"),
  saveAgentSettings: (s: { agent_default?: boolean; auto_retrieve?: boolean }) =>
    json<{ agent_default: boolean; auto_retrieve: boolean }>("/v1/agent/settings", { method: "PATCH", body: JSON.stringify(s) }),
  approve: (actionId: string, approve: boolean, note = "") =>
    json(`/v1/approvals/${actionId}`, { method: "POST", body: JSON.stringify({ approve, note }) }),
  tools: () => json<{ data: ToolInfo[] }>("/v1/tools").then((r) => r.data),
  setToolMode: (name: string, mode: string) =>
    json<ToolInfo>(`/v1/tools/${encodeURIComponent(name)}`, { method: "PATCH", body: JSON.stringify({ mode }) }),
  workspaces: () => json<{ data: string[]; default: string; suggestions: { desktop: string | null } }>("/v1/workspaces"),
  addWorkspace: (path: string) => json("/v1/workspaces", { method: "POST", body: JSON.stringify({ path }) }),
  removeWorkspace: (path: string) => json("/v1/workspaces/remove", { method: "POST", body: JSON.stringify({ path }) }),
  defaultWorkspace: (path: string) => json("/v1/workspaces/default", { method: "POST", body: JSON.stringify({ path }) }),
  backups: () => json<{ data: { id: string; original: string; reason: string; at: number }[] }>("/v1/backups").then((r) => r.data),
  restoreBackup: (id: string) => json(`/v1/backups/${id}/restore`, { method: "POST" }),

  // knowledge
  knowledge: () => json<KnowledgeStatus>("/v1/knowledge"),
  searchKnowledge: (query: string) =>
    json<{ data: { title: string; score: number; text: string; lines: number[] }[] }>("/v1/knowledge/search", {
      method: "POST", body: JSON.stringify({ query, k: 5 }) }).then((r) => r.data),
  addDocument: (name: string, content: string) =>
    json<{ saved: string; chunks: number; indexed: boolean; problem: string | null }>("/v1/knowledge/documents", {
      method: "POST", body: JSON.stringify({ name, content }) }),
  deleteCollection: (name: string) =>
    json(`/v1/knowledge/collections?name=${encodeURIComponent(name)}`, { method: "DELETE" }),

  // MCP
  mcpServers: () => json<{ data: MCPServerInfo[] }>("/v1/mcp/servers").then((r) => r.data),
  addMcpServer: (b: { name: string; command: string; args: string[]; enabled: boolean }) =>
    json<{ data: MCPServerInfo[] }>("/v1/mcp/servers", { method: "POST", body: JSON.stringify(b) }).then((r) => r.data),
  mcpAction: (name: string, action: "start" | "stop") =>
    json<{ data: MCPServerInfo[] }>(`/v1/mcp/servers/${encodeURIComponent(name)}/${action}`, { method: "POST" }).then((r) => r.data),
  deleteMcp: (name: string) =>
    json<{ data: MCPServerInfo[] }>(`/v1/mcp/servers/${encodeURIComponent(name)}`, { method: "DELETE" }).then((r) => r.data),

  // share / updates
  site: () => json<{ url: string; version: string; download: string; version_url: string }>("/v1/site"),

  // background jobs
  jobs: () => json<{ data: JobSummary[] }>("/v1/jobs").then((r) => r.data),
  job: (id: string) => json<JobSummary & { events: any[]; last_image: string | null }>(`/v1/jobs/${id}`),
  createJob: (b: { task: string; kind: "agent" | "screen"; autonomous: boolean }) =>
    json<JobSummary>("/v1/jobs", { method: "POST", body: JSON.stringify(b) }),
  stopJob: (id: string) => json(`/v1/jobs/${id}/stop`, { method: "POST" }),
  deleteJob: (id: string) => json(`/v1/jobs/${id}`, { method: "DELETE" }),
  autonomous: () => json<{ enabled: boolean }>("/v1/autonomous"),
  setAutonomous: (enabled: boolean) => json<{ enabled: boolean }>("/v1/autonomous", { method: "POST", body: JSON.stringify({ enabled }) }),

  // screen control
  computer: () =>
    json<{ supported: boolean; problem: string | null; vision_model: string; vision_model_installed: boolean;
      running: boolean; choices: string[]; installed_vision_models: string[] }>("/v1/computer"),
  setVisionModel: (model: string) => json("/v1/computer/model", { method: "POST", body: JSON.stringify({ model }) }),
  stopScreen: () => json("/v1/computer/stop", { method: "POST" }),

  // training
  feedback: (message_id: string, rating: 1 | -1, correction?: string) =>
    json("/v1/feedback", { method: "POST", body: JSON.stringify({ message_id, rating, correction: correction || null }) }),
  clearFeedback: (message_id: string) => json(`/v1/feedback/${message_id}`, { method: "DELETE" }),
  training: () =>
    json<{ feedback: { thumbs_up: number; thumbs_down: number; corrections: number; exports: string[] }; evaluations: EvalSummary[] }>("/v1/training"),
  exportTraining: () => json<{ files: Record<string, { path: string; examples: number }> }>("/v1/training/export", { method: "POST" }),
};

/** POST and read a text/event-stream response, calling onEvent for every `data:` payload. */
export async function streamSSE(
  path: string,
  body: unknown,
  onEvent: (data: any) => void,
  signal: AbortSignal,
): Promise<void> {
  const r = await fetch(path, {
    method: "POST",
    headers: authHeaders({ Accept: "text/event-stream" }),
    body: JSON.stringify(body),
    signal,
  });
  if (!r.ok || !r.body) {
    const err = await parseError(r);
    if (r.status === 401 && err.code === "auth_required") onAuthLost();
    if (r.status === 402) onLicenseLost();
    throw err;
  }
  const reader = r.body.getReader();
  const decoder = new TextDecoder();
  let buf = "";
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    let idx: number;
    while ((idx = buf.indexOf("\n\n")) >= 0) {
      const frame = buf.slice(0, idx);
      buf = buf.slice(idx + 2);
      for (const line of frame.split("\n")) {
        if (line.startsWith("data: ")) {
          const payload = line.slice(6);
          if (payload === "[DONE]") return;
          onEvent(JSON.parse(payload));
        }
      }
    }
  }
}

export function pullModel(tag: string, onProgress: (p: any) => void, signal: AbortSignal) {
  return streamSSE("/v1/models/pull", { model: tag }, onProgress, signal);
}

export function indexKnowledge(body: { target: "curated" | "workspace"; path?: string }, onProgress: (p: any) => void, signal: AbortSignal) {
  return streamSSE("/v1/knowledge/index", body, onProgress, signal);
}
