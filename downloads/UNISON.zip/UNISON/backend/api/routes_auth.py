"""Sign-in: set a password, log in for a session token, change it, sign out everywhere."""
from __future__ import annotations

import threading
import time
from collections import defaultdict, deque
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from ..security import sessions
from ..security.auth import (authenticate, client_ip, guests_enabled, is_remote, is_truly_local, local_only,
                             pc_only, revoked_keys)

router = APIRouter(prefix="/v1/auth", tags=["sign-in"])

WINDOW = 15 * 60            # seconds
MAX_FAILS_PER_IP = 8        # wrong passwords per address per window
MAX_FAILS_REMOTE = 40       # wrong passwords from all remote addresses per window (stops spraying)


class PasswordBody(BaseModel):
    password: str = Field(..., min_length=1, max_length=256)
    code: Optional[str] = Field(None, max_length=12, description="6-digit code from your authenticator app "
                                                                 "(needed from other devices once 2-step sign-in is on)")


class CodeBody(BaseModel):
    code: str = Field(..., min_length=6, max_length=12)


class FailedLogins:
    def __init__(self) -> None:
        self.by_ip: dict[str, deque] = defaultdict(deque)
        self.remote: deque = deque()
        self.lock = threading.Lock()

    @staticmethod
    def _trim(q: deque, now: float) -> None:
        while q and now - q[0] > WINDOW:
            q.popleft()

    def blocked(self, ip: str, remote: bool) -> float:
        """Seconds until this address may try again (0 = allowed)."""
        now = time.time()
        with self.lock:
            q = self.by_ip[ip]
            self._trim(q, now)
            self._trim(self.remote, now)
            if len(q) >= MAX_FAILS_PER_IP:
                return WINDOW - (now - q[0])
            if remote and len(self.remote) >= MAX_FAILS_REMOTE:
                return WINDOW - (now - self.remote[0])
        return 0.0

    def fail(self, ip: str, remote: bool) -> None:
        now = time.time()
        with self.lock:
            self.by_ip[ip].append(now)
            if remote:
                self.remote.append(now)

    def success(self, ip: str) -> None:
        with self.lock:
            self.by_ip.pop(ip, None)


failed = FailedLogins()


@router.get("/status")
async def status(request: Request):
    return {"password_set": sessions.password_set(), "remote": is_remote(request),
            "can_set_here": is_truly_local(request),
            "web_guests": guests_enabled() and sessions.password_set(),
            "two_factor": sessions.totp_enabled(),
            "code_required": sessions.totp_enabled() and is_remote(request)}


@router.post("/setup")
async def setup(body: PasswordBody, request: Request):
    """Create the first password, or replace it — only by someone sitting at the PC."""
    if not is_truly_local(request):
        raise HTTPException(403, {"code": "local_only",
                                  "message": "The password can only be set on the PC that runs UNISON."})
    try:
        sessions.set_password(body.password)
    except ValueError as e:
        raise HTTPException(400, {"code": "weak_password", "message": str(e)})
    return {"ok": True, "token": sessions.issue_token()}


@router.post("/login")
async def login(body: PasswordBody, request: Request):
    ip, remote = client_ip(request), is_remote(request)
    wait = failed.blocked(ip, remote)
    if wait > 0:
        raise HTTPException(429, {"code": "locked_out",
                                  "message": f"Too many wrong passwords. Try again in {int(wait // 60) + 1} min."})
    if not sessions.password_set():
        raise HTTPException(409, {"code": "no_password", "message": "No password is set yet. Set one on the PC first."})
    needs_code = remote and sessions.totp_enabled()
    pw_ok = sessions.verify_password(body.password)
    code_ok = (not needs_code) or (pw_ok and sessions.totp_check(body.code))
    if not (pw_ok and code_ok):
        failed.fail(ip, remote)
        if needs_code:   # one message for both, so a guesser can't tell whether the password was right
            raise HTTPException(401, {"code": "wrong_password_or_code", "message": "Wrong password or code."})
        raise HTTPException(401, {"code": "wrong_password", "message": "Wrong password."})
    failed.success(ip)
    return {"ok": True, "token": sessions.issue_token()}


# ---------------- 2-step sign-in (set up / turn off only at the PC) ----------------
@router.post("/2fa/begin", dependencies=[Depends(pc_only)])
async def two_factor_begin():
    return sessions.totp_begin()


@router.post("/2fa/confirm", dependencies=[Depends(pc_only)])
async def two_factor_confirm(body: CodeBody):
    if not sessions.totp_confirm(body.code):
        raise HTTPException(400, {"code": "wrong_code", "message": "That code didn't match. Check the time on your "
                                  "phone is automatic and try the newest code."})
    return {"ok": True, "two_factor": True}


@router.post("/2fa/disable", dependencies=[Depends(pc_only)])
async def two_factor_disable():
    sessions.totp_disable()
    return {"ok": True, "two_factor": False}


GUEST_HOURS = 12


class KeyBody(BaseModel):
    key: str = Field(..., min_length=10, max_length=2000)


@router.post("/key-login")
async def key_login(body: KeyBody, request: Request):
    """Website visitors sign in with a UNISON license key and get a short guest token that can ONLY chat with
    the active model (no files, tools, agent, screen, jobs, settings). Turn off with remote.web_guests=false."""
    from ..licensing import license as lic
    if not guests_enabled():
        raise HTTPException(403, {"code": "guests_off", "message": "This UNISON PC isn't accepting website guests."})
    if not sessions.password_set():
        raise HTTPException(403, {"code": "password_required",
                                  "message": "The owner hasn't set a sign-in password on this PC yet."})
    ip, remote = client_ip(request), is_remote(request)
    wait = failed.blocked(ip, remote)
    if wait > 0:
        raise HTTPException(429, {"code": "locked_out",
                                  "message": f"Too many invalid keys. Try again in {int(wait // 60) + 1} min."})
    try:
        data = lic.parse(body.key, any_pc=True)
    except lic.LicenseError as e:
        failed.fail(ip, remote)
        raise HTTPException(401, {"code": "invalid_key", "message": str(e)})
    if str(data.get("id")) in revoked_keys():
        failed.fail(ip, remote)
        raise HTTPException(401, {"code": "revoked_key", "message": "This key has been switched off by the owner."})
    failed.success(ip)
    exp = int(time.time()) + GUEST_HOURS * 3600
    if data.get("exp"):
        exp = min(exp, int(data["exp"]))
    return {"ok": True, "token": sessions.issue_guest_token(str(data["id"]), exp, str(data.get("plan") or "")),
            "expires": exp,
            "to": data.get("to"), "plan": data.get("plan")}


@router.post("/change", dependencies=[Depends(authenticate)])
async def change(body: PasswordBody, request: Request):
    # The middleware already required a valid session; changing from another device is allowed
    # because you proved you know the current password when you signed in there.
    if not sessions.password_set() and not is_truly_local(request):
        raise HTTPException(403, {"code": "local_only", "message": "Set the first password on the PC."})
    try:
        sessions.set_password(body.password)   # also signs out other devices
    except ValueError as e:
        raise HTTPException(400, {"code": "weak_password", "message": str(e)})
    return {"ok": True, "token": sessions.issue_token()}


@router.post("/logout_all", dependencies=[Depends(local_only)])
async def logout_all():
    sessions.rotate_secret()
    return {"ok": True}
