"""
RAM watcher: every minute, records how much memory UNISON's server, Ollama (the engine + the loaded brain) and
the app window (WebView2) use, plus the whole PC. Written to logs/memory.log (kept small) and shown at
GET /v1/system/memory, so a leak shows exactly which part is growing.
If UNISON's own server ever grows past SELF_LIMIT_MB it frees what it can (garbage collection).
"""
from __future__ import annotations

import asyncio
import gc
import json
import os
import time
from collections import deque
from typing import Optional

import psutil

from .config import LOG_DIR

INTERVAL = 30
SELF_LIMIT_MB = 1500
# Safety limits for the PC (see guard()):
LOW_RAM_MB = 1200          # less free RAM than this while UNISON is idle: unload the brain to give it back
HOT_GPU_C = 84             # GPU this hot: wait before starting the next reply...
COOL_GPU_C = 78            # ...until it's back under this (at most HOT_WAIT_S seconds)
HOT_WAIT_S = 45
LOG_MAX_BYTES = 512 * 1024
samples: deque[dict] = deque(maxlen=180)       # 3 hours of one-minute samples
_task: Optional[asyncio.Task] = None


def _mb(n: int) -> int:
    return round(n / 1048576)


def sample() -> dict:
    me = psutil.Process(os.getpid())
    groups = {"unison_server": 0, "ollama": 0, "app_window": 0}
    for p in psutil.process_iter(["name", "memory_info"]):
        try:
            name = (p.info["name"] or "").lower()
            rss = p.info["memory_info"].rss if p.info["memory_info"] else 0
        except (psutil.Error, AttributeError):
            continue
        if name.startswith("ollama"):
            groups["ollama"] += rss
        elif name.startswith("msedgewebview2") or name == "unison.exe":
            groups["app_window"] += rss
    try:
        groups["unison_server"] = me.memory_info().rss
    except psutil.Error:
        pass
    vm = psutil.virtual_memory()
    out = {"at": time.strftime("%Y-%m-%dT%H:%M:%S"), **{k: _mb(v) for k, v in groups.items()},
           "pc_used_mb": _mb(vm.total - vm.available), "pc_total_mb": _mb(vm.total), "pc_percent": vm.percent,
           "pc_free_mb": _mb(vm.available)}
    try:
        from .system_metrics import gpu_metrics
        g = (gpu_metrics() or [{}])[0]
        out.update(gpu_temp_c=g.get("temperature_c"), gpu_percent=g.get("utilization_percent"),
                   vram_used_mb=g.get("vram_used_mb"))
    except Exception:  # noqa: BLE001
        pass
    return out


def gpu_temp() -> Optional[float]:
    try:
        from .system_metrics import gpu_metrics
        return (gpu_metrics() or [{}])[0].get("temperature_c")
    except Exception:  # noqa: BLE001
        return None


async def wait_if_hot() -> None:
    """Before a reply starts: if the GPU is very hot, give it up to HOT_WAIT_S seconds to cool down."""
    t = await asyncio.to_thread(gpu_temp)
    if t is None or t < HOT_GPU_C:
        return
    _write({"at": time.strftime("%Y-%m-%dT%H:%M:%S"), "note": f"GPU at {t:.0f}C - letting it cool before replying"})
    waited = 0
    while waited < HOT_WAIT_S:
        await asyncio.sleep(5)
        waited += 5
        t = await asyncio.to_thread(gpu_temp)
        if t is None or t < COOL_GPU_C:
            return


async def guard(s: dict) -> Optional[str]:
    """Be careful with the PC: when free RAM gets very low and UNISON is idle, unload the brain so Windows
    (and your games/apps) get the memory back. It loads again by itself on the next message."""
    try:
        from ..inference.manager import manager
    except Exception:  # noqa: BLE001
        return None
    if s.get("pc_free_mb", 1e9) < LOW_RAM_MB and manager.active_generations == 0 and s.get("ollama", 0) > 500:
        model = manager.active_model
        if model and hasattr(manager.backend, "unload"):
            try:
                await manager.backend.unload(model)
                manager.brain = {"model": None, "state": "idle", "since": time.time(), "error": ""}
                manager.resting = True     # don't preload it again until the next message
                return f"PC low on RAM ({s['pc_free_mb']} MB free) - unloaded the brain while idle"
            except Exception:  # noqa: BLE001
                return None
    return None


def _write(s: dict) -> None:
    path = LOG_DIR / "memory.log"
    try:
        if path.exists() and path.stat().st_size > LOG_MAX_BYTES:
            lines = path.read_text(encoding="utf-8").splitlines()[-1000:]
            path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(s) + "\n")
    except OSError:
        pass


def growth() -> dict:
    """MB each part grew over the samples we have (positive = growing)."""
    if len(samples) < 2:
        return {}
    a, b = samples[0], samples[-1]
    return {k: b[k] - a[k] for k in ("unison_server", "ollama", "app_window", "pc_used_mb")}


async def _loop() -> None:
    while True:
        try:
            s = await asyncio.to_thread(sample)
            if s["unison_server"] > SELF_LIMIT_MB:
                gc.collect()
                s["note"] = "server over limit - freed memory"
            note = await guard(s)
            if note:
                s["note"] = note
            samples.append(s)
            _write(s)
        except Exception:  # noqa: BLE001 - never let the watcher take the server down
            pass
        await asyncio.sleep(INTERVAL)


def start() -> None:
    global _task
    if _task is None or _task.done():
        _task = asyncio.get_running_loop().create_task(_loop())


async def stop() -> None:
    global _task
    if _task:
        _task.cancel()
        try:
            await _task
        except (asyncio.CancelledError, Exception):  # noqa: BLE001
            pass
        _task = None
