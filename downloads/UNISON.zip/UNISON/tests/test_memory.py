"""Long-term memory: explicit 'remember', name, hidden notes, forgetting, recalling past chats, prompt section."""
import tempfile
import unittest
from pathlib import Path

from tests.helpers import IsolatedSettings  # noqa: I001
from backend.core import memory
from backend.core.chat_service import wants_build
from backend.database.db import Database


class MemoryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self.tmp.name) / "t.db")
        self.iso = IsolatedSettings()
        self.iso.__enter__()

    def tearDown(self):
        self.iso.__exit__(None, None, None)
        self.tmp.cleanup()

    def texts(self):
        return [f["text"] for f in memory.facts(self.db)]

    def test_remember_name_and_call_me(self):
        saved, _ = memory.capture(self.db, "hey unison, remember that my roblox game is called Sky Wars. My name is Nick")
        self.assertTrue(any("Sky Wars" in t for t in self.texts()), self.texts())
        self.assertIn("The user's name is Nick", self.texts())
        memory.capture(self.db, "call me Nicko")
        self.assertIn("The user likes to be called Nicko", self.texts())
        self.assertTrue(saved)

    def test_request_for_the_feature_is_not_a_fact(self):
        memory.capture(self.db, "also allow it to remember our convos please")
        memory.capture(self.db, "do you remember when we made the shooter?")
        self.assertEqual(self.texts(), [])

    def test_duplicates_and_forget(self):
        memory.add(self.db, "Uses Blender 5.2 for 3D models")
        memory.add(self.db, "uses blender 5.2 for 3d models")
        self.assertEqual(len(self.texts()), 1)
        _, gone = memory.capture(self.db, "forget that blender thing")
        self.assertEqual(self.texts(), [])
        self.assertTrue(gone)

    def test_hidden_note_is_saved_and_removed(self):
        clean, saved = memory.take_notes(self.db, "Nice, a pixel shooter!\n[remember: Is making a pixel-art shooter in Python]")
        self.assertEqual(clean, "Nice, a pixel shooter!")
        self.assertEqual(saved, ["Is making a pixel-art shooter in Python"])

    def test_recall_finds_earlier_conversation(self):
        old = self.db.create_conversation("Python shooter game")["id"]
        self.db.add_message(old, "user", "make me a top down shooter in pygame with zombies")
        self.db.add_message(old, "assistant", "Built shooter.py with zombies, waves and a score counter.", "m")
        new = self.db.create_conversation("now")["id"]
        hits = memory.recall(self.db, "remember the zombie shooter we made last time?", new)
        self.assertTrue(hits and "zombie" in hits[0]["text"].lower(), hits)
        text = memory.section(self.db, "can you add a boss to the zombie shooter from last time", new)
        self.assertIn("Python shooter game", text)
        self.assertIn("From earlier conversations", text)

    def test_section_lists_facts_and_can_be_disabled(self):
        memory.add(self.db, "GitHub account is SoftwareGlitching")
        self.assertIn("SoftwareGlitching", memory.section(self.db, "hi"))
        from backend.core.config import settings
        settings.set("assistant", "memory", False)
        self.assertEqual(memory.section(self.db, "hi"), "")
        self.assertEqual(memory.capture(self.db, "remember that I like cats"), ([], []))


class BuildDetectionTests(unittest.TestCase):
    def test_build_requests(self):
        for t in ["make me a shopping website with a header and cart", "build a platformer game in html",
                  "can you write a python script that renames my photos", "create a landing page for my bakery"]:
            self.assertTrue(wants_build(t), t)

    def test_questions_and_chat(self):
        for t in ["how do I make a website?", "what is css", "hey whats up", "explain how to build a game loop",
                  "i made a website today!!"]:
            self.assertFalse(wants_build(t), t)


if __name__ == "__main__":
    unittest.main()
