"""
UNISON programming benchmark.

Runs datasets/eval/benchmark.jsonl against the local model and scores it automatically:
  python_tests / js_tests  - the code in the reply is executed against hidden tests (temp folder, timeout)
  patterns                 - required/forbidden API patterns (Luau, Blender: no runtime available here)
  json / bullet_count      - instruction following
  multi_turn               - context retention across turns
  agent                    - the full tool loop in a throwaway workspace (create, run, fix, explore)

Results go to datasets/eval/results/. Compare runs before and after any change (new model,
knowledge base on/off, fine-tuned adapter) - never trust a change you haven't measured.
"""
from __future__ import annotations

import asyncio
import json
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Callable, Optional

from ..agents.approvals import ApprovalBroker
from ..core.chat_service import ChatService
from ..core.config import ROOT, settings
from ..database.db import Database
from ..inference.manager import ModelManager
from ..tools.registry import ToolRegistry

BENCHMARK = ROOT / "datasets" / "eval" / "benchmark.jsonl"
RESULTS = ROOT / "datasets" / "eval" / "results"
CODE_BLOCK = re.compile(r"```([\w+#-]*)[^\n]*\n(.*?)```", re.S)


def load_tasks(path: Path = BENCHMARK) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def extract_code(text: str, langs: tuple[str, ...]) -> str:
    blocks = CODE_BLOCK.findall(text)
    for lang, body in blocks:
        if lang.lower() in langs:
            return body
    if blocks:
        return max((b for _, b in blocks), key=len)
    return text


def _run(cmd: list[str], cwd: Path, timeout: int = 20) -> tuple[bool, str]:
    try:
        p = subprocess.run(cmd, cwd=str(cwd), capture_output=True, text=True, timeout=timeout,
                           creationflags=0x08000000 if sys.platform == "win32" else 0)
        return p.returncode == 0, (p.stdout + p.stderr)[-1500:]
    except subprocess.TimeoutExpired:
        return False, f"timed out after {timeout}s"
    except FileNotFoundError as e:
        return False, f"runtime missing: {e}"


# ---------------------------------------------------------------- graders
def grade_python(reply: str, task: dict) -> tuple[bool, str]:
    code = extract_code(reply, ("python", "py", "python3"))
    with tempfile.TemporaryDirectory() as d:
        d = Path(d)
        (d / "solution.py").write_text(code, encoding="utf-8")
        (d / "check.py").write_text("from solution import *\n" + task["tests"] + "\nprint('ALL TESTS PASSED')\n",
                                    encoding="utf-8")
        ok, out = _run([sys.executable, "check.py"], d)
        return ok and "ALL TESTS PASSED" in out, out


def grade_js(reply: str, task: dict) -> tuple[bool, str]:
    node = shutil.which("node")
    if not node:
        return False, "node not installed"
    code = extract_code(reply, ("javascript", "js"))
    code = re.sub(r"^\s*export\s+(default\s+)?", "", code, flags=re.M)
    with tempfile.TemporaryDirectory() as d:
        d = Path(d)
        (d / "check.js").write_text("const assert = require('assert');\n" + code + "\n" + task["tests"] +
                                    "\nconsole.log('ALL TESTS PASSED');\n", encoding="utf-8")
        ok, out = _run([node, "check.js"], d)
        return ok and "ALL TESTS PASSED" in out, out


def grade_patterns(reply: str, task: dict) -> tuple[bool, str]:
    code = extract_code(reply, ("lua", "luau", "python", "py")) if "```" in reply else reply
    missing = [p for p in task.get("must", []) if not re.search(p, code, re.M)]
    present = [p for p in task.get("must_not", []) if re.search(p, code, re.M)]
    ok = not missing and not present
    return ok, ("ok" if ok else f"missing {missing} forbidden {present}")


def grade_json(reply: str, task: dict) -> tuple[bool, str]:
    raw = reply.strip()
    if raw.startswith("```"):
        return False, "wrapped in a code fence (asked for JSON only)"
    try:
        obj = json.loads(raw)
    except json.JSONDecodeError as e:
        return False, f"not valid JSON: {e}"
    types = {"str": str, "int": int, "list": list}
    for k, t in task.get("json_types", {}).items():
        if not isinstance(obj.get(k), types[t]) or (t == "int" and isinstance(obj.get(k), bool)):
            return False, f"{k} is not {t}"
    c = task.get("json_checks", {})
    if "name" in c and obj.get("name") != c["name"]:
        return False, "wrong name"
    if "level" in c and obj.get("level") != c["level"]:
        return False, "wrong level"
    if "spells_len" in c and len(obj.get("spells", [])) != c["spells_len"]:
        return False, "wrong number of spells"
    return True, "ok"


def grade_bullets(reply: str, task: dict) -> tuple[bool, str]:
    lines = [l for l in reply.strip().splitlines() if l.strip()]
    bullets = [l for l in lines if re.match(r"^\s*([-*•]|\d+[.)])\s+", l)]
    ok = len(bullets) == task["count"] and len(lines) == len(bullets)
    return ok, f"{len(bullets)} bullets, {len(lines)} lines"


def grade_must(reply: str, task: dict) -> tuple[bool, str]:
    missing = [p for p in task.get("must", []) if not re.search(p, reply)]
    return not missing, "ok" if not missing else f"missing {missing}"


GRADERS: dict[str, Callable[[str, dict], tuple[bool, str]]] = {
    "python_tests": grade_python, "js_tests": grade_js, "patterns": grade_patterns, "json": grade_json,
    "bullet_count": grade_bullets, "multi_turn": grade_must,
}


# ---------------------------------------------------------------- runner
class Evaluator:
    def __init__(self, manager: ModelManager, model: str, use_knowledge: bool, log: Callable[[str], None] = print):
        self.manager = manager
        self.model = model
        self.use_knowledge = use_knowledge
        self.log = log
        self.tmp = tempfile.TemporaryDirectory(prefix="unison-eval-")
        self.db = Database(Path(self.tmp.name) / "eval.db")

    def _service(self, approve_all: bool) -> tuple[ChatService, ApprovalBroker]:
        broker = ApprovalBroker()
        knowledge = None if self.use_knowledge else _NoKnowledge()
        return ChatService(self.db, self.manager, tools=ToolRegistry(), approvals=broker, knowledge=knowledge), broker

    async def _chat(self, svc: ChatService, broker: ApprovalBroker, prompt: str, cid: Optional[str], tools: bool):
        opts = self.manager.default_options(temperature=0.0, seed=42)
        events = []
        loop = asyncio.get_running_loop()
        async for ev in svc.run(conversation_id=cid, content=prompt, model=self.model, options=opts, tools=tools):
            events.append(ev)
            if ev["type"] == "approval_required":
                loop.call_later(0.01, broker.resolve, ev["action_id"], True, "")
        start = next(e for e in events if e["type"] == "start")
        saved = [e for e in events if e["type"] == "assistant_saved"]
        done = next((e for e in events if e["type"] == "done"), {})
        return start["conversation_id"], (saved[-1]["content"] if saved else ""), events, done.get("stats") or {}

    async def run_task(self, task: dict) -> dict:
        t0 = time.time()
        svc, broker = self._service(task["kind"] == "agent")
        result = {"id": task["id"], "category": task["category"], "kind": task["kind"]}
        try:
            if task["kind"] == "multi_turn":
                cid, reply = None, ""
                for turn in task["turns"]:
                    cid, reply, _, stats = await self._chat(svc, broker, turn, cid, False)
                ok, detail = grade_must(reply, task)
            elif task["kind"] == "agent":
                ok, detail, reply, stats = await self._agent(svc, broker, task)
            else:
                _, reply, _, stats = await self._chat(svc, broker, task["prompt"], None, False)
                ok, detail = GRADERS[task["kind"]](reply, task)
            result.update(passed=ok, detail=detail[:600], reply=reply[:4000],
                          tokens_per_second=stats.get("tokens_per_second"))
        except Exception as e:  # noqa: BLE001
            result.update(passed=False, detail=f"error: {type(e).__name__}: {e}", reply="")
        result["seconds"] = round(time.time() - t0, 1)
        return result

    async def _agent(self, svc, broker, task):
        ws = Path(tempfile.mkdtemp(prefix="unison-eval-ws-"))
        for rel, content in (task.get("setup") or {}).items():
            p = ws / rel
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content, encoding="utf-8")
        tools_cfg = settings.data.setdefault("tools", {})
        saved_ws, saved_perm = tools_cfg.get("workspaces"), tools_cfg.get("permissions")
        tools_cfg["workspaces"], tools_cfg["permissions"] = [str(ws)], {}   # in memory only, never saved
        try:
            _, reply, events, stats = await self._chat(svc, broker, task["prompt"], None, True)
        finally:
            tools_cfg["workspaces"], tools_cfg["permissions"] = saved_ws, saved_perm
        c = task["check"]
        problems = []
        used = [e["name"] for e in events if e["type"] == "tool_call"]
        outputs = "\n".join(e.get("output", "") for e in events if e["type"] == "tool_result")
        if "file" in c and not (ws / c["file"]).exists():
            problems.append(f"{c['file']} not created")
        if "file_contains" in c and (ws / c.get("file", "")).exists() and c["file_contains"] not in (ws / c["file"]).read_text():
            problems.append(f"{c['file']} lacks {c['file_contains']!r}")
        if "tool_used" in c and not any(re.fullmatch(c["tool_used"], u) for u in used):
            problems.append(f"never used {c['tool_used']}")
        if "tool_output_contains" in c and c["tool_output_contains"] not in outputs:
            problems.append(f"tool output never showed {c['tool_output_contains']!r}")
        if "file_unchanged" in c and (ws / c["file_unchanged"]).read_text() != task["setup"][c["file_unchanged"]]:
            problems.append(f"{c['file_unchanged']} was modified")
        if "command_passes" in c:
            ok, out = _run([sys.executable if part == "python" else part for part in c["command_passes"].split()], ws, 60)
            if not ok:
                problems.append("tests still fail: " + out[-300:])
        for pat in c.get("answer_must", []):
            if not re.search(pat, reply):
                problems.append(f"answer lacks {pat}")
        shutil.rmtree(ws, ignore_errors=True)
        detail = "ok" if not problems else "; ".join(problems)
        detail += f" | tools used: {', '.join(used) or 'none'}"
        return not problems, detail, reply, stats

    async def run(self, tasks: list[dict]) -> dict:
        rows = []
        for n, t in enumerate(tasks, 1):
            self.log(f"[{n}/{len(tasks)}] {t['id']} ...")
            r = await self.run_task(t)
            rows.append(r)
            self.log(f"        {'PASS' if r['passed'] else 'FAIL'}  ({r['seconds']}s) {'' if r['passed'] else r['detail'][:160]}")
        by_cat: dict[str, list[bool]] = {}
        for r in rows:
            by_cat.setdefault(r["category"], []).append(r["passed"])
        return {
            "model": self.model,
            "knowledge": self.use_knowledge,
            "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "score": round(100 * sum(r["passed"] for r in rows) / max(len(rows), 1), 1),
            "passed": sum(r["passed"] for r in rows),
            "total": len(rows),
            "categories": {k: {"passed": sum(v), "total": len(v)} for k, v in sorted(by_cat.items())},
            "tasks": rows,
        }

    def close(self):
        self.db._conn.close()
        self.tmp.cleanup()


class _NoKnowledge:
    def counts(self):
        return {"sources": 0, "chunks": 0}


def save_result(result: dict) -> Path:
    RESULTS.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r"[^A-Za-z0-9._-]", "_", result["model"])
    path = RESULTS / f"{time.strftime('%Y%m%d-%H%M%S')}_{safe}{'_rag' if result['knowledge'] else ''}.json"
    path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    return path


def list_results() -> list[dict]:
    if not RESULTS.exists():
        return []
    out = []
    for p in sorted(RESULTS.glob("*.json"), reverse=True):
        try:
            r = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        out.append({"file": p.name, "model": r["model"], "knowledge": r["knowledge"], "created": r["created"],
                    "score": r["score"], "passed": r["passed"], "total": r["total"], "categories": r["categories"]})
    return out


def previous_for(model: str, knowledge: bool, exclude: Optional[str] = None) -> Optional[dict]:
    for r in list_results():
        if r["model"] == model and r["knowledge"] == knowledge and r["file"] != exclude:
            return r
    return None
