import { useEffect, useRef, useState } from "react";
import { api, pullModel, type InstalledModel, type TierModel } from "../lib/api";

const sizeGB = (b: number) => `${(b / 1e9).toFixed(1)} GB`;

export function ModelMenu({ onChanged }: { onChanged: () => void }) {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("");
  const [installed, setInstalled] = useState<InstalledModel[]>([]);
  const [tiers, setTiers] = useState<TierModel[]>([]);
  const [error, setError] = useState("");
  const [pulling, setPulling] = useState<{ tag: string; status: string; pct: number | null } | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const boxRef = useRef<HTMLDivElement>(null);

  const load = async () => {
    try {
      const [m, r] = await Promise.all([api.models(), api.recommended()]);
      setActive(m.active_model);
      setInstalled(m.data);
      setTiers(r.tiers);
      setError("");
    } catch (e: any) {
      setError(e.message);
    }
  };

  useEffect(() => {
    load();
  }, []);

  useEffect(() => {
    const close = (e: MouseEvent) => {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  const choose = async (tag: string) => {
    try {
      await api.setModel(tag);
      setActive(tag);
      setOpen(false);
      onChanged();
    } catch (e: any) {
      setError(e.message);
    }
  };

  const download = async (tag: string) => {
    const ctl = new AbortController();
    abortRef.current = ctl;
    setPulling({ tag, status: "starting", pct: null });
    try {
      await pullModel(
        tag,
        (p) => {
          if (p.error) throw new Error(p.error.message);
          const pct = p.total && p.completed ? Math.round((100 * p.completed) / p.total) : null;
          setPulling({ tag, status: p.status ?? "", pct });
        },
        ctl.signal,
      );
      await load();
    } catch (e: any) {
      if (e.name !== "AbortError") setError(e.message);
    } finally {
      setPulling(null);
    }
  };

  const tierFor = (tag: string) => tiers.find((t) => t.tag === tag);

  return (
    <div className="model-menu" ref={boxRef}>
      <button className="model-button" onClick={() => setOpen(!open)} title="Choose model">
        <span className="dot" />
        <span className="model-name">{active || "no model"}</span>
        {tierFor(active) && <span className="tier-tag">{tierFor(active)!.tier}</span>}
        <span className="caret">▾</span>
      </button>
      {open && (
        <div className="model-pop">
          <div className="pop-section">Installed on this PC</div>
          {installed.length === 0 && <div className="pop-empty">No models installed yet.</div>}
          {installed.map((m) => (
            <button key={m.id} className={`pop-row ${m.id === active ? "on" : ""}`} onClick={() => choose(m.id)}>
              <span className="pop-main">{m.id}</span>
              <span className="pop-meta">
                {m.unison.parameter_size} · {m.unison.quantization} · {sizeGB(m.unison.size_bytes)}
              </span>
            </button>
          ))}
          <div className="pop-section">Configurations picked for your hardware</div>
          {tiers.map((t) => (
            <div key={t.tier} className="pop-tier">
              <div className="pop-tier-head">
                <span className="tier-tag">{t.tier}</span>
                <span className="pop-main">{t.tag}</span>
                <span className="pop-meta">
                  {t.size_gb} GB · {t.placement} · {t.license}
                </span>
              </div>
              <div className="pop-reason">{t.reason}</div>
              {t.installed ? (
                t.tag !== active && (
                  <button className="pop-action" onClick={() => choose(t.tag)}>
                    use this model
                  </button>
                )
              ) : pulling?.tag === t.tag ? (
                <div className="pull-progress">
                  <div className="bar" style={{ width: `${pulling.pct ?? 2}%` }} />
                  <span>
                    {pulling.status} {pulling.pct != null ? `${pulling.pct}%` : ""}
                  </span>
                  <button className="pop-action" onClick={() => abortRef.current?.abort()}>
                    cancel
                  </button>
                </div>
              ) : (
                <button className="pop-action" disabled={!!pulling} onClick={() => download(t.tag)}>
                  download ({t.size_gb} GB)
                </button>
              )}
            </div>
          ))}
          {error && <div className="pop-error">{error}</div>}
        </div>
      )}
    </div>
  );
}
