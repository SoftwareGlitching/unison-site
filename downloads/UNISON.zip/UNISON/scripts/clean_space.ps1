# Free up disk space safely. Shows sizes and asks before each step.
# Never touches your chats, settings, projects, license, or the models UNISON uses.
. (Join-Path $PSScriptRoot "common.ps1")
Set-Location $Root

function Get-SizeGB([string]$path) {
    if (-not (Test-Path -LiteralPath $path)) { return 0 }
    $s = (Get-ChildItem -LiteralPath $path -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
    return [math]::Round(($s / 1GB), 2)
}
function Show-Drives {
    Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Used -ne $null -and ($_.Free + $_.Used) -gt 0 } | ForEach-Object {
        Write-Host ("     {0}:  {1,7:N1} GB free of {2,7:N1} GB" -f $_.Name, ($_.Free / 1GB), (($_.Free + $_.Used) / 1GB))
    }
}
function Remove-Contents([string]$path, [int]$olderThanDays = 0) {
    if (-not (Test-Path -LiteralPath $path)) { return }
    $cut = (Get-Date).AddDays(-$olderThanDays)
    Get-ChildItem -LiteralPath $path -Force -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt $cut } |
        ForEach-Object { Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue }
}

Write-Host ""
Write-Host "  U N I S O N   disk cleanup" -ForegroundColor Cyan
Write-Host "  Nothing is deleted without asking. Your chats, projects, settings and license are never touched." -ForegroundColor DarkGray
Write-Host ""
Write-Host "   Free space now:"
Show-Drives

# ------------------------------------------------------------------ 1. models UNISON doesn't use
Write-Step "1/6" "AI models you don't use any more"
$ollama = Find-OllamaExe
if (-not $ollama -or -not (Start-OllamaIfNeeded)) {
    Write-Warn2 "Ollama isn't running, skipping models. (Open Ollama from the Start menu and run this again.)"
} else {
    $keepJson = & $VenvPy -c @"
import json, re
from pathlib import Path
from backend.core.config import settings
keep = {settings.get('inference', 'active_model') or '', settings.get('computer', 'vision_model') or 'qwen3-vl:8b',
        settings.get('knowledge', 'embedding_model') or 'nomic-embed-text'}
mf = Path('config/unison.Modelfile')
if mf.exists():
    m = re.search(r'^FROM\s+(\S+)', mf.read_text(encoding='utf-8'), re.M)
    if m: keep.add(m.group(1))
print(json.dumps(sorted(k for k in keep if k)))
"@ 2>$null
    $keep = @()
    try { $keep = $keepJson | Select-Object -Last 1 | ConvertFrom-Json } catch { }
    $lines = & $ollama list 2>$null | Select-Object -Skip 1
    $models = @()
    foreach ($l in $lines) {
        $p = ($l -split "\s{2,}") | Where-Object { $_ -ne "" }
        if ($p.Count -ge 3) { $models += [pscustomobject]@{ Name = $p[0].Trim(); Size = $p[2].Trim() } }
    }
    $norm = { param($n) if ($n -match ":") { $n } else { "${n}:latest" } }
    $keepN = $keep | ForEach-Object { & $norm $_ }
    $hasUnison = $models | Where-Object { $_.Name -like "unison*" }
    if (-not $hasUnison) {
        Write-Warn2 "UNISON's new brain isn't installed yet - run FIX-UNISON.bat first, then this cleanup. Skipping models for safety."
    } else {
        $extra = $models | Where-Object { $keepN -notcontains (& $norm $_.Name) }
        Write-Host "   Keeping (UNISON uses these): $($keep -join ', ')"
        if (-not $extra) { Write-Ok "No unused models." }
        foreach ($m in $extra) {
            if (Ask-YesNo "Delete $($m.Name) ($($m.Size))? You can download it again any time." $true) {
                & $ollama rm $m.Name | Out-Null
                if ($LASTEXITCODE -eq 0) { Write-Ok "Deleted $($m.Name)" } else { Write-Warn2 "Couldn't delete $($m.Name)" }
            }
        }
    }
}

# ------------------------------------------------------------------ 2. old model files left on C: after moving them
Write-Step "2/6" "Old model files left behind on C:"
$newDir = [Environment]::GetEnvironmentVariable("OLLAMA_MODELS", "User")
$oldDir = Join-Path $env:USERPROFILE ".ollama\models"
if ($newDir -and (Test-Path -LiteralPath $newDir) -and ((Resolve-Path -LiteralPath $newDir).Path -ne (Resolve-Path -LiteralPath $oldDir -ErrorAction SilentlyContinue).Path)) {
    $gb = Get-SizeGB $oldDir
    $newHasModels = (Get-SizeGB (Join-Path $newDir "blobs")) -gt 0.1
    if ($gb -lt 0.05) { Write-Ok "Nothing left behind." }
    elseif (-not $newHasModels) { Write-Warn2 "Your models folder ($newDir) looks empty, so the C: copy ($gb GB) is kept to be safe." }
    elseif (Ask-YesNo "Delete $gb GB of old model files in $oldDir? (Ollama now uses $newDir)" $true) {
        Remove-Contents (Join-Path $oldDir "blobs"); Remove-Contents (Join-Path $oldDir "manifests")
        Write-Ok "Freed about $gb GB on C:"
    }
} else { Write-Ok "Models weren't moved; nothing to clean here." }

# ------------------------------------------------------------------ 3. download caches
Write-Step "3/6" "Download caches (pip, npm, UNISON update leftovers)"
$caches = @(
    @{ Name = "Python package cache"; Path = Join-Path $env:LOCALAPPDATA "pip\Cache" },
    @{ Name = "npm package cache"; Path = Join-Path $env:LOCALAPPDATA "npm-cache" },
    @{ Name = "UNISON update leftovers"; Path = Join-Path $env:TEMP "unison-update" }
)
foreach ($c in $caches) {
    $gb = Get-SizeGB $c.Path
    if ($gb -lt 0.05) { continue }
    if (Ask-YesNo "Clear the $($c.Name) ($gb GB)? It refills only if needed." $true) { Remove-Contents $c.Path; Write-Ok "Cleared $($c.Name)" }
}
Get-ChildItem -Path $Root -Recurse -Directory -Filter "__pycache__" -Force -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -notlike "*\.venv\*" } | ForEach-Object { Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue }
Write-Ok "Caches checked."

# ------------------------------------------------------------------ 4. temp files
Write-Step "4/6" "Temporary files older than 2 days"
$gb = Get-SizeGB $env:TEMP
if ($gb -ge 0.05 -and (Ask-YesNo "Clean your Temp folder (up to $gb GB; files in use are skipped)?" $true)) {
    Remove-Contents $env:TEMP 2
    Write-Ok "Temp cleaned."
} else { Write-Ok "Skipped." }

# ------------------------------------------------------------------ 5. old UNISON zips in Downloads
Write-Step "5/6" "Old UNISON downloads"
$zips = Get-ChildItem -Path (Join-Path $env:USERPROFILE "Downloads") -Filter "UNISON*.zip" -File -ErrorAction SilentlyContinue
if (-not $zips) { Write-Ok "None found." }
foreach ($z in $zips) {
    if (Ask-YesNo "Delete $($z.Name) from Downloads ($([math]::Round($z.Length / 1MB, 1)) MB)?" $true) { Remove-Item -LiteralPath $z.FullName -Force; Write-Ok "Deleted $($z.Name)" }
}

# ------------------------------------------------------------------ 6. recycle bin + Windows cleanup
Write-Step "6/6" "Recycle Bin and Windows' own cleanup"
if (Ask-YesNo "Empty the Recycle Bin? (deleted files there can't be recovered after this)" $false) {
    try { Clear-RecycleBin -Force -ErrorAction Stop; Write-Ok "Recycle Bin emptied." } catch { Write-Warn2 "Couldn't empty it: $($_.Exception.Message)" }
}
if (Ask-YesNo "Open Windows Disk Cleanup for old Windows Update files too? (it asks for admin)" $false) {
    try { Start-Process cleanmgr.exe -ArgumentList "/d C:" -Verb RunAs } catch { Write-Warn2 "Disk Cleanup didn't start." }
}

Write-Host ""
Write-Host "   Free space now:"
Show-Drives
Write-Host ""
Write-Host "  Done." -ForegroundColor Green
Read-Host "Press Enter to close"
