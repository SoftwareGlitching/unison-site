@echo off
rem Turn OFF remote access to UNISON (the public link and the private Tailscale address).
rem UNISON keeps working on this PC. Turn it back on with Enable-Remote.bat.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\remote.ps1" -Off
