"""
Workspaces: the only folders UNISON's tools may touch.

Rules
- Every path is resolved (symlinks and `..` included) and must land inside an approved workspace.
- Relative paths are taken from the first (default) workspace.
- Credential-looking files and folders are never readable or writable.
- UNISON never edits its own program, config or database through tools.
- Drive roots and system folders cannot be added as workspaces.
"""
from __future__ import annotations

import fnmatch
import json
import os
import shutil
import sys
import time
import uuid
from pathlib import Path
from typing import Optional

from ..core.config import DATA_DIR, ROOT, settings
from .base import ToolError

PROJECTS_DIR = ROOT / "projects"
BACKUP_DIR = DATA_DIR / "backups"

SENSITIVE_DIRS = {".ssh", ".gnupg", ".aws", ".azure", ".kube", ".docker", ".git-credentials"}
SENSITIVE_FILES = [".env", ".env.*", "*.pem", "*.key", "*.pfx", "*.p12", "id_rsa*", "id_ed25519*",
                   "credentials", "credentials.*", "*.kdbx", ".npmrc", ".pypirc", ".netrc"]
SKIP_DIRS = {"node_modules", ".git", "__pycache__", ".venv", "venv", "dist", "build", ".next",
             ".cache", ".idea", ".vs", "bin", "obj", "Library", "Temp"}


def _norm(p: Path) -> Path:
    return Path(os.path.normcase(str(p.resolve())))


def _within(child: Path, parent: Path) -> bool:
    c, p = _norm(child), _norm(parent)
    return c == p or p in c.parents


def system_dirs() -> list[Path]:
    if sys.platform == "win32":
        env = os.environ
        return [Path(env.get("SystemRoot", r"C:\Windows")), Path(env.get("ProgramFiles", r"C:\Program Files")),
                Path(env.get("ProgramFiles(x86)", r"C:\Program Files (x86)")),
                Path(env.get("ProgramData", r"C:\ProgramData"))]
    return [Path(p) for p in ("/bin", "/boot", "/etc", "/lib", "/proc", "/sbin", "/sys", "/usr", "/var")]


def desktop_path() -> Optional[Path]:
    """The real Desktop folder (handles OneDrive-redirected desktops on Windows)."""
    if sys.platform == "win32":
        try:
            import ctypes
            from ctypes import wintypes
            buf = ctypes.create_unicode_buffer(wintypes.MAX_PATH)
            ctypes.windll.shell32.SHGetFolderPathW(None, 0x0010, None, 0, buf)  # CSIDL_DESKTOPDIRECTORY
            if buf.value and Path(buf.value).is_dir():
                return Path(buf.value)
        except Exception:  # noqa: BLE001
            pass
    p = Path.home() / "Desktop"
    return p if p.is_dir() else None


class Workspaces:
    def list(self) -> list[Path]:
        raw = settings.get("tools", "workspaces")
        if not raw:
            PROJECTS_DIR.mkdir(parents=True, exist_ok=True)
            return [PROJECTS_DIR]
        return [Path(p) for p in raw]

    @property
    def default(self) -> Path:
        return self.list()[0]

    def validate_new(self, path: str) -> Path:
        p = Path(path).expanduser()
        if not p.is_absolute():
            raise ToolError("Use a full path, e.g. C:\\Users\\you\\Desktop\\my-game")
        if not p.is_dir():
            raise ToolError(f"Folder does not exist: {p}")
        p = p.resolve()
        if p.parent == p:
            raise ToolError("A whole drive can't be a workspace. Pick a folder.")
        for sd in system_dirs():
            if sd.exists() and _within(p, sd):
                raise ToolError(f"System folders can't be workspaces: {p}")
        if _within(ROOT, p) and _norm(p) != _norm(PROJECTS_DIR):
            raise ToolError("That folder contains UNISON itself. Use UNISON\\projects or another folder.")
        if any(part.lower() in SENSITIVE_DIRS for part in p.parts):
            raise ToolError("That folder holds credentials and can't be a workspace.")
        return p

    def add(self, path: str) -> list[str]:
        p = self.validate_new(path)
        current = [str(x) for x in self.list()]
        if not any(_norm(Path(c)) == _norm(p) for c in current):
            current.append(str(p))
        settings.set("tools", "workspaces", current)
        return current

    def remove(self, path: str) -> list[str]:
        current = [str(x) for x in self.list() if _norm(x) != _norm(Path(path))]
        settings.set("tools", "workspaces", current or [str(PROJECTS_DIR)])
        return current

    def make_default(self, path: str) -> list[str]:
        current = [str(x) for x in self.list()]
        match = [c for c in current if _norm(Path(c)) == _norm(Path(path))]
        if not match:
            raise ToolError("Not a workspace")
        rest = [c for c in current if c != match[0]]
        settings.set("tools", "workspaces", match + rest)
        return match + rest

    # ------------------------------------------------------------------ resolution
    def resolve(self, path: Optional[str], *, write: bool = False) -> Path:
        raw = (path or ".").strip().strip('"').strip("'")
        p = Path(raw).expanduser()
        if not p.is_absolute():
            p = self.default / p
        p = p.resolve()
        ws = self.list()
        if not any(_within(p, w) for w in ws):
            names = "; ".join(str(w) for w in ws)
            raise ToolError(f"'{p}' is outside the approved workspaces ({names}). "
                            "The user can add folders in Settings → Workspaces.")
        if _within(p, ROOT) and not _within(p, PROJECTS_DIR):
            raise ToolError("UNISON's own program files are off-limits to tools.")
        parts = [x.lower() for x in p.parts]
        if any(x in SENSITIVE_DIRS for x in parts) or self.is_sensitive_file(p):
            raise ToolError(f"'{p.name}' looks like a credentials/secrets file; tools may not access it.")
        if write and ".git" in parts:
            raise ToolError("Tools don't write inside .git folders; use git commands instead.")
        return p

    @staticmethod
    def is_sensitive_file(p: Path) -> bool:
        name = p.name.lower()
        if name in (".env.example", ".env.sample", ".env.template"):
            return False
        return any(fnmatch.fnmatch(name, pat) for pat in SENSITIVE_FILES)

    def display(self, p: Path) -> str:
        for w in self.list():
            if _within(p, w):
                rel = os.path.relpath(p, w)
                return rel if w == self.default else str(p)
        return str(p)


workspaces = Workspaces()


# ---------------------------------------------------------------------- backups
def backup(path: Path, reason: str) -> Optional[str]:
    """Copy a file before it is changed or deleted. Returns the backup id."""
    if not path.exists() or not path.is_file():
        return None
    stamp = time.strftime("%Y%m%d-%H%M%S")
    bid = f"{stamp}-{uuid.uuid4().hex[:8]}"
    dest_dir = BACKUP_DIR / bid
    dest_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, dest_dir / path.name)
    with open(BACKUP_DIR / "index.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps({"id": bid, "original": str(path), "file": str(dest_dir / path.name),
                            "reason": reason, "at": time.time()}) + "\n")
    return bid


def list_backups(limit: int = 200) -> list[dict]:
    idx = BACKUP_DIR / "index.jsonl"
    if not idx.exists():
        return []
    rows = [json.loads(line) for line in idx.read_text(encoding="utf-8").splitlines() if line.strip()]
    return list(reversed(rows))[:limit]


def restore_backup(bid: str) -> dict:
    for row in list_backups(10_000):
        if row["id"] == bid:
            src, dst = Path(row["file"]), Path(row["original"])
            if not src.exists():
                raise ToolError("Backup file is missing")
            dst.parent.mkdir(parents=True, exist_ok=True)
            if dst.exists():
                backup(dst, f"before restoring {bid}")
            shutil.copy2(src, dst)
            return row
    raise ToolError(f"No backup with id {bid}")
