@echo off
rem Move Ollama models (several GB) from C: to another drive, e.g. D:
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\move_models.ps1" %*
