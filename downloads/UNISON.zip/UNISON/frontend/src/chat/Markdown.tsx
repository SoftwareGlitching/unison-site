import { memo, useRef, useState, type ReactNode } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeHighlight from "rehype-highlight";

const FILE_NAMES: Record<string, string> = {
  html: "index.html", xml: "file.xml", css: "style.css", js: "script.js", javascript: "script.js", jsx: "App.jsx",
  ts: "script.ts", typescript: "script.ts", tsx: "App.tsx", json: "data.json", py: "main.py", python: "main.py",
  lua: "main.lua", luau: "script.luau", cs: "Program.cs", csharp: "Program.cs", "c#": "Program.cs", cpp: "main.cpp",
  "c++": "main.cpp", c: "main.c", java: "Main.java", go: "main.go", rust: "main.rs", rs: "main.rs", sh: "script.sh",
  bash: "script.sh", ps1: "script.ps1", powershell: "script.ps1", bat: "run.bat", batch: "run.bat", sql: "query.sql",
  md: "README.md", markdown: "README.md", yaml: "config.yaml", yml: "config.yaml", toml: "config.toml",
};

/** A sensible file name for a code block: a name mentioned in its first line comment, else by language. */
export function fileNameFor(lang: string, text: string): string {
  const first = text.split("\n", 3).join("\n");
  const named = /(?:^|[\s(<!\-#/*'"])([\w.-]+\.(?:html?|css|js|jsx|ts|tsx|json|py|lua|luau|cs|cpp|hpp|h|c|java|go|rs|sh|ps1|bat|sql|md|ya?ml|toml|txt))\b/i.exec(first);
  if (named) return named[1];
  return FILE_NAMES[(lang || "").toLowerCase()] ?? "code.txt";
}

function download(name: string, text: string) {
  const url = URL.createObjectURL(new Blob([text], { type: "text/plain;charset=utf-8" }));
  const a = Object.assign(document.createElement("a"), { href: url, download: name });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

function CodeBlock({ children, lang }: { children: ReactNode; lang: string }) {
  const ref = useRef<HTMLPreElement>(null);
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    const text = ref.current?.innerText ?? "";
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1400);
  };
  return (
    <div className="codeblock">
      <div className="codeblock-bar">
        <span className="codeblock-lang">{lang || "text"}</span>
        <span className="codeblock-actions">
          <button
            className="codeblock-copy"
            title="Download this as a file"
            onClick={() => {
              const text = ref.current?.innerText ?? "";
              download(fileNameFor(lang, text), text);
            }}
          >
            save file
          </button>
          <button className="codeblock-copy" onClick={copy}>
            {copied ? "copied" : "copy"}
          </button>
        </span>
      </div>
      <pre ref={ref}>{children}</pre>
    </div>
  );
}

function langOf(children: ReactNode): string {
  const child: any = Array.isArray(children) ? children[0] : children;
  const cls: string = child?.props?.className ?? "";
  const m = /language-([\w+#-]+)/.exec(cls);
  return m ? m[1] : "";
}

// The brain may end a reply with a hidden "[remember: ...]" note for long-term memory; never show it.
const NOTE = /\n?\[\s*remember\s*:[^\]\n]*(\]|$)/gi;

export const Markdown = memo(function Markdown({ text: raw }: { text: string }) {
  const text = raw.includes("[") ? raw.replace(NOTE, "") : raw;
  return (
    <div className="md">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        rehypePlugins={[[rehypeHighlight, { detect: true }]]}
        components={{
          pre: ({ children }) => <CodeBlock lang={langOf(children)}>{children}</CodeBlock>,
          a: ({ href, children }) => (
            <a href={href} target="_blank" rel="noreferrer noopener">
              {children}
            </a>
          ),
        }}
      >
        {text}
      </ReactMarkdown>
    </div>
  );
});
