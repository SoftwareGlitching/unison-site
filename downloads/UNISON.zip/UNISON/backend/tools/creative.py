"""Creative tools: 2D sprites (pixel art -> PNG, with animation frames), 3D assets through Blender, and opening
apps on the user's PC. They let UNISON make real game art instead of text-only games."""
from __future__ import annotations

import glob
import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from ..core.config import ROOT, settings
from .base import Tool, ToolError, ToolResult, i, obj, s
from .sandbox import backup, workspaces

MAX_SPRITE = 256          # pixels per side per frame (before scaling)
BLENDER_TIMEOUT = 600


# ---------------------------------------------------------------------- sprites
def _color(value: str) -> tuple[int, int, int, int]:
    v = (value or "").strip().lstrip("#")
    if v.lower() in ("", "transparent", "none"):
        return (0, 0, 0, 0)
    if len(v) == 3:
        v = "".join(c * 2 for c in v)
    if len(v) == 6:
        v += "ff"
    if len(v) != 8:
        raise ToolError(f"Colours must be hex like #ff8800 or #ff880080 (got {value!r})")
    return tuple(int(v[k:k + 2], 16) for k in (0, 2, 4, 6))  # type: ignore[return-value]


def make_sprite(a: dict) -> ToolResult:
    """Pixel art from text rows. Each character is a pixel; the palette says which colour each character is."""
    from PIL import Image

    path = workspaces.resolve(a.get("path"), write=True)
    if path.suffix.lower() != ".png":
        raise ToolError("Sprites are saved as .png - give a path ending in .png")
    frames = a.get("frames") or ([a["pixels"]] if a.get("pixels") else None)
    if not frames or not isinstance(frames, list):
        raise ToolError("Give 'pixels' (a list of text rows) or 'frames' (a list of frames, each a list of rows)")
    if isinstance(frames[0], str):
        frames = [frames]
    palette = {k: _color(v) for k, v in (a.get("palette") or {}).items()}
    palette.setdefault(".", (0, 0, 0, 0))
    palette.setdefault(" ", (0, 0, 0, 0))
    scale = max(1, min(int(a.get("scale") or 4), 32))
    w = max(len(r) for f in frames for r in f)
    h = max(len(f) for f in frames)
    if w > MAX_SPRITE or h > MAX_SPRITE:
        raise ToolError(f"Each frame can be at most {MAX_SPRITE}x{MAX_SPRITE} pixels")
    sheet = Image.new("RGBA", (w * len(frames), h), (0, 0, 0, 0))
    missing = set()
    for n, rows in enumerate(frames):
        for y, row in enumerate(rows):
            for x, ch in enumerate(row):
                if ch not in palette:
                    missing.add(ch)
                    continue
                sheet.putpixel((n * w + x, y), palette[ch])
    if missing:
        raise ToolError(f"These characters have no colour in the palette: {''.join(sorted(missing))}")
    if scale > 1:
        sheet = sheet.resize((sheet.width * scale, sheet.height * scale), Image.NEAREST)
    path.parent.mkdir(parents=True, exist_ok=True)
    bid = backup(path, "make_sprite") if path.exists() else None
    sheet.save(path)
    fw, fh = w * scale, h * scale
    info = {"path": str(path), "frames": len(frames), "frame_width": fw, "frame_height": fh, "backup": bid}
    note = (f" It's a sprite sheet: {len(frames)} frames side by side, each {fw}x{fh} px. In a canvas game draw frame k "
            f"with ctx.drawImage(img, k*{fw}, 0, {fw}, {fh}, x, y, {fw}, {fh}).") if len(frames) > 1 else ""
    return ToolResult(True, f"Saved {path} ({sheet.width}x{sheet.height} px).{note}", info)


def preview_sprite(a: dict) -> dict:
    frames = a.get("frames") or [a.get("pixels") or []]
    return {"kind": "text", "summary": f"Create sprite {a.get('path')}", "text": "\n\n".join("\n".join(f) for f in frames if f)}


# ---------------------------------------------------------------------- blender
def find_blender() -> str:
    configured = settings.get("tools", "blender_path")
    if configured and os.path.exists(configured):
        return configured
    try:
        hw = json.loads((ROOT / "config" / "hardware.json").read_text(encoding="utf-8-sig"))
        p = (hw.get("paths") or {}).get("blender")
        if p and os.path.exists(p):
            return p
    except (OSError, ValueError):
        pass
    for pattern in (r"C:\Program Files\Blender Foundation\Blender*\blender.exe",
                    os.path.expandvars(r"%LOCALAPPDATA%\Programs\Blender Foundation\Blender*\blender.exe"),
                    r"C:\Program Files (x86)\Steam\steamapps\common\Blender\blender.exe"):
        hits = sorted(glob.glob(pattern))
        if hits:
            return hits[-1]
    from shutil import which
    return which("blender") or ""


PREAMBLE = '''import bpy, os, sys, math
OUT = {out!r}                     # folder for exported files (the workspace)
os.makedirs(OUT, exist_ok=True)
def out(name): return os.path.join(OUT, name)
def clear_scene():
    bpy.ops.object.select_all(action="SELECT"); bpy.ops.object.delete()
def export_fbx(name):             # Roblox: Studio -> Import 3D accepts .fbx
    bpy.ops.export_scene.fbx(filepath=out(name), apply_unit_scale=True, apply_scale_options="FBX_SCALE_ALL", bake_space_transform=True)
def export_glb(name):             # web games (three.js / Babylon)
    bpy.ops.export_scene.gltf(filepath=out(name), export_format="GLB")
def export_obj(name):
    bpy.ops.wm.obj_export(filepath=out(name))
def save_blend(name):
    bpy.ops.wm.save_as_mainfile(filepath=out(name))
def render_png(name, size=512):   # a preview picture of the model
    s = bpy.context.scene; s.render.resolution_x = s.render.resolution_y = size
    s.render.engine = "BLENDER_EEVEE_NEXT" if "BLENDER_EEVEE_NEXT" in [e.identifier for e in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items] else "BLENDER_EEVEE"
    s.render.filepath = out(name); bpy.ops.render.render(write_still=True)
clear_scene()
# ---- script from UNISON ----
'''


def blender_script(a: dict) -> ToolResult:
    script = a.get("script") or ""
    if not script.strip():
        raise ToolError("Give the Blender Python (bpy) script to run")
    exe = find_blender()
    if not exe:
        raise ToolError("Blender isn't installed (or wasn't found). Install it from blender.org, or set its path in "
                        "Settings -> PC access.")
    folder = workspaces.resolve(a.get("folder") or ".", write=True)
    folder.mkdir(parents=True, exist_ok=True)
    before = {p: p.stat().st_mtime for p in folder.rglob("*") if p.is_file()}
    with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False, encoding="utf-8") as f:
        f.write(PREAMBLE.format(out=str(folder)) + script)
        tmp = f.name
    timeout = max(30, min(int(a.get("timeout_seconds") or 300), BLENDER_TIMEOUT))
    flags = 0x08000000 if sys.platform == "win32" else 0
    started = time.time()
    try:
        r = subprocess.run([exe, "--background", "--factory-startup", "--python-exit-code", "1", "--python", tmp],
                           cwd=str(folder), capture_output=True, text=True, encoding="utf-8", errors="replace",
                           timeout=timeout, creationflags=flags)
        code, out = r.returncode, (r.stdout or "") + (r.stderr or "")
    except subprocess.TimeoutExpired:
        code, out = -1, f"Blender didn't finish within {timeout}s and was stopped."
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass
    made = sorted(str(p) for p in folder.rglob("*") if p.is_file() and before.get(p) != p.stat().st_mtime)
    lines = [ln for ln in out.splitlines() if ln.strip() and not ln.startswith(("Blender ", "Read prefs", "Fra:"))]
    tail = "\n".join(lines[-40:])
    ok = code == 0 and bool(made)
    msg = (f"Blender {'finished' if code == 0 else 'failed (exit ' + str(code) + ')'} in {time.time() - started:.0f}s. "
           + (f"Files created/updated: {', '.join(made)}" if made else "No files were created - call export_fbx/"
              "export_glb/save_blend/render_png in the script."))
    return ToolResult(ok, msg + ("\nBlender output:\n" + tail if tail else ""), {"files": made, "exit_code": code})


def preview_blender(a: dict) -> dict:
    try:
        cwd = str(workspaces.resolve(a.get("folder") or "."))
    except ToolError as e:
        cwd = f"(invalid: {e})"
    return {"kind": "command", "summary": "Run a Blender script (makes 3D models)", "shell": "blender",
            "command": "blender --background --python <script>\n\n" + (a.get("script") or "")[:6000], "cwd": cwd}


# ---------------------------------------------------------------------- apps
_APPS = {
    "chrome": "chrome", "google chrome": "chrome", "browser": "msedge", "edge": "msedge", "microsoft edge": "msedge",
    "firefox": "firefox", "notepad": "notepad", "explorer": "explorer", "file explorer": "explorer",
    "calculator": "calc", "calc": "calc", "paint": "mspaint", "terminal": "wt", "cmd": "cmd",
    "powershell": "powershell", "settings": "ms-settings:", "task manager": "taskmgr", "spotify": "spotify:",
    "discord": "discord:", "steam": "steam:", "roblox studio": "roblox-studio:", "roblox": "roblox:",
    "vs code": "code", "vscode": "code", "visual studio code": "code", "recycle bin": "shell:RecycleBinFolder",
    "downloads": "shell:Downloads", "documents": "shell:Personal", "desktop": "shell:Desktop",
    "blender": "blender", "control panel": "control",
}


def open_app(a: dict) -> ToolResult:
    name = (a.get("name") or "").strip()
    if not name:
        raise ToolError("Which app? e.g. 'chrome', 'notepad', 'recycle bin', 'roblox studio'")
    target = _APPS.get(name.lower(), name)
    if target.lower() == "blender":
        target = find_blender() or target
    if sys.platform != "win32":
        raise ToolError("Opening apps only works on Windows")
    try:
        if ":" in target and not os.path.isabs(target):      # URI schemes and shell: folders
            os.startfile(target)                              # type: ignore[attr-defined]
        else:
            subprocess.Popen(["cmd", "/c", "start", "", target], creationflags=0x08000000)
    except OSError as e:
        raise ToolError(f"Couldn't open {name}: {e}") from e
    return ToolResult(True, f"Opened {name}. (To click or type inside it, the user can switch to screen mode.)",
                      {"target": target})


TOOLS = [
    Tool("make_sprite",
         "Draw a pixel-art sprite and save it as a PNG (use for game characters, items, tiles, UI icons). Each "
         "character in 'pixels' is one pixel; 'palette' maps characters to hex colours ('.' = transparent). Give "
         "'frames' (several pixel grids of the same size) to make an animation sprite sheet - frames are placed "
         "side by side. Typical sizes: 16x16 or 32x32 per frame, scale 4.",
         obj({"path": s("Where to save, e.g. game/assets/hero.png"),
              "pixels": {"type": "array", "items": {"type": "string"}, "description": "Rows of the image, top to bottom"},
              "frames": {"type": "array", "items": {"type": "array", "items": {"type": "string"}},
                         "description": "Animation frames, each a list of rows (use instead of pixels)"},
              "palette": {"type": "object", "additionalProperties": {"type": "string"},
                          "description": "Character -> colour, e.g. {\"k\": \"#000000\", \"s\": \"#f1c27d\"}"},
              "scale": i("Pixel size multiplier (default 4)")}, ["path", "palette"]),
         "write", make_sprite, preview_sprite, default_mode="auto"),
    Tool("blender_script",
         "Make 3D models with Blender: runs a Blender Python (bpy) script in the background. The scene starts empty. "
         "Helpers are predefined: out(name) gives a path in the output folder, export_fbx(name) (for Roblox "
         "Studio's Import 3D), export_glb(name) (web games), export_obj(name), save_blend(name), "
         "render_png(name) (a preview picture). Build with bpy.ops.mesh.primitive_* / modifiers / materials "
         "(principled BSDF base colour), then export. Keep Roblox models under 10k triangles.",
         obj({"script": s("The bpy Python code to run"),
              "folder": s("Output folder in the workspace (default: the workspace)"),
              "timeout_seconds": i("Stop after this many seconds (default 300)")}, ["script"]),
         "exec", blender_script, preview_blender, default_mode="ask"),
    Tool("open_app",
         "Open an app, folder or website on the user's PC by name: e.g. 'chrome', 'notepad', 'recycle bin', "
         "'downloads', 'roblox studio', 'blender', 'vs code', 'settings', or a full path / URL.",
         obj({"name": s("App name, folder, path or URL")}, ["name"]),
         "launch", open_app, default_mode="auto"),
]
