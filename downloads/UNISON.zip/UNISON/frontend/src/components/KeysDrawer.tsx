import { useEffect, useState } from "react";
import { issuer, type IssuedKey, type IssuerStatus } from "../lib/api";

const DURATIONS: { v: string; label: string }[] = [
  { v: "", label: "Never expires" },
  { v: "7", label: "1 week" },
  { v: "30", label: "1 month" },
  { v: "90", label: "3 months" },
  { v: "365", label: "1 year" },
  { v: "custom", label: "Custom…" },
];
const SITE = "https://softwareglitching.github.io/unison-site/";

function buyerMessage(k: IssuedKey) {
  return `Hey ${k.to.replace(/ #\d+$/, "")}! Thanks for getting UNISON 🎉\n\nYour license key:\n${k.key}\n\n` +
    `1. Download UNISON: ${SITE}\n2. Run Setup.bat and paste the key when it asks.\n3. The same key also unlocks the browser chat: ${SITE}chat.html\n\n` +
    `Plan: ${k.plan} · ${k.expires === "never" ? "never expires" : "expires " + k.expires}${k.machine !== "any PC" ? " · locked to PC " + k.machine : ""}`;
}

/** Owner / dev only: make license keys with the signing key on this PC (Key Studio's vault). */
export function KeysDrawer({ onClose }: { onClose: () => void }) {
  const [st, setSt] = useState<IssuerStatus | null>(null);
  const [err, setErr] = useState("");
  const [pw, setPw] = useState("");
  const [to, setTo] = useState("");
  const [email, setEmail] = useState("");
  const [plan, setPlan] = useState("personal");
  const [dur, setDur] = useState("30");
  const [days, setDays] = useState("");
  const [lock, setLock] = useState(false);
  const [mid, setMid] = useState("");
  const [count, setCount] = useState(1);
  const [notes, setNotes] = useState("");
  const [busy, setBusy] = useState(false);
  const [made, setMade] = useState<IssuedKey[]>([]);
  const [recent, setRecent] = useState<IssuedKey[]>([]);
  const [copied, setCopied] = useState("");

  const load = () => {
    issuer.status().then(setSt).catch((e) => setErr(e.message));
    issuer.recent(30).then(setRecent).catch(() => undefined);
  };
  useEffect(load, []);

  const copy = (text: string, what: string) => {
    navigator.clipboard?.writeText(text).then(() => { setCopied(what); setTimeout(() => setCopied(""), 1500); }).catch(() => undefined);
  };

  const make = async () => {
    setErr("");
    if (!to.trim()) return setErr("Enter who the key is for.");
    if (lock && !/^[0-9A-F]{4}(-[0-9A-F]{4}){3}$/.test(mid)) return setErr("Machine ID should look like ABCD-1234-EF56-7890.");
    const d = dur === "custom" ? Number(days) : dur ? Number(dur) : null;
    if (dur === "custom" && !(d && d >= 1 && d <= 36500)) return setErr("Enter a number of days (1–36500).");
    setBusy(true);
    try {
      const r = await issuer.issue({ password: pw, to: to.trim(), email, plan, days: d, machine: lock ? mid : "", count, notes });
      setMade(r.keys);
      load();
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="drawer-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="drawer">
        <div className="drawer-head">
          <span>🔑 License keys</span>
          <button className="icon-btn" onClick={onClose} aria-label="Close">✕</button>
        </div>
        <div className="drawer-body">
          <div className="tab-body">
            {!st && !err && <p className="hint">Loading…</p>}
            {st && !st.allowed && (
              <section><h4>Dev or owner license needed</h4><p className="hint">Making keys is only available with an owner or dev license.</p></section>
            )}
            {st && st.allowed && !st.available && (
              <section>
                <h4>No signing key on this PC</h4>
                <p className="hint">
                  Keys only work if they're signed with the owner's private signing key, and that key lives on the owner's PC
                  (Key Studio's vault, wired to that computer). On any other PC, keys can't be made — ask the owner instead.
                </p>
              </section>
            )}
            {st && st.allowed && st.available && (
              <>
                {st.matches_unison === false && (
                  <div className="banner bad" style={{ margin: "0 0 14px" }}>This signing key doesn't match the one built into UNISON — its keys won't work.</div>
                )}
                <section>
                  <h4>New key</h4>
                  <p className="hint">Signed with your Key Studio vault on this PC · {st.issued} key{st.issued === 1 ? "" : "s"} issued so far.</p>
                  <div className="grid2">
                    <div><label>Who is it for? *</label><input className="text" value={to} maxLength={80} onChange={(e) => setTo(e.target.value)} placeholder="Buyer's name" /></div>
                    <div><label>Email (log only)</label><input className="text" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="buyer@example.com" /></div>
                    <div>
                      <label>Plan</label>
                      <select className="text" value={plan} onChange={(e) => { setPlan(e.target.value); if (e.target.value === "lifetime" || e.target.value === "dev") setDur(""); if (e.target.value === "trial") setDur("7"); }}>
                        {st.plans.map((p) => <option key={p} value={p}>{p === "dev" ? "dev (extra privileges)" : p}</option>)}
                      </select>
                    </div>
                    <div>
                      <label>Expires</label>
                      <div className="row" style={{ margin: 0 }}>
                        <select className="text" value={dur} onChange={(e) => setDur(e.target.value)}>
                          {DURATIONS.map((d) => <option key={d.v} value={d.v}>{d.label}</option>)}
                        </select>
                        {dur === "custom" && <input className="text" style={{ width: 90 }} type="number" min={1} max={36500} value={days} onChange={(e) => setDays(e.target.value)} placeholder="days" />}
                      </div>
                    </div>
                    <div><label>How many</label><input className="text" type="number" min={1} max={200} value={count} onChange={(e) => setCount(Math.max(1, Math.min(200, Number(e.target.value) || 1)))} /></div>
                    <div><label>Notes (log only)</label><input className="text" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="e.g. paid $10 on Gumroad" /></div>
                  </div>
                  <label className="toggle" style={{ marginTop: 10 }}>
                    <input type="checkbox" checked={lock} onChange={(e) => setLock(e.target.checked)} /> Lock to the buyer's PC
                  </label>
                  {lock && (
                    <input className="text mono" value={mid} placeholder="ABCD-1234-EF56-7890" maxLength={19}
                      onChange={(e) => { const v = e.target.value.toUpperCase().replace(/[^0-9A-F]/g, "").slice(0, 16); setMid(v.match(/.{1,4}/g)?.join("-") ?? ""); }} />
                  )}
                  {st.needs_password && (
                    <>
                      <label className="lbl" style={{ marginTop: 10 }}>Key Studio password</label>
                      <input className="text" type="password" value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="current-password" />
                    </>
                  )}
                  {err && <div className="pop-error">{err}</div>}
                  <div className="row" style={{ marginTop: 10 }}>
                    <button className="pop-action primary" disabled={busy} onClick={make}>{busy ? "Signing…" : count > 1 ? `Generate ${count} keys` : "Generate key"}</button>
                    {copied && <span className="small ok-t">{copied} ✓</span>}
                  </div>
                </section>
                {made.length > 0 && (
                  <section>
                    <div className="row"><h4 className="grow" style={{ margin: 0 }}>{made.length > 1 ? `${made.length} new keys` : "New key"}</h4>
                      {made.length > 1 && <button className="pop-action" onClick={() => copy(made.map((k) => k.key).join("\n"), "All keys copied")}>Copy all</button>}
                    </div>
                    {made.map((k) => (
                      <div className="key-out" key={k.id}>
                        <div className="meta"><b>{k.to}</b><span>{k.plan}</span><span>{k.expires === "never" ? "never expires" : "expires " + k.expires}</span><span>{k.machine}</span>
                          <span className="grow" />
                          <button className="pop-action" onClick={() => copy(k.key, "Key copied")}>Copy key</button>
                          <button className="pop-action" onClick={() => copy(buyerMessage(k), "Message copied")}>Copy message</button>
                        </div>
                        <code>{k.key}</code>
                      </div>
                    ))}
                  </section>
                )}
                <section>
                  <h4>Recent keys</h4>
                  {recent.length === 0 ? <p className="hint">None yet.</p> : (
                    <div className="table-wrap">
                      <table className="eval">
                        <thead><tr><th>Issued</th><th>For</th><th>Plan</th><th>Expires</th><th>PC</th><th /></tr></thead>
                        <tbody>
                          {recent.map((k) => (
                            <tr key={k.id}><td>{k.issued}</td><td>{k.to}</td><td>{k.plan}</td><td>{k.expires}</td><td>{k.machine}</td>
                              <td><button className="link-btn" onClick={() => copy(k.key, "Key copied")}>copy</button></td></tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </section>
              </>
            )}
            {err && !st && <div className="pop-error">{err}</div>}
          </div>
        </div>
      </div>
    </div>
  );
}
