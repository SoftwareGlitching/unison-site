"""
Background jobs: tasks UNISON works on without a browser tab open (e.g. while you're at work).

- A job is an agent task (files + terminal) or a screen task (mouse + keyboard), queued and run one at a
  time by a runner inside the UNISON server.
- Progress (tool calls, results, approvals, summary) is stored in SQLite, so you can check it from your
  phone and it survives closing the page.
- autonomous=True approves every action itself; dangerous commands stay blocked and screen jobs keep the
  Esc / corner kill switches. Otherwise the job pauses on each risky action until you approve it (from
  any device), for up to 8 hours.
"""
from __future__ import annotations

import asyncio
import json
import time
import uuid
from typing import Callable, Optional

from ..database.db import Database
from .approvals import ApprovalBroker

JOB_SCHEMA = """
CREATE TABLE IF NOT EXISTS jobs (
    id TEXT PRIMARY KEY,
    kind TEXT NOT NULL,              -- agent | screen
    task TEXT NOT NULL,
    model TEXT,
    autonomous INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL,            -- queued | running | waiting_approval | done | failed | stopped | interrupted
    summary TEXT,
    conversation_id TEXT,
    pending_action TEXT,
    last_image TEXT,
    steps INTEGER NOT NULL DEFAULT 0,
    created_at REAL NOT NULL,
    started_at REAL,
    finished_at REAL
);
CREATE TABLE IF NOT EXISTS job_events (
    id INTEGER PRIMARY KEY,
    job_id TEXT NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    at REAL NOT NULL,
    type TEXT NOT NULL,
    data TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_job_events ON job_events(job_id, id);
"""

JOB_MAX_STEPS = 60
JOB_APPROVAL_TIMEOUT = 8 * 3600
SKIP_EVENTS = {"token", "thinking", "user_saved"}
FINISHED = {"done", "failed", "stopped", "interrupted"}


class JobStore:
    def __init__(self, db: Database):
        self.db = db
        with db._lock:
            db._conn.executescript(JOB_SCHEMA)
            # jobs that were running when UNISON closed can't resume mid-step
            db._conn.execute("UPDATE jobs SET status='interrupted', finished_at=? "
                             "WHERE status IN ('running','waiting_approval')", (time.time(),))

    def create(self, kind: str, task: str, autonomous: bool, model: Optional[str]) -> dict:
        jid = "job_" + uuid.uuid4().hex[:16]
        with self.db.tx() as c:
            c.execute("INSERT INTO jobs(id, kind, task, model, autonomous, status, created_at) VALUES(?,?,?,?,?,?,?)",
                      (jid, kind, task, model, int(autonomous), "queued", time.time()))
        return self.get(jid)

    def get(self, jid: str, with_events: bool = False) -> Optional[dict]:
        rows = self.db.query("SELECT * FROM jobs WHERE id=?", (jid,))
        if not rows:
            return None
        job = dict(rows[0])
        job["autonomous"] = bool(job["autonomous"])
        if with_events:
            job["events"] = [{"id": r["id"], "at": r["at"], "type": r["type"], **json.loads(r["data"])}
                             for r in self.db.query("SELECT * FROM job_events WHERE job_id=? ORDER BY id", (jid,))]
        else:
            job.pop("last_image", None)
        return job

    def list(self, limit: int = 50) -> list[dict]:
        rows = self.db.query("SELECT id, kind, task, model, autonomous, status, summary, conversation_id, "
                             "pending_action, steps, created_at, started_at, finished_at FROM jobs "
                             "ORDER BY created_at DESC LIMIT ?", (limit,))
        return [{**dict(r), "autonomous": bool(r["autonomous"])} for r in rows]

    def next_queued(self) -> Optional[dict]:
        rows = self.db.query("SELECT id FROM jobs WHERE status='queued' ORDER BY created_at LIMIT 1")
        return self.get(rows[0]["id"]) if rows else None

    def update(self, jid: str, **fields) -> None:
        if not fields:
            return
        cols = ", ".join(f"{k}=?" for k in fields)
        with self.db.tx() as c:
            c.execute(f"UPDATE jobs SET {cols} WHERE id=?", (*fields.values(), jid))

    def add_event(self, jid: str, ev: dict) -> None:
        data = {k: v for k, v in ev.items() if k != "type"}
        with self.db.tx() as c:
            c.execute("INSERT INTO job_events(job_id, at, type, data) VALUES(?,?,?,?)",
                      (jid, time.time(), ev.get("type", "?"), json.dumps(data, default=str)))

    def delete(self, jid: str) -> bool:
        with self.db.tx() as c:
            c.execute("DELETE FROM job_events WHERE job_id=?", (jid,))
            return c.execute("DELETE FROM jobs WHERE id=?", (jid,)).rowcount > 0


class JobRunner:
    def __init__(self, db: Database, manager, broker: ApprovalBroker,
                 desktop_factory: Optional[Callable] = None, chat_service_factory: Optional[Callable] = None):
        self.store = JobStore(db)
        self.db = db
        self.manager = manager
        self.broker = broker
        self.desktop_factory = desktop_factory
        self.chat_service_factory = chat_service_factory
        self._wake = asyncio.Event()
        self._task: Optional[asyncio.Task] = None
        self._current_id: Optional[str] = None
        self._current_task: Optional[asyncio.Task] = None
        self._current_screen = None

    # ------------------------------------------------------------------ control
    def start(self) -> None:
        if self._task is None:
            self._task = asyncio.create_task(self._loop())

    async def shutdown(self) -> None:
        if self._current_task:
            self._current_task.cancel()
        if self._task:
            self._task.cancel()

    def submit(self, kind: str, task: str, autonomous: bool, model: Optional[str] = None) -> dict:
        job = self.store.create(kind, task, autonomous, model)
        self._wake.set()
        return job

    def stop(self, jid: str) -> bool:
        job = self.store.get(jid)
        if not job or job["status"] in FINISHED:
            return False
        if job["status"] == "queued":
            self.store.update(jid, status="stopped", finished_at=time.time(), summary="Cancelled before it started")
            return True
        if jid == self._current_id:
            if self._current_screen is not None:
                self._current_screen.stop("Stopped from the jobs list")
            if job.get("conversation_id"):
                self.broker.cancel_for(job["conversation_id"])
            if self._current_task and self._current_screen is None:
                self._current_task.cancel()
            return True
        return False

    # ------------------------------------------------------------------ loop
    async def _loop(self) -> None:
        while True:
            job = self.store.next_queued()
            if not job:
                self._wake.clear()
                try:
                    await asyncio.wait_for(self._wake.wait(), timeout=5)
                except asyncio.TimeoutError:
                    pass
                continue
            self._current_id = job["id"]
            self._current_task = asyncio.create_task(self._run(job))
            try:
                await self._current_task
            except asyncio.CancelledError:
                if self._task and getattr(self._task, "cancelling", lambda: 0)():
                    raise
            finally:
                self._current_id, self._current_task, self._current_screen = None, None, None

    async def run_one(self, job: dict) -> None:
        """Run a single job to completion (used by the loop and by tests)."""
        self._current_id = job["id"]
        self._current_task = asyncio.current_task()
        try:
            await self._run(job)
        finally:
            self._current_id, self._current_task, self._current_screen = None, None, None

    async def _run(self, job: dict) -> None:
        jid = job["id"]
        self.store.update(jid, status="running", started_at=time.time())
        status, summary, steps = "failed", "", 0
        try:
            gen = self._events(job)
            async for ev in gen:
                t = ev.get("type")
                if t == "start" and ev.get("conversation_id"):
                    self.store.update(jid, conversation_id=ev["conversation_id"])
                    self.db.rename_conversation(ev["conversation_id"],
                                                ("Job: " if job["kind"] == "agent" else "Screen job: ") + job["task"][:60])
                if t == "screen":
                    self.store.update(jid, last_image=ev.get("image"))
                    ev = {k: v for k, v in ev.items() if k != "image"}
                if t == "approval_required":
                    self.store.update(jid, status="waiting_approval", pending_action=ev["action_id"])
                if t == "approval_resolved":
                    self.store.update(jid, status="running", pending_action=None)
                if t in ("tool_result", "action_result"):
                    steps += 1
                    self.store.update(jid, steps=steps)
                if t == "assistant_saved" and ev.get("content"):
                    summary = ev["content"]
                if t == "done":
                    if job["kind"] == "screen":
                        status, summary = ("done" if ev.get("status") == "done" else
                                           "stopped" if ev.get("status") == "stopped" else "failed"), ev.get("summary", "")
                    else:
                        status = "done"
                if t == "error":
                    status, summary = "failed", ev.get("message", "error")
                if t not in SKIP_EVENTS:
                    self.store.add_event(jid, ev)
        except asyncio.CancelledError:
            status, summary = "stopped", summary or "Stopped"
            self.store.add_event(jid, {"type": "notice", "message": "Stopped"})
            raise
        except Exception as e:  # noqa: BLE001
            status, summary = "failed", f"{type(e).__name__}: {e}"
            self.store.add_event(jid, {"type": "error", "message": summary})
        finally:
            self.store.update(jid, status=status, summary=summary[:4000], finished_at=time.time(),
                              pending_action=None)

    async def _events(self, job: dict):
        if job["kind"] == "screen":
            from ..computer.agent import ScreenAgent
            from ..computer.desktop import make_desktop
            from ..computer.service import set_current, vision_model
            desktop = (self.desktop_factory or make_desktop)()
            agent = ScreenAgent(desktop, self.manager.backend, job.get("model") or vision_model(), self.broker,
                                autopilot=job["autonomous"], minimize_self=False, db=self.db)
            self._current_screen = agent
            set_current(agent)
            try:
                async for ev in agent.run(job["task"]):
                    yield ev
            finally:
                agent.stop("Job ended")
                set_current(None)
            return
        if self.chat_service_factory:
            svc = self.chat_service_factory(job)
        else:
            from ..core.chat_service import ChatService
            svc = ChatService(self.db, self.manager, approvals=self.broker, max_steps=JOB_MAX_STEPS,
                              approval_timeout=JOB_APPROVAL_TIMEOUT, auto_approve=job["autonomous"])
        async for ev in svc.run(conversation_id=None, content=job["task"], model=job.get("model"), tools=True):
            yield ev


_runner: Optional[JobRunner] = None


def get_runner() -> Optional[JobRunner]:
    return _runner


def set_runner(r: Optional[JobRunner]) -> None:
    global _runner
    _runner = r
