"""Tests for the Ollama backend client, model manager and chat service, against tests/fake_ollama.py."""
import asyncio
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

try:
    import httpx  # noqa: F401
except ImportError:  # the build sandbox ships an httpx-compatible package under another name
    import httpx2
    sys.modules["httpx"] = httpx2

from backend.core.chat_service import ChatService, fit_context  # noqa: E402
from backend.database.db import Database  # noqa: E402
from backend.inference.base import ChatMessage, GenerationOptions, InferenceError  # noqa: E402
from backend.inference.manager import ModelManager  # noqa: E402
from backend.inference.ollama_backend import OllamaBackend  # noqa: E402
from tests.fake_ollama import FakeOllama  # noqa: E402

MODEL = "test-model:1b"


def run(coro):
    return asyncio.run(coro)


async def collect(agen):
    return [e async for e in agen]


class OllamaBackendTests(unittest.TestCase):
    def test_health_and_models(self):
        with FakeOllama() as fake:
            b = OllamaBackend(fake.url)
            h = run(b.health())
            self.assertTrue(h["ok"])
            self.assertEqual(h["version"], "0.0.0-test")
            models = run(b.list_models())
            self.assertEqual(models[0].name, MODEL)
            self.assertEqual(models[0].quantization, "Q4_K_M")
            loaded = run(b.loaded_models())
            self.assertEqual(loaded[0]["gpu_percent"], 75.0)

    def test_stream_tokens_and_real_stats(self):
        with FakeOllama() as fake:
            b = OllamaBackend(fake.url)
            evs = run(collect(b.chat_stream(MODEL, [ChatMessage("user", "hello there")],
                                            GenerationOptions(temperature=0.2, num_ctx=4096, max_tokens=50))))
            text = "".join(e.content for e in evs if e.type == "token")
            self.assertEqual(text, "Echo: hello there")
            done = evs[-1]
            self.assertEqual(done.type, "done")
            self.assertEqual(done.stats.completion_tokens, 3)
            self.assertEqual(done.stats.tokens_per_second, 6.0)   # 3 tokens / 0.5 s
            opts = fake.requests[-1]["body"]["options"]
            self.assertEqual(opts, {"temperature": 0.2, "num_ctx": 4096, "num_predict": 50})

    def test_missing_model_is_reported(self):
        with FakeOllama() as fake:
            b = OllamaBackend(fake.url)
            with self.assertRaises(InferenceError) as ctx:
                run(collect(b.chat_stream("nope:7b", [ChatMessage("user", "x")], GenerationOptions())))
            self.assertEqual(ctx.exception.code, "model_not_found")
            self.assertIn("ollama pull nope:7b", str(ctx.exception))

    def test_engine_offline(self):
        b = OllamaBackend("http://127.0.0.1:9")  # nothing listens here
        self.assertFalse(run(b.health())["ok"])
        with self.assertRaises(InferenceError) as ctx:
            run(collect(b.chat_stream(MODEL, [ChatMessage("user", "x")], GenerationOptions())))
        self.assertEqual(ctx.exception.code, "engine_offline")

    def test_pull_progress(self):
        with FakeOllama() as fake:
            b = OllamaBackend(fake.url)
            prog = run(collect(b.pull("new:1b")))
            self.assertEqual(prog[-1]["status"], "success")
            self.assertIn("new:1b", [m.name for m in run(b.list_models())])


class ChatServiceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self.tmp.name) / "t.db")

    def tearDown(self):
        self.db._conn.close()
        self.tmp.cleanup()

    def service(self, fake):
        mgr = ModelManager(OllamaBackend(fake.url))
        return ChatService(self.db, mgr), mgr

    def test_new_conversation_is_saved(self):
        with FakeOllama() as fake:
            svc, mgr = self.service(fake)
            evs = run(collect(svc.run(conversation_id=None, content="Write hello world in Luau", model=MODEL)))
            types = [e["type"] for e in evs]
            self.assertEqual(types[0], "user_saved")
            self.assertEqual(types[1], "start")
            self.assertEqual(types[-1], "done")
            cid = evs[1]["conversation_id"]
            msgs = self.db.messages(cid)
            self.assertEqual([m["role"] for m in msgs], ["user", "assistant"])
            self.assertEqual(msgs[1]["content"], "Echo: Write hello world in Luau")
            self.assertEqual(self.db.get_conversation(cid)["title"], "Write hello world in Luau")
            self.assertEqual(mgr.status()["last"]["completion_tokens"], 6)
            # A system prompt naming the foundation model is sent first.
            sent = fake.requests[-1]["body"]["messages"]
            self.assertEqual(sent[0]["role"], "system")

    def test_history_is_sent_and_regenerate_replaces_reply(self):
        with FakeOllama() as fake:
            svc, _ = self.service(fake)
            evs = run(collect(svc.run(conversation_id=None, content="first", model=MODEL)))
            cid = evs[1]["conversation_id"]
            run(collect(svc.run(conversation_id=cid, content="second", model=MODEL)))
            sent = [m["content"] for m in fake.requests[-1]["body"]["messages"] if m["role"] != "system"]
            self.assertEqual(sent, ["first", "Echo: first", "second"])
            run(collect(svc.run(conversation_id=cid, content=None, model=MODEL, regenerate=True)))
            roles = [m["role"] for m in self.db.messages(cid)]
            self.assertEqual(roles, ["user", "assistant", "user", "assistant"])
            sent = [m["content"] for m in fake.requests[-1]["body"]["messages"] if m["role"] != "system"]
            self.assertEqual(sent, ["first", "Echo: first", "second"])

    def test_stop_keeps_partial_reply(self):
        with FakeOllama(token_delay=0.05) as fake:
            svc, mgr = self.service(fake)

            async def stop_early():
                agen = svc.run(conversation_id=None, content="one two three four five six seven", model=MODEL)
                got, cid = 0, None
                async for ev in agen:
                    if ev["type"] == "start":
                        cid = ev["conversation_id"]
                    if ev["type"] == "token":
                        got += 1
                        if got == 2:
                            break
                await agen.aclose()
                return cid
            cid = run(stop_early())
            msgs = self.db.messages(cid)
            self.assertEqual(msgs[-1]["role"], "assistant")
            self.assertEqual(msgs[-1]["content"], "Echo: one")
            self.assertEqual(msgs[-1]["stats"]["done_reason"], "stopped")
            self.assertEqual(mgr.active_generations, 0)

    def test_errors_do_not_leave_empty_replies(self):
        with FakeOllama() as fake:
            svc, _ = self.service(fake)
            with self.assertRaises(InferenceError):
                run(collect(svc.run(conversation_id=None, content="hi", model="missing:1b")))
            for conv in self.db.list_conversations():
                self.assertNotIn("assistant", [m["role"] for m in self.db.messages(conv["id"])])

    def test_unknown_conversation(self):
        with FakeOllama() as fake:
            svc, _ = self.service(fake)
            with self.assertRaises(InferenceError) as ctx:
                run(collect(svc.run(conversation_id="conv_missing", content="hi", model=MODEL)))
            self.assertEqual(ctx.exception.status, 404)

    def test_search(self):
        with FakeOllama() as fake:
            svc, _ = self.service(fake)
            run(collect(svc.run(conversation_id=None, content="RemoteEvent question", model=MODEL)))
            run(collect(svc.run(conversation_id=None, content="Blender UV unwrap", model=MODEL)))
            self.assertEqual(len(self.db.list_conversations("RemoteEvent")), 1)
            self.assertEqual(len(self.db.list_conversations()), 2)


class ContextTests(unittest.TestCase):
    def test_trims_oldest_keeps_system_and_latest(self):
        sys_msg = ChatMessage("system", "s")
        hist = [ChatMessage("user", "x" * 3500) for _ in range(10)] + [ChatMessage("user", "latest")]
        out = fit_context(sys_msg, hist, 4096)
        self.assertEqual(out[0].role, "system")
        self.assertEqual(out[-1].content, "latest")
        self.assertLess(len(out), len(hist) + 1)

    def test_single_huge_message_is_still_sent(self):
        out = fit_context(None, [ChatMessage("user", "y" * 100000)], 2048)
        self.assertEqual(len(out), 1)


if __name__ == "__main__":
    unittest.main()
