"""A model that loops (endless hidden thinking, or a stalled stream) must not hang UNISON forever."""
import asyncio
import tempfile
import unittest
from pathlib import Path

from tests.helpers import IsolatedSettings  # noqa: I001
from backend.core import chat_service as cs
from backend.core.chat_service import ChatService
from backend.database.db import Database
from backend.inference.base import StreamEvent


class LoopingManager:
    """Thinks forever with native tools; answers normally with the text tool protocol."""
    def __init__(self):
        self.calls = []

    async def resolve_model(self, m):
        return "loopy:1b"

    def default_options(self, **kw):
        from backend.inference.base import GenerationOptions
        return GenerationOptions(num_ctx=8192)

    async def stream(self, model, msgs, opts, tools=None):
        self.calls.append(bool(tools))
        if tools:
            while True:
                yield StreamEvent("thinking", "hmm " * 50)
                await asyncio.sleep(0)
        yield StreamEvent("token", "Here you go.")
        yield StreamEvent("done")


class RunawayTests(unittest.TestCase):
    def test_overthinking_with_tools_falls_back_to_text_protocol(self):
        with tempfile.TemporaryDirectory() as d, IsolatedSettings():
            db = Database(Path(d) / "t.db")
            mgr = LoopingManager()
            svc = ChatService(db, mgr)

            async def go():
                return [ev async for ev in svc.run(conversation_id=None, content="look at my files", tools=True)]
            events = asyncio.run(asyncio.wait_for(go(), 30))
            db._conn.close()
        cs._text_protocol_models.discard("loopy:1b")
        self.assertEqual(mgr.calls[:2], [True, False])
        self.assertTrue(any(e["type"] == "notice" and "stuck" in e["message"] for e in events))
        self.assertTrue(any(e["type"] == "assistant_saved" and e["content"] == "Here you go." for e in events))


if __name__ == "__main__":
    unittest.main()
