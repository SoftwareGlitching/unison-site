# UNISON first-run setup.
# Inspects the PC, installs what's missing (asking first), downloads the chosen local model,
# builds the app, and runs an end-to-end self-test against the real model.
param([switch]$Yes)

. (Join-Path $PSScriptRoot "common.ps1")
Set-Location $Root
New-Item -ItemType Directory -Force -Path (Join-Path $Root "logs") | Out-Null
try { Start-Transcript -Path (Join-Path $Root "logs\setup.log") -Append | Out-Null } catch { }

function Stop-Setup([string]$msg) {
    Write-Bad $msg
    Write-Host ""
    Write-Host "Setup stopped. The full log is in logs\setup.log." -ForegroundColor Yellow
    try { Stop-Transcript | Out-Null } catch { }
    Read-Host "Press Enter to close"
    exit 1
}

function Ask-Install([string]$q) { if ($Yes) { return $true }; return (Ask-YesNo $q $true) }

Write-Host ""
Write-Host "  U N I S O N   setup" -ForegroundColor Cyan
Write-Host "  Private AI that runs on this computer." -ForegroundColor DarkGray

# ------------------------------------------------------------------------------------------
Write-Step "1/8" "Inspecting your hardware"
& (Join-Path $PSScriptRoot "inspect_hardware.ps1")
$hwFile = Join-Path $Root "config\hardware.json"
if (-not (Test-Path $hwFile)) { Stop-Setup "Hardware inspection failed." }

# ------------------------------------------------------------------------------------------
Write-Step "2/8" "Python"
$py = Find-Python
if (-not $py) {
    Write-Warn2 "Python 3.10-3.14 not found."
    if (Ask-Install "Install Python 3.12 now?") {
        Install-WithWinget "Python.Python.3.12" "Python 3.12" "https://www.python.org/downloads/" | Out-Null
        $py = Find-Python
    }
    if (-not $py) { Stop-Setup "Python is required. Install Python 3.12 from python.org (tick 'Add to PATH'), then run Setup.bat again." }
}
Write-Ok "Python: $py"

# ------------------------------------------------------------------------------------------
Write-Step "2b" "License key"
if (-not (Test-Path $VenvPy)) {
    & $py -m venv $Venv
    if ($LASTEXITCODE -ne 0) { Stop-Setup "Could not create the Python virtual environment." }
}
& $VenvPy -m pip install --disable-pip-version-check -q "cryptography>=42"
if ($LASTEXITCODE -ne 0) { Stop-Setup "Couldn't install the license checker (see above). Check your internet connection." }
& $VenvPy (Join-Path $PSScriptRoot "check_key.py") --existing
if ($LASTEXITCODE -ne 0) {
    Write-Host "   UNISON needs a license key to install. Get one at https://softwareglitching.github.io/unison-site/#license"
    $licensed = $false
    if ($env:UNISON_LICENSE_KEY) {
        & $VenvPy (Join-Path $PSScriptRoot "check_key.py") $env:UNISON_LICENSE_KEY
        $licensed = ($LASTEXITCODE -eq 0)
    }
    for ($try = 1; -not $licensed -and $try -le 5; $try++) {
        $k = Read-Host "   Paste your license key (UNISON-...)"
        if ([string]::IsNullOrWhiteSpace($k)) { continue }
        & $VenvPy (Join-Path $PSScriptRoot "check_key.py") $k.Trim()
        $licensed = ($LASTEXITCODE -eq 0)
    }
    if (-not $licensed) { Stop-Setup "Setup needs a valid license key. Nothing large was downloaded." }
}

# ------------------------------------------------------------------------------------------
Write-Step "3/8" "Node.js (builds the web interface)"
if ((Get-NodeMajor) -lt 18) {
    Write-Warn2 "Node.js 18+ not found."
    if (Ask-Install "Install Node.js LTS now?") {
        Install-WithWinget "OpenJS.NodeJS.LTS" "Node.js LTS" "https://nodejs.org/" | Out-Null
    }
    if ((Get-NodeMajor) -lt 18) { Stop-Setup "Node.js 18+ is required. Install the LTS version from nodejs.org, then run Setup.bat again." }
}
Write-Ok ("Node.js: " + (& node --version))

# ------------------------------------------------------------------------------------------
Write-Step "4/8" "Ollama (local inference engine)"
if (-not (Find-OllamaExe)) {
    Write-Warn2 "Ollama not found. UNISON uses it to run open-weight models on your GPU/CPU."
    if (Ask-Install "Install Ollama now?") {
        Install-WithWinget "Ollama.Ollama" "Ollama" "https://ollama.com/download/windows" | Out-Null
    }
    if (-not (Find-OllamaExe)) { Stop-Setup "Ollama is required. Install it from https://ollama.com/download/windows, then run Setup.bat again." }
}
if (-not (Start-OllamaIfNeeded)) { Stop-Setup "Ollama is installed but its server didn't start. Open the Ollama app from the Start menu, then run Setup.bat again." }
$ollama = Find-OllamaExe
Write-Ok ("Ollama running: " + (& $ollama --version 2>&1 | Select-Object -First 1))

# ------------------------------------------------------------------------------------------
Write-Step "5/8" "Choosing a model for your hardware"
& $py -m backend.core.model_selection | Out-Null
if ($LASTEXITCODE -ne 0) { Stop-Setup "Model selection failed." }
$cfg = Get-Content (Join-Path $Root "config\models.json") -Raw | ConvertFrom-Json
$tierNames = @("lightweight", "balanced", "advanced")
$i = 1
foreach ($t in $tierNames) {
    $m = $cfg.tiers.$t
    $mark = if ($t -eq $cfg.default_tier) { "  <- recommended" } else { "" }
    Write-Host ("   {0}) {1,-12} {2,-20} {3,5} GB  runs on {4}{5}" -f $i, $t, $m.tag, $m.size_gb, $m.placement, $mark)
    Write-Host ("      {0}" -f $m.reason) -ForegroundColor DarkGray
    $i++
}
foreach ($w in $cfg.warnings) { Write-Warn2 $w }
Write-Host "   Full report: docs\HARDWARE_REPORT.md" -ForegroundColor DarkGray
$choice = [array]::IndexOf($tierNames, $cfg.default_tier) + 1
if (-not $Yes) {
    $ans = Read-Host "   Which model? [1-3, Enter = $choice]"
    if ($ans -match "^[1-3]$") { $choice = [int]$ans }
}
$tier = $tierNames[$choice - 1]
$model = $cfg.tiers.$tier.tag
$sizeGb = [double]$cfg.tiers.$tier.size_gb

# Where Ollama stores models: OLLAMA_MODELS if set, else the user profile.
$modelDir = if ($env:OLLAMA_MODELS) { $env:OLLAMA_MODELS } else { Join-Path $env:USERPROFILE ".ollama\models" }
$drive = (Split-Path -Qualifier $modelDir)
$free = [math]::Round((Get-PSDrive ($drive.TrimEnd(":"))).Free / 1GB, 1)
if ($free -lt ($sizeGb + 2)) { Stop-Setup "Not enough space on $drive for $model ($sizeGb GB needed, $free GB free). Free up space or pick a smaller tier." }

& $py -c "from backend.core.config import settings; settings.set('inference', 'active_model', '$model')"
Write-Ok "Selected $tier model: $model (license $($cfg.tiers.$tier.license))"

# ------------------------------------------------------------------------------------------
Write-Step "6/8" "Downloading $model (one time, $sizeGb GB)"
$have = & $ollama list 2>$null | Out-String
if ($have -match [regex]::Escape($model)) {
    Write-Ok "Already downloaded."
} else {
    & $ollama pull $model
    if ($LASTEXITCODE -ne 0) { Stop-Setup "Model download failed. Check your internet connection and run Setup.bat again (downloads resume)." }
    Write-Ok "Downloaded $model"
}

# ------------------------------------------------------------------------------------------
Write-Step "7/8" "Installing UNISON's backend and building the web app"
if (-not (Test-Path $VenvPy)) {
    & $py -m venv $Venv
    if ($LASTEXITCODE -ne 0) { Stop-Setup "Could not create the Python virtual environment." }
}
& $VenvPy -m pip install --upgrade pip --disable-pip-version-check -q
& $VenvPy -m pip install -r (Join-Path $Root "requirements.txt") --disable-pip-version-check
if ($LASTEXITCODE -ne 0) { Stop-Setup "Installing Python packages failed (see above)." }
Write-Ok "Python packages installed in .venv"

Push-Location (Join-Path $Root "frontend")
& npm.cmd install --no-fund --no-audit
if ($LASTEXITCODE -ne 0) { Pop-Location; Stop-Setup "npm install failed (see above)." }
& npm.cmd run build
if ($LASTEXITCODE -ne 0) { Pop-Location; Stop-Setup "Building the web app failed (see above)." }
Pop-Location
if (-not (Test-Path (Join-Path $Root "frontend\dist\index.html"))) { Stop-Setup "The web app build produced no output." }
Write-Ok "Web app built"

# ------------------------------------------------------------------------------------------
Write-Step "8/8" "Knowledge base, workspace and end-to-end test with the real model"
$script:SelfTestOk = $false
. (Join-Path $PSScriptRoot "post_install.ps1") -Yes:$Yes
$selftestOk = $script:SelfTestOk

Set-Content -Path (Join-Path $Root ".setup-complete") -Value (Get-Date -Format s)
try { Stop-Transcript | Out-Null } catch { }

Write-Host ""
if ($selftestOk) {
    Write-Host "  UNISON is ready. Every self-test passed with your real model." -ForegroundColor Green
} else {
    Write-Host "  Setup finished, but some self-tests failed. See docs\SELFTEST.md and send it to me." -ForegroundColor Yellow
}

if (-not $Yes -and (Ask-YesNo "Create a desktop shortcut to start UNISON?" $true)) {
    $ws = New-Object -ComObject WScript.Shell
    $lnk = $ws.CreateShortcut((Join-Path ([Environment]::GetFolderPath("Desktop")) "UNISON.lnk"))
    $lnk.TargetPath = Join-Path $Root "Start-UNISON.bat"
    $lnk.WorkingDirectory = $Root
    $lnk.Description = "Start UNISON (local AI)"
    $lnk.Save()
    Write-Ok "Shortcut created on your desktop"
}
if (-not $Yes -and (Ask-YesNo "Start UNISON now?" $true)) {
    Start-Process -FilePath (Join-Path $Root "Start-UNISON.bat") -WorkingDirectory $Root
}
