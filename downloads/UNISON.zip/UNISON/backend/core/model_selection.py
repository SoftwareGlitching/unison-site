"""
Hardware-aware model selection for UNISON.

Reads the hardware profile produced by scripts/inspect_hardware.ps1 (config/hardware.json)
and chooses three model configurations (lightweight / balanced / advanced) from a catalog of
open-weight models that Ollama can run locally.

Every catalog entry records its license so the choice can be audited. Sizes are the
download size of Ollama's default 4-bit (Q4_K_M) build, in GB.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Optional

# Approximate extra memory needed beyond the weights: KV cache for an 8K context plus runtime.
GPU_OVERHEAD_GB = 1.5
# Memory the OS and other apps keep when the model runs from system RAM.
RAM_RESERVE_GB = 6.0


@dataclass(frozen=True)
class CatalogModel:
    tag: str                 # Ollama tag
    family: str
    params: str
    size_gb: float           # download / weight size at default quant
    license: str
    license_url: str
    moe: bool = False        # mixture-of-experts: tolerates CPU offload far better than dense models
    context: int = 32768
    notes: str = ""


# Ordered from smallest/fastest to largest/strongest. All coding-focused, all Apache-2.0.
# (Qwen2.5-Coder 3B is deliberately excluded: it ships under the non-commercial Qwen Research license.)
CATALOG: list[CatalogModel] = [
    CatalogModel("qwen2.5-coder:1.5b", "Qwen2.5-Coder", "1.5B", 1.0, "Apache-2.0",
                 "https://huggingface.co/Qwen/Qwen2.5-Coder-1.5B-Instruct/blob/main/LICENSE",
                 notes="Very fast; fine for quick answers and autocomplete-style help."),
    CatalogModel("qwen2.5-coder:7b", "Qwen2.5-Coder", "7B", 4.7, "Apache-2.0",
                 "https://huggingface.co/Qwen/Qwen2.5-Coder-7B-Instruct/blob/main/LICENSE",
                 notes="Strong all-round coder for 8 GB GPUs."),
    CatalogModel("qwen2.5-coder:14b", "Qwen2.5-Coder", "14B", 9.0, "Apache-2.0",
                 "https://huggingface.co/Qwen/Qwen2.5-Coder-14B-Instruct/blob/main/LICENSE",
                 notes="Noticeably better reasoning and multi-file code than 7B."),
    CatalogModel("devstral:24b", "Devstral", "24B", 14.0, "Apache-2.0",
                 "https://huggingface.co/mistralai/Devstral-Small-2505",
                 notes="Agentic coding model; good at multi-step software tasks."),
    CatalogModel("qwen3-coder:30b", "Qwen3-Coder", "30B-A3B (MoE)", 19.0, "Apache-2.0",
                 "https://huggingface.co/Qwen/Qwen3-Coder-30B-A3B-Instruct/blob/main/LICENSE",
                 moe=True, context=262144,
                 notes="Mixture-of-experts: only ~3B parameters active per token, so it stays usable "
                       "even when part of it runs from system RAM."),
]

# Local embedding model used from Phase 2 onward (retrieval / memory). Apache-2.0.
EMBEDDING_MODEL = CatalogModel(
    "nomic-embed-text", "Nomic Embed", "137M", 0.27, "Apache-2.0",
    "https://huggingface.co/nomic-ai/nomic-embed-text-v1.5", context=8192,
    notes="Local embedding model for knowledge retrieval and memory search.")


@dataclass
class Hardware:
    ram_gb: float
    gpu_vendor: str = "none"          # nvidia | amd | intel | none
    gpu_name: str = ""
    vram_gb: float = 0.0
    cuda_version: Optional[str] = None
    cpu_cores: int = 4

    @property
    def usable_vram_gb(self) -> float:
        """VRAM Ollama can actually use. Ollama accelerates NVIDIA (CUDA) and recent AMD (ROCm);
        integrated/Intel graphics run on CPU."""
        if self.gpu_vendor in ("nvidia", "amd"):
            return self.vram_gb
        return 0.0

    @classmethod
    def from_json(cls, data: dict) -> "Hardware":
        gpus = data.get("gpus") or []
        # Prefer the discrete GPU with the most memory that Ollama can use.
        best = None
        for g in gpus:
            vendor = (g.get("vendor") or "").lower()
            if vendor not in ("nvidia", "amd"):
                continue
            if best is None or (g.get("vram_gb") or 0) > (best.get("vram_gb") or 0):
                best = g
        if best is None and gpus:
            best = gpus[0]
        return cls(
            ram_gb=float(data.get("ram_gb") or 8),
            gpu_vendor=(best or {}).get("vendor", "none").lower() if best else "none",
            gpu_name=(best or {}).get("name", "") if best else "",
            vram_gb=float((best or {}).get("vram_gb") or 0) if best else 0.0,
            cuda_version=data.get("cuda_version"),
            cpu_cores=int(data.get("cpu_logical_cores") or data.get("cpu_cores") or 4),
        )


@dataclass
class TierChoice:
    tier: str
    model: CatalogModel
    placement: str   # "gpu" | "hybrid" | "cpu"
    reason: str

    def to_dict(self) -> dict:
        d = {"tier": self.tier, "placement": self.placement, "reason": self.reason}
        d.update({k: v for k, v in asdict(self.model).items()})
        return d


@dataclass
class Selection:
    hardware: Hardware
    tiers: dict[str, TierChoice] = field(default_factory=dict)
    default_tier: str = "balanced"
    warnings: list[str] = field(default_factory=list)

    def to_config(self) -> dict:
        return {
            "generated_from": "config/hardware.json",
            "default_tier": self.default_tier,
            "active_model": self.tiers[self.default_tier].model.tag,
            "tiers": {k: v.to_dict() for k, v in self.tiers.items()},
            "embedding_model": asdict(EMBEDDING_MODEL),
            "warnings": self.warnings,
            "catalog": [asdict(m) for m in CATALOG],
        }


def _fits_gpu(m: CatalogModel, vram: float) -> bool:
    return vram > 0 and vram >= m.size_gb + GPU_OVERHEAD_GB


def _fits_ram(m: CatalogModel, ram: float) -> bool:
    return ram >= m.size_gb + RAM_RESERVE_GB


def _placement(m: CatalogModel, hw: Hardware) -> str:
    if _fits_gpu(m, hw.usable_vram_gb):
        return "gpu"
    if hw.usable_vram_gb > 0:
        return "hybrid"
    return "cpu"


def select_models(hw: Hardware) -> Selection:
    vram, ram = hw.usable_vram_gb, hw.ram_gb
    sel = Selection(hardware=hw)
    idx = {m.tag: i for i, m in enumerate(CATALOG)}

    # Models that run fully on the GPU.
    gpu_fit = [m for m in CATALOG if _fits_gpu(m, vram)]
    # Models that can at least be held in RAM (CPU or GPU+CPU split).
    ram_fit = [m for m in CATALOG if _fits_ram(m, ram)]

    if not ram_fit:
        ram_fit = [CATALOG[0]]
        sel.warnings.append(
            f"Only {ram:.0f} GB RAM detected. Even the smallest model will be tight; close other apps.")

    if vram > 0:
        i_gpu = idx[gpu_fit[-1].tag] if gpu_fit else -1
        # ---------- ADVANCED: strongest model that still runs at a usable speed ----------
        i_adv = max(i_gpu, 0)
        # Dense models: allow up to two steps above what fits on the GPU, split GPU+RAM,
        # as long as the weights are no more than ~2.5x the VRAM (beyond that it is mostly CPU).
        for step in (1, 2):
            j = i_gpu + step
            if 0 <= j < len(CATALOG):
                m = CATALOG[j]
                if not m.moe and _fits_ram(m, ram) and m.size_gb <= vram * 2.5:
                    i_adv = max(i_adv, j)
        # Mixture-of-experts: only a few billion parameters are active per token, so a GPU+RAM
        # split stays fast enough to be the top option on mid-range cards.
        for j, m in enumerate(CATALOG):
            if m.moe and _fits_ram(m, ram) and vram >= 6:
                i_adv = max(i_adv, j)
        # ---------- BALANCED: best model fully on the GPU ----------
        if i_gpu >= 1 and i_gpu < i_adv:
            i_bal = i_gpu
        elif i_gpu == i_adv and i_gpu >= 1:
            i_bal = i_gpu - 1
        else:
            i_bal = min(i_adv, 1)
        # ---------- LIGHTWEIGHT: one step down, minimum the 1.5B model ----------
        i_light = max(0, i_bal - 1)
        light, balanced, advanced = CATALOG[i_light], CATALOG[i_bal], CATALOG[i_adv]
    else:
        # CPU only: dense models slow down quickly. Allow up to 14B with plenty of RAM.
        cpu_ok = [m for m in ram_fit if not m.moe and m.size_gb <= 9.0 and ram >= m.size_gb * 2 + 4]
        advanced = cpu_ok[-1] if cpu_ok else ram_fit[0]
        seven = CATALOG[1]
        balanced = seven if (ram >= 16 and _fits_ram(seven, ram)) else CATALOG[0]
        if idx[balanced.tag] > idx[advanced.tag]:
            balanced = advanced
        light = CATALOG[0]

    def why(m: CatalogModel, tier: str) -> str:
        p = _placement(m, hw)
        need = m.size_gb + GPU_OVERHEAD_GB
        if p == "gpu":
            return f"{m.size_gb:g} GB weights + ~{GPU_OVERHEAD_GB:g} GB cache fits in your {vram:g} GB VRAM; runs fully on GPU."
        if p == "hybrid":
            extra = " Mixture-of-experts keeps it usable when split." if m.moe else " Expect slower replies."
            return f"Needs ~{need:g} GB; your GPU has {vram:g} GB, so Ollama splits it between GPU and RAM.{extra}"
        return f"No supported GPU, so it runs on CPU from your {ram:g} GB RAM. Expect a few tokens per second."

    for tier, m in (("lightweight", light), ("balanced", balanced), ("advanced", advanced)):
        sel.tiers[tier] = TierChoice(tier, m, _placement(m, hw), why(m, tier))

    if vram == 0:
        sel.default_tier = "lightweight" if ram < 16 else "balanced"
        if hw.gpu_vendor == "intel":
            sel.warnings.append("Intel graphics detected: Ollama will run on CPU.")
        elif hw.gpu_vendor == "none":
            sel.warnings.append("No dedicated GPU detected: Ollama will run on CPU.")
    if hw.gpu_vendor == "amd":
        sel.warnings.append("AMD GPU: Ollama's ROCm support covers Radeon RX 6800 and newer on Windows; "
                            "older cards fall back to CPU.")
    if hw.gpu_vendor == "nvidia" and not hw.cuda_version:
        sel.warnings.append("NVIDIA GPU found but nvidia-smi did not report a CUDA version. "
                            "Update the NVIDIA driver for GPU acceleration.")
    return sel


def write_selection(hardware_json: Path, models_json: Path, report_md: Path) -> Selection:
    raw = json.loads(hardware_json.read_text(encoding="utf-8-sig"))
    hw = Hardware.from_json(raw)
    sel = select_models(hw)
    models_json.parent.mkdir(parents=True, exist_ok=True)
    models_json.write_text(json.dumps(sel.to_config(), indent=2), encoding="utf-8")
    report_md.parent.mkdir(parents=True, exist_ok=True)
    report_md.write_text(render_report(raw, sel), encoding="utf-8")
    return sel


def render_report(raw: dict, sel: Selection) -> str:
    hw = sel.hardware
    tools = raw.get("tools") or {}
    lines = [
        "# UNISON hardware report",
        "",
        f"Generated by setup on {raw.get('collected_at', 'unknown date')}.",
        "",
        "## Your computer",
        "",
        f"- **Windows:** {raw.get('os_caption', '?')} (build {raw.get('os_build', '?')})",
        f"- **CPU:** {raw.get('cpu_name', '?')} — {raw.get('cpu_cores', '?')} cores / {raw.get('cpu_logical_cores', '?')} threads",
        f"- **RAM:** {hw.ram_gb:g} GB",
    ]
    for g in raw.get("gpus") or []:
        lines.append(f"- **GPU:** {g.get('name')} ({g.get('vendor')}), {g.get('vram_gb', 0):g} GB VRAM")
    if not raw.get("gpus"):
        lines.append("- **GPU:** none detected")
    lines.append(f"- **CUDA (driver):** {hw.cuda_version or 'not available'}")
    for d in raw.get("disks") or []:
        lines.append(f"- **Drive {d.get('drive')}:** {d.get('free_gb', 0):g} GB free of {d.get('size_gb', 0):g} GB")
    lines += ["", "## Installed tools", ""]
    for name, val in tools.items():
        lines.append(f"- **{name}:** {val or 'not found'}")
    lines += [
        "",
        "## Inference engine",
        "",
        "Ollama (built on llama.cpp). It uses CUDA on NVIDIA, ROCm on supported AMD cards, and falls back "
        "to CPU automatically. One engine only; models can be swapped without touching UNISON.",
        "",
        "## Model configurations",
        "",
        "| Tier | Model | Size | Runs on | License |",
        "|---|---|---|---|---|",
    ]
    for tier in ("lightweight", "balanced", "advanced"):
        t = sel.tiers[tier]
        mark = " (default)" if tier == sel.default_tier else ""
        lines.append(f"| {tier}{mark} | `{t.model.tag}` | {t.model.size_gb:g} GB | {t.placement} | {t.model.license} |")
    lines.append("")
    for tier in ("lightweight", "balanced", "advanced"):
        t = sel.tiers[tier]
        lines.append(f"- **{tier}** — {t.reason} {t.model.notes}")
    if sel.warnings:
        lines += ["", "## Notes", ""] + [f"- {w}" for w in sel.warnings]
    lines += ["", f"Embedding model for later phases: `{EMBEDDING_MODEL.tag}` ({EMBEDDING_MODEL.license}).", ""]
    return "\n".join(lines)


if __name__ == "__main__":
    import sys
    root = Path(__file__).resolve().parents[2]
    hw_path = Path(sys.argv[1]) if len(sys.argv) > 1 else root / "config" / "hardware.json"
    s = write_selection(hw_path, root / "config" / "models.json", root / "docs" / "HARDWARE_REPORT.md")
    print(json.dumps({k: v.model.tag for k, v in s.tiers.items()} | {"default": s.default_tier}))
