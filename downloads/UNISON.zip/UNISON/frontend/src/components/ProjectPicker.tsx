import { useEffect, useState } from "react";
import { api } from "../lib/api";

/** Opens with the app, like Codex: pick the project folder UNISON Code builds in. */
export function ProjectPicker({ onPicked, onSkip }: { onPicked: (path: string) => void; onSkip: () => void }) {
  const [folders, setFolders] = useState<string[]>([]);
  const [current, setCurrent] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [typed, setTyped] = useState("");

  useEffect(() => {
    api
      .workspaces()
      .then((w) => {
        setFolders(w.data);
        setCurrent(w.default);
      })
      .catch(() => undefined);
  }, []);

  const name = (p: string) => p.split(/[\\/]/).filter(Boolean).pop() || p;

  const use = async (path: string) => {
    setBusy(true);
    setErr("");
    try {
      if (path !== current) await api.defaultWorkspace(path);
      onPicked(path);
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };

  const browse = async () => {
    setBusy(true);
    setErr("");
    try {
      const r = await api.pickWorkspace();
      if (r.picked) onPicked(r.picked);
    } catch (e: any) {
      setErr(e.message || "Couldn't open the folder window. Type the folder path below instead.");
    } finally {
      setBusy(false);
    }
  };

  const addTyped = async () => {
    const p = typed.trim().replace(/^"|"$/g, "");
    if (!p) return;
    setBusy(true);
    setErr("");
    try {
      await api.addWorkspace(p);
      onPicked(p);
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="picker-backdrop">
      <div className="picker" role="dialog" aria-label="Open a project folder">
        <div className="head">
          <svg viewBox="0 0 32 32" className="brand-mark" aria-hidden>
            <circle cx="12" cy="16" r="7" />
            <circle cx="20" cy="16" r="7" className="second" />
          </svg>
          <h2>Open a project</h2>
        </div>
        <p>Pick the folder UNISON Code works in. It reads the code there and builds new files, websites, games and apps right in that folder.</p>
        {folders.length > 0 && (
          <div className="recent">
            {folders.map((f) => (
              <button key={f} onClick={() => use(f)} disabled={busy} title={f}>
                <span className="ico">📁</span>
                <b>{name(f)}{f === current ? " · last used" : ""}</b>
                <span>{f}</span>
              </button>
            ))}
          </div>
        )}
        <div className="actions">
          <button className="primary" onClick={browse} disabled={busy}>
            Open folder…
          </button>
          <button className="ghost" onClick={onSkip} disabled={busy}>
            Just chat
          </button>
        </div>
        <div className="row" style={{ marginTop: 14 }}>
          <input
            value={typed}
            onChange={(e) => setTyped(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && addTyped()}
            placeholder="or paste a folder path, e.g. C:\Users\you\Desktop\my-site"
            style={{ flex: 1 }}
          />
          <button className="ghost" onClick={addTyped} disabled={busy || !typed.trim()}>
            Use
          </button>
        </div>
        {err && <div className="err">{err}</div>}
      </div>
    </div>
  );
}
