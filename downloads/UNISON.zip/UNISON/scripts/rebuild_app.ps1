# Rebuilds UNISON's interface after an update (about 30 seconds), then reopens UNISON. Chats and settings are kept.
. (Join-Path $PSScriptRoot "common.ps1")
Set-Location $Root
Write-Host ""
Write-Host "  U N I S O N   rebuild" -ForegroundColor Cyan
Get-Process -Name "UNISON" -ErrorAction SilentlyContinue | ForEach-Object { & taskkill /PID $_.Id /T /F 2>$null | Out-Null }
Push-Location (Join-Path $Root "frontend")
& npm.cmd install --no-fund --no-audit --loglevel=error
& npm.cmd run build
$ok = ($LASTEXITCODE -eq 0)
Pop-Location
& (Join-Path $Root "desktop\build.ps1") -IfNeeded -Quiet
if ($ok) { Write-Ok "Rebuilt" } else { Write-Bad "The rebuild failed (see above)."; Read-Host "Press Enter to close"; exit 1 }
$app = Join-Path $Root "UNISON.exe"
if (Test-Path $app) { Start-Process -FilePath $app -WorkingDirectory $Root } else { Start-Process -FilePath (Join-Path $Root "Start-UNISON.bat") -WorkingDirectory $Root }
Write-Ok "UNISON is opening."
Start-Sleep -Seconds 2
