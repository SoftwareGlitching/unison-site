# Remote access to UNISON from your phone or work computer, using Tailscale. Two modes:
#
#  Private (tailscale serve):  an https:// address only devices signed in to YOUR Tailscale account can open.
#                              Needs the Tailscale app on the phone/laptop.
#  Public link (tailscale funnel): the same address opens in ANY browser (e.g. a locked-down work PC where you
#                              can't install anything). Protected by UNISON's password sign-in + lockouts.
#
# UNISON itself keeps listening only on 127.0.0.1; no router ports are opened in either mode.
param([switch]$Off, [switch]$Public, [switch]$Private)

. (Join-Path $PSScriptRoot "common.ps1")
Set-Location $Root

function Find-Tailscale {
    $cmd = Get-Command tailscale -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($cmd) { return $cmd.Source }
    $p = Join-Path $env:ProgramFiles "Tailscale\tailscale.exe"
    if (Test-Path $p) { return $p }
    return $null
}

Write-Host ""
Write-Host "  UNISON remote access (via Tailscale)" -ForegroundColor Cyan
Write-Host ""

$ts = Find-Tailscale
if ($Off) {
    if ($ts) {
        & $ts funnel reset 2>$null
        & $ts serve reset
        Write-Ok "Remote access turned off (private address and public link)."
    } else { Write-Ok "Tailscale isn't installed; nothing to turn off." }
    Read-Host "Press Enter to close"
    exit 0
}

# 1. install Tailscale
if (-not $ts) {
    Write-Host "   Tailscale is free for personal use. It must be installed on this PC and on your phone."
    if (Ask-YesNo "Install Tailscale on this PC now?" $true) {
        Install-WithWinget "Tailscale.Tailscale" "Tailscale" "https://tailscale.com/download/windows" | Out-Null
        Start-Sleep -Seconds 5
        $ts = Find-Tailscale
    }
    if (-not $ts) { Write-Bad "Install Tailscale from https://tailscale.com/download/windows, then run this again."; Read-Host "Press Enter to close"; exit 1 }
}

# 2. sign in
$status = & $ts status --json 2>$null | Out-String | ConvertFrom-Json -ErrorAction SilentlyContinue
if (-not $status -or $status.BackendState -ne "Running") {
    Write-Host "   Sign in to Tailscale in the browser window that opens (Google, Microsoft or GitHub account)."
    & $ts up
    $status = & $ts status --json 2>$null | Out-String | ConvertFrom-Json -ErrorAction SilentlyContinue
}
if (-not $status -or $status.BackendState -ne "Running") { Write-Bad "Tailscale isn't connected yet. Open the Tailscale app, sign in, and run this again."; Read-Host "Press Enter to close"; exit 1 }

$login = $null
try { $login = $status.User."$($status.Self.UserID)".LoginName } catch { }
$dns = ($status.Self.DNSName).TrimEnd(".")
Write-Ok "Tailscale connected as $login ($dns)"

# 3. only this Tailscale account may use UNISON remotely
if ($login) {
    & $VenvPy -c "import sys; from backend.core.config import settings; settings.set('remote', 'allowed_logins', [sys.argv[1]])" $login
    Write-Ok "Only $login can use UNISON remotely."
}

# 3b. choose how other devices reach UNISON
$mode = "private"
if ($Public) { $mode = "public" } elseif (-not $Private) {
    Write-Host ""
    Write-Host "   How do you want to reach UNISON?"
    Write-Host "   1) Private - only devices with the Tailscale app signed in as $login   <- safest"
    Write-Host "   2) Public link - opens in ANY browser, e.g. your work computer (no install there),"
    Write-Host "      protected by a strong UNISON password"
    $ans = Read-Host "   Choose [1-2, Enter = 1]"
    if ($ans -eq "2") { $mode = "public" }
}

# 3c. a sign-in password is required for both modes; the public link needs a strong one
function Read-NewPassword([int]$min) {
    do {
        $p1 = Read-Host "   Choose a password (at least $min characters)" -AsSecureString
        $p2 = Read-Host "   Repeat it" -AsSecureString
        $s1 = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($p1))
        $s2 = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($p2))
        if ($s1 -ne $s2) { Write-Warn2 "They didn't match, try again." }
        elseif ($s1.Length -lt $min) { Write-Warn2 "Too short, try again." }
    } while ($s1 -ne $s2 -or $s1.Length -lt $min)
    & $VenvPy -c "import sys; from backend.security import sessions; sessions.set_password(sys.argv[1])" "$s1"
    Write-Ok "Sign-in password set. Every device signs in with it once."
}
$hasPw = (& $VenvPy -c "from backend.security import sessions; print('yes' if sessions.password_set() else 'no')" 2>$null | Select-Object -Last 1)
Write-Host ""
if ($mode -eq "public") {
    Write-Warn2 "The public link can be opened by anyone who finds the address, so the password is the lock."
    Write-Host  "   Use at least 12 characters, not used anywhere else (e.g. three random words + a number)."
    if ($hasPw -ne "yes" -or (Ask-YesNo "Set a new strong password now? (recommended)" $true)) { Read-NewPassword 12 }
} elseif ($hasPw -ne "yes") {
    Write-Warn2 "No sign-in password is set yet."
    Read-NewPassword 6
} else {
    Write-Ok "Sign-in password already set."
}

# 4. publish UNISON
& $ts funnel reset 2>$null | Out-Null
if ($mode -eq "public") {
    Write-Host "   Opening the public link https://$dns ..."
    & $ts funnel --bg 8770
} else {
    Write-Host "   Publishing UNISON privately at https://$dns ..."
    & $ts serve --bg 8770
}
if ($LASTEXITCODE -ne 0) {
    Write-Warn2 "Tailscale asked for something above - usually to enable HTTPS certificates"
    if ($mode -eq "public") { Write-Host "   and Funnel for your account." }
    Write-Host  "   Open the link it printed, click Enable, then run Enable-Remote.bat again."
    Read-Host "Press Enter to close"
    exit 1
}
& $VenvPy -c "import sys; from backend.core.config import settings; settings.set('remote', 'mode', sys.argv[1]); settings.set('remote', 'url', sys.argv[2])" $mode "https://$dns"
Write-Ok "Remote address: https://$dns  ($mode)"

# 5. keep the PC reachable while you're away
Write-Host ""
if (Ask-YesNo "Stop this PC from sleeping while it's plugged in? (needed for jobs while you're away)" $true) {
    & powercfg /change standby-timeout-ac 0
    & powercfg /change hibernate-timeout-ac 0
    Write-Ok "Sleep disabled on AC power (Settings -> System -> Power to change it back)."
}
if (Ask-YesNo "Start UNISON automatically when you sign in to Windows?" $true) {
    $ws = New-Object -ComObject WScript.Shell
    $lnk = $ws.CreateShortcut((Join-Path ([Environment]::GetFolderPath("Startup")) "UNISON.lnk"))
    $app = Join-Path $Root "UNISON.exe"
    if (Test-Path $app) { $lnk.TargetPath = $app; $lnk.Arguments = "--background"; $lnk.IconLocation = "$app,0" }
    else { $lnk.TargetPath = Join-Path $Root "Start-UNISON.bat"; $lnk.Arguments = "-NoBrowser" }
    $lnk.WorkingDirectory = $Root
    $lnk.WindowStyle = 7   # minimised
    $lnk.Save()
    Write-Ok "UNISON will start (minimised) when you sign in."
}

Write-Host ""
if ($mode -eq "public") {
    Write-Host "  At work (or anywhere):" -ForegroundColor Cyan
    Write-Host "   1. Open https://$dns in any browser."
    Write-Host "   2. Sign in with your UNISON password. Chat, rate answers, run jobs and approve steps."
    Write-Host "   Wrong passwords lock that address out for 15 minutes. Use 'lock' in the sidebar on shared PCs."
    Write-Host "   STRONGLY recommended: turn on 2-step sign-in at the PC (Settings -> PC access -> 2-step sign-in)." -ForegroundColor Yellow
    Write-Host "   Then signing in from other devices also needs the 6-digit code from your phone."
    Write-Host ""
    Write-Host "  On the UNISON website (people with a license key):" -ForegroundColor Cyan
    Write-Host "   The browser chat at softwareglitching.github.io/unison-site/chat.html can use THIS PC's model."
    Write-Host "   In the chat: Settings -> Brain -> 'UNISON PC' and paste:  https://$dns"
    Write-Host "   Key holders can only chat with your active model - no files, tools, screen or settings."
    Write-Host "   Turn that off with: .venv\Scripts\python -c `"from backend.core.config import settings; settings.set('remote','web_guests',False)`""
} else {
    Write-Host "  On your phone:" -ForegroundColor Cyan
    Write-Host "   1. Install the Tailscale app and sign in with the same account ($login)."
    Write-Host "   2. Open https://$dns in the phone's browser (add it to your home screen)."
    Write-Host "   3. Use the Jobs button to give UNISON work and approve its actions."
}
Write-Host ""
Write-Host "  Screen jobs need Windows unlocked; file/terminal jobs work while the PC is locked." -ForegroundColor DarkGray
Write-Host "  Turn remote access off any time with: Enable-Remote.bat -Off" -ForegroundColor DarkGray
Read-Host "Press Enter to close"
