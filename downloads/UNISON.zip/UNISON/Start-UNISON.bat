@echo off
rem Double-click to start UNISON. Opens the UNISON app (and runs setup the first time).
rem "Start-UNISON.bat -Console" starts the server in a console window the old way.
cd /d "%~dp0"
if /i "%~1"=="-Console" goto console
set "UNISON_ARGS="
if /i "%~1"=="-NoBrowser" set "UNISON_ARGS=--background"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0desktop\build.ps1" -IfNeeded -Quiet
if exist "%~dp0UNISON.exe" (
  start "" "%~dp0UNISON.exe" %UNISON_ARGS%
  exit /b 0
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\start.ps1" %*
exit /b %errorlevel%
:console
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\start.ps1"
