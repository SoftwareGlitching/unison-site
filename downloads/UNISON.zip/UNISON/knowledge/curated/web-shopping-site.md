# Building a complete shopping website (static, works by double-clicking index.html)

## File plan
```
shop/
  index.html        home: header, hero, featured products, categories, newsletter, footer
  products.html     all products: search, category filter, sort, grid
  product.html      one product (product.html?id=3): image, price, options, qty, add to cart, related items
  cart.html         cart lines, qty +/- , remove, subtotal/shipping/tax/total, checkout button
  checkout.html     contact + shipping form with validation, order summary, "Place order" -> thank-you message
  about.html, contact.html (optional)
  css/style.css     variables, header, grid, cards, buttons, forms, footer, responsive rules
  js/products.js    const PRODUCTS = [ {id, name, price (cents), category, image, rating, description, badge} ]
  js/cart.js        the Cart object (localStorage) + header badge
  js/app.js         page logic: render grids, filters, product page, cart page, checkout
  images/           sprites/SVGs, or use inline SVG / gradients
```
Load scripts on every page in this order, at the end of body: products.js, cart.js, app.js.

## Header used on every page
```html
<header class="site-header"><div class="container header-row">
  <a class="logo" href="index.html">NOVA<span>SHOP</span></a>
  <button class="menu-btn" aria-expanded="false" aria-controls="nav" aria-label="Menu">☰</button>
  <nav id="nav" class="nav">
    <a href="index.html">Home</a><a href="products.html">Shop</a>
    <a href="products.html?cat=new">New</a><a href="about.html">About</a>
  </nav>
  <div class="header-actions">
    <form class="search" action="products.html"><input name="q" placeholder="Search products" aria-label="Search"></form>
    <a class="cart-link" href="cart.html" aria-label="Cart">🛒<span class="cart-count" hidden>0</span></a>
  </div>
</div></header>
```

## js/cart.js (complete)
```js
const Cart = {
  key: "shop.cart.v1",
  load() { try { return JSON.parse(localStorage.getItem(this.key) || "[]"); } catch { return []; } },
  save(lines) { try { localStorage.setItem(this.key, JSON.stringify(lines)); } catch {} this.badge(); },
  lines() { return this.load(); },
  add(id, qty = 1) {
    const lines = this.load(), line = lines.find(l => l.id === String(id));
    if (line) line.qty += qty; else lines.push({ id: String(id), qty });
    this.save(lines); toast("Added to cart");
  },
  setQty(id, qty) {
    let lines = this.load().map(l => l.id === String(id) ? { ...l, qty } : l).filter(l => l.qty > 0);
    this.save(lines);
  },
  remove(id) { this.save(this.load().filter(l => l.id !== String(id))); },
  clear() { this.save([]); },
  count() { return this.load().reduce((n, l) => n + l.qty, 0); },
  detailed() {
    return this.load().map(l => ({ ...l, product: PRODUCTS.find(p => String(p.id) === l.id) }))
                      .filter(l => l.product);
  },
  totals() {
    const subtotal = this.detailed().reduce((s, l) => s + l.product.price * l.qty, 0);
    const shipping = subtotal === 0 || subtotal >= 5000 ? 0 : 599;   // free over $50
    const tax = Math.round(subtotal * 0.08);
    return { subtotal, shipping, tax, total: subtotal + shipping + tax };
  },
  badge() {
    document.querySelectorAll(".cart-count").forEach(el => {
      const n = this.count(); el.textContent = n; el.hidden = n === 0;
    });
  },
};
const money = c => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(c / 100);
function toast(msg) {
  const t = Object.assign(document.createElement("div"), { className: "toast", textContent: msg });
  document.body.append(t); setTimeout(() => t.classList.add("show"), 10);
  setTimeout(() => { t.classList.remove("show"); setTimeout(() => t.remove(), 300); }, 1800);
}
window.addEventListener("storage", e => { if (e.key === Cart.key) Cart.badge(); });
document.addEventListener("DOMContentLoaded", () => Cart.badge());
```

## js/app.js patterns
```js
const esc = s => String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const card = p => `
  <article class="card">
    <a href="product.html?id=${p.id}" class="card-img">${p.badge ? `<span class="badge">${esc(p.badge)}</span>` : ""}
      <img src="${p.image}" alt="${esc(p.name)}" loading="lazy" width="400" height="300"></a>
    <div class="card-body">
      <h3><a href="product.html?id=${p.id}">${esc(p.name)}</a></h3>
      <p class="price">${money(p.price)}</p>
      <button class="btn" type="button" data-add="${p.id}">Add to cart</button>
    </div>
  </article>`;
document.addEventListener("click", e => {
  const add = e.target.closest("[data-add]"); if (add) Cart.add(add.dataset.add);
});
// products.html: search (?q=), category (?cat=), sort select
function renderShop() {
  const grid = document.querySelector("#grid"); if (!grid) return;
  const params = new URLSearchParams(location.search);
  const q = (document.querySelector("#q")?.value ?? params.get("q") ?? "").toLowerCase();
  const cat = document.querySelector("#cat")?.value || params.get("cat") || "all";
  const sort = document.querySelector("#sort")?.value || "featured";
  let list = PRODUCTS.filter(p => (cat === "all" || p.category === cat) && p.name.toLowerCase().includes(q));
  if (sort === "low") list.sort((a, b) => a.price - b.price);
  if (sort === "high") list.sort((a, b) => b.price - a.price);
  grid.innerHTML = list.length ? list.map(card).join("") : `<p class="empty">No products match.</p>`;
}
```
- Cart page: render lines with qty buttons (`data-qty="+1"` / `"-1"`, `data-remove`), recompute totals,
  show an empty state with a "Continue shopping" link when the cart is empty.
- Checkout: `form.reportValidity()`, then show "Thanks, order #A1B2C3 placed" (random id),
  `Cart.clear()`. State clearly it's a demo: real payments need a payment provider (Stripe Checkout,
  PayPal, Shopify Buy Button) - never collect card numbers in your own form.

## Product data example
```js
const PRODUCTS = [
  { id: 1, name: "Aurora Headphones", price: 12999, category: "audio", image: "images/headphones.svg",
    rating: 4.6, badge: "Best seller", description: "Wireless, 40h battery, active noise cancelling." },
  // 8-12 products across 3-4 categories make the grid look real
];
```

## Quality checklist before saying it's done
1. Every page has the same header (logo, nav, search, cart badge) and footer; current page highlighted.
2. Works at 360 px: hamburger menu, single-column grid, no sideways scroll; and at 1280 px.
3. Add to cart from grid and product page; badge updates on every page; qty +/-; remove; totals right.
4. Cart survives a reload (localStorage). Empty cart and "no results" states look intentional.
5. `node --check` passes for each JS file; open index.html and click through every page.
6. Images exist (or are inline SVG/gradients); no broken links between pages.
